import { createClient } from '@supabase/supabase-js';

// Server-side Supabase client with service role key
export function createServerClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

  return createClient(supabaseUrl, supabaseServiceKey);
}

// Admin operations
export async function getUsers() {
  const supabase = createServerClient();
  const { data, error } = await supabase.auth.admin.listUsers();
  return { data, error };
}

export async function deleteUser(userId: string) {
  const supabase = createServerClient();
  const { data, error } = await supabase.auth.admin.deleteUser(userId);
  return { data, error };
}
