/**
 * OnTarget PSP - Transaction API Utility
 * Handles all transaction-related API calls and actions
 */

const API_BASE_URL = 'https://api.ontarget-egy.com/v1';

// Types
export type TransactionStatus = 
  | 'pending' 
  | 'processing' 
  | 'paid' 
  | 'completed' 
  | 'refunded' 
  | 'cancelled' 
  | 'expired' 
  | 'failed' 
  | 'declined';

export type TransactionType = 'deposit' | 'withdrawal' | 'payment';

export type PaymentMethod = 
  | 'vodafone_cash' 
  | 'orange_money' 
  | 'instapay' 
  | 'fawry' 
  | 'card' 
  | 'bank_transfer';

export interface Transaction {
  id: string;
  transaction_id: string;
  amount: number;
  currency: string;
  status: TransactionStatus;
  type: TransactionType;
  payment_method: PaymentMethod;
  merchant_id?: string;
  merchant_name?: string;
  customer_name?: string;
  customer_email?: string;
  customer_phone?: string;
  proof_image_url?: string;
  fee?: number;
  net_amount?: number;
  order_id?: string;
  created_at: string;
  completed_at?: string;
  metadata?: Record<string, any>;
}

export interface CreateTransactionRequest {
  amount: number;
  currency: string;
  order_id: string;
  customer_email?: string;
  customer_name?: string;
  customer_phone?: string;
  callback_url?: string;
  success_url?: string;
  cancel_url?: string;
  metadata?: Record<string, any>;
}

export interface UpdateTransactionRequest {
  status?: TransactionStatus;
  proof_image_url?: string;
  customer_phone?: string;
  customer_name?: string;
  metadata?: Record<string, any>;
}

export interface TransactionActionRequest {
  action: 'approve' | 'reject' | 'refund' | 'cancel' | 'mark_paid' | 'verify_payment';
  reason?: string;
  refund_amount?: number;
  notes?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}

// Helper function to get API key from environment or storage
function getApiKey(): string {
  // In production, this should come from secure storage
  return localStorage.getItem('ontarget_api_key') || 'sk_test_demo_key';
}

// Helper function to make API requests
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const apiKey = getApiKey();
  
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        error: data.error || {
          code: 'api_error',
          message: `API request failed with status ${response.status}`,
        },
      };
    }

    return data;
  } catch (error) {
    return {
      success: false,
      error: {
        code: 'network_error',
        message: error instanceof Error ? error.message : 'Network request failed',
      },
    };
  }
}

/**
 * Transaction API Functions
 */

// Create a new transaction
export async function createTransaction(
  request: CreateTransactionRequest
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>('/transactions', {
    method: 'POST',
    body: JSON.stringify(request),
  });
}

// Get transaction by ID
export async function getTransaction(
  transactionId: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}`, {
    method: 'GET',
  });
}

// List all transactions with filters
export async function listTransactions(params?: {
  limit?: number;
  offset?: number;
  status?: TransactionStatus;
  from_date?: string;
  to_date?: string;
  merchant_id?: string;
  payment_method?: PaymentMethod;
}): Promise<ApiResponse<{ transactions: Transaction[]; pagination: any }>> {
  const queryParams = new URLSearchParams();
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        queryParams.append(key, String(value));
      }
    });
  }

  const queryString = queryParams.toString();
  const endpoint = queryString ? `/transactions?${queryString}` : '/transactions';

  return apiRequest<{ transactions: Transaction[]; pagination: any }>(endpoint, {
    method: 'GET',
  });
}

// Update transaction details
export async function updateTransaction(
  transactionId: string,
  updates: UpdateTransactionRequest
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
}

/**
 * Transaction Action Functions
 * These are the main action handlers for transaction state changes
 */

// Approve a pending transaction
export async function approveTransaction(
  transactionId: string,
  notes?: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}/actions`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'approve',
      notes,
    }),
  });
}

// Reject a transaction
export async function rejectTransaction(
  transactionId: string,
  reason: string,
  notes?: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}/actions`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'reject',
      reason,
      notes,
    }),
  });
}

// Mark transaction as paid (manual confirmation)
export async function markTransactionPaid(
  transactionId: string,
  proofImageUrl?: string,
  notes?: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}/actions`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'mark_paid',
      proof_image_url: proofImageUrl,
      notes,
    }),
  });
}

// Verify payment proof
export async function verifyPayment(
  transactionId: string,
  verified: boolean,
  notes?: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}/actions`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'verify_payment',
      verified,
      notes,
    }),
  });
}

// Refund a transaction
export async function refundTransaction(
  transactionId: string,
  refundAmount?: number,
  reason?: string,
  notes?: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}/actions`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'refund',
      refund_amount: refundAmount,
      reason,
      notes,
    }),
  });
}

// Cancel a transaction
export async function cancelTransaction(
  transactionId: string,
  reason?: string,
  notes?: string
): Promise<ApiResponse<Transaction>> {
  return apiRequest<Transaction>(`/transactions/${transactionId}/actions`, {
    method: 'POST',
    body: JSON.stringify({
      action: 'cancel',
      reason,
      notes,
    }),
  });
}

/**
 * Bulk Transaction Actions
 */

// Bulk approve transactions
export async function bulkApproveTransactions(
  transactionIds: string[],
  notes?: string
): Promise<ApiResponse<{ processed: number; failed: number; results: any[] }>> {
  return apiRequest<{ processed: number; failed: number; results: any[] }>(
    '/transactions/bulk/approve',
    {
      method: 'POST',
      body: JSON.stringify({
        transaction_ids: transactionIds,
        notes,
      }),
    }
  );
}

// Bulk reject transactions
export async function bulkRejectTransactions(
  transactionIds: string[],
  reason: string,
  notes?: string
): Promise<ApiResponse<{ processed: number; failed: number; results: any[] }>> {
  return apiRequest<{ processed: number; failed: number; results: any[] }>(
    '/transactions/bulk/reject',
    {
      method: 'POST',
      body: JSON.stringify({
        transaction_ids: transactionIds,
        reason,
        notes,
      }),
    }
  );
}

/**
 * Upload proof image
 */
export async function uploadProofImage(
  transactionId: string,
  imageFile: File
): Promise<ApiResponse<{ url: string }>> {
  const formData = new FormData();
  formData.append('proof_image', imageFile);
  formData.append('transaction_id', transactionId);

  const apiKey = getApiKey();

  try {
    const response = await fetch(`${API_BASE_URL}/transactions/${transactionId}/proof`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
      },
      body: formData,
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        error: data.error || {
          code: 'upload_error',
          message: 'Failed to upload proof image',
        },
      };
    }

    return data;
  } catch (error) {
    return {
      success: false,
      error: {
        code: 'network_error',
        message: error instanceof Error ? error.message : 'Upload failed',
      },
    };
  }
}

/**
 * Transaction Statistics
 */
export async function getTransactionStats(params?: {
  from_date?: string;
  to_date?: string;
  merchant_id?: string;
}): Promise<ApiResponse<{
  total_count: number;
  total_volume: number;
  by_status: Record<TransactionStatus, number>;
  by_payment_method: Record<PaymentMethod, number>;
  success_rate: number;
}>> {
  const queryParams = new URLSearchParams();
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        queryParams.append(key, String(value));
      }
    });
  }

  const queryString = queryParams.toString();
  const endpoint = queryString 
    ? `/transactions/stats?${queryString}` 
    : '/transactions/stats';

  return apiRequest(endpoint, { method: 'GET' });
}

/**
 * Export transactions
 */
export async function exportTransactions(params?: {
  format?: 'csv' | 'xlsx' | 'json';
  from_date?: string;
  to_date?: string;
  status?: TransactionStatus;
}): Promise<ApiResponse<{ download_url: string }>> {
  const queryParams = new URLSearchParams();
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        queryParams.append(key, String(value));
      }
    });
  }

  const queryString = queryParams.toString();
  const endpoint = queryString 
    ? `/transactions/export?${queryString}` 
    : '/transactions/export';

  return apiRequest<{ download_url: string }>(endpoint, {
    method: 'POST',
  });
}

/**
 * Webhook simulation (for testing)
 */
export async function simulateWebhook(
  transactionId: string,
  status: TransactionStatus
): Promise<ApiResponse<{ sent: boolean }>> {
  return apiRequest<{ sent: boolean }>(`/transactions/${transactionId}/webhook`, {
    method: 'POST',
    body: JSON.stringify({ status }),
  });
}

/**
 * Helper functions for UI
 */

// Get status color for UI display
export function getStatusColor(status: TransactionStatus): string {
  const colors: Record<TransactionStatus, string> = {
    pending: 'text-yellow-500 bg-yellow-500/10 border-yellow-500/30',
    processing: 'text-blue-500 bg-blue-500/10 border-blue-500/30',
    paid: 'text-green-500 bg-green-500/10 border-green-500/30',
    completed: 'text-green-600 bg-green-600/10 border-green-600/30',
    refunded: 'text-purple-500 bg-purple-500/10 border-purple-500/30',
    cancelled: 'text-gray-500 bg-gray-500/10 border-gray-500/30',
    expired: 'text-gray-600 bg-gray-600/10 border-gray-600/30',
    failed: 'text-red-500 bg-red-500/10 border-red-500/30',
    declined: 'text-red-600 bg-red-600/10 border-red-600/30',
  };
  return colors[status] || 'text-gray-500';
}

// Format amount for display
export function formatAmount(amount: number, currency: string = 'EGP'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
  }).format(amount);
}

// Format date for display
export function formatDate(dateString: string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateString));
}
