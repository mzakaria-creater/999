import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import { GlassCard } from './GlassCard';
import { useLanguage } from '../context/LanguageContext';
import { useState } from 'react';

interface FxRate {
  pair: string;
  rate: number;
  change: number;
  changePercent: number;
  flag: string;
  country: string;
  countryAr: string;
}

const fxRates: FxRate[] = [
  { 
    pair: 'USD/EGP', 
    rate: 49.85, 
    change: 0.12, 
    changePercent: 0.24, 
    flag: '🇪🇬', 
    country: 'Egypt',
    countryAr: 'مصر'
  },
  { 
    pair: 'USD/SAR', 
    rate: 3.7500, 
    change: 0.0, 
    changePercent: 0.0, 
    flag: '🇸🇦', 
    country: 'Saudi Arabia',
    countryAr: 'السعودية'
  },
  { 
    pair: 'USD/AED', 
    rate: 3.6725, 
    change: -0.0011, 
    changePercent: -0.03, 
    flag: '🇦🇪', 
    country: 'UAE',
    countryAr: 'الإمارات'
  },
  { 
    pair: 'USD/KWD', 
    rate: 0.3073, 
    change: 0.0003, 
    changePercent: 0.10, 
    flag: '🇰🇼', 
    country: 'Kuwait',
    countryAr: 'الكويت'
  },
  { 
    pair: 'USD/QAR', 
    rate: 3.6404, 
    change: 0.0, 
    changePercent: 0.0, 
    flag: '🇶🇦', 
    country: 'Qatar',
    countryAr: 'قطر'
  },
  { 
    pair: 'USD/BHD', 
    rate: 0.3771, 
    change: 0.0019, 
    changePercent: 0.05, 
    flag: '🇧🇭', 
    country: 'Bahrain',
    countryAr: 'البحرين'
  },
  { 
    pair: 'USD/OMR', 
    rate: 0.3850, 
    change: 0.0, 
    changePercent: 0.0, 
    flag: '🇴🇲', 
    country: 'Oman',
    countryAr: 'عمان'
  },
  { 
    pair: 'USD/JOD', 
    rate: 0.7090, 
    change: 0.0, 
    changePercent: 0.0, 
    flag: '🇯🇴', 
    country: 'Jordan',
    countryAr: 'الأردن'
  },
];

export function FxRatesWidget() {
  const { t, language } = useLanguage();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const formatRate = (rate: number) => {
    return rate.toFixed(4);
  };

  return (
    <GlassCard className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-white mb-1">
            {language === 'ar' ? 'أسعار الصرف المباشرة' : 'Live FX Rates'}
          </h3>
          <p className="text-sm text-gray-400">
            {language === 'ar' ? 'أسعار صرف العملات في الوقت الفعلي' : 'Real-time currency exchange rates'}
          </p>
        </div>
        <motion.button
          onClick={handleRefresh}
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          whileTap={{ scale: 0.95 }}
          animate={{ rotate: isRefreshing ? 360 : 0 }}
          transition={{ duration: 0.5 }}
        >
          <RefreshCw className="w-5 h-5 text-gray-400" />
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {fxRates.map((rate, index) => (
          <motion.div
            key={rate.pair}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="relative p-4 rounded-xl bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/10 hover:border-white/20 transition-all group"
          >
            {/* Country Flag & Name */}
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{rate.flag}</span>
              <div className="flex-1">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  {rate.pair}
                </div>
                <div className="text-xs text-gray-500">
                  {language === 'ar' ? rate.countryAr : rate.country}
                </div>
              </div>
            </div>

            {/* Exchange Rate */}
            <div className="mb-2">
              <div className="text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                {formatRate(rate.rate)}
              </div>
            </div>

            {/* Change Indicator */}
            <div className={`flex items-center gap-1 text-sm ${
              rate.changePercent > 0 
                ? 'text-green-400' 
                : rate.changePercent < 0 
                ? 'text-red-400' 
                : 'text-gray-400'
            }`}>
              {rate.changePercent !== 0 && (
                rate.changePercent > 0 ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5" />
                )
              )}
              <span className="font-semibold">
                {rate.changePercent > 0 && '+'}
                {rate.changePercent.toFixed(2)}%
              </span>
              <span className="text-xs text-gray-500 mx-1">•</span>
              <span className="text-xs">
                {rate.change > 0 && '+'}
                {rate.change.toFixed(4)}
              </span>
            </div>

            {/* Spread Info */}
            <div className="mt-3 pt-3 border-t border-white/5">
              <div className="text-[10px] text-gray-500 flex items-center justify-between">
                <span>{language === 'ar' ? 'الفارق' : 'Spread'}</span>
                <span className="text-cyan-400 font-semibold">0.07</span>
              </div>
            </div>

            {/* Hover Effect Glow */}
            <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-cyan-500/0 to-blue-500/0 group-hover:from-cyan-500/5 group-hover:to-blue-500/5 transition-all pointer-events-none" />
          </motion.div>
        ))}
      </div>

      {/* Last Updated */}
      <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span>{language === 'ar' ? 'تحديث مباشر' : 'Live updates'}</span>
        </div>
        <span>
          {language === 'ar' ? 'آخر تحديث: الآن' : 'Last updated: Now'}
        </span>
      </div>
    </GlassCard>
  );
}
