import { motion, AnimatePresence } from 'motion/react';
import { X, TrendingUp, AlertCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface MerchantDetail {
  id: string;
  name: string;
  code: string;
  country: string;
  status: 'active' | 'inactive' | 'gold';
  volumeToday: string;
  joined: string;
  group: string;
  tabs: Array<{
    id: string;
    label: string;
    icon: string;
  }>;
  volumeData: Array<{
    day: string;
    value: number;
  }>;
  paymentMethods: Array<{
    name: string;
    percentage: number;
    amount: string;
  }>;
  stats: {
    successRate: string;
    avgTransaction: string;
    complaints: string;
    chargebacks: string;
  };
}

interface DesktopMerchantSidebarProps {
  merchant: MerchantDetail | null;
  onClose: () => void;
}

export function DesktopMerchantSidebar({ merchant, onClose }: DesktopMerchantSidebarProps) {
  const { t, language } = useLanguage();
  const isRTL = language === 'ar';

  if (!merchant) return null;

  const maxVolume = Math.max(...merchant.volumeData.map(d => d.value));

  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: isRTL ? '-100%' : '100%', opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: isRTL ? '-100%' : '100%', opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className={`fixed top-0 ${isRTL ? 'left-0' : 'right-0'} h-full w-[480px] bg-gradient-to-br from-[#1a1d23]/98 via-[#16181d]/98 to-[#121417]/98 backdrop-blur-2xl border-${isRTL ? 'r' : 'l'} border-white/10 shadow-2xl z-50 overflow-hidden`}
        style={{
          boxShadow: isRTL 
            ? '4px 0 40px rgba(139, 92, 246, 0.15), 4px 0 80px rgba(59, 130, 246, 0.1)'
            : '-4px 0 40px rgba(139, 92, 246, 0.15), -4px 0 80px rgba(59, 130, 246, 0.1)'
        }}
      >
        {/* Top Border Gradient */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#8b5cf6]/50 to-transparent" />

        {/* Header */}
        <div className="relative px-6 py-5 border-b border-white/10 bg-gradient-to-b from-[#1a1d23] to-transparent">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-white font-bold text-lg shadow-lg">
                {merchant.code}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{merchant.name}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-sm text-gray-400">{merchant.code}</span>
                  <span className="text-gray-600">•</span>
                  <div className="flex items-center gap-1">
                    <span className="text-lg">{merchant.country === 'Egypt' ? '🇪🇬' : '🌍'}</span>
                    <span className="text-sm text-gray-400">{merchant.country}</span>
                  </div>
                </div>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="p-2 hover:bg-white/5 rounded-xl transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </motion.button>
          </div>

          {/* Status Badges */}
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
              merchant.status === 'active' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
              merchant.status === 'gold' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
              'bg-gray-500/20 text-gray-400 border border-gray-500/30'
            }`}>
              {merchant.status === 'active' ? 'Active' : merchant.status === 'gold' ? '⭐ Gold' : 'Inactive'}
            </span>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-4 px-6 py-4 bg-gradient-to-b from-white/5 to-transparent border-b border-white/5">
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">Volume Today</div>
            <div className="text-2xl font-bold text-white">{merchant.volumeToday}</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">Joined</div>
            <div className="text-lg font-semibold text-gray-300">{merchant.joined}</div>
          </div>
          <div className="col-span-2">
            <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">Group</div>
            <div className="text-sm font-medium text-gray-300">{merchant.group}</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 px-6 py-3 border-b border-white/5 overflow-x-auto">
          {merchant.tabs.map((tab, index) => (
            <motion.button
              key={tab.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                index === 0 
                  ? 'bg-white/10 text-white shadow-lg' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="text-xs">{tab.icon}</span>
              <span>{tab.label}</span>
            </motion.button>
          ))}
        </div>

        {/* Content - Scrollable */}
        <div className="overflow-y-auto h-[calc(100vh-340px)] px-6 py-4">
          {/* Volume Chart */}
          <div className="mb-6">
            <div className="text-xs text-gray-400 uppercase tracking-wider mb-3">Volume — Last 7 Days</div>
            <div className="relative h-32 bg-gradient-to-b from-[#8b5cf6]/10 to-transparent rounded-2xl border border-white/5 p-4">
              {/* Chart Grid */}
              <div className="absolute inset-0 flex items-end justify-around px-4 pb-4">
                {merchant.volumeData.map((data, index) => {
                  const height = (data.value / maxVolume) * 100;
                  return (
                    <div key={data.day} className="flex flex-col items-center gap-2 flex-1">
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${height}%` }}
                        transition={{ delay: index * 0.1, duration: 0.6, ease: 'easeOut' }}
                        className="w-full bg-gradient-to-t from-[#3b82f6] to-[#8b5cf6] rounded-t-lg min-h-[4px]"
                      />
                      <span className="text-[10px] text-gray-500 font-medium">{data.day}</span>
                    </div>
                  );
                })}
              </div>
              {/* Chart Line Overlay */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop key="stop-1" offset="0%" stopColor="#8b5cf6" stopOpacity="0.8" />
                    <stop key="stop-2" offset="100%" stopColor="#3b82f6" stopOpacity="0.8" />
                  </linearGradient>
                </defs>
                <motion.path
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 1.5, ease: 'easeInOut' }}
                  d={`M ${merchant.volumeData.map((d, i) => {
                    const x = (i / (merchant.volumeData.length - 1)) * 100;
                    const y = 100 - (d.value / maxVolume * 70);
                    return `${x},${y}`;
                  }).join(' L ')}`}
                  fill="none"
                  stroke="url(#lineGradient)"
                  strokeWidth="2"
                  vectorEffect="non-scaling-stroke"
                />
              </svg>
            </div>
          </div>

          {/* Top Payment Methods */}
          <div className="mb-6">
            <div className="text-xs text-gray-400 uppercase tracking-wider mb-3">Top Payment Methods</div>
            <div className="space-y-3">
              {merchant.paymentMethods.map((method, index) => (
                <motion.div
                  key={method.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="space-y-1.5"
                >
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300 font-medium">{method.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-gray-400 font-semibold">{method.percentage}%</span>
                      <span className="text-white font-bold">{method.amount}</span>
                    </div>
                  </div>
                  <div className="relative h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${method.percentage}%` }}
                      transition={{ delay: index * 0.1 + 0.3, duration: 0.8, ease: 'easeOut' }}
                      className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] rounded-full"
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="p-4 rounded-2xl bg-gradient-to-br from-green-500/10 to-green-600/5 border border-green-500/20"
            >
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-xs text-gray-400">Success Rate</span>
              </div>
              <div className="text-2xl font-bold text-green-400">{merchant.stats.successRate}</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.02 }}
              className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/20"
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs text-gray-400">Avg Transaction</span>
              </div>
              <div className="text-2xl font-bold text-blue-400">{merchant.stats.avgTransaction}</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.02 }}
              className="p-4 rounded-2xl bg-gradient-to-br from-orange-500/10 to-orange-600/5 border border-orange-500/20"
            >
              <div className="flex items-center gap-2 mb-1">
                <AlertCircle className="w-4 h-4 text-orange-400" />
                <span className="text-xs text-gray-400">Complaints</span>
              </div>
              <div className="text-xl font-bold text-orange-400">{merchant.stats.complaints}</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.02 }}
              className="p-4 rounded-2xl bg-gradient-to-br from-purple-500/10 to-purple-600/5 border border-purple-500/20"
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs text-gray-400">Chargebacks</span>
              </div>
              <div className="text-xl font-bold text-purple-400">{merchant.stats.chargebacks}</div>
            </motion.div>
          </div>
        </div>

        {/* Bottom Glow */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#8b5cf6]/10 via-transparent to-transparent pointer-events-none" />
      </motion.div>
    </AnimatePresence>
  );
}