import { useEffect, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router';
import { Layout } from './Layout';
import { MobileAppLayout } from './MobileAppLayout';

export function ResponsiveLayout() {
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const checkIsMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
    };

    // Initial check
    checkIsMobile();

    // Listen for resize
    window.addEventListener('resize', checkIsMobile);
    return () => window.removeEventListener('resize', checkIsMobile);
  }, []);

  useEffect(() => {
    // If on mobile and on a desktop-only route, redirect to mobile equivalent
    if (isMobile && !location.pathname.startsWith('/mobile')) {
      // Map desktop routes to mobile routes
      const pathMap: Record<string, string> = {
        '/': '/mobile/dashboard',
        '/transactions': '/mobile/transactions',
        '/wallets': '/mobile/wallets',
        '/merchants': '/mobile/merchants',
        '/dashboard': '/mobile/dashboard',
      };

      const mobilePath = pathMap[location.pathname];
      if (mobilePath && location.pathname !== mobilePath) {
        navigate(mobilePath, { replace: true });
      }
    }
  }, [isMobile, location.pathname, navigate]);

  // Render mobile layout for mobile devices
  if (isMobile) {
    return <MobileAppLayout />;
  }

  // Render desktop layout for desktop devices
  return <Layout />;
}
