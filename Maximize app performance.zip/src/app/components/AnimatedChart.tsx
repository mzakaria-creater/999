import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface AnimatedChartWrapperProps {
  children: ReactNode;
  delay?: number;
}

export function AnimatedChartWrapper({ children, delay = 0 }: AnimatedChartWrapperProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.5,
        delay,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      {children}
    </motion.div>
  );
}

// Custom Label Animation Component for Recharts
export function AnimatedLabel({ x, y, value, delay = 0 }: any) {
  return (
    <motion.text
      x={x}
      y={y}
      fill="#fff"
      fontSize={12}
      fontWeight="bold"
      textAnchor="middle"
      initial={{ opacity: 0, y: y + 10 }}
      animate={{ opacity: 1, y }}
      transition={{
        duration: 0.5,
        delay: delay * 0.1,
        ease: 'easeOut',
      }}
    >
      {value}
    </motion.text>
  );
}

// Animated Counter with Spring Effect
interface AnimatedCounterProps {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
}

export function AnimatedCounter({
  value,
  prefix = '',
  suffix = '',
  decimals = 0,
  duration = 2000,
}: AnimatedCounterProps) {
  return (
    <motion.span
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{
        duration: 0.5,
        type: 'spring',
        stiffness: 100,
      }}
    >
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {prefix}
      </motion.span>
      <motion.span
        initial={{ filter: 'blur(4px)' }}
        animate={{ filter: 'blur(0px)' }}
        transition={{ duration: 0.5 }}
      >
        {value.toLocaleString(undefined, {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals,
        })}
      </motion.span>
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {suffix}
      </motion.span>
    </motion.span>
  );
}

// Stagger Children Animation
export function StaggerContainer({ children, staggerDelay = 0.1 }: { children: ReactNode; staggerDelay?: number }) {
  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        visible: {
          transition: {
            staggerChildren: staggerDelay,
          },
        },
      }}
    >
      {children}
    </motion.div>
  );
}

export function StaggerItem({ children }: { children: ReactNode }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 },
      }}
      transition={{
        duration: 0.5,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      {children}
    </motion.div>
  );
}
