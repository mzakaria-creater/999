import { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { motion } from 'motion/react';
import {
  Webhook,
  CreditCard,
  Wallet,
  Building2,
  Shield,
  Copy,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  Users,
  Activity
} from 'lucide-react';

export interface DecisionNodeData {
  label: string;
  labelAr?: string;
  type: 'input' | 'check' | 'routing' | 'decision' | 'output';
  status?: 'active' | 'success' | 'warning' | 'error' | 'pending' | 'neutral';
  icon?: string;
  description?: string;
  metrics?: {
    count?: number;
    value?: string;
  };
  isAnimating?: boolean;
}

const iconMap: Record<string, any> = {
  webhook: Webhook,
  card: CreditCard,
  wallet: Wallet,
  building: Building2,
  shield: Shield,
  copy: Copy,
  alert: AlertTriangle,
  check: CheckCircle,
  x: XCircle,
  clock: Clock,
  trending: TrendingUp,
  users: Users,
  activity: Activity,
};

function DecisionNode({ data, selected }: NodeProps<DecisionNodeData>) {
  const Icon = data.icon ? iconMap[data.icon] : Activity;

  const getStatusStyles = () => {
    switch (data.status) {
      case 'success':
        return {
          border: 'border-green-400/50',
          bg: 'bg-green-400/10',
          glow: 'shadow-green-400/20',
          icon: 'text-green-400',
          dot: 'bg-green-400'
        };
      case 'warning':
        return {
          border: 'border-yellow-400/50',
          bg: 'bg-yellow-400/10',
          glow: 'shadow-yellow-400/20',
          icon: 'text-yellow-400',
          dot: 'bg-yellow-400'
        };
      case 'error':
        return {
          border: 'border-red-400/50',
          bg: 'bg-red-400/10',
          glow: 'shadow-red-400/20',
          icon: 'text-red-400',
          dot: 'bg-red-400'
        };
      case 'active':
        return {
          border: 'border-[#8b5cf6]/50',
          bg: 'bg-[#8b5cf6]/10',
          glow: 'shadow-[#8b5cf6]/30',
          icon: 'text-[#8b5cf6]',
          dot: 'bg-[#8b5cf6]'
        };
      case 'pending':
        return {
          border: 'border-blue-400/50',
          bg: 'bg-blue-400/10',
          glow: 'shadow-blue-400/20',
          icon: 'text-blue-400',
          dot: 'bg-blue-400'
        };
      default:
        return {
          border: 'border-white/20',
          bg: 'bg-white/5',
          glow: 'shadow-white/10',
          icon: 'text-gray-400',
          dot: 'bg-gray-400'
        };
    }
  };

  const styles = getStatusStyles();

  return (
    <>
      <Handle 
        type="target" 
        position={Position.Top} 
        className="!bg-[#8b5cf6] !w-3 !h-3 !border-2 !border-white/20"
      />
      
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ 
          scale: selected ? 1.05 : 1, 
          opacity: 1 
        }}
        whileHover={{ scale: 1.02 }}
        className={`
          min-w-[200px] px-4 py-3 rounded-2xl border-2 backdrop-blur-xl
          transition-all duration-300
          ${styles.border} ${styles.bg}
          ${selected ? `${styles.glow} shadow-2xl` : 'shadow-lg'}
          ${data.isAnimating ? 'ring-4 ring-[#8b5cf6]/50 animate-pulse' : ''}
        `}
      >
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div className={`
            w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0
            bg-gradient-to-br from-[#1a1d23] to-[#252932] border border-white/10
          `}>
            <Icon className={`w-5 h-5 ${styles.icon}`} />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-white font-semibold text-sm truncate">
                {data.label}
              </h3>
              {data.status && (
                <div className={`w-2 h-2 rounded-full ${styles.dot} animate-pulse`} />
              )}
            </div>
            
            {data.description && (
              <p className="text-gray-400 text-xs leading-tight mb-2">
                {data.description}
              </p>
            )}

            {data.metrics && (
              <div className="flex items-center gap-3 mt-2">
                {data.metrics.count !== undefined && (
                  <div className="text-xs">
                    <span className="text-gray-500">Count: </span>
                    <span className="text-white font-medium">{data.metrics.count}</span>
                  </div>
                )}
                {data.metrics.value && (
                  <div className="text-xs">
                    <span className="text-gray-500">Value: </span>
                    <span className="text-white font-medium">{data.metrics.value}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </motion.div>

      <Handle 
        type="source" 
        position={Position.Bottom} 
        className="!bg-[#8b5cf6] !w-3 !h-3 !border-2 !border-white/20"
      />
    </>
  );
}

export default memo(DecisionNode);
