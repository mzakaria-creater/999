import { useCallback, useState, useMemo } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  Node,
  Edge,
  Connection,
  addEdge,
  useNodesState,
  useEdgesState,
  MarkerType,
  ConnectionLineType,
} from 'reactflow';
import 'reactflow/dist/style.css';
import DecisionNode from './DecisionNode';
import { motion } from 'motion/react';
import { ZoomIn, ZoomOut, Maximize2, Play, Pause } from 'lucide-react';

interface FlowDiagramProps {
  initialNodes?: Node[];
  initialEdges?: Edge[];
  onNodeClick?: (node: Node) => void;
  isAnimating?: boolean;
  onToggleAnimation?: () => void;
}

const nodeTypes = {
  decision: DecisionNode,
};

const defaultEdgeOptions = {
  type: 'smoothstep',
  markerEnd: {
    type: MarkerType.ArrowClosed,
    width: 20,
    height: 20,
    color: '#8b5cf6',
  },
  style: {
    strokeWidth: 2,
    stroke: '#8b5cf6',
  },
};

export function FlowDiagram({
  initialNodes = [],
  initialEdges = [],
  onNodeClick,
  isAnimating = false,
  onToggleAnimation,
}: FlowDiagramProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onInit = useCallback((instance: any) => {
    setReactFlowInstance(instance);
    setTimeout(() => {
      instance.fitView({ padding: 0.2 });
    }, 50);
  }, []);

  const handleNodeClick = useCallback(
    (_: any, node: Node) => {
      onNodeClick?.(node);
    },
    [onNodeClick]
  );

  const handleZoomIn = useCallback(() => {
    reactFlowInstance?.zoomIn();
  }, [reactFlowInstance]);

  const handleZoomOut = useCallback(() => {
    reactFlowInstance?.zoomOut();
  }, [reactFlowInstance]);

  const handleFitView = useCallback(() => {
    reactFlowInstance?.fitView({ padding: 0.2 });
  }, [reactFlowInstance]);

  return (
    <div className="relative w-full h-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={handleNodeClick}
        onInit={onInit}
        nodeTypes={nodeTypes}
        defaultEdgeOptions={defaultEdgeOptions}
        connectionLineType={ConnectionLineType.SmoothStep}
        fitView
        className="bg-gradient-to-br from-[#0a0b0d] via-[#121417] to-[#0a0b0d]"
        minZoom={0.2}
        maxZoom={2}
      >
        <Background 
          gap={20} 
          size={1}
          color="#ffffff10"
        />
        
        <Controls 
          className="!bg-[#1a1d23]/90 !border-white/10 !shadow-2xl"
          showInteractive={false}
        />
        
        <MiniMap
          className="!bg-[#1a1d23]/90 !border !border-white/10 !shadow-2xl"
          nodeColor={(node) => {
            if (node.data?.status === 'success') return '#4ade80';
            if (node.data?.status === 'error') return '#f87171';
            if (node.data?.status === 'warning') return '#fbbf24';
            if (node.data?.status === 'active') return '#8b5cf6';
            return '#6b7280';
          }}
          maskColor="rgba(10, 11, 13, 0.8)"
        />
      </ReactFlow>

      {/* Custom Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        {onToggleAnimation && (
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onToggleAnimation}
            className={`
              p-3 rounded-xl backdrop-blur-xl border shadow-2xl
              transition-all duration-300
              ${isAnimating 
                ? 'bg-[#8b5cf6]/20 border-[#8b5cf6]/50 text-[#8b5cf6]' 
                : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'
              }
            `}
          >
            {isAnimating ? (
              <Pause className="w-5 h-5" />
            ) : (
              <Play className="w-5 h-5" />
            )}
          </motion.button>
        )}
        
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleZoomIn}
          className="p-3 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 text-gray-400 hover:text-white transition-all shadow-2xl"
        >
          <ZoomIn className="w-5 h-5" />
        </motion.button>
        
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleZoomOut}
          className="p-3 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 text-gray-400 hover:text-white transition-all shadow-2xl"
        >
          <ZoomOut className="w-5 h-5" />
        </motion.button>
        
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleFitView}
          className="p-3 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 text-gray-400 hover:text-white transition-all shadow-2xl"
        >
          <Maximize2 className="w-5 h-5" />
        </motion.button>
      </div>
    </div>
  );
}
