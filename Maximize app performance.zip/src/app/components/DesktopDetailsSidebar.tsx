import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { ReactNode } from 'react';

interface DesktopDetailsSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  icon?: string;
  subtitle?: string;
  children: ReactNode;
  width?: string;
}

export function DesktopDetailsSidebar({
  isOpen,
  onClose,
  title,
  icon,
  subtitle,
  children,
  width = '480px'
}: DesktopDetailsSidebarProps) {
  const { language } = useLanguage();
  const isRTL = language === 'ar';

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: isRTL ? '-100%' : '100%', opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: isRTL ? '-100%' : '100%', opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className={`fixed top-0 ${isRTL ? 'left-0' : 'right-0'} h-full bg-gradient-to-br from-[#1a1d23]/98 via-[#16181d]/98 to-[#121417]/98 backdrop-blur-2xl border-${isRTL ? 'r' : 'l'} border-white/10 shadow-2xl z-50 overflow-hidden`}
        style={{
          width,
          boxShadow: isRTL 
            ? '4px 0 40px rgba(139, 92, 246, 0.15), 4px 0 80px rgba(59, 130, 246, 0.1)'
            : '-4px 0 40px rgba(139, 92, 246, 0.15), -4px 0 80px rgba(59, 130, 246, 0.1)'
        }}
      >
        {/* Top Border Gradient */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#8b5cf6]/50 to-transparent" />

        {/* Header */}
        <div className="relative px-6 py-5 border-b border-white/10 bg-gradient-to-b from-[#1a1d23] to-transparent">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3 flex-1">
              {icon && (
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-2xl shadow-lg">
                  {icon}
                </div>
              )}
              <div className="flex-1">
                <h2 className="text-xl font-bold text-white">{title}</h2>
                {subtitle && (
                  <p className="text-sm text-gray-400 mt-1">{subtitle}</p>
                )}
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="p-2 hover:bg-white/5 rounded-xl transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </motion.button>
          </div>
        </div>

        {/* Content - Scrollable */}
        <div className="overflow-y-auto h-[calc(100vh-100px)] px-6 py-4">
          {children}
        </div>

        {/* Bottom Glow */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#8b5cf6]/10 via-transparent to-transparent pointer-events-none" />
      </motion.div>
    </AnimatePresence>
  );
}
