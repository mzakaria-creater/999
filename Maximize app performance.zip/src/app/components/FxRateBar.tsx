import { motion } from 'motion/react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useState, useEffect } from 'react';

interface FxRate {
  pair: string;
  rate: number;
  change: number;
  flag: string;
  country: string;
}

const fxRates: FxRate[] = [
  { pair: 'USD/KWD', rate: 0.3073, change: 0.001, flag: '🇰🇼', country: 'Kuwait' },
  { pair: 'USD/QAR', rate: 3.6404, change: 0.0, flag: '🇶🇦', country: 'Qatar' },
  { pair: 'USD/EGP', rate: 49.85, change: 0.24, flag: '🇪🇬', country: 'Egypt' },
  { pair: 'USD/SAR', rate: 3.7500, change: 0.0, flag: '🇸🇦', country: 'Saudi Arabia' },
  { pair: 'USD/AED', rate: 3.6725, change: -0.03, flag: '🇦🇪', country: 'UAE' },
  { pair: 'USD/BHD', rate: 0.3771, change: 0.05, flag: '🇧🇭', country: 'Bahrain' },
  { pair: 'USD/OMR', rate: 0.3850, change: 0.0, flag: '🇴🇲', country: 'Oman' },
  { pair: 'USD/JOD', rate: 0.7090, change: 0.0, flag: '🇯🇴', country: 'Jordan' },
];

export function FxRateBar() {
  const { language, direction } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % fxRates.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 border-b border-white/10">
      <div className="overflow-hidden">
        <div className="flex items-center gap-1 py-1.5 px-4">
          <div className="flex items-center gap-1.5 bg-blue-950/40 px-2 py-1 rounded-full border border-blue-400/30">
            <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
            <span className="text-[10px] font-semibold text-white">FX LIVE</span>
          </div>

          <div className="flex-1 overflow-hidden">
            <motion.div
              className="flex gap-6"
              animate={{ x: direction === 'rtl' ? '100%' : '-100%' }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            >
              {[...fxRates, ...fxRates].map((rate, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  <span className="text-sm">{rate.flag}</span>
                  <span className="text-xs font-semibold text-white/90">
                    {rate.pair}
                  </span>
                  <span className="text-xs font-bold text-white">
                    {rate.rate.toFixed(4)}
                  </span>
                  <div className={`flex items-center gap-0.5 text-[10px] ${
                    rate.change > 0 ? 'text-green-400' :
                    rate.change < 0 ? 'text-red-400' :
                    'text-gray-400'
                  }`}>
                    {rate.change > 0 ? (
                      <TrendingUp className="w-2.5 h-2.5" />
                    ) : rate.change < 0 ? (
                      <TrendingDown className="w-2.5 h-2.5" />
                    ) : null}
                    <span>
                      {rate.change > 0 ? '+' : ''}{rate.change.toFixed(2)}%
                    </span>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
