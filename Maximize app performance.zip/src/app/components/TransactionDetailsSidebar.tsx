import { motion } from 'motion/react';
import { DesktopDetailsSidebar } from './DesktopDetailsSidebar';
import { Check, Clock, XCircle, CreditCard, Building, Wallet, Copy, ExternalLink, Download } from 'lucide-react';
import { useState } from 'react';

interface Transaction {
  id: string;
  merchant: string;
  amount: number;
  status: 'success' | 'pending' | 'failed';
  paymentMethod: string;
  wallet: string;
  date: string;
  time: string;
  customerEmail: string;
  fee: number;
  netAmount: number;
}

interface TransactionDetailsSidebarProps {
  transaction: Transaction | null;
  onClose: () => void;
}

const statusConfig = {
  success: {
    bg: 'bg-[#6ee7b7]/10',
    text: 'text-[#6ee7b7]',
    border: 'border-[#6ee7b7]/30',
    icon: Check,
    label: 'Success'
  },
  pending: {
    bg: 'bg-[#fbbf24]/10',
    text: 'text-[#fbbf24]',
    border: 'border-[#fbbf24]/30',
    icon: Clock,
    label: 'Pending'
  },
  failed: {
    bg: 'bg-[#f87171]/10',
    text: 'text-[#f87171]',
    border: 'border-[#f87171]/30',
    icon: XCircle,
    label: 'Failed'
  }
};

const paymentMethodIcons = {
  'Credit Card': CreditCard,
  'Bank Transfer': Building,
  'E-Wallet': Wallet
};

export function TransactionDetailsSidebar({ transaction, onClose }: TransactionDetailsSidebarProps) {
  const [copied, setCopied] = useState(false);

  if (!transaction) return null;

  const config = statusConfig[transaction.status];
  const StatusIcon = config.icon;
  const PaymentIcon = paymentMethodIcons[transaction.paymentMethod as keyof typeof paymentMethodIcons] || CreditCard;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <DesktopDetailsSidebar
      isOpen={!!transaction}
      onClose={onClose}
      title={`Transaction ${transaction.id}`}
      icon="💳"
      subtitle={`${transaction.date} at ${transaction.time}`}
      width="420px"
    >
      {/* Status Badge */}
      <div className="mb-6">
        <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${config.bg} ${config.text} border ${config.border}`}>
          <StatusIcon className="w-4 h-4" />
          <span className="font-semibold">{config.label}</span>
        </div>
      </div>

      {/* Amount Section */}
      <div className="mb-6 p-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 via-[#3b82f6]/20 to-[#06b6d4]/20 border border-white/10">
        <div className="text-sm text-gray-400 mb-2">Total Amount</div>
        <div className="text-4xl font-bold text-white mb-4">
          ${transaction.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </div>
        
        <div className="space-y-2 pt-4 border-t border-white/10">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Processing Fee</span>
            <span className="text-white font-medium">-${transaction.fee.toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Net Amount</span>
            <span className="text-green-400 font-bold">${transaction.netAmount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Transaction Details */}
      <div className="space-y-4 mb-6">
        <div className="text-sm text-gray-400 uppercase tracking-wider">Transaction Details</div>
        
        {/* Transaction ID */}
        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-gray-400 mb-1">Transaction ID</div>
              <div className="text-sm font-mono text-white">{transaction.id}</div>
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => copyToClipboard(transaction.id)}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              {copied ? (
                <Check className="w-4 h-4 text-green-400" />
              ) : (
                <Copy className="w-4 h-4 text-gray-400" />
              )}
            </motion.button>
          </div>
        </div>

        {/* Merchant */}
        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <div className="text-xs text-gray-400 mb-1">Merchant</div>
          <div className="text-sm font-medium text-white">{transaction.merchant}</div>
        </div>

        {/* Customer Email */}
        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <div className="text-xs text-gray-400 mb-1">Customer Email</div>
          <div className="text-sm font-medium text-white">{transaction.customerEmail}</div>
        </div>

        {/* Payment Method */}
        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <div className="text-xs text-gray-400 mb-1">Payment Method</div>
          <div className="flex items-center gap-2">
            <PaymentIcon className="w-4 h-4 text-[#8b5cf6]" />
            <div className="text-sm font-medium text-white">{transaction.paymentMethod}</div>
          </div>
        </div>

        {/* Wallet */}
        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
          <div className="text-xs text-gray-400 mb-1">Wallet</div>
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-[#3b82f6]" />
            <div className="text-sm font-medium text-white">{transaction.wallet}</div>
          </div>
        </div>

        {/* Date & Time */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="text-xs text-gray-400 mb-1">Date</div>
            <div className="text-sm font-medium text-white">{transaction.date}</div>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="text-xs text-gray-400 mb-1">Time</div>
            <div className="text-sm font-medium text-white">{transaction.time}</div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="space-y-3">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2"
        >
          <Download className="w-4 h-4" />
          Download Receipt
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium flex items-center justify-center gap-2 hover:bg-white/10 transition-colors"
        >
          <ExternalLink className="w-4 h-4" />
          View Full Details
        </motion.button>
      </div>

      {/* Timeline (if needed for future) */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <div className="text-xs text-gray-400 uppercase tracking-wider mb-3">Transaction Timeline</div>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-green-400 mt-2"></div>
            <div>
              <div className="text-sm text-white">Transaction Created</div>
              <div className="text-xs text-gray-400">{transaction.date} {transaction.time}</div>
            </div>
          </div>
          {transaction.status === 'success' && (
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-green-400 mt-2"></div>
              <div>
                <div className="text-sm text-white">Payment Confirmed</div>
                <div className="text-xs text-gray-400">{transaction.date} {transaction.time}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </DesktopDetailsSidebar>
  );
}
