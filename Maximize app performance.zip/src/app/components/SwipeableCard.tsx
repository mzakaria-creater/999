import { motion, useMotionValue, useTransform, PanInfo } from 'motion/react';
import { ReactNode, useState } from 'react';
import { Trash2, Archive, Check } from 'lucide-react';

interface SwipeableCardProps {
  children: ReactNode;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onDelete?: () => void;
  leftAction?: 'delete' | 'archive' | 'approve';
  rightAction?: 'delete' | 'archive' | 'approve';
  threshold?: number;
  disabled?: boolean;
}

const actionIcons = {
  delete: Trash2,
  archive: Archive,
  approve: Check,
};

const actionColors = {
  delete: 'bg-red-500',
  archive: 'bg-yellow-500',
  approve: 'bg-green-500',
};

export function SwipeableCard({
  children,
  onSwipeLeft,
  onSwipeRight,
  onDelete,
  leftAction = 'delete',
  rightAction = 'approve',
  threshold = 100,
  disabled = false,
}: SwipeableCardProps) {
  const [isDeleted, setIsDeleted] = useState(false);
  const x = useMotionValue(0);
  const opacity = useTransform(x, [-threshold * 2, -threshold, 0, threshold, threshold * 2], [0, 1, 1, 1, 0]);
  const scale = useTransform(x, [-threshold, 0, threshold], [0.95, 1, 0.95]);

  // Action indicators
  const leftActionOpacity = useTransform(x, [-threshold, 0], [1, 0]);
  const rightActionOpacity = useTransform(x, [0, threshold], [0, 1]);

  const LeftIcon = actionIcons[leftAction];
  const RightIcon = actionIcons[rightAction];

  const handleDragEnd = (event: any, info: PanInfo) => {
    if (disabled) return;

    const swipeDistance = info.offset.x;

    // Swipe left (negative)
    if (swipeDistance < -threshold) {
      x.set(-500);
      setTimeout(() => {
        setIsDeleted(true);
        onSwipeLeft?.();
        onDelete?.();
      }, 200);
    }
    // Swipe right (positive)
    else if (swipeDistance > threshold) {
      x.set(500);
      setTimeout(() => {
        setIsDeleted(true);
        onSwipeRight?.();
      }, 200);
    }
    // Return to center
    else {
      x.set(0);
    }
  };

  if (isDeleted) return null;

  return (
    <div className="relative">
      {/* Background Actions */}
      <div className="absolute inset-0 flex items-center justify-between px-6 rounded-xl overflow-hidden">
        {/* Left Action */}
        <motion.div
          className={`flex items-center gap-2 ${actionColors[leftAction]} px-4 py-2 rounded-lg`}
          style={{ opacity: leftActionOpacity }}
        >
          <LeftIcon className="w-5 h-5 text-white" />
          <span className="text-white font-medium capitalize">{leftAction}</span>
        </motion.div>

        {/* Right Action */}
        <motion.div
          className={`flex items-center gap-2 ${actionColors[rightAction]} px-4 py-2 rounded-lg`}
          style={{ opacity: rightActionOpacity }}
        >
          <span className="text-white font-medium capitalize">{rightAction}</span>
          <RightIcon className="w-5 h-5 text-white" />
        </motion.div>
      </div>

      {/* Swipeable Card */}
      <motion.div
        drag={disabled ? false : 'x'}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.7}
        onDragEnd={handleDragEnd}
        style={{ x, opacity, scale }}
        className="relative z-10 cursor-grab active:cursor-grabbing"
      >
        {children}
      </motion.div>
    </div>
  );
}

// Swipe Navigation for Mobile Pages
interface SwipeNavigationProps {
  children: ReactNode;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  threshold?: number;
}

export function SwipeNavigation({
  children,
  onSwipeLeft,
  onSwipeRight,
  threshold = 50,
}: SwipeNavigationProps) {
  const x = useMotionValue(0);

  const handleDragEnd = (event: any, info: PanInfo) => {
    const swipeDistance = info.offset.x;

    if (swipeDistance < -threshold && onSwipeLeft) {
      onSwipeLeft();
    } else if (swipeDistance > threshold && onSwipeRight) {
      onSwipeRight();
    }

    x.set(0);
  };

  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.2}
      onDragEnd={handleDragEnd}
      style={{ x }}
      className="touch-pan-y"
    >
      {children}
    </motion.div>
  );
}
