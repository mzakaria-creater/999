import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Download, 
  RefreshCw, 
  Copy, 
  Check, 
  AlertCircle,
  Calendar,
  User,
  CreditCard,
  Wallet,
  DollarSign,
  Clock,
  Mail,
  Building,
  Hash,
  TrendingUp,
  FileText,
  CheckCircle2,
  XCircle,
  Smartphone
} from 'lucide-react';
import { useState } from 'react';
import { GlassCard } from './GlassCard';
import { useLanguage } from '../context/LanguageContext';

interface Transaction {
  id: string;
  merchant: string;
  amount: number;
  status: 'success' | 'pending' | 'failed';
  paymentMethod: string;
  wallet: string;
  date: string;
  time: string;
  customerEmail: string;
  fee: number;
  netAmount: number;
  customerName?: string;
  customerPhone?: string;
  ipAddress?: string;
  deviceInfo?: string;
}

interface TransactionDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
}

export function TransactionDetailsModal({ isOpen, onClose, transaction }: TransactionDetailsModalProps) {
  const { t, language } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [refunding, setRefunding] = useState(false);
  const [downloading, setDownloading] = useState(false);

  if (!transaction) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRefund = () => {
    setRefunding(true);
    // Simulate refund API call
    setTimeout(() => {
      setRefunding(false);
      alert(t('transactions.refundSuccess'));
    }, 1500);
  };

  const handleDownloadReceipt = () => {
    setDownloading(true);
    // Simulate receipt generation
    setTimeout(() => {
      setDownloading(false);
      alert(t('transactions.receiptDownloaded'));
    }, 1000);
  };

  const getStatusConfig = () => {
    switch (transaction.status) {
      case 'success':
        return {
          icon: CheckCircle2,
          color: '#6ee7b7',
          bg: 'bg-[#6ee7b7]/10',
          border: 'border-[#6ee7b7]/30',
          text: t('transactions.success')
        };
      case 'failed':
        return {
          icon: XCircle,
          color: '#ef4444',
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          text: t('transactions.failed')
        };
      default:
        return {
          icon: Clock,
          color: '#fbbf24',
          bg: 'bg-[#fbbf24]/10',
          border: 'border-[#fbbf24]/30',
          text: t('transactions.pending')
        };
    }
  };

  const statusConfig = getStatusConfig();
  const StatusIcon = statusConfig.icon;

  const getPaymentMethodIcon = () => {
    switch (transaction.paymentMethod.toLowerCase()) {
      case 'credit card':
        return CreditCard;
      case 'bank transfer':
        return Building;
      case 'e-wallet':
        return Wallet;
      default:
        return DollarSign;
    }
  };

  const PaymentIcon = getPaymentMethodIcon();

  const timeline = [
    { time: transaction.time, event: t('transactions.timelineInitiated'), status: 'completed' },
    { time: transaction.time, event: t('transactions.timelinePaymentProcessed'), status: 'completed' },
    { time: transaction.time, event: t('transactions.timelineSettled'), status: transaction.status === 'success' ? 'completed' : transaction.status },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard className="w-full max-w-4xl max-h-[90vh] overflow-y-auto my-8">
              {/* Header */}
              <div className="sticky top-0 z-10 p-6 border-b border-white/10 bg-[#1a1d23]/95 backdrop-blur-sm">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-1">
                      {t('transactions.transactionDetails')}
                    </h2>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-gray-400">{transaction.id}</p>
                      <button
                        onClick={() => copyToClipboard(transaction.id)}
                        className="p-1 rounded hover:bg-white/10 transition-colors"
                      >
                        {copied ? (
                          <Check className="w-3 h-3 text-[#6ee7b7]" />
                        ) : (
                          <Copy className="w-3 h-3 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={onClose}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <X className="w-5 h-5 text-gray-400" />
                  </button>
                </div>

                {/* Status Badge */}
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border ${statusConfig.bg} ${statusConfig.border}`}>
                  <StatusIcon className="w-4 h-4" style={{ color: statusConfig.color }} />
                  <span className="text-sm font-medium text-white">{statusConfig.text}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-6">
                {/* Amount Card */}
                <div className="p-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400 mb-1">{t('transactions.totalAmount')}</p>
                      <p className="text-4xl font-bold text-white">${transaction.amount.toFixed(2)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-400 mb-1">{t('transactions.netAmount')}</p>
                      <p className="text-2xl font-semibold text-[#6ee7b7]">${transaction.netAmount.toFixed(2)}</p>
                      <p className="text-xs text-gray-500 mt-1">{t('transactions.fee')}: ${transaction.fee.toFixed(2)}</p>
                    </div>
                  </div>
                </div>

                {/* Transaction Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <Building className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('transactions.merchant')}</span>
                    </div>
                    <p className="text-base font-semibold text-white">{transaction.merchant}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <PaymentIcon className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('transactions.method')}</span>
                    </div>
                    <p className="text-base font-semibold text-white">{transaction.paymentMethod}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <Wallet className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('transactions.walletUsed')}</span>
                    </div>
                    <p className="text-base font-semibold text-white">{transaction.wallet}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('transactions.dateTime')}</span>
                    </div>
                    <p className="text-base font-semibold text-white">
                      {transaction.date} {transaction.time}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 md:col-span-2">
                    <div className="flex items-center gap-2 mb-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('transactions.customerEmail')}</span>
                    </div>
                    <p className="text-base font-semibold text-white">{transaction.customerEmail}</p>
                  </div>
                </div>

                {/* Transaction Timeline */}
                <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-[#8b5cf6]" />
                    {t('transactions.timeline')}
                  </h3>
                  <div className="space-y-4">
                    {timeline.map((item, index) => (
                      <div key={index} className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              item.status === 'completed'
                                ? 'bg-[#6ee7b7]/20 border-2 border-[#6ee7b7]'
                                : 'bg-gray-500/20 border-2 border-gray-500'
                            }`}
                          >
                            {item.status === 'completed' && (
                              <Check className="w-4 h-4 text-[#6ee7b7]" />
                            )}
                          </div>
                          {index < timeline.length - 1 && (
                            <div className="w-0.5 h-12 bg-white/10" />
                          )}
                        </div>
                        <div className="flex-1 pb-4">
                          <p className="text-sm font-medium text-white">{item.event}</p>
                          <p className="text-xs text-gray-400 mt-1">{item.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-white/10">
                  <motion.button
                    onClick={handleDownloadReceipt}
                    disabled={downloading}
                    className="flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2 disabled:opacity-50"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <Download className="w-4 h-4" />
                    {downloading ? t('transactions.downloading') : t('transactions.downloadReceipt')}
                  </motion.button>

                  {transaction.status === 'success' && (
                    <motion.button
                      onClick={handleRefund}
                      disabled={refunding}
                      className="flex-1 py-3 px-6 rounded-xl bg-white/5 border border-white/10 text-white font-medium flex items-center justify-center gap-2 hover:bg-white/10 transition-colors disabled:opacity-50"
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <RefreshCw className={`w-4 h-4 ${refunding ? 'animate-spin' : ''}`} />
                      {refunding ? t('transactions.processing') : t('transactions.initiateRefund')}
                    </motion.button>
                  )}

                  <motion.button
                    onClick={onClose}
                    className="py-3 px-6 rounded-xl bg-white/5 border border-white/10 text-gray-300 font-medium hover:bg-white/10 transition-colors"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    {t('common.cancel')}
                  </motion.button>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
