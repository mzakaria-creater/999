import { Outlet, useLocation, useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Bell, 
  Search,
  MoreVertical,
  Home,
  Receipt,
  Wallet,
  Store,
  User,
  Settings,
  Monitor
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { MobileStatusBar } from './MobileStatusBar';
import { FxRateBar } from './FxRateBar';
import { MobileBottomNav } from './MobileBottomNav';
import { useState, useEffect } from 'react';

interface NavItem {
  path: string;
  icon: typeof Home;
  labelKey: string;
}

const navItems: NavItem[] = [
  { path: '/mobile/dashboard', icon: Home, labelKey: 'nav.dashboard' },
  { path: '/mobile/transactions', icon: Receipt, labelKey: 'nav.transactions' },
  { path: '/mobile/wallets', icon: Wallet, labelKey: 'nav.wallets' },
  { path: '/mobile/merchants', icon: Store, labelKey: 'nav.merchants' },
  { path: '/mobile/settings', icon: Settings, labelKey: 'nav.settings' }
];

export function MobileAppLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t, direction } = useLanguage();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  const currentPath = location.pathname;
  const showBackButton = currentPath !== '/mobile/dashboard' && currentPath !== '/mobile/apps' && currentPath !== '/';

  useEffect(() => {
    const handleScroll = (e: Event) => {
      const target = e.target as HTMLElement;
      setScrollY(target.scrollTop);
    };

    const mainContent = document.getElementById('mobile-main-content');
    mainContent?.addEventListener('scroll', handleScroll);
    
    return () => mainContent?.removeEventListener('scroll', handleScroll);
  }, []);

  const getPageTitle = () => {
    const pathMap: Record<string, string> = {
      '/dashboard': 'nav.dashboard',
      '/mobile/dashboard': 'nav.dashboard',
      '/mobile/apps': 'nav.apps',
      '/transactions': 'nav.transactions',
      '/mobile/transactions': 'nav.transactions',
      '/wallets': 'nav.wallets',
      '/mobile/wallets': 'nav.wallets',
      '/merchants': 'nav.merchants',
      '/mobile/merchants': 'nav.merchants',
      '/payment-methods': 'nav.paymentMethods',
      '/payment-accounts': 'nav.paymentAccounts',
      '/payment-pages': 'nav.paymentPages',
      '/users': 'nav.users',
      '/approvals': 'nav.approvals',
      '/settlement': 'nav.settlement',
      '/payouts': 'nav.payouts',
      '/risk': 'nav.risk',
      '/reports': 'nav.reports',
      '/api-docs': 'nav.apiDocs',
      '/binance': 'Binance Integration',
      '/settings': 'nav.settings',
      '/mobile/settings': 'nav.settings'
    };

    return t(pathMap[currentPath] || 'OnTarget PSP');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0a0b0d] overflow-hidden fixed inset-0">
      {/* iOS-style Status Bar with Notch */}
      <div className="relative z-50">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[150px] h-[30px] bg-black rounded-b-3xl" />
        <MobileStatusBar />
      </div>

      {/* FX Rate Bar */}
      <FxRateBar />

      {/* App Header */}
      <motion.header 
        className="relative z-40 bg-gradient-to-b from-[#1a1d23]/95 to-[#1a1d23]/80 backdrop-blur-xl border-b border-white/5"
        style={{
          boxShadow: scrollY > 10 ? '0 4px 20px rgba(0,0,0,0.3)' : 'none',
        }}
      >
        <div className="px-4 py-3 flex items-center justify-between">
          {/* Left: Back Button or Logo */}
          <div className="flex items-center gap-3 flex-1">
            {showBackButton ? (
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => navigate(-1)}
                className="p-2 -ml-2 rounded-full active:bg-white/10 transition-colors"
              >
                <ArrowLeft className={`w-5 h-5 text-white ${direction === 'rtl' ? 'rotate-180' : ''}`} />
              </motion.button>
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                  <span className="text-white font-bold text-sm">OT</span>
                </div>
              </div>
            )}
            <h1 className="text-lg font-semibold text-white truncate">
              {getPageTitle()}
            </h1>
          </div>

          {/* Right: Action Buttons */}
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="p-2 rounded-full active:bg-white/10 transition-colors relative"
            >
              <Search className="w-5 h-5 text-gray-300" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 rounded-full active:bg-white/10 transition-colors relative"
            >
              <Bell className="w-5 h-5 text-gray-300" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-[#1a1d23]" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 rounded-full active:bg-white/10 transition-colors"
            >
              <MoreVertical className="w-5 h-5 text-gray-300" />
            </motion.button>
          </div>
        </div>
      </motion.header>

      {/* Main Content with Pull-to-Refresh */}
      <main 
        id="mobile-main-content"
        className="flex-1 overflow-y-auto overflow-x-hidden bg-gradient-to-b from-[#0a0b0d] via-[#121417] to-[#0a0b0d]"
        style={{
          WebkitOverflowScrolling: 'touch',
        }}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, x: direction === 'rtl' ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction === 'rtl' ? 20 : -20 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="min-h-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
        
        {/* Bottom spacing for navigation */}
        <div className="h-20" />
      </main>

      {/* Bottom Navigation */}
      <MobileBottomNav />

      {/* Notification Panel */}
      <AnimatePresence>
        {showNotifications && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowNotifications(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-20 right-4 w-80 max-w-[calc(100vw-2rem)] bg-[#1a1d23]/98 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl z-[70] overflow-hidden"
            >
              <div className="p-4 border-b border-white/10">
                <h3 className="text-white font-semibold">Notifications</h3>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="p-4 border-b border-white/5 hover:bg-white/5 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center flex-shrink-0">
                        <Bell className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white font-medium">Payment Received</p>
                        <p className="text-xs text-gray-400 mt-1">You received $1,234.56</p>
                        <p className="text-xs text-gray-500 mt-1">2 minutes ago</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Menu Panel */}
      <AnimatePresence>
        {showMenu && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMenu(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-20 right-4 w-64 max-w-[calc(100vw-2rem)] bg-[#1a1d23]/98 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl z-[70] overflow-hidden"
            >
              <div className="p-3">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setShowMenu(false);
                    navigate('/');
                  }}
                  className="w-full relative group"
                >
                  {/* Glassmorphic Button Container - Same style as mobile bottom nav */}
                  <div className="relative px-4 py-3 rounded-2xl backdrop-blur-2xl border shadow-lg overflow-hidden bg-gradient-to-t from-[#1a1d23] via-[#1a1d23]/98 to-[#1a1d23]/95 border-white/10">
                    {/* Top Border Gradient */}
                    <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                    
                    {/* Hover Glow Effect */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      initial={false}
                    />
                    
                    {/* Content */}
                    <div className="relative flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center shadow-lg shadow-violet-500/30">
                        <span className="text-xl">💻</span>
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm text-white font-medium">Desktop View</p>
                        <p className="text-xs text-gray-400">Switch to full dashboard</p>
                      </div>
                    </div>
                    
                    {/* Active Indicator Dot */}
                    <motion.div
                      className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-[#8b5cf6] rounded-full opacity-0 group-hover:opacity-100"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  </div>
                </motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}