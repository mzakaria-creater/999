import { motion, AnimatePresence } from 'motion/react';
import { ReactNode, useState } from 'react';

interface TooltipProps {
  content: string;
  children: ReactNode;
  enabled?: boolean;
  side?: 'left' | 'right';
}

export function Tooltip({ content, children, enabled = true, side = 'right' }: TooltipProps) {
  const [isVisible, setIsVisible] = useState(false);

  if (!enabled) return <>{children}</>;

  return (
    <div
      className="relative inline-block"
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, x: side === 'right' ? -10 : 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: side === 'right' ? -10 : 10 }}
            transition={{ duration: 0.15 }}
            className={`absolute ${side === 'right' ? 'left-full ml-3' : 'right-full mr-3'} top-1/2 -translate-y-1/2 z-50 pointer-events-none`}
          >
            <div className="px-3 py-2 rounded-lg bg-[#1a1d23] border border-white/10 shadow-2xl backdrop-blur-xl whitespace-nowrap">
              <span className="text-sm text-white font-medium">{content}</span>
            </div>
            {/* Arrow */}
            <div className={`absolute ${side === 'right' ? 'right-full mr-[-1px]' : 'left-full ml-[-1px]'} top-1/2 -translate-y-1/2`}>
              <div className={`w-2 h-2 bg-[#1a1d23] border border-white/10 transform rotate-45 ${side === 'right' ? 'border-r-0 border-t-0' : 'border-l-0 border-b-0'}`} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}