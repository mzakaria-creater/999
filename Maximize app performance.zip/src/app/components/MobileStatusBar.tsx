import { Battery, Signal, Wifi } from 'lucide-react';
import { useEffect, useState } from 'react';

export function MobileStatusBar() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const timeString = currentTime.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: false,
  });

  return (
    <div className="bg-white/5 backdrop-blur-sm border-b border-white/10">
      
    </div>
  );
}
