import { motion } from 'motion/react';
import { useNavigate, useLocation } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import {
  Home,
  Receipt,
  Wallet,
  Store,
  Settings,
  Plus,
  TrendingUp,
} from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  path: string;
  icon: typeof Home;
  label: string;
  badge?: number;
}

const navItems: NavItem[] = [
  { path: '/mobile/apps', icon: Home, label: 'Home' },
  { path: '/mobile/transactions', icon: Receipt, label: 'Transactions' },
  { path: '/mobile/wallets', icon: Wallet, label: 'Wallets' },
  { path: '/mobile/merchants', icon: Store, label: 'Merchants' },
  { path: '/mobile/settings', icon: Settings, label: 'Settings' },
];

export function MobileBottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLanguage();
  const [showQuickActions, setShowQuickActions] = useState(false);

  const quickActions = [
    { icon: Plus, label: 'New Transaction', action: () => navigate('/mobile/transactions/new') },
    { icon: TrendingUp, label: 'View Reports', action: () => navigate('/mobile/reports') },
    { icon: Wallet, label: 'Add Wallet', action: () => navigate('/mobile/wallets/add') },
  ];

  return (
    <>
      {/* Quick Actions Overlay */}
      {showQuickActions && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowQuickActions(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 100 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 100 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-3 p-4 bg-[#1a1d23]/98 backdrop-blur-xl rounded-3xl border border-white/10 shadow-2xl"
          >
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <motion.button
                  key={action.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => {
                    action.action();
                    setShowQuickActions(false);
                  }}
                  className="flex items-center gap-3 px-6 py-3 rounded-2xl bg-white/5 hover:bg-white/10 active:bg-white/15 transition-all min-w-[200px]"
                  whileTap={{ scale: 0.95 }}
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-white font-medium text-sm">{action.label}</span>
                </motion.button>
              );
            })}
          </motion.div>
        </>
      )}

      {/* Bottom Navigation Bar */}
      <motion.nav
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 z-50"
        style={{
          paddingBottom: 'max(env(safe-area-inset-bottom), 8px)',
        }}
      >
        {/* Glassmorphic Background */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a1d23] via-[#1a1d23]/98 to-[#1a1d23]/95 backdrop-blur-2xl" />
        
        {/* Top Border with Gradient */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        
        {/* Shadow */}
        <div className="absolute inset-0 shadow-[0_-4px_30px_rgba(0,0,0,0.5)]" />

        {/* Nav Content */}
        <div className="relative px-4 pt-2">
          <div className="flex items-center justify-around">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <motion.button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className="flex flex-col items-center gap-1 py-2 px-3 relative group"
                  whileTap={{ scale: 0.9 }}
                >
                  {/* Active Indicator */}
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6]"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  
                  {/* Icon with special styling for Home */}
                  <div className={`relative ${item.path === '/mobile/apps' ? 'w-11 h-11' : 'w-10 h-10'} rounded-2xl flex items-center justify-center transition-all ${
                    item.path === '/mobile/apps' 
                      ? 'bg-gray-700/80 shadow-lg' 
                      : isActive 
                        ? 'bg-white/10' 
                        : 'group-hover:bg-white/5'
                  }`}>
                    {item.path === '/mobile/apps' ? (
                      <span className="text-2xl">🏠</span>
                    ) : (
                      <Icon className={`w-5 h-5 transition-colors ${
                        isActive 
                          ? 'text-white' 
                          : 'text-gray-400 group-hover:text-gray-300'
                      }`} />
                    )}
                    
                    {item.badge && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                        <span className="text-xs font-bold text-white">{item.badge}</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Label */}
                  <span className={`text-xs font-medium transition-colors ${
                    isActive ? 'text-white' : 'text-gray-500'
                  }`}>
                    {item.label}
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Home Indicator (iPhone-style) */}
        <div className="flex justify-center pb-1.5">
          <div className="w-32 h-1 bg-white/20 rounded-full" />
        </div>
      </motion.nav>
    </>
  );
}