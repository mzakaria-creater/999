import { useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';

interface ConfettiEffectProps {
  trigger?: boolean;
  type?: 'success' | 'celebration' | 'burst' | 'rain';
  duration?: number;
}

export function useConfetti() {
  const fireConfetti = useCallback((type: 'success' | 'celebration' | 'burst' | 'rain' = 'success') => {
    const configs = {
      success: () => {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#8b5cf6', '#3b82f6', '#6ee7b7', '#fbbf24'],
        });
      },
      celebration: () => {
        const duration = 3000;
        const animationEnd = Date.now() + duration;
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

        const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

        const interval = setInterval(() => {
          const timeLeft = animationEnd - Date.now();

          if (timeLeft <= 0) {
            return clearInterval(interval);
          }

          const particleCount = 50 * (timeLeft / duration);

          confetti({
            ...defaults,
            particleCount,
            origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
            colors: ['#8b5cf6', '#3b82f6', '#6ee7b7'],
          });
          confetti({
            ...defaults,
            particleCount,
            origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
            colors: ['#fbbf24', '#f59e0b', '#06b6d4'],
          });
        }, 250);
      },
      burst: () => {
        const count = 200;
        const defaults = {
          origin: { y: 0.5 },
          zIndex: 9999,
        };

        function fire(particleRatio: number, opts: any) {
          confetti({
            ...defaults,
            ...opts,
            particleCount: Math.floor(count * particleRatio),
          });
        }

        fire(0.25, { spread: 26, startVelocity: 55, colors: ['#8b5cf6', '#3b82f6'] });
        fire(0.2, { spread: 60, colors: ['#6ee7b7', '#06b6d4'] });
        fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8, colors: ['#fbbf24', '#f59e0b'] });
        fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
        fire(0.1, { spread: 120, startVelocity: 45 });
      },
      rain: () => {
        const duration = 2000;
        const animationEnd = Date.now() + duration;

        const interval = setInterval(() => {
          const timeLeft = animationEnd - Date.now();

          if (timeLeft <= 0) {
            return clearInterval(interval);
          }

          confetti({
            particleCount: 2,
            angle: 90,
            spread: 45,
            origin: { x: Math.random(), y: 0 },
            colors: ['#8b5cf6', '#3b82f6', '#6ee7b7', '#fbbf24'],
            gravity: 1.2,
            scalar: 0.8,
            drift: 0,
            ticks: 200,
          });
        }, 50);
      },
    };

    configs[type]();
  }, []);

  return { fireConfetti };
}

export function ConfettiEffect({ trigger = false, type = 'success', duration = 3000 }: ConfettiEffectProps) {
  const { fireConfetti } = useConfetti();

  useEffect(() => {
    if (trigger) {
      fireConfetti(type);
    }
  }, [trigger, type, fireConfetti]);

  return null;
}

// Success Toast with Confetti
export function SuccessConfetti() {
  const { fireConfetti } = useConfetti();

  useEffect(() => {
    fireConfetti('success');
  }, [fireConfetti]);

  return null;
}
