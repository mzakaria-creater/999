import { useRole, UserRole } from '../context/RoleContext';
import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import { useState } from 'react';

const roles: UserRole[] = ['Owner', 'Admin', 'Finance', 'Operations', 'Merchant', 'Viewer'];

export function RoleSwitcher() {
  const { role, setRole } = useRole();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <span className="text-sm font-medium text-white">Role: {role}</span>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </motion.button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setIsOpen(false)} />
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-full mt-2 right-0 w-48 bg-[#1a1d23] border border-white/10 rounded-xl shadow-2xl overflow-hidden z-20 backdrop-blur-xl"
            style={{ boxShadow: '0 0 40px rgba(0, 0, 0, 0.5)' }}
          >
            {roles.map((r) => (
              <button
                key={r}
                onClick={() => {
                  setRole(r);
                  setIsOpen(false);
                }}
                className={`w-full px-4 py-3 text-left text-sm transition-all ${
                  r === role
                    ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border-l-2 border-[#8b5cf6]'
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                {r}
              </button>
            ))}
          </motion.div>
        </>
      )}
    </div>
  );
}
