import { motion } from 'motion/react';

interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'circular' | 'rectangular' | 'card';
  animate?: boolean;
}

export function Skeleton({ className = '', variant = 'text', animate = true }: SkeletonProps) {
  const baseStyles = 'bg-gradient-to-r from-white/5 via-white/10 to-white/5';
  
  const variantStyles = {
    text: 'h-4 rounded',
    circular: 'rounded-full aspect-square',
    rectangular: 'rounded-lg',
    card: 'h-48 rounded-2xl',
  };

  return (
    <motion.div
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
      animate={animate ? {
        backgroundPosition: ['200% 0', '-200% 0'],
      } : {}}
      transition={{
        duration: 2,
        repeat: Infinity,
        ease: 'linear',
      }}
      style={{
        backgroundSize: '200% 100%',
      }}
    />
  );
}

// Dashboard Card Skeleton
export function DashboardCardSkeleton() {
  return (
    <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 space-y-4">
      <div className="flex items-start justify-between">
        <Skeleton variant="circular" className="w-12 h-12" />
        <Skeleton variant="text" className="w-16 h-4" />
      </div>
      <div className="space-y-2">
        <Skeleton variant="text" className="w-24 h-3" />
        <Skeleton variant="text" className="w-32 h-8" />
        <Skeleton variant="text" className="w-20 h-3" />
      </div>
    </div>
  );
}

// Table Row Skeleton
export function TableRowSkeleton({ columns = 5 }: { columns?: number }) {
  return (
    <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5">
      {Array.from({ length: columns }).map((_, i) => (
        <Skeleton key={i} variant="text" className="flex-1 h-4" />
      ))}
    </div>
  );
}

// Chart Skeleton
export function ChartSkeleton() {
  return (
    <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
      <div className="space-y-4 mb-6">
        <Skeleton variant="text" className="w-48 h-6" />
        <Skeleton variant="text" className="w-32 h-4" />
      </div>
      <div className="space-y-3">
        {[60, 80, 45, 90, 70, 55, 85].map((height, i) => (
          <div key={i} className="flex items-end gap-2">
            <Skeleton variant="rectangular" className="flex-1" style={{ height: `${height}%` }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// Transaction Item Skeleton
export function TransactionSkeleton() {
  return (
    <div className="flex items-center justify-between p-4 rounded-xl bg-white/5">
      <div className="flex items-center gap-4 flex-1">
        <Skeleton variant="circular" className="w-10 h-10" />
        <div className="space-y-2 flex-1">
          <Skeleton variant="text" className="w-32 h-4" />
          <Skeleton variant="text" className="w-24 h-3" />
        </div>
      </div>
      <div className="space-y-2">
        <Skeleton variant="text" className="w-20 h-4" />
        <Skeleton variant="text" className="w-16 h-3" />
      </div>
    </div>
  );
}
