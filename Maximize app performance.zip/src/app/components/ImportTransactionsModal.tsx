import { motion, AnimatePresence } from 'motion/react';
import { X, Upload, FileText, AlertCircle, CheckCircle, Trash2, Download } from 'lucide-react';
import { useState, useCallback, useRef } from 'react';
import { GlassCard } from './GlassCard';
import { useLanguage } from '../context/LanguageContext';

interface ImportedTransaction {
  orderId: string;
  merchant: string;
  amount: number;
  method: string;
  account: string;
  reference: string;
  time: string;
  errors?: string[];
}

interface ImportTransactionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ImportTransactionsModal({ isOpen, onClose }: ImportTransactionsModalProps) {
  const { t, direction } = useLanguage();
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [transactions, setTransactions] = useState<ImportedTransaction[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [step, setStep] = useState<'upload' | 'preview'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const parseCSV = (text: string): ImportedTransaction[] => {
    const lines = text.split('\n').filter(line => line.trim());
    const headers = lines[0].split(/[,\t]/).map(h => h.trim().toLowerCase());
    
    return lines.slice(1).map((line, index) => {
      const values = line.split(/[,\t]/).map(v => v.trim());
      const tx: any = {};
      
      headers.forEach((header, i) => {
        tx[header.replace('_', '')] = values[i] || '';
      });

      // Validate and detect errors
      const errors: string[] = [];
      if (!tx.amount || isNaN(parseFloat(tx.amount))) {
        errors.push('Invalid amount');
      }
      if (!tx.merchant) errors.push('Missing merchant');
      if (!tx.method) errors.push('Missing payment method');

      return {
        orderId: tx.orderid || tx.order || `ORD-${1000 + index}`,
        merchant: tx.merchant || 'Unknown',
        amount: parseFloat(tx.amount) || 0,
        method: tx.method || 'N/A',
        account: tx.account || 'N/A',
        reference: tx.reference || tx.ref || '',
        time: tx.time || tx.timestamp || new Date().toLocaleTimeString(),
        errors: errors.length > 0 ? errors : undefined
      };
    });
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && (droppedFile.type === 'text/csv' || droppedFile.name.endsWith('.csv') || droppedFile.name.endsWith('.xlsx'))) {
      setFile(droppedFile);
      processFile(droppedFile);
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      processFile(selectedFile);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const parsed = parseCSV(text);
      setTransactions(parsed);
      setStep('preview');
    };
    reader.readAsText(file);
  };

  const toggleSelection = (orderId: string) => {
    setSelectedIds(prev =>
      prev.includes(orderId) ? prev.filter(id => id !== orderId) : [...prev, orderId]
    );
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === transactions.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(transactions.map(tx => tx.orderId));
    }
  };

  const handleBulkAction = (action: 'approve' | 'reject' | 'delete' | 'export') => {
    const selectedTransactions = transactions.filter(tx => selectedIds.includes(tx.orderId));
    
    switch (action) {
      case 'approve':
        console.log('Approving:', selectedTransactions);
        alert(`Approved ${selectedIds.length} transactions`);
        break;
      case 'reject':
        console.log('Rejecting:', selectedTransactions);
        alert(`Rejected ${selectedIds.length} transactions`);
        break;
      case 'delete':
        setTransactions(prev => prev.filter(tx => !selectedIds.includes(tx.orderId)));
        setSelectedIds([]);
        break;
      case 'export':
        console.log('Exporting:', selectedTransactions);
        alert(`Exported ${selectedIds.length} transactions`);
        break;
    }
  };

  const handleImport = () => {
    const validTransactions = transactions.filter(tx => !tx.errors || tx.errors.length === 0);
    console.log('Importing transactions:', validTransactions);
    alert(`Successfully imported ${validTransactions.length} transactions!`);
    onClose();
    setTransactions([]);
    setSelectedIds([]);
    setStep('upload');
    setFile(null);
  };

  const downloadTemplate = () => {
    const template = 'order_id,merchant,amount,method,account,reference,time\nORD001,TechStore,1500,Vodafone Cash,01012345678,928172,12:30\nORD002,FashionHub,900,InstaPay,IBAN123,827171,12:45';
    const blob = new Blob([template], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transactions_template.csv';
    a.click();
  };

  if (!isOpen) return null;

  const validCount = transactions.filter(tx => !tx.errors || tx.errors.length === 0).length;
  const errorCount = transactions.length - validCount;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-6xl max-h-[90vh] overflow-hidden"
        >
          <GlassCard className="relative">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <div>
                <h2 className="text-2xl font-semibold text-white flex items-center gap-3">
                  <Upload className="w-6 h-6 text-[#8b5cf6]" />
                  {t('importTransactions')}
                </h2>
                <p className="text-gray-400 text-sm mt-1">
                  {t('bulkUploadTransactions')}
                </p>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-180px)]">
              {step === 'upload' ? (
                <div className="space-y-6">
                  {/* Download Template */}
                  <div className="flex items-center justify-between p-4 bg-[#8b5cf6]/10 border border-[#8b5cf6]/30 rounded-xl">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-[#8b5cf6]" />
                      <div>
                        <p className="text-white font-medium">Download Template</p>
                        <p className="text-sm text-gray-400">Use our CSV template to format your data</p>
                      </div>
                    </div>
                    <motion.button
                      onClick={downloadTemplate}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-lg bg-[#8b5cf6] text-white font-medium flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </motion.button>
                  </div>

                  {/* Upload Area */}
                  <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-2xl p-12 transition-all cursor-pointer ${
                      dragActive
                        ? 'border-[#8b5cf6] bg-[#8b5cf6]/10'
                        : 'border-white/20 hover:border-white/40 bg-white/5'
                    }`}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".csv,.xlsx"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <div className="text-center space-y-4">
                      <motion.div
                        animate={{ y: dragActive ? -10 : 0 }}
                        className="flex justify-center"
                      >
                        <div className="p-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
                          <Upload className="w-12 h-12 text-[#8b5cf6]" />
                        </div>
                      </motion.div>
                      <div>
                        <p className="text-xl font-semibold text-white mb-2">
                          {dragActive ? 'Drop file here' : 'Drag & Drop File'}
                        </p>
                        <p className="text-gray-400">
                          or click to browse • CSV or Excel files supported
                        </p>
                      </div>
                      {file && (
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#6ee7b7]/10 border border-[#6ee7b7]/30">
                          <FileText className="w-4 h-4 text-[#6ee7b7]" />
                          <span className="text-sm text-white font-medium">{file.name}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Supported Formats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {['CSV', 'Excel (.xlsx)', 'Google Sheets', 'Numbers'].map(format => (
                      <div key={format} className="p-4 bg-white/5 border border-white/10 rounded-xl text-center">
                        <CheckCircle className="w-5 h-5 text-[#6ee7b7] mx-auto mb-2" />
                        <p className="text-sm text-gray-400">{format}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Stats Bar */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="p-4 bg-white/5 border border-white/10 rounded-xl">
                      <p className="text-sm text-gray-400 mb-1">Total Rows</p>
                      <p className="text-2xl font-bold text-white">{transactions.length}</p>
                    </div>
                    <div className="p-4 bg-[#6ee7b7]/10 border border-[#6ee7b7]/30 rounded-xl">
                      <p className="text-sm text-gray-400 mb-1">Valid</p>
                      <p className="text-2xl font-bold text-[#6ee7b7]">{validCount}</p>
                    </div>
                    <div className="p-4 bg-[#f87171]/10 border border-[#f87171]/30 rounded-xl">
                      <p className="text-sm text-gray-400 mb-1">Errors</p>
                      <p className="text-2xl font-bold text-[#f87171]">{errorCount}</p>
                    </div>
                  </div>

                  {/* Bulk Actions Toolbar */}
                  {selectedIds.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-3 p-4 bg-[#8b5cf6]/10 border border-[#8b5cf6]/30 rounded-xl"
                    >
                      <span className="text-white font-medium">{selectedIds.length} selected</span>
                      <div className="flex gap-2 ml-auto">
                        <motion.button
                          onClick={() => handleBulkAction('approve')}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="px-4 py-2 rounded-lg bg-[#6ee7b7] text-[#121417] font-medium"
                        >
                          Approve
                        </motion.button>
                        <motion.button
                          onClick={() => handleBulkAction('reject')}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="px-4 py-2 rounded-lg bg-[#fbbf24] text-[#121417] font-medium"
                        >
                          Reject
                        </motion.button>
                        <motion.button
                          onClick={() => handleBulkAction('export')}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="px-4 py-2 rounded-lg bg-white/10 text-white font-medium"
                        >
                          <Download className="w-4 h-4" />
                        </motion.button>
                        <motion.button
                          onClick={() => handleBulkAction('delete')}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="px-4 py-2 rounded-lg bg-[#f87171]/20 text-[#f87171] font-medium"
                        >
                          <Trash2 className="w-4 h-4" />
                        </motion.button>
                      </div>
                    </motion.div>
                  )}

                  {/* Preview Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-white/10">
                          <th className="px-4 py-3 text-left">
                            <input
                              type="checkbox"
                              checked={selectedIds.length === transactions.length}
                              onChange={toggleSelectAll}
                              className="w-4 h-4 rounded border-white/20 bg-white/5 text-[#8b5cf6] focus:ring-[#8b5cf6]"
                            />
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Order ID</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Merchant</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Amount</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Method</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Account</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Reference</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-400">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((tx) => (
                          <tr
                            key={tx.orderId}
                            className={`border-b border-white/5 hover:bg-white/5 transition-all ${
                              tx.errors ? 'bg-[#f87171]/5' : ''
                            }`}
                          >
                            <td className="px-4 py-3">
                              <input
                                type="checkbox"
                                checked={selectedIds.includes(tx.orderId)}
                                onChange={() => toggleSelection(tx.orderId)}
                                className="w-4 h-4 rounded border-white/20 bg-white/5 text-[#8b5cf6] focus:ring-[#8b5cf6]"
                              />
                            </td>
                            <td className="px-4 py-3 text-sm text-white font-mono">{tx.orderId}</td>
                            <td className="px-4 py-3 text-sm text-white">{tx.merchant}</td>
                            <td className="px-4 py-3 text-sm text-white font-semibold">${tx.amount.toFixed(2)}</td>
                            <td className="px-4 py-3 text-sm text-gray-400">{tx.method}</td>
                            <td className="px-4 py-3 text-sm text-gray-400 font-mono">{tx.account}</td>
                            <td className="px-4 py-3 text-sm text-gray-400">{tx.reference}</td>
                            <td className="px-4 py-3">
                              {tx.errors ? (
                                <div className="flex items-center gap-1 text-[#f87171]">
                                  <AlertCircle className="w-4 h-4" />
                                  <span className="text-xs">{tx.errors[0]}</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-[#6ee7b7]">
                                  <CheckCircle className="w-4 h-4" />
                                  <span className="text-xs">Valid</span>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between p-6 border-t border-white/10">
              <motion.button
                onClick={() => {
                  if (step === 'preview') {
                    setStep('upload');
                    setTransactions([]);
                    setSelectedIds([]);
                  } else {
                    onClose();
                  }
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 rounded-xl bg-white/5 text-white font-medium hover:bg-white/10 transition-all"
              >
                {step === 'preview' ? 'Back' : 'Cancel'}
              </motion.button>

              {step === 'preview' && (
                <motion.button
                  onClick={handleImport}
                  disabled={validCount === 0}
                  whileHover={{ scale: validCount > 0 ? 1.05 : 1 }}
                  whileTap={{ scale: validCount > 0 ? 0.95 : 1 }}
                  className={`px-6 py-3 rounded-xl font-medium flex items-center gap-2 ${
                    validCount > 0
                      ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white'
                      : 'bg-white/5 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <Upload className="w-5 h-5" />
                  Import {validCount} Transactions
                </motion.button>
              )}
            </div>
          </GlassCard>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
