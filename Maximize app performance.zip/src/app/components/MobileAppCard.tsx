import { motion } from 'motion/react';
import { ReactNode } from 'react';
import { ChevronRight } from 'lucide-react';

interface MobileAppCardProps {
  children: ReactNode;
  className?: string;
  gradient?: boolean;
  onClick?: () => void;
  showChevron?: boolean;
}

export function MobileAppCard({ 
  children, 
  className = '', 
  gradient = false,
  onClick,
  showChevron = false 
}: MobileAppCardProps) {
  const baseClasses = "rounded-2xl p-4 backdrop-blur-xl border transition-all duration-200";
  const gradientClasses = gradient
    ? "bg-gradient-to-br from-[#1a1d23]/90 to-[#252932]/90 border-white/10"
    : "bg-[#1a1d23]/60 border-white/5";
  const interactiveClasses = onClick ? "active:scale-[0.98] cursor-pointer" : "";

  const content = (
    <>
      <div className="flex-1">{children}</div>
      {showChevron && (
        <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
      )}
    </>
  );

  if (onClick) {
    return (
      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={onClick}
        className={`${baseClasses} ${gradientClasses} ${interactiveClasses} ${className} flex items-center gap-3 w-full text-left`}
      >
        {content}
      </motion.button>
    );
  }

  return (
    <div className={`${baseClasses} ${gradientClasses} ${className}`}>
      {children}
    </div>
  );
}

interface MobileAppSectionProps {
  title: string;
  children: ReactNode;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function MobileAppSection({ title, children, action }: MobileAppSectionProps) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3 px-4">
        <h2 className="text-white font-semibold text-base">{title}</h2>
        {action && (
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={action.onClick}
            className="text-[#8b5cf6] text-sm font-medium active:text-[#7c4ee8]"
          >
            {action.label}
          </motion.button>
        )}
      </div>
      <div className="space-y-3 px-4">
        {children}
      </div>
    </div>
  );
}

interface MobileListItemProps {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  value?: string;
  badge?: {
    text: string;
    variant: 'success' | 'warning' | 'error' | 'info';
  };
  onClick?: () => void;
  showChevron?: boolean;
}

export function MobileListItem({
  icon,
  title,
  subtitle,
  value,
  badge,
  onClick,
  showChevron = true
}: MobileListItemProps) {
  const badgeColors = {
    success: 'bg-green-500/20 text-green-400 border-green-500/30',
    warning: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    error: 'bg-red-500/20 text-red-400 border-red-500/30',
    info: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  };

  const content = (
    <>
      {icon && (
        <div className="flex-shrink-0">
          {icon}
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-white font-medium text-sm truncate">{title}</p>
          {badge && (
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${badgeColors[badge.variant]}`}>
              {badge.text}
            </span>
          )}
        </div>
        {subtitle && (
          <p className="text-gray-400 text-xs mt-0.5 truncate">{subtitle}</p>
        )}
      </div>
      {value && (
        <div className="flex-shrink-0 text-right">
          <p className="text-white font-semibold text-sm">{value}</p>
        </div>
      )}
      {showChevron && onClick && (
        <ChevronRight className="w-5 h-5 text-gray-500 flex-shrink-0" />
      )}
    </>
  );

  if (onClick) {
    return (
      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={onClick}
        className="w-full flex items-center gap-3 p-3 rounded-xl bg-[#1a1d23]/60 backdrop-blur-xl border border-white/5 active:bg-[#1a1d23]/80 transition-colors text-left"
      >
        {content}
      </motion.button>
    );
  }

  return (
    <div className="flex items-center gap-3 p-3 rounded-xl bg-[#1a1d23]/60 backdrop-blur-xl border border-white/5">
      {content}
    </div>
  );
}

interface MobileStatsCardProps {
  label: string;
  value: string;
  change?: {
    value: string;
    isPositive: boolean;
  };
  icon?: ReactNode;
  gradient?: 'violet' | 'blue' | 'mint' | 'amber';
}

export function MobileStatsCard({ label, value, change, icon, gradient = 'violet' }: MobileStatsCardProps) {
  const gradients = {
    violet: 'from-[#8b5cf6]/20 to-[#7c4ee8]/20 border-[#8b5cf6]/30',
    blue: 'from-[#3b82f6]/20 to-[#2563eb]/20 border-[#3b82f6]/30',
    mint: 'from-[#6ee7b7]/20 to-[#34d399]/20 border-[#6ee7b7]/30',
    amber: 'from-[#fbbf24]/20 to-[#f59e0b]/20 border-[#fbbf24]/30',
  };

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className={`p-4 rounded-2xl bg-gradient-to-br ${gradients[gradient]} border backdrop-blur-xl`}
    >
      <div className="flex items-start justify-between mb-3">
        <p className="text-gray-300 text-xs font-medium uppercase tracking-wide">{label}</p>
        {icon && <div className="text-white/70">{icon}</div>}
      </div>
      <div className="flex items-end justify-between">
        <p className="text-white text-2xl font-bold">{value}</p>
        {change && (
          <div className={`flex items-center gap-1 text-xs font-semibold ${
            change.isPositive ? 'text-green-400' : 'text-red-400'
          }`}>
            <span>{change.isPositive ? '↑' : '↓'}</span>
            <span>{change.value}</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}
