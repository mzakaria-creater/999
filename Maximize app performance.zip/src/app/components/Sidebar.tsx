import { Link, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  ArrowLeftRight,
  Wallet,
  Users,
  CreditCard,
  Code,
  FileText,
  Shield,
  ChevronLeft,
  ChevronRight,
  Settings,
  Building2,
  ChevronDown,
  Smartphone,
  Bitcoin,
  UserCog,
  UserPlus,
  Droplets,
  Database,
  Zap,
  Activity,
  DollarSign,
  FileUp,
  Send,
  BarChart3,
  GitBranch,
  ShieldAlert,
  CheckCircle,
  Banknote,
  Globe,
  MessageSquare,
  Table,
  TrendingUp,
  Eye
} from 'lucide-react';
import { useRole, hasPermission } from '../context/RoleContext';
import { useLanguage } from '../context/LanguageContext';
import { useState } from 'react';
import { Tooltip } from './Tooltip';

interface SubNavItem {
  name: string;
  path: string;
  permission: string;
  translationKey: string;
}

interface NavItem {
  name: string;
  path?: string;
  icon: React.ComponentType<{ className?: string }>;
  permission: string;
  translationKey: string;
  subItems?: SubNavItem[];
}

const navItems: NavItem[] = [
  // Core Dashboard & Monitoring
  { 
    name: 'Live Monitor', 
    path: '/', 
    icon: Eye, 
    permission: 'dashboard', 
    translationKey: 'nav.liveMonitor' 
  },
  { 
    name: 'Dashboard', 
    path: '/dashboard', 
    icon: LayoutDashboard, 
    permission: 'dashboard', 
    translationKey: 'nav.dashboard' 
  },
  
  // Transactions Section
  {
    name: 'Transactions',
    icon: ArrowLeftRight,
    permission: 'transactions',
    translationKey: 'nav.transactions',
    subItems: [
      { name: 'Transaction Manager', path: '/transactions', permission: 'transactions', translationKey: 'nav.transactions' },
      { name: 'Table Transactions', path: '/table-transactions', permission: 'transactions', translationKey: 'nav.tableTransactions' },
      { name: 'NGPay Dashboard', path: '/ngpay-dashboard', permission: 'transactions', translationKey: 'nav.ngpayDashboard' },
      { name: 'Import Transactions', path: '/import-transactions', permission: 'transactions', translationKey: 'nav.importTransactions' },
      { name: 'Mobile Wallet', path: '/mobile-wallet-transactions', permission: 'transactions', translationKey: 'nav.mobileWallet' },
    ]
  },
  
  // Financial Management
  {
    name: 'Financial',
    icon: DollarSign,
    permission: 'wallets',
    translationKey: 'nav.financial',
    subItems: [
      { name: 'Wallets', path: '/wallets', permission: 'wallets', translationKey: 'nav.wallets' },
      { name: 'Wallet Pools', path: '/wallet-pools', permission: 'wallets', translationKey: 'nav.walletPools' },
      { name: 'Settlement', path: '/settlement', permission: 'settlement', translationKey: 'nav.settlement' },
      { name: 'Payouts', path: '/payouts', permission: 'payouts', translationKey: 'nav.payouts' },
      { name: 'Live Rates', path: '/live-rates', permission: 'dashboard', translationKey: 'nav.liveRates' },
    ]
  },
  
  // Merchant Management
  {
    name: 'Merchants',
    icon: Users,
    permission: 'merchants',
    translationKey: 'nav.merchants',
    subItems: [
      { name: 'Merchants Directory', path: '/merchants', permission: 'merchants', translationKey: 'nav.merchants' },
      { name: 'Merchant Onboarding', path: '/merchant-onboarding', permission: 'merchants', translationKey: 'nav.merchantOnboarding' },
    ]
  },
  
  // Payment Configuration
  {
    name: 'Payment Settings',
    icon: Settings,
    permission: 'payment-settings',
    translationKey: 'nav.paymentSettings',
    subItems: [
      { name: 'Payment Methods', path: '/payment-methods', permission: 'payment-methods', translationKey: 'nav.paymentMethods' },
      { name: 'Payment Accounts', path: '/payment-accounts', permission: 'payment-methods', translationKey: 'nav.paymentAccounts' },
      { name: 'Payment Pages', path: '/payment-pages', permission: 'payment-methods', translationKey: 'nav.paymentPages' },
      { name: 'Smart Checkout', path: '/smart-checkout', permission: 'dashboard', translationKey: 'nav.smartCheckout' },
      { name: 'Payment Checkout', path: '/payment-checkout', permission: 'dashboard', translationKey: 'nav.paymentCheckout' },
    ]
  },
  
  // Integration & APIs
  {
    name: 'Integration',
    icon: Code,
    permission: 'integration',
    translationKey: 'nav.integration',
    subItems: [
      { name: 'Embed Integration', path: '/embed', permission: 'embed-integration', translationKey: 'nav.embedIntegration' },
      { name: 'API Documentation', path: '/api-docs', permission: 'api-docs', translationKey: 'nav.apiDocs' },
      { name: 'API Endpoints', path: '/api-documentation', permission: 'api-docs', translationKey: 'nav.apiEndpoints' },
      { name: 'Animation Showcase', path: '/animations', permission: 'dashboard', translationKey: 'nav.animations' },
      { name: 'Mobile Preview', path: '/mobile-view', permission: 'dashboard', translationKey: 'nav.mobilePreview' },
    ]
  },
  
  // Third-Party Services
  {
    name: 'Services',
    icon: Globe,
    permission: 'dashboard',
    translationKey: 'nav.services',
    subItems: [
      { name: 'Binance Integration', path: '/binance', permission: 'dashboard', translationKey: 'nav.binance' },
      { name: 'Binance P2P', path: '/binance-p2p', permission: 'dashboard', translationKey: 'nav.binanceP2P' },
      { name: 'Telegram Payments', path: '/telegram-payments', permission: 'dashboard', translationKey: 'nav.telegramPayments' },
      { name: 'Zoho Forms', path: '/zoho-forms', permission: 'dashboard', translationKey: 'nav.zohoForms' },
    ]
  },
  
  // Automation & Workflows
  {
    name: 'Automation',
    icon: Zap,
    permission: 'dashboard',
    translationKey: 'nav.automationCenter',
    subItems: [
      { name: 'Workflow Manager', path: '/workflow-manager', permission: 'dashboard', translationKey: 'nav.workflowManager' },
      { name: 'Automation Center', path: '/automation-center', permission: 'dashboard', translationKey: 'nav.automationCenter' },
    ]
  },
  
  // Operations & Compliance
  {
    name: 'Operations',
    icon: CheckCircle,
    permission: 'dashboard',
    translationKey: 'nav.operations',
    subItems: [
      { name: 'Approvals', path: '/approvals', permission: 'approvals', translationKey: 'nav.approvals' },
      { name: 'Risk & Fraud', path: '/risk', permission: 'risk', translationKey: 'nav.risk' },
    ]
  },
  
  // Reports & Analytics
  { 
    name: 'Reports', 
    path: '/reports', 
    icon: BarChart3, 
    permission: 'reports', 
    translationKey: 'nav.reports' 
  },
  
  // Administration
  {
    name: 'Administration',
    icon: Shield,
    permission: 'permissions',
    translationKey: 'nav.administration',
    subItems: [
      { name: 'User Management', path: '/user-management', permission: 'permissions', translationKey: 'nav.userManagement' },
      { name: 'Permissions', path: '/permissions', permission: 'permissions', translationKey: 'nav.permissions' },
    ]
  },
];

export function Sidebar() {
  const location = useLocation();
  const { role } = useRole();
  const { t, direction } = useLanguage();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  const isCategoryActive = (item: NavItem) => {
    if (item.path) return isActive(item.path);
    if (item.subItems) {
      return item.subItems.some(sub => isActive(sub.path));
    }
    return false;
  };

  const handleCategoryClick = (itemName: string, hasSubItems: boolean) => {
    if (hasSubItems) {
      setExpandedCategory(expandedCategory === itemName ? null : itemName);
      if (isCollapsed) {
        setIsCollapsed(false);
      }
    }
  };

  return (
    <motion.div
      className={`relative bg-[#1a1d23]/95 backdrop-blur-xl border-${direction === 'rtl' ? 'l' : 'r'} border-white/10 flex flex-col transition-all duration-300 z-10`}
      initial={{ width: 280 }}
      animate={{ width: isCollapsed ? 80 : 280 }}
    >
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <AnimatePresence mode="wait">
          {!isCollapsed ? (
            <motion.div
              key="full-logo"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                <span className="text-white font-bold text-lg">OT</span>
              </div>
              <div>
                <h1 className="text-lg font-bold bg-linear-to-r from-white to-white/70 bg-clip-text text-transparent tracking-tight">OnTarget <span className="text-blue-400">p$p</span></h1>
                <p className="text-xs text-gray-400">{t('common.platformSubtitle')}</p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="collapsed-logo"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-center"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                <span className="text-white font-bold text-lg">OT</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navItems.map((item) => {
          if (!hasPermission(role, item.permission)) return null;

          const Icon = item.icon;
          const active = isCategoryActive(item);
          const hasSubItems = !!item.subItems;
          const isExpanded = expandedCategory === item.name;

          return (
            <div key={item.name}>
              {/* Main Item */}
              {item.path ? (
                <Tooltip key={item.path} content={t(item.translationKey)} enabled={isCollapsed} side={direction === 'rtl' ? 'left' : 'right'}>
                  <Link to={item.path}>
                    <motion.div
                      className={`relative flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${
                        active
                          ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`}
                      whileHover={{ x: direction === 'rtl' ? -2 : 2 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {active && (
                        <motion.div
                          layoutId="activeIndicator"
                          className={`absolute ${direction === 'rtl' ? 'right-0' : 'left-0'} top-0 bottom-0 w-1 bg-gradient-to-b from-[#8b5cf6] to-[#3b82f6] rounded-${direction === 'rtl' ? 'l' : 'r'}-full`}
                          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                        />
                      )}
                      <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-[#8b5cf6]' : ''}`} />
                      <AnimatePresence mode="wait">
                        {!isCollapsed && (
                          <motion.span
                            key="label"
                            initial={{ opacity: 0, width: 0 }}
                            animate={{ opacity: 1, width: 'auto' }}
                            exit={{ opacity: 0, width: 0 }}
                            className="text-sm font-medium whitespace-nowrap overflow-hidden"
                          >
                            {t(item.translationKey)}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  </Link>
                </Tooltip>
              ) : (
                <Tooltip content={t(item.translationKey)} enabled={isCollapsed} side={direction === 'rtl' ? 'left' : 'right'}>
                  <motion.div
                    onClick={() => handleCategoryClick(item.name, hasSubItems)}
                    className={`relative flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${
                      active
                        ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                        : 'text-gray-400 hover:bg-white/5 hover:text-white'
                    }`}
                    whileHover={{ x: direction === 'rtl' ? -2 : 2 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {active && (
                      <motion.div
                        layoutId="activeIndicator"
                        className={`absolute ${direction === 'rtl' ? 'right-0' : 'left-0'} top-0 bottom-0 w-1 bg-gradient-to-b from-[#8b5cf6] to-[#3b82f6] rounded-${direction === 'rtl' ? 'l' : 'r'}-full`}
                        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                      />
                    )}
                    <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-[#8b5cf6]' : ''}`} />
                    <AnimatePresence mode="wait">
                      {!isCollapsed && (
                        <>
                          <motion.span
                            key="label"
                            initial={{ opacity: 0, width: 0 }}
                            animate={{ opacity: 1, width: 'auto' }}
                            exit={{ opacity: 0, width: 0 }}
                            className="text-sm font-medium whitespace-nowrap overflow-hidden flex-1 text-[#f4f8ff]"
                          >
                            {t(item.translationKey)}
                          </motion.span>
                          {hasSubItems && (
                            <motion.div
                              animate={{ rotate: isExpanded ? 180 : 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <ChevronDown className="w-4 h-4" />
                            </motion.div>
                          )}
                        </>
                      )}
                    </AnimatePresence>
                  </motion.div>
                </Tooltip>
              )}

              {/* Sub Items */}
              {hasSubItems && !isCollapsed && (
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className={`${direction === 'rtl' ? 'pr-4' : 'pl-4'} mt-2 space-y-1`}>
                        {item.subItems?.map((subItem) => {
                          if (!hasPermission(role, subItem.permission)) return null;
                          const subActive = isActive(subItem.path);

                          return (
                            <Link key={subItem.path} to={subItem.path}>
                              <motion.div
                                className={`flex items-center gap-3 px-4 py-2 rounded-lg cursor-pointer transition-all ${
                                  subActive
                                    ? 'bg-[#8b5cf6]/10 text-white'
                                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                                }`}
                                whileHover={{ x: direction === 'rtl' ? -2 : 2 }}
                                whileTap={{ scale: 0.98 }}
                              >
                                <div className={`w-1.5 h-1.5 rounded-full ${
                                  subActive ? 'bg-[#8b5cf6]' : 'bg-gray-500'
                                }`} />
                                <span className="text-xs font-medium">
                                  {t(subItem.translationKey)}
                                </span>
                              </motion.div>
                            </Link>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              )}
            </div>
          );
        })}
      </nav>

      {/* Toggle Button */}
      <div className="p-4 border-t border-white/10">
        <motion.button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-all"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          {isCollapsed ? (
            direction === 'rtl' ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />
          ) : (
            <>
              {direction === 'rtl' ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
              <AnimatePresence>
                {!isCollapsed && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: 'auto' }}
                    exit={{ opacity: 0, width: 0 }}
                    className="text-sm font-medium overflow-hidden whitespace-nowrap"
                  >
                    Collapse
                  </motion.span>
                )}
              </AnimatePresence>
            </>
          )}
        </motion.button>
      </div>
    </motion.div>
  );
}