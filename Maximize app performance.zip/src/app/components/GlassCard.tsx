import { ReactNode } from 'react';
import { motion } from 'motion/react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export function GlassCard({ children, className = '', hover = false }: GlassCardProps) {
  return (
    <motion.div
      className={`bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl ${className}`}
      whileHover={hover ? { y: -4, boxShadow: '0 0 30px rgba(139, 92, 246, 0.2)' } : {}}
      transition={{ duration: 0.2 }}
    >
      {children}
    </motion.div>
  );
}
