/**
 * TransactionActions Component
 * Provides action buttons and handlers for transaction management
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  Ban, 
  DollarSign,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import {
  executeTransactionAction,
  approveTransaction,
  rejectTransaction,
  markTransactionPaid,
  refundTransaction,
  cancelTransaction,
  verifyPayment,
  type Transaction,
  type TransactionActionRequest,
  getStatusColor
} from '../utils/transactionApi';

interface TransactionActionsProps {
  transaction: Transaction;
  onActionComplete?: (updatedTransaction: Transaction) => void;
  compact?: boolean;
}

export function TransactionActions({ 
  transaction, 
  onActionComplete,
  compact = false 
}: TransactionActionsProps) {
  const [loading, setLoading] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showRefundDialog, setShowRefundDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [refundAmount, setRefundAmount] = useState(transaction.amount);
  const [refundReason, setRefundReason] = useState('');

  // Helper function to handle any action
  const handleAction = async (
    actionFn: () => Promise<any>,
    successMessage: string,
    errorMessage: string
  ) => {
    setLoading(true);
    try {
      const response = await actionFn();
      
      if (response.success && response.data) {
        toast.success(successMessage);
        onActionComplete?.(response.data);
      } else {
        toast.error(response.error?.message || errorMessage);
      }
    } catch (error) {
      toast.error(errorMessage);
      console.error('Transaction action error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Specific action handlers
  const handleApprove = async () => {
    await handleAction(
      () => approveTransaction(transaction.id, 'Approved via dashboard'),
      'Transaction approved successfully',
      'Failed to approve transaction'
    );
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    await handleAction(
      () => rejectTransaction(transaction.id, rejectReason, 'Rejected via dashboard'),
      'Transaction rejected successfully',
      'Failed to reject transaction'
    );
    
    setShowRejectDialog(false);
    setRejectReason('');
  };

  const handleMarkPaid = async () => {
    await handleAction(
      () => markTransactionPaid(transaction.id, transaction.proof_image_url, 'Marked as paid via dashboard'),
      'Transaction marked as paid',
      'Failed to mark transaction as paid'
    );
  };

  const handleVerifyPayment = async (verified: boolean) => {
    await handleAction(
      () => verifyPayment(transaction.id, verified, verified ? 'Payment verified' : 'Payment verification failed'),
      verified ? 'Payment verified successfully' : 'Payment marked as unverified',
      'Failed to verify payment'
    );
  };

  const handleRefund = async () => {
    if (!refundReason.trim()) {
      toast.error('Please provide a refund reason');
      return;
    }

    if (refundAmount <= 0 || refundAmount > transaction.amount) {
      toast.error('Invalid refund amount');
      return;
    }

    await handleAction(
      () => refundTransaction(transaction.id, refundAmount, refundReason, 'Refunded via dashboard'),
      `Transaction refunded: ${refundAmount} ${transaction.currency}`,
      'Failed to refund transaction'
    );
    
    setShowRefundDialog(false);
    setRefundReason('');
    setRefundAmount(transaction.amount);
  };

  const handleCancel = async () => {
    await handleAction(
      () => cancelTransaction(transaction.id, 'Cancelled via dashboard', 'User cancelled transaction'),
      'Transaction cancelled successfully',
      'Failed to cancel transaction'
    );
  };

  // Example using the generic executeTransactionAction function
  const handleCustomAction = async (action: TransactionActionRequest['action']) => {
    await handleAction(
      () => executeTransactionAction(transaction.id, { 
        action, 
        notes: `Custom action: ${action} via dashboard` 
      }),
      `Transaction ${action} successfully`,
      `Failed to ${action} transaction`
    );
  };

  // Determine which actions are available based on transaction status
  const availableActions = {
    canApprove: ['pending', 'processing'].includes(transaction.status),
    canReject: ['pending', 'processing'].includes(transaction.status),
    canMarkPaid: transaction.status === 'processing',
    canVerify: transaction.status === 'paid' && transaction.proof_image_url,
    canRefund: ['paid', 'completed'].includes(transaction.status),
    canCancel: ['pending'].includes(transaction.status),
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        {availableActions.canApprove && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleApprove}
            disabled={loading}
            className="p-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 text-green-500 transition-colors disabled:opacity-50"
            title="Approve"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
          </motion.button>
        )}
        
        {availableActions.canReject && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowRejectDialog(true)}
            disabled={loading}
            className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-500 transition-colors disabled:opacity-50"
            title="Reject"
          >
            <XCircle className="w-4 h-4" />
          </motion.button>
        )}

        {availableActions.canRefund && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowRefundDialog(true)}
            disabled={loading}
            className="p-2 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-500 transition-colors disabled:opacity-50"
            title="Refund"
          >
            <RefreshCw className="w-4 h-4" />
          </motion.button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Action Buttons Grid */}
      <div className="grid grid-cols-2 gap-3">
        {availableActions.canApprove && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleApprove}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-green-500/20 hover:bg-green-500/30 text-green-500 font-medium transition-colors disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
            Approve
          </motion.button>
        )}

        {availableActions.canReject && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowRejectDialog(true)}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-500 font-medium transition-colors disabled:opacity-50"
          >
            <XCircle className="w-5 h-5" />
            Reject
          </motion.button>
        )}

        {availableActions.canMarkPaid && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleMarkPaid}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-500 font-medium transition-colors disabled:opacity-50"
          >
            <DollarSign className="w-5 h-5" />
            Mark Paid
          </motion.button>
        )}

        {availableActions.canVerify && (
          <>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleVerifyPayment(true)}
              disabled={loading}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-green-500/20 hover:bg-green-500/30 text-green-500 font-medium transition-colors disabled:opacity-50"
            >
              <CheckCircle className="w-5 h-5" />
              Verify Payment
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleVerifyPayment(false)}
              disabled={loading}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-500 font-medium transition-colors disabled:opacity-50"
            >
              <AlertCircle className="w-5 h-5" />
              Unverify
            </motion.button>
          </>
        )}

        {availableActions.canRefund && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowRefundDialog(true)}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-500 font-medium transition-colors disabled:opacity-50"
          >
            <RefreshCw className="w-5 h-5" />
            Refund
          </motion.button>
        )}

        {availableActions.canCancel && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleCancel}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gray-500/20 hover:bg-gray-500/30 text-gray-400 font-medium transition-colors disabled:opacity-50"
          >
            <Ban className="w-5 h-5" />
            Cancel
          </motion.button>
        )}
      </div>

      {/* Reject Dialog */}
      {showRejectDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#1a1d23] border border-white/10 rounded-2xl p-6 max-w-md w-full mx-4"
          >
            <h3 className="text-xl font-semibold text-white mb-4">Reject Transaction</h3>
            <p className="text-gray-400 text-sm mb-4">
              Transaction ID: <span className="text-white font-mono">{transaction.transaction_id}</span>
            </p>
            
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Enter rejection reason..."
              className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-red-500 transition-colors resize-none"
              rows={4}
            />

            <div className="flex gap-3 mt-4">
              <button
                onClick={() => {
                  setShowRejectDialog(false);
                  setRejectReason('');
                }}
                className="flex-1 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                disabled={loading || !rejectReason.trim()}
                className="flex-1 px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white font-medium transition-colors disabled:opacity-50"
              >
                {loading ? 'Rejecting...' : 'Reject Transaction'}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Refund Dialog */}
      {showRefundDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#1a1d23] border border-white/10 rounded-2xl p-6 max-w-md w-full mx-4"
          >
            <h3 className="text-xl font-semibold text-white mb-4">Refund Transaction</h3>
            <p className="text-gray-400 text-sm mb-4">
              Transaction ID: <span className="text-white font-mono">{transaction.transaction_id}</span>
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Refund Amount</label>
                <input
                  type="number"
                  value={refundAmount}
                  onChange={(e) => setRefundAmount(parseFloat(e.target.value) || 0)}
                  max={transaction.amount}
                  step="0.01"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-purple-500 transition-colors"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Maximum: {transaction.amount} {transaction.currency}
                </p>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2">Refund Reason</label>
                <textarea
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  placeholder="Enter refund reason..."
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-purple-500 transition-colors resize-none"
                  rows={3}
                />
              </div>
            </div>

            <div className="flex gap-3 mt-4">
              <button
                onClick={() => {
                  setShowRefundDialog(false);
                  setRefundReason('');
                  setRefundAmount(transaction.amount);
                }}
                className="flex-1 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleRefund}
                disabled={loading || !refundReason.trim() || refundAmount <= 0}
                className="flex-1 px-4 py-2 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-medium transition-colors disabled:opacity-50"
              >
                {loading ? 'Processing...' : 'Process Refund'}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Transaction Status Badge */}
      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
        <span className="text-sm text-gray-400">Current Status:</span>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase ${getStatusColor(transaction.status)}`}>
          {transaction.status}
        </span>
      </div>
    </div>
  );
}
