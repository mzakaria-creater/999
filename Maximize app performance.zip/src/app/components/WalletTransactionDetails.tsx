import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Eye, 
  Upload, 
  Download, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Smartphone,
  Calendar,
  User,
  DollarSign,
  Hash
} from 'lucide-react';
import { useState } from 'react';
import { GlassCard } from './GlassCard';
import { useLanguage } from '../context/LanguageContext';

type TransactionStatus = 'pending' | 'completed' | 'failed' | 'reviewing';

interface WalletTransactionDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: {
    id: string;
    phone: string;
    amount: string;
    provider: {
      name: string;
      nameAr: string;
      logo: string;
      color: string;
    };
    status: TransactionStatus;
    date: string;
    ussdCode: string;
  } | null;
}

export function WalletTransactionDetails({ isOpen, onClose, transaction }: WalletTransactionDetailsProps) {
  const { t, language } = useLanguage();
  const [status, setStatus] = useState<TransactionStatus>(transaction?.status || 'pending');
  const [proofImage, setProofImage] = useState<string | null>(null);
  const [showProofModal, setShowProofModal] = useState(false);

  if (!transaction) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const getStatusConfig = (currentStatus: TransactionStatus) => {
    switch (currentStatus) {
      case 'completed':
        return {
          icon: CheckCircle2,
          color: '#6ee7b7',
          bg: 'bg-[#6ee7b7]/10',
          border: 'border-[#6ee7b7]/30',
          text: t('walletTransaction.statusCompleted')
        };
      case 'failed':
        return {
          icon: XCircle,
          color: '#ef4444',
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          text: t('walletTransaction.statusFailed')
        };
      case 'reviewing':
        return {
          icon: AlertCircle,
          color: '#fbbf24',
          bg: 'bg-[#fbbf24]/10',
          border: 'border-[#fbbf24]/30',
          text: t('walletTransaction.statusReviewing')
        };
      default:
        return {
          icon: Clock,
          color: '#94a3b8',
          bg: 'bg-gray-500/10',
          border: 'border-gray-500/30',
          text: t('walletTransaction.statusPending')
        };
    }
  };

  const statusConfig = getStatusConfig(status);
  const StatusIcon = statusConfig.icon;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div 
                className="sticky top-0 z-10 p-6 border-b border-white/10 flex items-center justify-between"
                style={{
                  background: `linear-gradient(135deg, ${transaction.provider.color}20, ${transaction.provider.color}10)`
                }}
              >
                <div className="flex items-center gap-4">
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{ background: `linear-gradient(135deg, ${transaction.provider.color}, ${transaction.provider.color}dd)` }}
                  >
                    <img 
                      src={transaction.provider.logo} 
                      alt={language === 'ar' ? transaction.provider.nameAr : transaction.provider.name}
                      className="w-8 h-8 object-contain"
                    />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold text-white">
                      {t('walletTransaction.title')}
                    </h2>
                    <p className="text-sm text-gray-400">#{transaction.id}</p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6 space-y-6">
                {/* Transaction Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <Smartphone className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('walletTransaction.phoneNumber')}</span>
                    </div>
                    <p className="text-lg font-semibold text-white" dir="ltr">{transaction.phone}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('walletTransaction.amount')}</span>
                    </div>
                    <p className="text-lg font-semibold text-white">{transaction.amount} {t('walletTransaction.egp')}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('walletTransaction.provider')}</span>
                    </div>
                    <p className="text-lg font-semibold text-white">
                      {language === 'ar' ? transaction.provider.nameAr : transaction.provider.name}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">{t('walletTransaction.date')}</span>
                    </div>
                    <p className="text-lg font-semibold text-white">{transaction.date}</p>
                  </div>
                </div>

                {/* USSD Code */}
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <div className="flex items-center gap-2 mb-2">
                    <Hash className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-400">{t('walletTransaction.ussdCode')}</span>
                  </div>
                  <p className="font-mono text-white font-bold tracking-wider text-[16px]" dir="ltr">
                    {transaction.ussdCode}
                  </p>
                </div>

                {/* Status Change */}
                <div className="space-y-3">
                  <label className="text-sm text-gray-300 font-medium">
                    {t('walletTransaction.changeStatus')}
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {(['pending', 'reviewing', 'completed', 'failed'] as TransactionStatus[]).map((statusOption) => {
                      const config = getStatusConfig(statusOption);
                      const Icon = config.icon;
                      const isActive = status === statusOption;

                      return (
                        <motion.button
                          key={statusOption}
                          onClick={() => setStatus(statusOption)}
                          className={`p-3 rounded-xl border transition-all ${
                            isActive
                              ? `${config.bg} ${config.border}`
                              : 'bg-white/5 border-white/10 hover:bg-white/10'
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Icon 
                            className={`w-5 h-5 mx-auto mb-1`}
                            style={{ color: isActive ? config.color : '#94a3b8' }}
                          />
                          <p 
                            className={`text-xs font-medium ${isActive ? 'text-white' : 'text-gray-400'}`}
                          >
                            {config.text}
                          </p>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>

                {/* Current Status Display */}
                <div 
                  className={`p-4 rounded-xl border flex items-center gap-3 ${statusConfig.bg} ${statusConfig.border}`}
                >
                  <StatusIcon className="w-6 h-6" style={{ color: statusConfig.color }} />
                  <div className="flex-1">
                    <p className="text-sm text-gray-400">{t('walletTransaction.currentStatus')}</p>
                    <p className="text-lg font-semibold text-white">{statusConfig.text}</p>
                  </div>
                </div>

                {/* Payment Proof Section */}
                <div className="space-y-3">
                  <label className="text-sm text-gray-300 font-medium">
                    {t('walletTransaction.paymentProof')}
                  </label>

                  {proofImage ? (
                    <div className="relative p-4 rounded-xl bg-white/5 border border-white/10">
                      <img 
                        src={proofImage} 
                        alt="Payment Proof" 
                        className="w-full h-48 object-contain rounded-lg bg-white/5"
                      />
                      <div className="mt-3 flex gap-2">
                        <motion.button
                          onClick={() => setShowProofModal(true)}
                          className="flex-1 py-2 px-4 rounded-lg bg-[#3b82f6]/20 border border-[#3b82f6]/30 text-[#3b82f6] text-sm font-medium flex items-center justify-center gap-2"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Eye className="w-4 h-4" />
                          {t('walletTransaction.viewProof')}
                        </motion.button>
                        <motion.button
                          onClick={() => setProofImage(null)}
                          className="py-2 px-4 rounded-lg bg-red-500/20 border border-red-500/30 text-red-400 text-sm font-medium"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <X className="w-4 h-4" />
                        </motion.button>
                      </div>
                    </div>
                  ) : (
                    <label className="block">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <motion.div
                        className="p-8 rounded-xl border-2 border-dashed border-white/20 bg-white/5 cursor-pointer hover:bg-white/10 transition-colors"
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                      >
                        <Upload className="w-8 h-8 mx-auto mb-3 text-gray-400" />
                        <p className="text-center text-sm text-gray-300">
                          {t('walletTransaction.uploadProof')}
                        </p>
                        <p className="text-center text-xs text-gray-500 mt-1">
                          {t('walletTransaction.uploadHint')}
                        </p>
                      </motion.div>
                    </label>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4 border-t border-white/10">
                  <motion.button
                    onClick={onClose}
                    className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 font-medium hover:bg-white/10 transition-colors"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    {t('common.cancel')}
                  </motion.button>
                  <motion.button
                    className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-semibold"
                    whileHover={{ scale: 1.01, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
                    whileTap={{ scale: 0.99 }}
                  >
                    {t('walletTransaction.saveChanges')}
                  </motion.button>
                </div>
              </div>
            </GlassCard>
          </motion.div>

          {/* Proof Image Modal */}
          <AnimatePresence>
            {showProofModal && proofImage && (
              <>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setShowProofModal(false)}
                  className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60]"
                />
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="fixed inset-0 z-[60] flex items-center justify-center p-4"
                  onClick={() => setShowProofModal(false)}
                >
                  <div className="relative max-w-4xl max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
                    <img 
                      src={proofImage} 
                      alt="Payment Proof Full View" 
                      className="w-full h-full object-contain rounded-2xl"
                    />
                    <button
                      onClick={() => setShowProofModal(false)}
                      className="absolute top-4 right-4 p-3 rounded-full bg-black/50 backdrop-blur-sm hover:bg-black/70 transition-colors"
                    >
                      <X className="w-6 h-6 text-white" />
                    </button>
                    <motion.a
                      href={proofImage}
                      download="payment-proof.jpg"
                      className="absolute bottom-4 right-4 p-3 rounded-full bg-[#6ee7b7] hover:bg-[#5dd6a6] transition-colors"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Download className="w-6 h-6 text-[#121417]" />
                    </motion.a>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </>
      )}
    </AnimatePresence>
  );
}
