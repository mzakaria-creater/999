import { motion } from 'motion/react';
import { DesktopDetailsSidebar } from './DesktopDetailsSidebar';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Activity, DollarSign } from 'lucide-react';

interface WalletDetail {
  id: string;
  name: string;
  balance: number;
  currency: string;
  transactions24h: number;
  volumeChange: number;
  recentTransactions: Array<{
    id: string;
    type: 'credit' | 'debit';
    amount: number;
    description: string;
    time: string;
    status: 'completed' | 'pending';
  }>;
  monthlyStats: {
    totalIn: number;
    totalOut: number;
    netChange: number;
    avgTransaction: number;
  };
}

interface DashboardWalletSidebarProps {
  wallet: WalletDetail | null;
  onClose: () => void;
}

export function DashboardWalletSidebar({ wallet, onClose }: DashboardWalletSidebarProps) {
  if (!wallet) return null;

  return (
    <DesktopDetailsSidebar
      isOpen={!!wallet}
      onClose={onClose}
      title={wallet.name}
      icon="💰"
      subtitle={`${wallet.currency} Wallet • ${wallet.id}`}
    >
      {/* Balance Section */}
      <div className="mb-6 p-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 via-[#3b82f6]/20 to-[#06b6d4]/20 border border-white/10">
        <div className="text-sm text-gray-400 mb-2">Current Balance</div>
        <div className="text-4xl font-bold text-white mb-3">
          {wallet.currency} {wallet.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <div className="flex items-center gap-2">
          {wallet.volumeChange >= 0 ? (
            <>
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-green-400 text-sm font-semibold">+{wallet.volumeChange}%</span>
            </>
          ) : (
            <>
              <TrendingDown className="w-4 h-4 text-red-400" />
              <span className="text-red-400 text-sm font-semibold">{wallet.volumeChange}%</span>
            </>
          )}
          <span className="text-gray-400 text-sm">vs last month</span>
        </div>
      </div>

      {/* Monthly Stats */}
      <div className="mb-6">
        <div className="text-sm text-gray-400 uppercase tracking-wider mb-3">Monthly Summary</div>
        <div className="grid grid-cols-2 gap-3">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="p-4 rounded-xl bg-gradient-to-br from-green-500/10 to-green-600/5 border border-green-500/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <ArrowUpRight className="w-4 h-4 text-green-400" />
              <span className="text-xs text-gray-400">Total In</span>
            </div>
            <div className="text-xl font-bold text-green-400">
              {wallet.currency} {(wallet.monthlyStats.totalIn / 1000).toFixed(1)}K
            </div>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="p-4 rounded-xl bg-gradient-to-br from-red-500/10 to-red-600/5 border border-red-500/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <ArrowDownRight className="w-4 h-4 text-red-400" />
              <span className="text-xs text-gray-400">Total Out</span>
            </div>
            <div className="text-xl font-bold text-red-400">
              {wallet.currency} {(wallet.monthlyStats.totalOut / 1000).toFixed(1)}K
            </div>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="p-4 rounded-xl bg-gradient-to-br from-blue-500/10 to-blue-600/5 border border-blue-500/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-gray-400">Net Change</span>
            </div>
            <div className="text-xl font-bold text-blue-400">
              {wallet.currency} {(wallet.monthlyStats.netChange / 1000).toFixed(1)}K
            </div>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-purple-600/5 border border-purple-500/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-gray-400">Avg Transaction</span>
            </div>
            <div className="text-xl font-bold text-purple-400">
              {wallet.currency} {wallet.monthlyStats.avgTransaction.toLocaleString()}
            </div>
          </motion.div>
        </div>
      </div>

      {/* 24h Activity */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm text-gray-400 uppercase tracking-wider">Last 24 Hours</div>
          <div className="text-sm font-semibold text-white">{wallet.transactions24h} transactions</div>
        </div>
        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min((wallet.transactions24h / 100) * 100, 100)}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="h-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] rounded-full"
          />
        </div>
      </div>

      {/* Recent Transactions */}
      <div>
        <div className="text-sm text-gray-400 uppercase tracking-wider mb-3">Recent Transactions</div>
        <div className="space-y-2">
          {wallet.recentTransactions.map((tx, index) => (
            <motion.div
              key={tx.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {tx.type === 'credit' ? (
                    <div className="w-8 h-8 rounded-lg bg-green-500/20 border border-green-500/30 flex items-center justify-center">
                      <ArrowUpRight className="w-4 h-4 text-green-400" />
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-lg bg-red-500/20 border border-red-500/30 flex items-center justify-center">
                      <ArrowDownRight className="w-4 h-4 text-red-400" />
                    </div>
                  )}
                  <div>
                    <div className="text-sm font-medium text-white">{tx.description}</div>
                    <div className="text-xs text-gray-400">{tx.time}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-bold ${tx.type === 'credit' ? 'text-green-400' : 'text-red-400'}`}>
                    {tx.type === 'credit' ? '+' : '-'}{wallet.currency} {tx.amount.toLocaleString()}
                  </div>
                  <div className={`text-xs ${tx.status === 'completed' ? 'text-gray-400' : 'text-yellow-400'}`}>
                    {tx.status}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </DesktopDetailsSidebar>
  );
}
