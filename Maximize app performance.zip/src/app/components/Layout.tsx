import { Outlet, useNavigate, useLocation } from 'react-router';
import { Sidebar } from './Sidebar';
import { RoleSwitcher } from './RoleSwitcher';
import { LanguageSwitcher } from './LanguageSwitcher';
import { FxRateBar } from './FxRateBar';
import { useLanguage } from '../context/LanguageContext';
import { PageTransition } from './PageTransition';
import { motion } from 'motion/react';
import { useDeviceDetection } from '../hooks/useDeviceDetection';
import { useEffect } from 'react';

export function Layout() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const { isMobile } = useDeviceDetection();

  // Auto-redirect ONLY mobile devices (< 640px)
  useEffect(() => {
    if (isMobile && !location.pathname.startsWith('/mobile')) {
      navigate('/mobile/apps', { replace: true });
    }
  }, [isMobile, location.pathname, navigate]);

  const handleMobileView = () => {
    navigate('/mobile/apps');
  };

  return (
    <div className="flex h-screen w-screen bg-[#121417] overflow-hidden fixed inset-0">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* FX Rate Bar */}
        <FxRateBar />
        
        <header className="border-b border-white/10 bg-[#1a1d23]/50 backdrop-blur-sm px-4 sm:px-8 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-4">
            <div className="text-xs sm:text-sm text-gray-400">
              {t('header.date')}
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Mobile View Toggle Button */}
            <motion.button
              onClick={handleMobileView}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative group"
              title="Switch to Mobile View"
            >
              {/* Glassmorphic Button Container */}
              <div className="relative px-4 py-2.5 rounded-2xl backdrop-blur-2xl border shadow-lg overflow-hidden bg-gradient-to-t from-[#1a1d23] via-[#1a1d23]/98 to-[#1a1d23]/95 border-white/10">
                {/* Top Border Gradient */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                
                {/* Hover Glow Effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  initial={false}
                />
                
                {/* Content */}
                <div className="relative flex items-center gap-2">
                  <span className="text-xl">💻</span>
                  <span className="hidden sm:inline text-white text-sm font-medium">Mobile View</span>
                </div>
                
                {/* Active Indicator Dot */}
                <motion.div
                  className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-[#8b5cf6] rounded-full opacity-0 group-hover:opacity-100"
                  transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                />
              </div>
            </motion.button>
            <LanguageSwitcher />
            <RoleSwitcher />
          </div>
        </header>
        <main className="flex-1 overflow-y-auto overflow-x-hidden">
          <PageTransition type="slide">
            <Outlet />
          </PageTransition>
        </main>
      </div>
    </div>
  );
}