// Version marker to force cache refresh
export const APP_VERSION = '3.2.0';
export const BUILD_TIME = '2026-03-17T18:00:00.000Z';
export const PLATFORM_NAME = 'OnTarget PSP';
export const STATUS = 'Production Ready';

// Feature flags
export const FEATURES = {
  liveMonitor: true,
  workflowManager: true,
  mobileExperience: true,
  multiLanguage: true,
  realtimeUpdates: true,
  advancedAnimations: true,
  rbacSystem: true,
  apiIntegration: true,
  bulkImport: true,
  telegramPayments: true,
  binanceIntegration: true,
  liveRates: true,
  organizedSidebar: true,
} as const;

// Statistics
export const PLATFORM_STATS = {
  totalPages: 40,
  totalComponents: 50,
  workflows: 6,
  templates: 6,
  animations: 8,
  languages: 2,
  roles: 6,
  permissions: 16,
  paymentMethods: 6,
  linesOfCode: 15000,
  sidebarCategories: 11,
  sidebarItems: 25,
} as const;

// Release notes
export const RELEASE_NOTES = {
  'v3.2.0': {
    date: '2026-03-17',
    highlights: [
      'Complete sidebar reorganization',
      'All 40+ pages added to navigation',
      '11 organized categories',
      'Collapsible sub-menus',
      'Full translation support',
    ],
  },
  'v3.1.0': {
    date: '2026-03-17',
    highlights: [
      'Workflow Manager implementation',
      'Visual node-based editor',
      '6 pre-built automation workflows',
      '6 workflow templates',
      'Complete documentation update',
    ],
  },
  'v3.0.0': {
    date: '2026-03-17',
    highlights: [
      'Live Monitor as default homepage',
      'Real-time transaction feed',
      'System health monitoring',
      'Live statistics dashboard',
    ],
  },
  'v2.8.0': {
    date: '2026-03-17',
    highlights: [
      '11 new pages added',
      'Import Transactions',
      'Telegram Payments',
      'Live Exchange Rates',
      'Edit Role & Payment Method',
      'Table Transactions with pagination',
    ],
  },
} as const;
