import { RouterProvider } from 'react-router';
import { router } from './routes';
import { LanguageProvider } from './context/LanguageContext';
import { RoleProvider } from './context/RoleContext';
import { MobileThemeProvider } from './context/MobileThemeContext';
import { APP_VERSION, BUILD_TIME } from './version';

console.log('🚀 OnTarget PSP v' + APP_VERSION, 'Build:', BUILD_TIME);
console.log('✅ Providers loaded: Language, MobileTheme, Role');

export default function App() {
  return (
    <LanguageProvider>
      <MobileThemeProvider>
        <RoleProvider>
          <RouterProvider router={router} />
        </RoleProvider>
      </MobileThemeProvider>
    </LanguageProvider>
  );
}