/**
 * Exchange Rate Service
 * Fetches and manages currency exchange rates
 */

export interface ExchangeRate {
  base: string;
  target: string;
  rate: number;
  timestamp: Date;
  source: string;
}

export interface CurrencyPair {
  from: string;
  to: string;
  rate: number;
  buy: number;
  sell: number;
  lastUpdate: Date;
}

export interface RateHistory {
  date: Date;
  rate: number;
  high: number;
  low: number;
  volume?: number;
}

// Common currency pairs for Egyptian market
const COMMON_PAIRS = [
  'USD/EGP',
  'EUR/EGP',
  'GBP/EGP',
  'SAR/EGP',
  'AED/EGP',
  'USD/EUR',
  'USD/GBP'
];

class ExchangeRateService {
  private rates: Map<string, ExchangeRate> = new Map();
  private rateHistory: Map<string, RateHistory[]> = new Map();
  private updateInterval: number = 60000; // 1 minute
  private intervalId?: number;
  private customRates: Map<string, number> = new Map();

  constructor() {
    this.loadCustomRates();
    this.initializeDefaultRates();
    this.startAutoUpdate();
  }

  /**
   * Initialize with default/mock rates
   */
  private initializeDefaultRates(): void {
    const defaultRates: ExchangeRate[] = [
      { base: 'USD', target: 'EGP', rate: 52.50, timestamp: new Date(), source: 'manual' },
      { base: 'EUR', target: 'EGP', rate: 57.20, timestamp: new Date(), source: 'manual' },
      { base: 'GBP', target: 'EGP', rate: 66.80, timestamp: new Date(), source: 'manual' },
      { base: 'SAR', target: 'EGP', rate: 14.00, timestamp: new Date(), source: 'manual' },
      { base: 'AED', target: 'EGP', rate: 14.30, timestamp: new Date(), source: 'manual' },
      { base: 'USD', target: 'EUR', rate: 0.92, timestamp: new Date(), source: 'manual' },
      { base: 'USD', target: 'GBP', rate: 0.79, timestamp: new Date(), source: 'manual' },
    ];

    defaultRates.forEach(rate => {
      const key = `${rate.base}/${rate.target}`;
      this.rates.set(key, rate);
    });
  }

  /**
   * Load custom rates from localStorage
   */
  private loadCustomRates(): void {
    const stored = localStorage.getItem('custom_exchange_rates');
    if (stored) {
      const parsed = JSON.parse(stored);
      this.customRates = new Map(Object.entries(parsed));
    }
  }

  /**
   * Save custom rates to localStorage
   */
  private saveCustomRates(): void {
    const obj = Object.fromEntries(this.customRates);
    localStorage.setItem('custom_exchange_rates', JSON.stringify(obj));
  }

  /**
   * Get exchange rate for a currency pair
   */
  getRate(from: string, to: string): number {
    const key = `${from}/${to}`;
    
    // Check custom rates first
    if (this.customRates.has(key)) {
      return this.customRates.get(key)!;
    }

    // Check stored rates
    const rate = this.rates.get(key);
    if (rate) {
      return rate.rate;
    }

    // Try inverse rate
    const inverseKey = `${to}/${from}`;
    const inverseRate = this.rates.get(inverseKey);
    if (inverseRate) {
      return 1 / inverseRate.rate;
    }

    // If same currency
    if (from === to) {
      return 1;
    }

    throw new Error(`Exchange rate not found for ${from}/${to}`);
  }

  /**
   * Get rate with buy/sell spread
   */
  getRateWithSpread(from: string, to: string, spreadPercent: number = 0.5): CurrencyPair {
    const baseRate = this.getRate(from, to);
    const spread = baseRate * (spreadPercent / 100);

    return {
      from,
      to,
      rate: baseRate,
      buy: baseRate - spread,
      sell: baseRate + spread,
      lastUpdate: new Date()
    };
  }

  /**
   * Convert amount from one currency to another
   */
  convert(amount: number, from: string, to: string): number {
    const rate = this.getRate(from, to);
    return amount * rate;
  }

  /**
   * Set custom exchange rate
   */
  setCustomRate(from: string, to: string, rate: number): void {
    const key = `${from}/${to}`;
    this.customRates.set(key, rate);
    this.saveCustomRates();

    // Also update in rates map
    this.rates.set(key, {
      base: from,
      target: to,
      rate,
      timestamp: new Date(),
      source: 'custom'
    });
  }

  /**
   * Remove custom rate
   */
  removeCustomRate(from: string, to: string): void {
    const key = `${from}/${to}`;
    this.customRates.delete(key);
    this.saveCustomRates();
  }

  /**
   * Fetch live rates from API
   */
  async fetchLiveRates(apiKey?: string): Promise<void> {
    try {
      // Example: Using exchangerate-api.com
      // In production, use your preferred API
      if (!apiKey) {
        console.warn('No API key provided for live rates');
        return;
      }

      const baseCurrency = 'USD';
      const response = await fetch(
        `https://v6.exchangerate-api.com/v6/${apiKey}/latest/${baseCurrency}`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch exchange rates');
      }

      const data = await response.json();
      
      if (data.result === 'success') {
        const rates = data.conversion_rates;
        
        // Update rates
        Object.entries(rates).forEach(([currency, rate]) => {
          const key = `${baseCurrency}/${currency}`;
          this.rates.set(key, {
            base: baseCurrency,
            target: currency as string,
            rate: rate as number,
            timestamp: new Date(),
            source: 'api'
          });
        });

        console.log('Exchange rates updated successfully');
      }
    } catch (error) {
      console.error('Failed to fetch live rates:', error);
    }
  }

  /**
   * Get all available currency pairs
   */
  getAllPairs(): string[] {
    return Array.from(this.rates.keys());
  }

  /**
   * Get rate details
   */
  getRateDetails(from: string, to: string): ExchangeRate | null {
    const key = `${from}/${to}`;
    return this.rates.get(key) || null;
  }

  /**
   * Add rate to history
   */
  private addToHistory(pair: string, rate: number, high: number, low: number): void {
    if (!this.rateHistory.has(pair)) {
      this.rateHistory.set(pair, []);
    }

    const history = this.rateHistory.get(pair)!;
    history.push({
      date: new Date(),
      rate,
      high,
      low
    });

    // Keep only last 30 days
    if (history.length > 30) {
      history.shift();
    }
  }

  /**
   * Get rate history for a pair
   */
  getHistory(from: string, to: string, days: number = 7): RateHistory[] {
    const key = `${from}/${to}`;
    const history = this.rateHistory.get(key) || [];
    return history.slice(-days);
  }

  /**
   * Get trend for a currency pair
   */
  getTrend(from: string, to: string): 'up' | 'down' | 'stable' {
    const history = this.getHistory(from, to, 7);
    
    if (history.length < 2) {
      return 'stable';
    }

    const latest = history[history.length - 1].rate;
    const previous = history[0].rate;
    const change = ((latest - previous) / previous) * 100;

    if (change > 0.5) return 'up';
    if (change < -0.5) return 'down';
    return 'stable';
  }

  /**
   * Calculate percentage change
   */
  getChangePercent(from: string, to: string, days: number = 1): number {
    const history = this.getHistory(from, to, days + 1);
    
    if (history.length < 2) {
      return 0;
    }

    const latest = history[history.length - 1].rate;
    const previous = history[0].rate;
    return ((latest - previous) / previous) * 100;
  }

  /**
   * Start auto-update interval
   */
  startAutoUpdate(intervalMs: number = 60000): void {
    this.stopAutoUpdate();
    this.updateInterval = intervalMs;
    
    this.intervalId = window.setInterval(() => {
      this.updateRatesWithVariation();
    }, this.updateInterval);
  }

  /**
   * Stop auto-update
   */
  stopAutoUpdate(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = undefined;
    }
  }

  /**
   * Simulate rate updates with small variations
   */
  private updateRatesWithVariation(): void {
    this.rates.forEach((rate, key) => {
      if (rate.source === 'api' || rate.source === 'manual') {
        // Add small random variation (-0.1% to +0.1%)
        const variation = 1 + (Math.random() - 0.5) * 0.002;
        const newRate = rate.rate * variation;

        this.rates.set(key, {
          ...rate,
          rate: newRate,
          timestamp: new Date()
        });

        // Add to history
        const high = newRate * 1.001;
        const low = newRate * 0.999;
        this.addToHistory(key, newRate, high, low);
      }
    });
  }

  /**
   * Get popular pairs
   */
  getPopularPairs(): CurrencyPair[] {
    return COMMON_PAIRS.map(pair => {
      const [from, to] = pair.split('/');
      return this.getRateWithSpread(from, to);
    });
  }

  /**
   * Calculate cross rate (e.g., EUR/GBP via USD)
   */
  getCrossRate(from: string, to: string, via: string = 'USD'): number {
    try {
      return this.getRate(from, to);
    } catch {
      // Calculate via intermediate currency
      const fromToVia = this.getRate(from, via);
      const viaToTo = this.getRate(via, to);
      return fromToVia * viaToTo;
    }
  }

  /**
   * Get best rate from multiple sources
   */
  getBestRate(from: string, to: string, type: 'buy' | 'sell'): { rate: number; source: string } {
    const key = `${from}/${to}`;
    const rate = this.rates.get(key);

    if (!rate) {
      throw new Error(`Rate not found for ${from}/${to}`);
    }

    const withSpread = this.getRateWithSpread(from, to);
    const bestRate = type === 'buy' ? withSpread.buy : withSpread.sell;

    return {
      rate: bestRate,
      source: rate.source
    };
  }

  /**
   * Bulk convert multiple amounts
   */
  bulkConvert(amounts: { amount: number; from: string; to: string }[]): number[] {
    return amounts.map(({ amount, from, to }) => this.convert(amount, from, to));
  }

  /**
   * Get market summary
   */
  getMarketSummary() {
    const pairs = this.getPopularPairs();
    
    return {
      totalPairs: this.rates.size,
      lastUpdate: new Date(),
      topMovers: pairs
        .map(pair => ({
          pair: `${pair.from}/${pair.to}`,
          rate: pair.rate,
          change: this.getChangePercent(pair.from, pair.to, 1)
        }))
        .sort((a, b) => Math.abs(b.change) - Math.abs(a.change))
        .slice(0, 5)
    };
  }
}

// Export singleton instance
export const exchangeRateService = new ExchangeRateService();
