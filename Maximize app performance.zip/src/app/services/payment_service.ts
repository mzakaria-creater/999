/**
 * Payment Service
 * Unified payment processing for multiple providers
 */

export type PaymentProvider = 'paypal' | 'binance' | 'okx' | 'vodafone' | 'instapay';

export interface PaymentMethod {
  id: PaymentProvider;
  name: string;
  displayName: string;
  logo: string;
  enabled: boolean;
  fees: {
    fixed: number;
    percentage: number;
  };
  limits: {
    min: number;
    max: number;
  };
  currencies: string[];
  processingTime: string;
  description: string;
}

export interface PaymentRequest {
  id: string;
  amount: number;
  currency: string;
  provider: PaymentProvider;
  merchantId: string;
  customerEmail?: string;
  customerPhone?: string;
  description: string;
  metadata?: Record<string, any>;
  returnUrl?: string;
  cancelUrl?: string;
  webhookUrl?: string;
}

export interface PaymentResponse {
  success: boolean;
  transactionId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  amount: number;
  currency: string;
  provider: PaymentProvider;
  paymentUrl?: string;
  qrCode?: string;
  reference?: string;
  message: string;
  timestamp: Date;
  error?: string;
}

export interface Transaction {
  id: string;
  amount: number;
  currency: string;
  provider: PaymentProvider;
  status: PaymentResponse['status'];
  customerEmail?: string;
  customerPhone?: string;
  description: string;
  createdAt: Date;
  completedAt?: Date;
  metadata?: Record<string, any>;
}

// Payment methods configuration
const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'paypal',
    name: 'PayPal',
    displayName: 'PayPal',
    logo: '💳',
    enabled: true,
    fees: {
      fixed: 0.30,
      percentage: 2.9
    },
    limits: {
      min: 1,
      max: 10000
    },
    currencies: ['USD', 'EUR', 'GBP', 'EGP'],
    processingTime: 'Instant',
    description: 'Pay securely with your PayPal account'
  },
  {
    id: 'binance',
    name: 'Binance Pay',
    displayName: 'Binance Pay',
    logo: '₿',
    enabled: true,
    fees: {
      fixed: 0,
      percentage: 0
    },
    limits: {
      min: 10,
      max: 100000
    },
    currencies: ['USDT', 'BUSD', 'BTC', 'ETH', 'BNB'],
    processingTime: '1-3 minutes',
    description: 'Pay with cryptocurrency via Binance'
  },
  {
    id: 'okx',
    name: 'OKX',
    displayName: 'OKX Pay',
    logo: '🔷',
    enabled: true,
    fees: {
      fixed: 0,
      percentage: 0.1
    },
    limits: {
      min: 10,
      max: 50000
    },
    currencies: ['USDT', 'USDC', 'BTC', 'ETH'],
    processingTime: '1-5 minutes',
    description: 'Fast crypto payments with OKX'
  },
  {
    id: 'vodafone',
    name: 'Vodafone Cash',
    displayName: 'Vodafone Cash',
    logo: '📱',
    enabled: true,
    fees: {
      fixed: 0,
      percentage: 1.5
    },
    limits: {
      min: 10,
      max: 6000
    },
    currencies: ['EGP'],
    processingTime: 'Instant',
    description: 'Pay with Vodafone Cash mobile wallet'
  },
  {
    id: 'instapay',
    name: 'InstaPay',
    displayName: 'InstaPay',
    logo: '⚡',
    enabled: true,
    fees: {
      fixed: 0,
      percentage: 0.5
    },
    limits: {
      min: 1,
      max: 5000
    },
    currencies: ['EGP'],
    processingTime: 'Instant',
    description: 'Instant bank transfers in Egypt'
  }
];

class PaymentService {
  private transactions: Map<string, Transaction> = new Map();
  private apiKeys: Map<PaymentProvider, string> = new Map();

  constructor() {
    this.loadTransactions();
    this.loadApiKeys();
  }

  /**
   * Load transactions from localStorage
   */
  private loadTransactions(): void {
    const stored = localStorage.getItem('payment_transactions');
    if (stored) {
      const parsed = JSON.parse(stored);
      this.transactions = new Map(
        parsed.map((t: any) => [
          t.id,
          {
            ...t,
            createdAt: new Date(t.createdAt),
            completedAt: t.completedAt ? new Date(t.completedAt) : undefined
          }
        ])
      );
    }
  }

  /**
   * Save transactions to localStorage
   */
  private saveTransactions(): void {
    const array = Array.from(this.transactions.values());
    localStorage.setItem('payment_transactions', JSON.stringify(array));
  }

  /**
   * Load API keys from localStorage
   */
  private loadApiKeys(): void {
    const stored = localStorage.getItem('payment_api_keys');
    if (stored) {
      const parsed = JSON.parse(stored);
      this.apiKeys = new Map(Object.entries(parsed));
    }
  }

  /**
   * Save API keys to localStorage
   */
  private saveApiKeys(): void {
    const obj = Object.fromEntries(this.apiKeys);
    localStorage.setItem('payment_api_keys', JSON.stringify(obj));
  }

  /**
   * Get all payment methods
   */
  getPaymentMethods(currency?: string): PaymentMethod[] {
    let methods = PAYMENT_METHODS.filter(m => m.enabled);
    
    if (currency) {
      methods = methods.filter(m => m.currencies.includes(currency));
    }

    return methods;
  }

  /**
   * Get specific payment method
   */
  getPaymentMethod(provider: PaymentProvider): PaymentMethod | null {
    return PAYMENT_METHODS.find(m => m.id === provider) || null;
  }

  /**
   * Set API key for a provider
   */
  setApiKey(provider: PaymentProvider, apiKey: string): void {
    this.apiKeys.set(provider, apiKey);
    this.saveApiKeys();
  }

  /**
   * Get API key for a provider
   */
  getApiKey(provider: PaymentProvider): string | null {
    return this.apiKeys.get(provider) || null;
  }

  /**
   * Calculate fees for a payment
   */
  calculateFees(amount: number, provider: PaymentProvider): number {
    const method = this.getPaymentMethod(provider);
    if (!method) return 0;

    const percentageFee = (amount * method.fees.percentage) / 100;
    const totalFee = method.fees.fixed + percentageFee;
    
    return parseFloat(totalFee.toFixed(2));
  }

  /**
   * Calculate total amount including fees
   */
  calculateTotal(amount: number, provider: PaymentProvider): number {
    const fees = this.calculateFees(amount, provider);
    return parseFloat((amount + fees).toFixed(2));
  }

  /**
   * Validate payment request
   */
  private validatePayment(request: PaymentRequest): { valid: boolean; error?: string } {
    const method = this.getPaymentMethod(request.provider);

    if (!method) {
      return { valid: false, error: 'Invalid payment provider' };
    }

    if (!method.enabled) {
      return { valid: false, error: 'Payment method is disabled' };
    }

    if (!method.currencies.includes(request.currency)) {
      return { valid: false, error: `Currency ${request.currency} not supported` };
    }

    if (request.amount < method.limits.min) {
      return { valid: false, error: `Minimum amount is ${method.limits.min} ${request.currency}` };
    }

    if (request.amount > method.limits.max) {
      return { valid: false, error: `Maximum amount is ${method.limits.max} ${request.currency}` };
    }

    return { valid: true };
  }

  /**
   * Process PayPal payment
   */
  private async processPayPal(request: PaymentRequest): Promise<PaymentResponse> {
    // In production, integrate with PayPal API
    // https://developer.paypal.com/docs/api/orders/v2/
    
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      transactionId: `pp_${Date.now()}`,
      status: 'pending',
      amount: request.amount,
      currency: request.currency,
      provider: 'paypal',
      paymentUrl: `https://www.paypal.com/checkoutnow?token=MOCK_${request.id}`,
      message: 'Redirecting to PayPal...',
      timestamp: new Date()
    };
  }

  /**
   * Process Binance Pay payment
   */
  private async processBinance(request: PaymentRequest): Promise<PaymentResponse> {
    // In production, integrate with Binance Pay API
    // https://developers.binance.com/docs/binance-pay/introduction
    
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      transactionId: `bnb_${Date.now()}`,
      status: 'pending',
      amount: request.amount,
      currency: request.currency,
      provider: 'binance',
      qrCode: `BINANCE:${request.merchantId}:${request.amount}:${request.currency}`,
      reference: `BNB${Date.now()}`,
      message: 'Scan QR code with Binance app',
      timestamp: new Date()
    };
  }

  /**
   * Process OKX payment
   */
  private async processOKX(request: PaymentRequest): Promise<PaymentResponse> {
    // In production, integrate with OKX Pay API
    
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      transactionId: `okx_${Date.now()}`,
      status: 'pending',
      amount: request.amount,
      currency: request.currency,
      provider: 'okx',
      qrCode: `OKX:${request.merchantId}:${request.amount}:${request.currency}`,
      reference: `OKX${Date.now()}`,
      message: 'Scan QR code with OKX app',
      timestamp: new Date()
    };
  }

  /**
   * Process Vodafone Cash payment
   */
  private async processVodafone(request: PaymentRequest): Promise<PaymentResponse> {
    // In production, integrate with Vodafone Cash API
    
    if (!request.customerPhone) {
      return {
        success: false,
        transactionId: '',
        status: 'failed',
        amount: request.amount,
        currency: request.currency,
        provider: 'vodafone',
        message: 'Phone number required for Vodafone Cash',
        timestamp: new Date(),
        error: 'Missing phone number'
      };
    }

    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      transactionId: `vf_${Date.now()}`,
      status: 'pending',
      amount: request.amount,
      currency: request.currency,
      provider: 'vodafone',
      reference: `*9*${request.amount}#`,
      message: `Dial *9*${request.amount}# to complete payment`,
      timestamp: new Date()
    };
  }

  /**
   * Process InstaPay payment
   */
  private async processInstaPay(request: PaymentRequest): Promise<PaymentResponse> {
    // In production, integrate with InstaPay API
    
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      transactionId: `ip_${Date.now()}`,
      status: 'pending',
      amount: request.amount,
      currency: request.currency,
      provider: 'instapay',
      reference: `IP${Date.now()}`,
      message: 'Use your banking app to complete InstaPay transfer',
      timestamp: new Date()
    };
  }

  /**
   * Create payment
   */
  async createPayment(request: PaymentRequest): Promise<PaymentResponse> {
    // Validate request
    const validation = this.validatePayment(request);
    if (!validation.valid) {
      return {
        success: false,
        transactionId: '',
        status: 'failed',
        amount: request.amount,
        currency: request.currency,
        provider: request.provider,
        message: validation.error || 'Validation failed',
        timestamp: new Date(),
        error: validation.error
      };
    }

    try {
      let response: PaymentResponse;

      // Route to appropriate processor
      switch (request.provider) {
        case 'paypal':
          response = await this.processPayPal(request);
          break;
        case 'binance':
          response = await this.processBinance(request);
          break;
        case 'okx':
          response = await this.processOKX(request);
          break;
        case 'vodafone':
          response = await this.processVodafone(request);
          break;
        case 'instapay':
          response = await this.processInstaPay(request);
          break;
        default:
          throw new Error('Unsupported payment provider');
      }

      // Save transaction
      if (response.success) {
        const transaction: Transaction = {
          id: response.transactionId,
          amount: request.amount,
          currency: request.currency,
          provider: request.provider,
          status: response.status,
          customerEmail: request.customerEmail,
          customerPhone: request.customerPhone,
          description: request.description,
          createdAt: new Date(),
          metadata: request.metadata
        };

        this.transactions.set(transaction.id, transaction);
        this.saveTransactions();
      }

      return response;
    } catch (error) {
      return {
        success: false,
        transactionId: '',
        status: 'failed',
        amount: request.amount,
        currency: request.currency,
        provider: request.provider,
        message: 'Payment processing failed',
        timestamp: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Get transaction by ID
   */
  getTransaction(transactionId: string): Transaction | null {
    return this.transactions.get(transactionId) || null;
  }

  /**
   * Get all transactions
   */
  getAllTransactions(): Transaction[] {
    return Array.from(this.transactions.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  /**
   * Update transaction status
   */
  updateTransactionStatus(
    transactionId: string,
    status: Transaction['status']
  ): boolean {
    const transaction = this.transactions.get(transactionId);
    if (!transaction) return false;

    transaction.status = status;
    if (status === 'completed') {
      transaction.completedAt = new Date();
    }

    this.transactions.set(transactionId, transaction);
    this.saveTransactions();
    return true;
  }

  /**
   * Get transaction statistics
   */
  getStatistics() {
    const transactions = this.getAllTransactions();

    return {
      total: transactions.length,
      pending: transactions.filter(t => t.status === 'pending').length,
      completed: transactions.filter(t => t.status === 'completed').length,
      failed: transactions.filter(t => t.status === 'failed').length,
      totalAmount: transactions
        .filter(t => t.status === 'completed')
        .reduce((sum, t) => sum + t.amount, 0),
      byProvider: PAYMENT_METHODS.map(method => ({
        provider: method.id,
        name: method.displayName,
        count: transactions.filter(t => t.provider === method.id).length,
        amount: transactions
          .filter(t => t.provider === method.id && t.status === 'completed')
          .reduce((sum, t) => sum + t.amount, 0)
      }))
    };
  }

  /**
   * Verify payment (webhook simulation)
   */
  async verifyPayment(transactionId: string): Promise<boolean> {
    // In production, verify with payment provider
    await new Promise(resolve => setTimeout(resolve, 500));

    // Simulate random success
    const success = Math.random() > 0.1; // 90% success rate
    
    if (success) {
      this.updateTransactionStatus(transactionId, 'completed');
    } else {
      this.updateTransactionStatus(transactionId, 'failed');
    }

    return success;
  }

  /**
   * Cancel payment
   */
  cancelPayment(transactionId: string): boolean {
    return this.updateTransactionStatus(transactionId, 'cancelled');
  }
}

// Export singleton instance
export const paymentService = new PaymentService();
