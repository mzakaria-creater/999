/**
 * Crypto Price Service
 * Fetches and manages cryptocurrency prices
 */

export interface CryptoPrice {
  symbol: string;
  name: string;
  price: number;
  priceChange24h: number;
  priceChangePercent24h: number;
  volume24h: number;
  marketCap: number;
  high24h: number;
  low24h: number;
  lastUpdate: Date;
}

export interface PriceAlert {
  id: string;
  symbol: string;
  condition: 'above' | 'below';
  targetPrice: number;
  active: boolean;
  createdAt: Date;
  triggeredAt?: Date;
}

export interface ChartDataPoint {
  timestamp: Date;
  price: number;
  volume: number;
}

// Popular cryptocurrencies
const POPULAR_CRYPTOS = [
  { symbol: 'BTC', name: 'Bitcoin' },
  { symbol: 'ETH', name: 'Ethereum' },
  { symbol: 'BNB', name: 'Binance Coin' },
  { symbol: 'USDT', name: 'Tether' },
  { symbol: 'USDC', name: 'USD Coin' },
  { symbol: 'XRP', name: 'Ripple' },
  { symbol: 'ADA', name: 'Cardano' },
  { symbol: 'SOL', name: 'Solana' },
  { symbol: 'DOGE', name: 'Dogecoin' },
  { symbol: 'TRX', name: 'TRON' },
  { symbol: 'DOT', name: 'Polkadot' },
  { symbol: 'MATIC', name: 'Polygon' }
];

class CryptoPriceService {
  private prices: Map<string, CryptoPrice> = new Map();
  private priceHistory: Map<string, ChartDataPoint[]> = new Map();
  private alerts: PriceAlert[] = [];
  private updateInterval: number = 30000; // 30 seconds
  private intervalId?: number;
  private apiBaseUrl: string = 'https://api.binance.com/api/v3';

  constructor() {
    this.loadAlerts();
    this.initializeDefaultPrices();
    this.startAutoUpdate();
  }

  /**
   * Initialize with default/mock prices
   */
  private initializeDefaultPrices(): void {
    const defaultPrices: CryptoPrice[] = [
      {
        symbol: 'BTC',
        name: 'Bitcoin',
        price: 68500,
        priceChange24h: 1250,
        priceChangePercent24h: 1.86,
        volume24h: 28500000000,
        marketCap: 1340000000000,
        high24h: 69200,
        low24h: 66800,
        lastUpdate: new Date()
      },
      {
        symbol: 'ETH',
        name: 'Ethereum',
        price: 3450,
        priceChange24h: -85,
        priceChangePercent24h: -2.40,
        volume24h: 15200000000,
        marketCap: 415000000000,
        high24h: 3580,
        low24h: 3420,
        lastUpdate: new Date()
      },
      {
        symbol: 'BNB',
        name: 'Binance Coin',
        price: 425,
        priceChange24h: 12,
        priceChangePercent24h: 2.90,
        volume24h: 1250000000,
        marketCap: 63500000000,
        high24h: 432,
        low24h: 410,
        lastUpdate: new Date()
      },
      {
        symbol: 'USDT',
        name: 'Tether',
        price: 1.00,
        priceChange24h: 0,
        priceChangePercent24h: 0.01,
        volume24h: 45000000000,
        marketCap: 95000000000,
        high24h: 1.001,
        low24h: 0.999,
        lastUpdate: new Date()
      },
      {
        symbol: 'SOL',
        name: 'Solana',
        price: 145,
        priceChange24h: 8.5,
        priceChangePercent24h: 6.23,
        volume24h: 2800000000,
        marketCap: 65000000000,
        high24h: 148,
        low24h: 135,
        lastUpdate: new Date()
      }
    ];

    defaultPrices.forEach(price => {
      this.prices.set(price.symbol, price);
    });
  }

  /**
   * Load alerts from localStorage
   */
  private loadAlerts(): void {
    const stored = localStorage.getItem('crypto_price_alerts');
    if (stored) {
      this.alerts = JSON.parse(stored).map((alert: any) => ({
        ...alert,
        createdAt: new Date(alert.createdAt),
        triggeredAt: alert.triggeredAt ? new Date(alert.triggeredAt) : undefined
      }));
    }
  }

  /**
   * Save alerts to localStorage
   */
  private saveAlerts(): void {
    localStorage.setItem('crypto_price_alerts', JSON.stringify(this.alerts));
  }

  /**
   * Get price for a cryptocurrency
   */
  getPrice(symbol: string): CryptoPrice | null {
    return this.prices.get(symbol.toUpperCase()) || null;
  }

  /**
   * Get all prices
   */
  getAllPrices(): CryptoPrice[] {
    return Array.from(this.prices.values());
  }

  /**
   * Get popular cryptocurrencies with prices
   */
  getPopularCryptos(): CryptoPrice[] {
    return POPULAR_CRYPTOS.map(crypto => {
      return this.prices.get(crypto.symbol) || {
        symbol: crypto.symbol,
        name: crypto.name,
        price: 0,
        priceChange24h: 0,
        priceChangePercent24h: 0,
        volume24h: 0,
        marketCap: 0,
        high24h: 0,
        low24h: 0,
        lastUpdate: new Date()
      };
    }).filter(price => price.price > 0);
  }

  /**
   * Fetch live prices from Binance API
   */
  async fetchLivePrices(symbols?: string[]): Promise<void> {
    try {
      const targetSymbols = symbols || POPULAR_CRYPTOS.map(c => c.symbol);
      
      // Fetch 24h ticker data from Binance
      const response = await fetch(`${this.apiBaseUrl}/ticker/24hr`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch crypto prices');
      }

      const data = await response.json();
      
      // Process data for requested symbols
      data.forEach((ticker: any) => {
        // Binance uses USDT pairs (e.g., BTCUSDT)
        const symbol = ticker.symbol.replace('USDT', '');
        
        if (targetSymbols.includes(symbol)) {
          const crypto = POPULAR_CRYPTOS.find(c => c.symbol === symbol);
          
          this.prices.set(symbol, {
            symbol,
            name: crypto?.name || symbol,
            price: parseFloat(ticker.lastPrice),
            priceChange24h: parseFloat(ticker.priceChange),
            priceChangePercent24h: parseFloat(ticker.priceChangePercent),
            volume24h: parseFloat(ticker.volume) * parseFloat(ticker.lastPrice),
            marketCap: 0, // Not provided by this endpoint
            high24h: parseFloat(ticker.highPrice),
            low24h: parseFloat(ticker.lowPrice),
            lastUpdate: new Date()
          });

          // Add to history
          this.addToHistory(symbol, parseFloat(ticker.lastPrice), parseFloat(ticker.volume));
        }
      });

      console.log('Crypto prices updated successfully');
      this.checkAlerts();
    } catch (error) {
      console.error('Failed to fetch crypto prices:', error);
      // Fall back to simulated updates
      this.updatePricesWithVariation();
    }
  }

  /**
   * Fetch historical data for charting
   */
  async fetchHistoricalData(
    symbol: string, 
    interval: '1m' | '5m' | '15m' | '1h' | '4h' | '1d' = '1h',
    limit: number = 24
  ): Promise<ChartDataPoint[]> {
    try {
      const pair = `${symbol.toUpperCase()}USDT`;
      const response = await fetch(
        `${this.apiBaseUrl}/klines?symbol=${pair}&interval=${interval}&limit=${limit}`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch historical data');
      }

      const data = await response.json();
      
      return data.map((candle: any) => ({
        timestamp: new Date(candle[0]),
        price: parseFloat(candle[4]), // Close price
        volume: parseFloat(candle[5])
      }));
    } catch (error) {
      console.error('Failed to fetch historical data:', error);
      return this.priceHistory.get(symbol) || [];
    }
  }

  /**
   * Add price to history
   */
  private addToHistory(symbol: string, price: number, volume: number): void {
    if (!this.priceHistory.has(symbol)) {
      this.priceHistory.set(symbol, []);
    }

    const history = this.priceHistory.get(symbol)!;
    history.push({
      timestamp: new Date(),
      price,
      volume
    });

    // Keep only last 100 data points
    if (history.length > 100) {
      history.shift();
    }
  }

  /**
   * Get price history
   */
  getHistory(symbol: string, hours: number = 24): ChartDataPoint[] {
    const history = this.priceHistory.get(symbol) || [];
    const pointsPerHour = Math.max(1, Math.floor(60 / (this.updateInterval / 60000)));
    const totalPoints = hours * pointsPerHour;
    return history.slice(-totalPoints);
  }

  /**
   * Convert crypto to fiat
   */
  convertToFiat(amount: number, cryptoSymbol: string, fiatCurrency: string = 'USD'): number {
    const crypto = this.getPrice(cryptoSymbol);
    if (!crypto) {
      throw new Error(`Price not found for ${cryptoSymbol}`);
    }

    let usdValue = amount * crypto.price;

    // If target is not USD, convert
    if (fiatCurrency !== 'USD') {
      // This would integrate with exchange rate service
      // For now, using simple conversions
      const conversionRates: Record<string, number> = {
        'EGP': 52.50,
        'EUR': 0.92,
        'GBP': 0.79
      };

      if (conversionRates[fiatCurrency]) {
        usdValue *= conversionRates[fiatCurrency];
      }
    }

    return usdValue;
  }

  /**
   * Convert fiat to crypto
   */
  convertFromFiat(amount: number, fiatCurrency: string, cryptoSymbol: string): number {
    const crypto = this.getPrice(cryptoSymbol);
    if (!crypto) {
      throw new Error(`Price not found for ${cryptoSymbol}`);
    }

    let usdValue = amount;

    // Convert fiat to USD first
    if (fiatCurrency !== 'USD') {
      const conversionRates: Record<string, number> = {
        'EGP': 52.50,
        'EUR': 0.92,
        'GBP': 0.79
      };

      if (conversionRates[fiatCurrency]) {
        usdValue = amount / conversionRates[fiatCurrency];
      }
    }

    return usdValue / crypto.price;
  }

  /**
   * Create price alert
   */
  createAlert(symbol: string, condition: 'above' | 'below', targetPrice: number): PriceAlert {
    const alert: PriceAlert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      symbol: symbol.toUpperCase(),
      condition,
      targetPrice,
      active: true,
      createdAt: new Date()
    };

    this.alerts.push(alert);
    this.saveAlerts();
    return alert;
  }

  /**
   * Get all alerts
   */
  getAlerts(activeOnly: boolean = false): PriceAlert[] {
    return activeOnly 
      ? this.alerts.filter(a => a.active)
      : this.alerts;
  }

  /**
   * Delete alert
   */
  deleteAlert(alertId: string): void {
    this.alerts = this.alerts.filter(a => a.id !== alertId);
    this.saveAlerts();
  }

  /**
   * Check if any alerts should trigger
   */
  private checkAlerts(): void {
    this.alerts.forEach(alert => {
      if (!alert.active) return;

      const price = this.getPrice(alert.symbol);
      if (!price) return;

      let shouldTrigger = false;

      if (alert.condition === 'above' && price.price >= alert.targetPrice) {
        shouldTrigger = true;
      } else if (alert.condition === 'below' && price.price <= alert.targetPrice) {
        shouldTrigger = true;
      }

      if (shouldTrigger) {
        alert.active = false;
        alert.triggeredAt = new Date();
        this.saveAlerts();

        // Trigger notification (browser notification API)
        this.notifyAlert(alert, price.price);
      }
    });
  }

  /**
   * Send notification for triggered alert
   */
  private notifyAlert(alert: PriceAlert, currentPrice: number): void {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(`${alert.symbol} Price Alert`, {
        body: `${alert.symbol} is now ${alert.condition} ${alert.targetPrice}. Current price: $${currentPrice.toFixed(2)}`,
        icon: '/favicon.ico'
      });
    }
  }

  /**
   * Request notification permission
   */
  async requestNotificationPermission(): Promise<boolean> {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  }

  /**
   * Start auto-update interval
   */
  startAutoUpdate(intervalMs: number = 30000): void {
    this.stopAutoUpdate();
    this.updateInterval = intervalMs;
    
    this.intervalId = window.setInterval(() => {
      this.fetchLivePrices();
    }, this.updateInterval);

    // Initial fetch
    this.fetchLivePrices();
  }

  /**
   * Stop auto-update
   */
  stopAutoUpdate(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = undefined;
    }
  }

  /**
   * Simulate price updates with variations
   */
  private updatePricesWithVariation(): void {
    this.prices.forEach((price, symbol) => {
      // Add random variation (-2% to +2%)
      const variation = 1 + (Math.random() - 0.5) * 0.04;
      const newPrice = price.price * variation;
      const priceChange = newPrice - price.price;
      const changePercent = (priceChange / price.price) * 100;

      this.prices.set(symbol, {
        ...price,
        price: newPrice,
        priceChange24h: priceChange,
        priceChangePercent24h: changePercent,
        lastUpdate: new Date()
      });

      this.addToHistory(symbol, newPrice, price.volume24h);
    });

    this.checkAlerts();
  }

  /**
   * Get top gainers
   */
  getTopGainers(limit: number = 5): CryptoPrice[] {
    return this.getAllPrices()
      .sort((a, b) => b.priceChangePercent24h - a.priceChangePercent24h)
      .slice(0, limit);
  }

  /**
   * Get top losers
   */
  getTopLosers(limit: number = 5): CryptoPrice[] {
    return this.getAllPrices()
      .sort((a, b) => a.priceChangePercent24h - b.priceChangePercent24h)
      .slice(0, limit);
  }

  /**
   * Get market statistics
   */
  getMarketStats() {
    const prices = this.getAllPrices();
    
    return {
      totalMarketCap: prices.reduce((sum, p) => sum + p.marketCap, 0),
      total24hVolume: prices.reduce((sum, p) => sum + p.volume24h, 0),
      btcDominance: prices.find(p => p.symbol === 'BTC')?.marketCap || 0,
      activeCoins: prices.length,
      gainers: prices.filter(p => p.priceChangePercent24h > 0).length,
      losers: prices.filter(p => p.priceChangePercent24h < 0).length
    };
  }

  /**
   * Search cryptocurrencies
   */
  search(query: string): CryptoPrice[] {
    const lowerQuery = query.toLowerCase();
    return this.getAllPrices().filter(price => 
      price.symbol.toLowerCase().includes(lowerQuery) ||
      price.name.toLowerCase().includes(lowerQuery)
    );
  }

  /**
   * Calculate portfolio value
   */
  calculatePortfolio(holdings: { symbol: string; amount: number }[]): {
    total: number;
    holdings: { symbol: string; amount: number; value: number; change24h: number }[];
  } {
    const portfolioHoldings = holdings.map(holding => {
      const price = this.getPrice(holding.symbol);
      const value = price ? holding.amount * price.price : 0;
      const change24h = price ? holding.amount * price.priceChange24h : 0;

      return {
        symbol: holding.symbol,
        amount: holding.amount,
        value,
        change24h
      };
    });

    const total = portfolioHoldings.reduce((sum, h) => sum + h.value, 0);

    return {
      total,
      holdings: portfolioHoldings
    };
  }
}

// Export singleton instance
export const cryptoPriceService = new CryptoPriceService();
