/**
 * Automated Withdrawals Service
 * Handles automatic withdrawal processing with configurable rules
 */

export interface WithdrawalRule {
  id: string;
  name: string;
  enabled: boolean;
  minAmount: number;
  maxAmount: number;
  currency: string;
  paymentMethod: string;
  autoApprove: boolean;
  priority: 'low' | 'medium' | 'high';
  conditions: {
    timeWindow?: { start: string; end: string };
    maxDailyAmount?: number;
    merchantWhitelist?: string[];
    requiresKYC?: boolean;
  };
}

export interface WithdrawalRequest {
  id: string;
  merchantId: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  destination: string;
  requestedAt: Date;
  status: 'pending' | 'approved' | 'processing' | 'completed' | 'rejected' | 'failed';
  metadata?: Record<string, any>;
}

export interface ProcessingResult {
  success: boolean;
  withdrawalId: string;
  status: WithdrawalRequest['status'];
  message: string;
  processedAt: Date;
  transactionHash?: string;
  error?: string;
}

// Default withdrawal rules
const defaultRules: WithdrawalRule[] = [
  {
    id: 'rule-1',
    name: 'Small Withdrawals Auto-Approval',
    enabled: true,
    minAmount: 0,
    maxAmount: 1000,
    currency: 'USD',
    paymentMethod: 'vodafone',
    autoApprove: true,
    priority: 'high',
    conditions: {
      maxDailyAmount: 5000,
      requiresKYC: true
    }
  },
  {
    id: 'rule-2',
    name: 'Bank Transfer Large Amounts',
    enabled: true,
    minAmount: 1000,
    maxAmount: 50000,
    currency: 'USD',
    paymentMethod: 'bank',
    autoApprove: false,
    priority: 'medium',
    conditions: {
      timeWindow: { start: '09:00', end: '17:00' },
      requiresKYC: true
    }
  },
  {
    id: 'rule-3',
    name: 'Instapay Express',
    enabled: true,
    minAmount: 0,
    maxAmount: 5000,
    currency: 'EGP',
    paymentMethod: 'instapay',
    autoApprove: true,
    priority: 'high',
    conditions: {
      maxDailyAmount: 20000
    }
  }
];

class AutomatedWithdrawalService {
  private rules: WithdrawalRule[] = [];
  private processingQueue: WithdrawalRequest[] = [];
  private dailyTotals: Map<string, number> = new Map();

  constructor() {
    this.loadRules();
    this.resetDailyTotalsAtMidnight();
  }

  /**
   * Load withdrawal rules from storage or use defaults
   */
  private loadRules(): void {
    const stored = localStorage.getItem('withdrawal_rules');
    this.rules = stored ? JSON.parse(stored) : defaultRules;
  }

  /**
   * Save rules to storage
   */
  private saveRules(): void {
    localStorage.setItem('withdrawal_rules', JSON.stringify(this.rules));
  }

  /**
   * Get all withdrawal rules
   */
  getRules(): WithdrawalRule[] {
    return this.rules;
  }

  /**
   * Add a new withdrawal rule
   */
  addRule(rule: WithdrawalRule): void {
    this.rules.push(rule);
    this.saveRules();
  }

  /**
   * Update an existing rule
   */
  updateRule(id: string, updates: Partial<WithdrawalRule>): void {
    const index = this.rules.findIndex(r => r.id === id);
    if (index !== -1) {
      this.rules[index] = { ...this.rules[index], ...updates };
      this.saveRules();
    }
  }

  /**
   * Delete a rule
   */
  deleteRule(id: string): void {
    this.rules = this.rules.filter(r => r.id !== id);
    this.saveRules();
  }

  /**
   * Check if withdrawal request matches a rule
   */
  private matchesRule(request: WithdrawalRequest, rule: WithdrawalRule): boolean {
    if (!rule.enabled) return false;
    
    // Check amount range
    if (request.amount < rule.minAmount || request.amount > rule.maxAmount) {
      return false;
    }

    // Check currency
    if (request.currency !== rule.currency) {
      return false;
    }

    // Check payment method
    if (request.paymentMethod !== rule.paymentMethod) {
      return false;
    }

    // Check time window
    if (rule.conditions.timeWindow) {
      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const { start, end } = rule.conditions.timeWindow;
      if (currentTime < start || currentTime > end) {
        return false;
      }
    }

    // Check daily limit
    if (rule.conditions.maxDailyAmount) {
      const dailyKey = `${request.merchantId}-${rule.id}-${new Date().toDateString()}`;
      const dailyTotal = this.dailyTotals.get(dailyKey) || 0;
      if (dailyTotal + request.amount > rule.conditions.maxDailyAmount) {
        return false;
      }
    }

    // Check whitelist
    if (rule.conditions.merchantWhitelist && rule.conditions.merchantWhitelist.length > 0) {
      if (!rule.conditions.merchantWhitelist.includes(request.merchantId)) {
        return false;
      }
    }

    return true;
  }

  /**
   * Find applicable rule for a withdrawal request
   */
  private findApplicableRule(request: WithdrawalRequest): WithdrawalRule | null {
    // Sort rules by priority
    const sortedRules = [...this.rules].sort((a, b) => {
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    });

    return sortedRules.find(rule => this.matchesRule(request, rule)) || null;
  }

  /**
   * Process a withdrawal request
   */
  async processWithdrawal(request: WithdrawalRequest): Promise<ProcessingResult> {
    const rule = this.findApplicableRule(request);

    if (!rule) {
      return {
        success: false,
        withdrawalId: request.id,
        status: 'pending',
        message: 'No applicable rule found. Manual approval required.',
        processedAt: new Date()
      };
    }

    // Update daily totals
    if (rule.conditions.maxDailyAmount) {
      const dailyKey = `${request.merchantId}-${rule.id}-${new Date().toDateString()}`;
      const currentTotal = this.dailyTotals.get(dailyKey) || 0;
      this.dailyTotals.set(dailyKey, currentTotal + request.amount);
    }

    if (rule.autoApprove) {
      // Auto-approve and process
      return await this.executeWithdrawal(request);
    } else {
      // Add to queue for manual approval
      this.processingQueue.push(request);
      return {
        success: true,
        withdrawalId: request.id,
        status: 'pending',
        message: 'Withdrawal queued for manual approval.',
        processedAt: new Date()
      };
    }
  }

  /**
   * Execute the actual withdrawal
   */
  private async executeWithdrawal(request: WithdrawalRequest): Promise<ProcessingResult> {
    try {
      // Simulate API call to payment processor
      await new Promise(resolve => setTimeout(resolve, 1000));

      // In production, this would call actual payment APIs
      const transactionHash = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      return {
        success: true,
        withdrawalId: request.id,
        status: 'completed',
        message: 'Withdrawal processed successfully.',
        processedAt: new Date(),
        transactionHash
      };
    } catch (error) {
      return {
        success: false,
        withdrawalId: request.id,
        status: 'failed',
        message: 'Withdrawal processing failed.',
        processedAt: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Get pending withdrawals queue
   */
  getPendingWithdrawals(): WithdrawalRequest[] {
    return this.processingQueue.filter(w => w.status === 'pending');
  }

  /**
   * Manually approve a withdrawal
   */
  async approveWithdrawal(withdrawalId: string): Promise<ProcessingResult> {
    const request = this.processingQueue.find(w => w.id === withdrawalId);
    if (!request) {
      return {
        success: false,
        withdrawalId,
        status: 'rejected',
        message: 'Withdrawal request not found.',
        processedAt: new Date()
      };
    }

    request.status = 'approved';
    return await this.executeWithdrawal(request);
  }

  /**
   * Reject a withdrawal
   */
  rejectWithdrawal(withdrawalId: string, reason: string): ProcessingResult {
    const request = this.processingQueue.find(w => w.id === withdrawalId);
    if (!request) {
      return {
        success: false,
        withdrawalId,
        status: 'rejected',
        message: 'Withdrawal request not found.',
        processedAt: new Date()
      };
    }

    request.status = 'rejected';
    return {
      success: true,
      withdrawalId,
      status: 'rejected',
      message: reason,
      processedAt: new Date()
    };
  }

  /**
   * Get withdrawal statistics
   */
  getStatistics(merchantId?: string) {
    const allWithdrawals = this.processingQueue;
    const filtered = merchantId 
      ? allWithdrawals.filter(w => w.merchantId === merchantId)
      : allWithdrawals;

    return {
      total: filtered.length,
      pending: filtered.filter(w => w.status === 'pending').length,
      approved: filtered.filter(w => w.status === 'approved').length,
      completed: filtered.filter(w => w.status === 'completed').length,
      rejected: filtered.filter(w => w.status === 'rejected').length,
      failed: filtered.filter(w => w.status === 'failed').length,
      totalAmount: filtered.reduce((sum, w) => sum + w.amount, 0)
    };
  }

  /**
   * Reset daily totals at midnight
   */
  private resetDailyTotalsAtMidnight(): void {
    const now = new Date();
    const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const msUntilMidnight = tomorrow.getTime() - now.getTime();

    setTimeout(() => {
      this.dailyTotals.clear();
      this.resetDailyTotalsAtMidnight(); // Schedule next reset
    }, msUntilMidnight);
  }

  /**
   * Bulk process withdrawals
   */
  async bulkProcess(requests: WithdrawalRequest[]): Promise<ProcessingResult[]> {
    const results: ProcessingResult[] = [];
    
    for (const request of requests) {
      const result = await this.processWithdrawal(request);
      results.push(result);
    }

    return results;
  }

  /**
   * Get daily total for a merchant
   */
  getDailyTotal(merchantId: string, ruleId: string): number {
    const dailyKey = `${merchantId}-${ruleId}-${new Date().toDateString()}`;
    return this.dailyTotals.get(dailyKey) || 0;
  }
}

// Export singleton instance
export const withdrawalService = new AutomatedWithdrawalService();
