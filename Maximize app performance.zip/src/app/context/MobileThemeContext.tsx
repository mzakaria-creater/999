import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type MobileTheme = 
  | 'dark' 
  | 'light' 
  | 'violet-dark' 
  | 'blue-dark' 
  | 'mint-dark' 
  | 'amber-dark'
  | 'cyber-dark'
  | 'neon-dark';

interface ThemeConfig {
  name: string;
  background: string;
  cardBg: string;
  cardBorder: string;
  primaryGradient: string;
  accentColor: string;
  textPrimary: string;
  textSecondary: string;
  statusBar: string;
  navBg: string;
  appGridBg: string;
}

const themeConfigs: Record<MobileTheme, ThemeConfig> = {
  'dark': {
    name: 'Dark Mode',
    background: 'from-[#0a0b0d] via-[#121417] to-[#0a0b0d]',
    cardBg: 'from-[#1a1d23]/90 to-[#252932]/90',
    cardBorder: 'border-white/10',
    primaryGradient: 'from-[#8b5cf6] to-[#3b82f6]',
    accentColor: '#8b5cf6',
    textPrimary: 'text-white',
    textSecondary: 'text-gray-400',
    statusBar: 'bg-[#0a0b0d]',
    navBg: 'bg-[#1a1d23]/98',
    appGridBg: 'bg-[#1a1d23]/90'
  },
  'light': {
    name: 'Light Mode',
    background: 'from-gray-50 via-white to-gray-50',
    cardBg: 'from-white/95 to-gray-50/95',
    cardBorder: 'border-gray-200',
    primaryGradient: 'from-[#8b5cf6] to-[#3b82f6]',
    accentColor: '#8b5cf6',
    textPrimary: 'text-gray-900',
    textSecondary: 'text-gray-600',
    statusBar: 'bg-white',
    navBg: 'bg-white/98',
    appGridBg: 'bg-gray-50/90'
  },
  'violet-dark': {
    name: 'Violet Dark',
    background: 'from-[#1a0b2e] via-[#2d1b4e] to-[#1a0b2e]',
    cardBg: 'from-[#2d1b4e]/90 to-[#3d2b5e]/90',
    cardBorder: 'border-[#8b5cf6]/20',
    primaryGradient: 'from-[#a78bfa] to-[#8b5cf6]',
    accentColor: '#a78bfa',
    textPrimary: 'text-white',
    textSecondary: 'text-purple-300',
    statusBar: 'bg-[#1a0b2e]',
    navBg: 'bg-[#2d1b4e]/98',
    appGridBg: 'bg-[#2d1b4e]/90'
  },
  'blue-dark': {
    name: 'Blue Dark',
    background: 'from-[#0a1628] via-[#1a2744] to-[#0a1628]',
    cardBg: 'from-[#1a2744]/90 to-[#2a3754]/90',
    cardBorder: 'border-[#3b82f6]/20',
    primaryGradient: 'from-[#60a5fa] to-[#3b82f6]',
    accentColor: '#60a5fa',
    textPrimary: 'text-white',
    textSecondary: 'text-blue-300',
    statusBar: 'bg-[#0a1628]',
    navBg: 'bg-[#1a2744]/98',
    appGridBg: 'bg-[#1a2744]/90'
  },
  'mint-dark': {
    name: 'Mint Dark',
    background: 'from-[#0a2820] via-[#1a3830] to-[#0a2820]',
    cardBg: 'from-[#1a3830]/90 to-[#2a4840]/90',
    cardBorder: 'border-[#6ee7b7]/20',
    primaryGradient: 'from-[#6ee7b7] to-[#34d399]',
    accentColor: '#6ee7b7',
    textPrimary: 'text-white',
    textSecondary: 'text-emerald-300',
    statusBar: 'bg-[#0a2820]',
    navBg: 'bg-[#1a3830]/98',
    appGridBg: 'bg-[#1a3830]/90'
  },
  'amber-dark': {
    name: 'Amber Dark',
    background: 'from-[#2a1a0a] via-[#3a2a1a] to-[#2a1a0a]',
    cardBg: 'from-[#3a2a1a]/90 to-[#4a3a2a]/90',
    cardBorder: 'border-[#fbbf24]/20',
    primaryGradient: 'from-[#fbbf24] to-[#f59e0b]',
    accentColor: '#fbbf24',
    textPrimary: 'text-white',
    textSecondary: 'text-amber-300',
    statusBar: 'bg-[#2a1a0a]',
    navBg: 'bg-[#3a2a1a]/98',
    appGridBg: 'bg-[#3a2a1a]/90'
  },
  'cyber-dark': {
    name: 'Cyber Dark',
    background: 'from-[#0d0221] via-[#1a0f3d] to-[#0d0221]',
    cardBg: 'from-[#1a0f3d]/90 to-[#2a1f4d]/90',
    cardBorder: 'border-cyan-500/20',
    primaryGradient: 'from-[#06b6d4] to-[#8b5cf6]',
    accentColor: '#06b6d4',
    textPrimary: 'text-white',
    textSecondary: 'text-cyan-300',
    statusBar: 'bg-[#0d0221]',
    navBg: 'bg-[#1a0f3d]/98',
    appGridBg: 'bg-[#1a0f3d]/90'
  },
  'neon-dark': {
    name: 'Neon Dark',
    background: 'from-[#0a0014] via-[#1a0028] to-[#0a0014]',
    cardBg: 'from-[#1a0028]/90 to-[#2a0038]/90',
    cardBorder: 'border-pink-500/20',
    primaryGradient: 'from-[#ec4899] to-[#f43f5e]',
    accentColor: '#ec4899',
    textPrimary: 'text-white',
    textSecondary: 'text-pink-300',
    statusBar: 'bg-[#0a0014]',
    navBg: 'bg-[#1a0028]/98',
    appGridBg: 'bg-[#1a0028]/90'
  }
};

interface MobileThemeContextType {
  theme: MobileTheme;
  setTheme: (theme: MobileTheme) => void;
  config: ThemeConfig;
  availableThemes: Array<{ value: MobileTheme; label: string }>;
}

const MobileThemeContext = createContext<MobileThemeContextType | undefined>(undefined);

export function MobileThemeProvider({ children }: { children: ReactNode }) {
  console.log('🎨 MobileThemeProvider initialized');
  const [theme, setThemeState] = useState<MobileTheme>(() => {
    const saved = localStorage.getItem('mobile-theme');
    return (saved as MobileTheme) || 'dark';
  });

  const setTheme = (newTheme: MobileTheme) => {
    setThemeState(newTheme);
    localStorage.setItem('mobile-theme', newTheme);
  };

  const config = themeConfigs[theme];

  const availableThemes = Object.entries(themeConfigs).map(([value, config]) => ({
    value: value as MobileTheme,
    label: config.name
  }));

  return (
    <MobileThemeContext.Provider value={{ theme, setTheme, config, availableThemes }}>
      {children}
    </MobileThemeContext.Provider>
  );
}

export function useMobileTheme() {
  const context = useContext(MobileThemeContext);
  if (context === undefined) {
    throw new Error('useMobileTheme must be used within a MobileThemeProvider');
  }
  return context;
}