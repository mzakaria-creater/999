import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'Owner' | 'Admin' | 'Finance' | 'Operations' | 'Merchant' | 'Viewer';

interface RoleContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<UserRole>('Owner');

  return (
    <RoleContext.Provider value={{ role, setRole }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
}

// Role permissions mapping
export const rolePermissions: Record<UserRole, Record<string, boolean>> = {
  Owner: {
    dashboard: true,
    transactions: true,
    wallets: true,
    merchants: true,
    'payment-settings': true,
    'payment-methods': true,
    'payment-accounts': true,
    'payment-pages': true,
    'integration': true,
    'embed-integration': true,
    'api-docs': true,
    permissions: true,
  },
  Admin: {
    dashboard: true,
    transactions: true,
    wallets: true,
    merchants: true,
    'payment-settings': true,
    'payment-methods': true,
    'payment-accounts': true,
    'payment-pages': true,
    'integration': true,
    'embed-integration': true,
    'api-docs': true,
    permissions: true,
  },
  Finance: {
    dashboard: true,
    transactions: true,
    wallets: true,
    merchants: false,
    'payment-settings': false,
    'payment-methods': false,
    'payment-accounts': true,
    'payment-pages': false,
    'integration': false,
    'embed-integration': false,
    'api-docs': false,
    permissions: false,
  },
  Operations: {
    dashboard: true,
    transactions: true,
    wallets: true,
    merchants: true,
    'payment-settings': true,
    'payment-methods': true,
    'payment-accounts': true,
    'payment-pages': true,
    'integration': false,
    'embed-integration': false,
    'api-docs': false,
    permissions: false,
  },
  Merchant: {
    dashboard: true,
    transactions: true,
    wallets: false,
    merchants: false,
    'payment-settings': false,
    'payment-methods': false,
    'payment-accounts': false,
    'payment-pages': true,
    'integration': true,
    'embed-integration': true,
    'api-docs': true,
    permissions: false,
  },
  Viewer: {
    dashboard: true,
    transactions: true,
    wallets: false,
    merchants: false,
    'payment-settings': false,
    'payment-methods': false,
    'payment-accounts': false,
    'payment-pages': false,
    'integration': false,
    'embed-integration': false,
    'api-docs': false,
    permissions: false,
  },
};

export function hasPermission(role: UserRole, page: string): boolean {
  return rolePermissions[role][page] || false;
}