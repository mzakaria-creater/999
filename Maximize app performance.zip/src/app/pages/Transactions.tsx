import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { GlassCard } from '../components/GlassCard';
import { motion } from 'motion/react';
import {
  ArrowLeftRight,
  Search,
  Filter,
  Download,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  Loader,
  Calendar,
  DollarSign,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { paymentService, type Transaction, type PaymentProvider } from '../services/payment_service';
import { useLanguage } from '../context/LanguageContext';

const STATUS_COLORS = {
  pending: { bg: 'bg-[#fbbf24]/20', text: 'text-[#fbbf24]', icon: Clock },
  processing: { bg: 'bg-[#3b82f6]/20', text: 'text-[#3b82f6]', icon: Loader },
  completed: { bg: 'bg-[#6ee7b7]/20', text: 'text-[#6ee7b7]', icon: CheckCircle },
  failed: { bg: 'bg-[#f87171]/20', text: 'text-[#f87171]', icon: XCircle },
  cancelled: { bg: 'bg-gray-500/20', text: 'text-gray-400', icon: XCircle }
};

const PROVIDER_LABELS: Record<PaymentProvider, string> = {
  paypal: 'PayPal',
  binance: 'Binance Pay',
  okx: 'OKX Pay',
  vodafone: 'Vodafone Cash',
  instapay: 'InstaPay'
};

export function Transactions() {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterProvider, setFilterProvider] = useState<string>('all');
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    loadTransactions();
  }, []);

  useEffect(() => {
    filterTransactions();
  }, [transactions, searchQuery, filterStatus, filterProvider]);

  const loadTransactions = () => {
    const allTransactions = paymentService.getAllTransactions();
    setTransactions(allTransactions);
    
    const statistics = paymentService.getStatistics();
    setStats(statistics);
  };

  const filterTransactions = () => {
    let filtered = [...transactions];

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(t =>
        t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.customerEmail?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(t => t.status === filterStatus);
    }

    // Provider filter
    if (filterProvider !== 'all') {
      filtered = filtered.filter(t => t.provider === filterProvider);
    }

    setFilteredTransactions(filtered);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency === 'USDT' ? 'USD' : currency,
      minimumFractionDigits: 2
    }).format(amount);
  };

  const exportToCSV = () => {
    const headers = ['Transaction ID', 'Date', 'Amount', 'Currency', 'Provider', 'Status', 'Description'];
    const rows = filteredTransactions.map(t => [
      t.id,
      formatDate(t.createdAt),
      t.amount,
      t.currency,
      PROVIDER_LABELS[t.provider],
      t.status,
      t.description
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transactions_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Transactions
          </h1>
          <p className="text-gray-400">
            View and manage all payment transactions
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate('/payment-checkout')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg hover:shadow-xl transition-all"
        >
          <DollarSign className="w-4 h-4" />
          New Payment
        </motion.button>
      </div>

      {/* Statistics */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <GlassCard className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <ArrowLeftRight className="w-4 h-4 text-[#8b5cf6]" />
              <p className="text-xs text-gray-400">Total</p>
            </div>
            <p className="text-2xl font-bold text-white">{stats.total}</p>
          </GlassCard>

          <GlassCard className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-[#fbbf24]" />
              <p className="text-xs text-gray-400">Pending</p>
            </div>
            <p className="text-2xl font-bold text-white">{stats.pending}</p>
          </GlassCard>

          <GlassCard className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-[#6ee7b7]" />
              <p className="text-xs text-gray-400">Completed</p>
            </div>
            <p className="text-2xl font-bold text-white">{stats.completed}</p>
          </GlassCard>

          <GlassCard className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="w-4 h-4 text-[#f87171]" />
              <p className="text-xs text-gray-400">Failed</p>
            </div>
            <p className="text-2xl font-bold text-white">{stats.failed}</p>
          </GlassCard>

          <GlassCard className="p-4 col-span-2">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-[#6ee7b7]" />
              <p className="text-xs text-gray-400">Total Volume</p>
            </div>
            <p className="text-2xl font-bold text-white">
              ${stats.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </p>
          </GlassCard>
        </div>
      )}

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="md:col-span-2 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]"
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="completed">Completed</option>
            <option value="failed">Failed</option>
            <option value="cancelled">Cancelled</option>
          </select>

          {/* Provider Filter */}
          <select
            value={filterProvider}
            onChange={(e) => setFilterProvider(e.target.value)}
            className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]"
          >
            <option value="all">All Providers</option>
            <option value="paypal">PayPal</option>
            <option value="binance">Binance Pay</option>
            <option value="okx">OKX Pay</option>
            <option value="vodafone">Vodafone Cash</option>
            <option value="instapay">InstaPay</option>
          </select>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/10">
          <p className="text-sm text-gray-400">
            Showing {filteredTransactions.length} of {transactions.length} transactions
          </p>
          <button
            onClick={exportToCSV}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white text-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </GlassCard>

      {/* Transactions Table */}
      <GlassCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Transaction
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Provider
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {filteredTransactions.map((transaction, index) => {
                const statusConfig = STATUS_COLORS[transaction.status];
                const StatusIcon = statusConfig.icon;

                return (
                  <motion.tr
                    key={transaction.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="hover:bg-white/5 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-mono text-sm text-white">
                          {transaction.id}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                          {transaction.description}
                        </p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-white">
                          {formatDate(transaction.createdAt)}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="font-semibold text-white">
                        {formatCurrency(transaction.amount, transaction.currency)}
                      </p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 rounded-full text-xs bg-white/10 text-white">
                        {PROVIDER_LABELS[transaction.provider]}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full ${statusConfig.bg} ${statusConfig.text}`}>
                        <StatusIcon className="w-3 h-3" />
                        <span className="text-xs font-medium capitalize">
                          {transaction.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => navigate(`/transactions/${transaction.id}`)}
                        className="p-2 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        <Eye className="w-4 h-4 text-gray-400" />
                      </button>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>

          {filteredTransactions.length === 0 && (
            <div className="text-center py-12">
              <ArrowLeftRight className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No transactions found</p>
            </div>
          )}
        </div>
      </GlassCard>

      {/* Provider Statistics */}
      {stats && stats.byProvider.length > 0 && (
        <GlassCard className="p-6">
          <h2 className="text-lg font-bold text-white mb-4">
            By Payment Provider
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {stats.byProvider.map((provider: any) => (
              <div
                key={provider.provider}
                className="p-4 rounded-xl bg-white/5 border border-white/10"
              >
                <p className="text-sm text-gray-400 mb-1">{provider.name}</p>
                <p className="text-xl font-bold text-white mb-2">
                  {provider.count}
                </p>
                <p className="text-xs text-gray-400">
                  ${provider.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </p>
              </div>
            ))}
          </div>
        </GlassCard>
      )}
    </div>
  );
}
