import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ArrowUp, ArrowDown, TrendingUp, AlertTriangle, CheckCircle, Clock, DollarSign, Users, Wallet, CreditCard } from 'lucide-react';
import { transactions, merchants, wallets, paymentMethods } from '../data/seedData';

export default function NewP2PDashboard() {
  const [language, setLanguage] = useState<'en' | 'ar'>('en');

  const t = {
    en: {
      dashboard: 'Dashboard',
      overview: 'Overview',
      totalVolume: 'Total Volume',
      transactions: 'Transactions',
      successRate: 'Success Rate',
      activeWallets: 'Active Wallets',
      recentTransactions: 'Recent Transactions',
      walletCapacity: 'Wallet Capacity',
      paymentMethods: 'Payment Methods',
      topMerchants: 'Top Merchants',
      volumeTrend: 'Volume Trend (7 Days)',
      statusDistribution: 'Transaction Status',
      view: 'View',
      critical: 'Critical',
      warning: 'Warning',
      healthy: 'Healthy',
    },
    ar: {
      dashboard: 'لوحة التحكم',
      overview: 'نظرة عامة',
      totalVolume: 'إجمالي الحجم',
      transactions: 'المعاملات',
      successRate: 'معدل النجاح',
      activeWallets: 'المحافظ النشطة',
      recentTransactions: 'المعاملات الأخيرة',
      walletCapacity: 'سعة المحافظ',
      paymentMethods: 'طرق الدفع',
      topMerchants: 'أفضل التجار',
      volumeTrend: 'اتجاه الحجم (7 أيام)',
      statusDistribution: 'توزيع حالة المعاملات',
      view: 'عرض',
      critical: 'حرج',
      warning: 'تحذير',
      healthy: 'صحي',
    },
  };

  const isRTL = language === 'ar';
  const text = t[language];

  // Calculate stats
  const totalVolume = transactions.reduce((sum, tx) => sum + tx.usdAmount, 0);
  const completedTxns = transactions.filter(tx => tx.status === 'completed').length;
  const successRate = ((completedTxns / transactions.length) * 100).toFixed(1);
  const activeWalletCount = wallets.filter(w => w.status === 'active').length;

  // Volume trend data
  const volumeTrendData = [
    { date: 'Mar 16', volume: 8500 },
    { date: 'Mar 17', volume: 9200 },
    { date: 'Mar 18', volume: 7800 },
    { date: 'Mar 19', volume: 10500 },
    { date: 'Mar 20', volume: 9800 },
    { date: 'Mar 21', volume: 11200 },
    { date: 'Mar 22', volume: 12800 },
  ];

  // Status distribution
  const statusData = [
    { name: 'Completed', value: 2, color: '#10b981' },
    { name: 'Pending', value: 1, color: '#f59e0b' },
    { name: 'On Hold', value: 1, color: '#ef4444' },
    { name: 'Failed', value: 1, color: '#6b7280' },
    { name: 'Expired', value: 1, color: '#8b5cf6' },
  ];

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-6 ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">{text.dashboard}</h1>
          <p className="text-blue-200">New P2P Payment Service Platform</p>
        </div>
        <button
          onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          {language === 'en' ? 'العربية' : 'English'}
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={<DollarSign className="w-8 h-8" />}
          title={text.totalVolume}
          value={`$${totalVolume.toLocaleString()}`}
          change="+12.5%"
          positive
        />
        <StatCard
          icon={<CreditCard className="w-8 h-8" />}
          title={text.transactions}
          value={transactions.length.toString()}
          change="+8.3%"
          positive
        />
        <StatCard
          icon={<TrendingUp className="w-8 h-8" />}
          title={text.successRate}
          value={`${successRate}%`}
          change="+2.1%"
          positive
        />
        <StatCard
          icon={<Wallet className="w-8 h-8" />}
          title={text.activeWallets}
          value={activeWalletCount.toString()}
          change="-1"
          positive={false}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Volume Trend */}
        <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">{text.volumeTrend}</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={volumeTrendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Line type="monotone" dataKey="volume" stroke="#3b82f6" strokeWidth={3} dot={{ fill: '#3b82f6', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Status Distribution */}
        <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">{text.statusDistribution}</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={5}
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Wallet Capacity */}
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 mb-8">
        <h3 className="text-lg font-semibold text-white mb-4">{text.walletCapacity}</h3>
        <div className="space-y-4">
          {wallets.slice(0, 4).map((wallet) => {
            const percentage = (wallet.balance / wallet.capacity) * 100;
            const isWarning = percentage >= 80;
            const isCritical = percentage >= 95;

            return (
              <div key={wallet.id} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-medium">{wallet.name}</span>
                    {isCritical && <span className="px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded">{text.critical}</span>}
                    {isWarning && !isCritical && <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-400 text-xs rounded">{text.warning}</span>}
                  </div>
                  <span className="text-blue-200">
                    {wallet.balance.toLocaleString()} / {wallet.capacity.toLocaleString()} {wallet.currency}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full transition-all ${
                      isCritical ? 'bg-red-500' : isWarning ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">{text.recentTransactions}</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b border-slate-700">
                <th className="pb-3 text-sm font-medium text-blue-200">ID</th>
                <th className="pb-3 text-sm font-medium text-blue-200">Customer</th>
                <th className="pb-3 text-sm font-medium text-blue-200">Amount</th>
                <th className="pb-3 text-sm font-medium text-blue-200">Method</th>
                <th className="pb-3 text-sm font-medium text-blue-200">Status</th>
                <th className="pb-3 text-sm font-medium text-blue-200">Time</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {transactions.slice(0, 5).map((tx, idx) => (
                <tr key={tx.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                  <td className="py-3 text-white font-mono">{tx.id}</td>
                  <td className="py-3 text-blue-100">{tx.customer.name}</td>
                  <td className="py-3 text-white font-semibold">
                    {tx.amount.toLocaleString()} {tx.currency}
                  </td>
                  <td className="py-3 text-blue-200">{tx.paymentMethod.replace('_', ' ')}</td>
                  <td className="py-3">
                    <StatusBadge status={tx.status} />
                  </td>
                  <td className="py-3 text-blue-200">{new Date(tx.createdAt).toLocaleTimeString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, title, value, change, positive }: any) {
  return (
    <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 hover:border-blue-500/50 transition-all">
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 bg-blue-600/20 rounded-xl text-blue-400">{icon}</div>
        <div className={`flex items-center gap-1 text-sm font-medium ${positive ? 'text-green-400' : 'text-red-400'}`}>
          {positive ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
          {change}
        </div>
      </div>
      <div className="text-2xl font-bold text-white mb-1">{value}</div>
      <div className="text-sm text-blue-200">{title}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: any = {
    completed: { bg: 'bg-green-500/20', text: 'text-green-400', label: 'Completed', icon: CheckCircle },
    pending_review: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', label: 'Pending', icon: Clock },
    on_hold: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'On Hold', icon: AlertTriangle },
    failed: { bg: 'bg-gray-500/20', text: 'text-gray-400', label: 'Failed', icon: AlertTriangle },
    expired: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Expired', icon: Clock },
  };

  const { bg, text, label, icon: Icon } = config[status] || config.pending_review;

  return (
    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${bg} ${text}`}>
      <Icon className="w-3 h-3" />
      {label}
    </span>
  );
}
