import { useState } from 'react';
import { Search, Filter, Download, RefreshCw, Eye, CheckCircle, XCircle, Clock, AlertTriangle, PlayCircle, Ban } from 'lucide-react';
import { transactions } from '../data/seedData';

export default function NewTransactions() {
  const [selectedTx, setSelectedTx] = useState<any>(null);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTransactions = transactions.filter(tx => {
    const matchesFilter = filter === 'all' || tx.status === filter;
    const matchesSearch = 
      tx.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.merchant.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Transactions</h1>
          <p className="text-blue-200">{filteredTransactions.length} transactions found</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-2 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg flex items-center gap-2 transition-colors">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 mb-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-400" />
              <input
                type="text"
                placeholder="Search by ID, customer, or merchant..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {[
              { label: 'All', value: 'all' },
              { label: 'Completed', value: 'completed' },
              { label: 'Pending', value: 'pending_review' },
              { label: 'On Hold', value: 'on_hold' },
              { label: 'Failed', value: 'failed' },
              { label: 'Expired', value: 'expired' },
            ].map(f => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  filter === f.value
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-900/50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Transaction ID</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Customer</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Merchant</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Amount</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Method</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Status</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Risk</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-blue-200 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {filteredTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-700/30 transition-colors">
                  <td className="px-6 py-4 text-white font-mono text-sm">{tx.id}</td>
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-white font-medium">{tx.customer.name}</div>
                      <div className="text-xs text-blue-300">{tx.customer.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{tx.merchant.logo}</span>
                      <span className="text-blue-100">{tx.merchant.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-white font-semibold">{tx.amount.toLocaleString()} {tx.currency}</div>
                    <div className="text-xs text-blue-300">${tx.usdAmount.toFixed(2)}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-slate-700 rounded text-xs text-blue-200">
                      {tx.paymentMethod.replace('_', ' ').toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={tx.status} />
                  </td>
                  <td className="px-6 py-4">
                    <RiskScore score={tx.riskScore} />
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setSelectedTx(tx)}
                      className="p-2 hover:bg-blue-600/20 rounded-lg transition-colors text-blue-400"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Details Modal */}
      {selectedTx && (
        <TransactionDetailsModal
          transaction={selectedTx}
          onClose={() => setSelectedTx(null)}
        />
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: any = {
    completed: { bg: 'bg-green-500/20', text: 'text-green-400', label: 'Completed', icon: CheckCircle },
    pending_review: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', label: 'Pending Review', icon: Clock },
    on_hold: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'On Hold', icon: AlertTriangle },
    failed: { bg: 'bg-gray-500/20', text: 'text-gray-400', label: 'Failed', icon: XCircle },
    expired: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Expired', icon: Clock },
  };

  const { bg, text, label, icon: Icon } = config[status] || config.pending_review;

  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${bg} ${text}`}>
      <Icon className="w-3.5 h-3.5" />
      {label}
    </span>
  );
}

function RiskScore({ score }: { score: number }) {
  const color = score < 30 ? 'text-green-400' : score < 70 ? 'text-yellow-400' : 'text-red-400';
  const bg = score < 30 ? 'bg-green-500/20' : score < 70 ? 'bg-yellow-500/20' : 'bg-red-500/20';

  return (
    <span className={`inline-flex items-center px-2 py-1 rounded ${bg} ${color} text-xs font-semibold`}>
      {score}
    </span>
  );
}

function TransactionDetailsModal({ transaction, onClose }: any) {
  const [activeTab, setActiveTab] = useState('details');

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-slate-700 flex items-center justify-between sticky top-0 bg-slate-800 z-10">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">{transaction.id}</h2>
            <p className="text-blue-300">Transaction Details</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors text-slate-400"
          >
            ✕
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-slate-700 px-6">
          <div className="flex gap-4">
            {['details', 'actions', 'proof', 'audit', 'webhooks'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-3 font-medium border-b-2 transition-colors ${
                  activeTab === tab
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'details' && (
            <div className="grid grid-cols-2 gap-6">
              <DetailField label="Customer" value={transaction.customer.name} />
              <DetailField label="Email" value={transaction.customer.email} />
              <DetailField label="Phone" value={transaction.customer.phone} />
              <DetailField label="Merchant" value={transaction.merchant.name} />
              <DetailField label="Amount" value={`${transaction.amount.toLocaleString()} ${transaction.currency}`} />
              <DetailField label="USD Amount" value={`$${transaction.usdAmount.toFixed(2)}`} />
              <DetailField label="Fee" value={`${transaction.fee} ${transaction.currency}`} />
              <DetailField label="Net Amount" value={`${transaction.netAmount.toLocaleString()} ${transaction.currency}`} />
              <DetailField label="Payment Method" value={transaction.paymentMethod.replace('_', ' ').toUpperCase()} />
              <DetailField label="Corridor" value={transaction.corridor} />
              <DetailField label="Reference" value={transaction.reference} />
              <DetailField label="Type" value={transaction.type} />
              <DetailField label="Risk Score" value={transaction.riskScore.toString()} />
              <DetailField label="Status" value={<StatusBadge status={transaction.status} />} />
            </div>
          )}

          {activeTab === 'actions' && (
            <div className="space-y-4">
              <p className="text-blue-200 mb-4">Available transaction actions:</p>
              <div className="grid grid-cols-2 gap-3">
                <ActionButton icon={<CheckCircle />} label="Approve" color="green" />
                <ActionButton icon={<XCircle />} label="Decline" color="red" />
                <ActionButton icon={<Clock />} label="Review" color="yellow" />
                <ActionButton icon={<AlertTriangle />} label="Hold" color="orange" />
                <ActionButton icon={<PlayCircle />} label="Release Hold" color="blue" />
                <ActionButton icon={<CheckCircle />} label="Settle Now" color="green" />
                <ActionButton icon={<Ban />} label="Expire" color="purple" />
                <ActionButton icon={<RefreshCw />} label="Reopen" color="blue" />
              </div>
            </div>
          )}

          {activeTab === 'proof' && (
            <div className="space-y-4">
              <p className="text-blue-200 mb-4">Proof of Payment Gallery:</p>
              {transaction.proof.length > 0 ? (
                <div className="grid grid-cols-3 gap-4">
                  {transaction.proof.map((img: string, idx: number) => (
                    <div key={idx} className="aspect-video bg-slate-700 rounded-lg flex items-center justify-center text-slate-400">
                      📷 {img}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">No proof uploaded</div>
              )}
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="space-y-3">
              <AuditEntry time="2024-03-22 14:32:00" user="Ahmed Mahmoud" action="Transaction created" />
              <AuditEntry time="2024-03-22 14:32:30" user="System" action="Risk score calculated: 12" />
              <AuditEntry time="2024-03-22 14:33:00" user="System" action="Payment processed" />
              <AuditEntry time="2024-03-22 14:33:15" user="System" action="Transaction completed" />
              <AuditEntry time="2024-03-22 14:33:20" user="System" action="Webhook sent" />
            </div>
          )}

          {activeTab === 'webhooks' && (
            <div className="space-y-3">
              <WebhookLog
                time="2024-03-22 14:33:20"
                url="https://electronics-store.com/webhooks/payment"
                status="success"
                response="200 OK"
              />
              <WebhookLog
                time="2024-03-22 14:33:25"
                url="https://electronics-store.com/webhooks/payment"
                status="retry"
                response="Timeout"
              />
            </div>
          )}
        </div>

        {/* Notes Section */}
        <div className="p-6 border-t border-slate-700">
          <h3 className="text-white font-semibold mb-3">Notes</h3>
          <textarea
            className="w-full p-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            rows={3}
            placeholder="Add notes about this transaction..."
            defaultValue={transaction.notes}
          />
        </div>
      </div>
    </div>
  );
}

function DetailField({ label, value }: any) {
  return (
    <div>
      <div className="text-xs text-blue-300 mb-1">{label}</div>
      <div className="text-white font-medium">{value}</div>
    </div>
  );
}

function ActionButton({ icon, label, color }: any) {
  const colors: any = {
    green: 'bg-green-600 hover:bg-green-700',
    red: 'bg-red-600 hover:bg-red-700',
    yellow: 'bg-yellow-600 hover:bg-yellow-700',
    orange: 'bg-orange-600 hover:bg-orange-700',
    blue: 'bg-blue-600 hover:bg-blue-700',
    purple: 'bg-purple-600 hover:bg-purple-700',
  };

  return (
    <button className={`flex items-center gap-2 px-4 py-3 rounded-lg text-white font-medium transition-colors ${colors[color]}`}>
      {icon}
      {label}
    </button>
  );
}

function AuditEntry({ time, user, action }: any) {
  return (
    <div className="flex items-start gap-3 p-3 bg-slate-900/50 rounded-lg">
      <div className="w-2 h-2 mt-2 bg-blue-500 rounded-full" />
      <div className="flex-1">
        <div className="text-white font-medium">{action}</div>
        <div className="text-xs text-blue-300 mt-1">
          {time} • {user}
        </div>
      </div>
    </div>
  );
}

function WebhookLog({ time, url, status, response }: any) {
  const statusColor = status === 'success' ? 'text-green-400' : 'text-yellow-400';
  const statusBg = status === 'success' ? 'bg-green-500/20' : 'bg-yellow-500/20';

  return (
    <div className="p-4 bg-slate-900/50 rounded-lg">
      <div className="flex items-center justify-between mb-2">
        <div className="text-white font-medium">{url}</div>
        <span className={`px-2 py-1 rounded text-xs ${statusBg} ${statusColor}`}>
          {status.toUpperCase()}
        </span>
      </div>
      <div className="text-xs text-blue-300">
        {time} • Response: {response}
      </div>
    </div>
  );
}
