import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import { RefreshCw, DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface RateData {
  lastPrice: string;
  highPrice: string;
  lowPrice: string;
  priceChange: string;
  priceChangePercent: string;
}

export function BinancePage() {
  const { t } = useLanguage();
  const [rate, setRate] = useState<RateData>({
    lastPrice: '50.45',
    highPrice: '51.20',
    lowPrice: '49.80',
    priceChange: '0.65',
    priceChangePercent: '1.30',
  });
  const [loading, setLoading] = useState(false);

  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1000);
  };

  return (
    <div className="p-4 sm:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-white mb-2">Binance Integration</h1>
          <p className="text-sm text-gray-400">USDT/EGP exchange rates and P2P marketplace</p>
        </div>
        <motion.button
          onClick={handleRefresh}
          className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
          whileTap={{ scale: 0.95 }}
        >
          <RefreshCw className={`w-5 h-5 text-white ${loading ? 'animate-spin' : ''}`} />
        </motion.button>
      </div>

      {/* Rate Card */}
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#F0B90B] to-[#F0B90B]/70 flex items-center justify-center">
              <span className="text-2xl font-bold text-black">₿</span>
            </div>
            <div>
              <p className="text-sm text-gray-400">USDT / EGP</p>
              <h2 className="text-4xl font-bold text-white tracking-tight">
                {parseFloat(rate.lastPrice).toFixed(2)} EGP
              </h2>
            </div>
          </div>
          <div className={`flex items-center gap-2 ${
            parseFloat(rate.priceChange) > 0 ? 'text-[#6ee7b7]' : 'text-[#f87171]'
          }`}>
            {parseFloat(rate.priceChange) > 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
            <span className="text-xl font-bold">
              {parseFloat(rate.priceChangePercent).toFixed(2)}%
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <p className="text-xs text-gray-400 mb-1">24h High</p>
            <p className="text-lg font-bold text-white">{parseFloat(rate.highPrice).toFixed(2)}</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <p className="text-xs text-gray-400 mb-1">24h Low</p>
            <p className="text-lg font-bold text-white">{parseFloat(rate.lowPrice).toFixed(2)}</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <p className="text-xs text-gray-400 mb-1">24h Change</p>
            <p className={`text-lg font-bold ${parseFloat(rate.priceChange) > 0 ? 'text-[#6ee7b7]' : 'text-[#f87171]'}`}>
              {parseFloat(rate.priceChange) > 0 ? '+' : ''}{parseFloat(rate.priceChange).toFixed(2)}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <p className="text-xs text-gray-400 mb-1">Volume</p>
            <p className="text-lg font-bold text-white">2.4M</p>
          </div>
        </div>
      </GlassCard>

      {/* Quick Convert */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: '1 USDT =', value: parseFloat(rate.lastPrice).toFixed(2) + ' EGP' },
          { label: '100 USDT =', value: (parseFloat(rate.lastPrice) * 100).toFixed(2) + ' EGP' },
          { label: '1000 EGP =', value: (1000 / parseFloat(rate.lastPrice)).toFixed(2) + ' USDT' },
        ].map((item, index) => (
          <GlassCard key={index} className="p-4">
            <p className="text-xs text-gray-400 mb-2">{item.label}</p>
            <p className="text-xl font-bold text-white">{item.value}</p>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
