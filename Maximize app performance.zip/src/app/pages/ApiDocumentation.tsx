import { useState, useRef } from 'react';
import { motion } from 'motion/react';
import {
  BookOpen, Database, Globe, Shield, Code2, ChevronDown, ChevronRight,
  Copy, CheckCircle2, Send, ArrowRightLeft, Zap, CreditCard, Wallet,
  Building2, Bell, BarChart3, Lock, Clock, AlertTriangle, Ban, Hash, Download
} from 'lucide-react';
import { GlassCard } from '../components/GlassCard';
import { useLanguage } from '../context/LanguageContext';

type HttpMethod = 'GET' | 'POST' | 'PATCH' | 'DELETE';

interface Endpoint {
  method: HttpMethod;
  path: string;
  title: string;
  description: string;
  category: string;
  requestBody?: string;
  responseBody: string;
  queryParams?: string;
}

const endpoints: Endpoint[] = [
  {
    method: 'POST', path: '/transactions', title: 'Create Transaction (Hosted Checkout)',
    category: 'Payments',
    description: 'Create a new payment request and receive a hosted checkout URL.',
    requestBody: JSON.stringify({
      amount: 1000, currency: 'EGP', order_id: 'ORD_12345',
      customer_email: 'customer@example.com', customer_name: 'Ahmed Hassan',
      callback_url: 'https://merchant.com/webhook',
      success_url: 'https://merchant.com/success',
      cancel_url: 'https://merchant.com/cancel',
      metadata: { cart_id: 'CART_123' }
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'TRX_1234567890',
        checkout_url: 'https://checkout.ontarget-egy.com/TRX_1234567890',
        status: 'pending', amount: 1000, currency: 'EGP',
        expires_at: '2026-02-20T14:30:00Z'
      }
    }, null, 2),
  },
  {
    method: 'GET', path: '/transactions', title: 'List Transactions',
    category: 'Payments',
    description: 'Retrieve a paginated list of all transactions with optional filters.',
    queryParams: 'limit=20&offset=0&status=completed&from_date=2026-01-01&to_date=2026-03-01',
    responseBody: JSON.stringify({
      success: true, data: [
        { id: 'TRX_001', amount: 1000, currency: 'EGP', status: 'completed', payment_method: 'vodafone_cash' },
        { id: 'TRX_002', amount: 500, currency: 'EGP', status: 'pending', payment_method: 'instapay' },
      ], pagination: { limit: 20, offset: 0, total: 156 }
    }, null, 2),
  },
  {
    method: 'POST', path: '/withdrawals', title: 'Create Withdrawal',
    category: 'Withdrawals',
    description: 'Create a payout/withdrawal request to a bank account or mobile wallet.',
    requestBody: JSON.stringify({
      amount: 5000, currency: 'EGP',
      destination: { type: 'bank_account', account_number: '1234567890', bank_code: 'NBEG', account_holder: 'Ahmed Hassan' }
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'WTH_1234567890', status: 'processing', amount: 5000, currency: 'EGP',
        estimated_arrival: '1-2 business days'
      }
    }, null, 2),
  },
  {
    method: 'POST', path: '/merchants', title: 'Create Merchant',
    category: 'Merchants',
    description: 'Create a new merchant account. Supports hierarchy: master_l1, merchant_l2, sub_l3.',
    requestBody: JSON.stringify({
      level: 'merchant_l2', parent_merchant_id: 'M_001',
      business_name: 'Tech Solutions Ltd', email: 'merchant@techsolutions.com',
      country: 'EG', currency: 'EGP'
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'M_002', mid: 'MER-A3B7K9', level: 'merchant_l2',
        business_name: 'Tech Solutions Ltd', status: 'active', api_key: 'sk_live_...'
      }
    }, null, 2),
  },
];

const methodColors: Record<HttpMethod, string> = {
  GET: 'bg-[#6ee7b7]/15 text-[#6ee7b7] border-[#6ee7b7]/30',
  POST: 'bg-[#8b5cf6]/15 text-[#8b5cf6] border-[#8b5cf6]/30',
  PATCH: 'bg-[#fbbf24]/15 text-[#fbbf24] border-[#fbbf24]/30',
  DELETE: 'bg-[#f87171]/15 text-[#f87171] border-[#f87171]/30',
};

const statusList = [
  { status: 'PENDING', icon: Clock, color: 'text-[#fbbf24]', desc: 'Waiting for payment' },
  { status: 'PROCESSING', icon: Zap, color: 'text-[#6ee7b7]', desc: 'Being processed' },
  { status: 'PAID', icon: CheckCircle2, color: 'text-[#8b5cf6]', desc: 'Payment confirmed' },
  { status: 'COMPLETED', icon: CheckCircle2, color: 'text-[#6ee7b7]', desc: 'Fully completed' },
  { status: 'FAILED', icon: AlertTriangle, color: 'text-[#f87171]', desc: 'Failed' },
  { status: 'DECLINED', icon: Ban, color: 'text-[#f87171]', desc: 'Declined' },
];

const categories = [...new Set(endpoints.map(e => e.category))];

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="relative group">
      <pre className="bg-[#0a0a0c] border border-white/10 rounded-xl p-4 text-xs font-mono overflow-x-auto text-white/80">
        <code>{code}</code>
      </pre>
      <button onClick={handleCopy} className="absolute top-2 right-2 p-1.5 rounded-md bg-white/10 text-white/70 hover:text-white opacity-0 group-hover:opacity-100 transition-all">
        {copied ? <CheckCircle2 size={14} /> : <Copy size={14} />}
      </button>
    </div>
  );
}

function EndpointCard({ endpoint }: { endpoint: Endpoint }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <GlassCard className="overflow-hidden">
      <button onClick={() => setExpanded(!expanded)} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors text-left">
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${methodColors[endpoint.method]}`}>
          {endpoint.method}
        </span>
        <code className="text-xs font-mono text-gray-400 flex-1">{endpoint.path}</code>
        <span className="text-sm font-medium hidden sm:block text-white">{endpoint.title}</span>
        {expanded ? <ChevronDown size={16} className="text-gray-400" /> : <ChevronRight size={16} className="text-gray-400" />}
      </button>
      {expanded && (
        <div className="px-4 pb-4 space-y-4 border-t border-white/10 pt-4">
          <p className="text-sm text-gray-400">{endpoint.description}</p>
          <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">Headers</div>
          <CodeBlock code={`Authorization: Bearer sk_test_your_api_key_here\nContent-Type: application/json`} />
          {endpoint.queryParams && (
            <>
              <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">Query Parameters</div>
              <CodeBlock code={endpoint.queryParams} />
            </>
          )}
          {endpoint.requestBody && (
            <>
              <div className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                <Send size={12} /> Request Body
              </div>
              <CodeBlock code={endpoint.requestBody} />
            </>
          )}
          <div className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
            <ArrowRightLeft size={12} /> Response
          </div>
          <CodeBlock code={endpoint.responseBody} />
        </div>
      )}
    </GlassCard>
  );
}

export function ApiDocumentation() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'endpoints' | 'statuses' | 'auth'>('endpoints');

  return (
    <div className="p-4 sm:p-8 space-y-6 sm:space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <motion.div 
            className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6]"
            whileHover={{ scale: 1.05 }}
          >
            <BookOpen className="w-7 h-7 text-white" />
          </motion.div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-semibold text-white">API Documentation</h1>
            <p className="text-sm text-gray-400 mt-1">
              OnTarget REST API — payments, withdrawals, merchants, webhooks & reports
            </p>
          </div>
        </div>
      </div>

      {/* Base URL */}
      <GlassCard className="p-4 flex items-center gap-3">
        <Globe size={16} className="text-[#8b5cf6] shrink-0" />
        <div>
          <span className="text-xs text-gray-400">Base URL</span>
          <code className="block text-sm font-mono text-white">https://api.ontarget-egy.com/v1</code>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 bg-white/5 p-1 rounded-xl w-fit flex-wrap">
        {[
          { key: 'endpoints' as const, label: 'Endpoints', icon: Globe },
          { key: 'auth' as const, label: 'Auth', icon: Lock },
          { key: 'statuses' as const, label: 'Statuses', icon: Zap },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.key ? 'bg-white/10 text-white shadow-sm' : 'text-gray-400 hover:text-white'
            }`}
          >
            <tab.icon size={15} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Auth Tab */}
      {activeTab === 'auth' && (
        <div className="space-y-4">
          <GlassCard className="p-5 space-y-4">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white">
              <Shield size={16} className="text-[#8b5cf6]" /> Bearer Token Authentication
            </h3>
            <p className="text-sm text-gray-400">
              All API requests require a Bearer token in the <code className="px-1.5 py-0.5 bg-white/10 rounded text-xs font-mono">Authorization</code> header.
            </p>
            <CodeBlock code={`curl -X POST https://api.ontarget-egy.com/v1/transactions \\
  -H "Authorization: Bearer sk_test_your_api_key" \\
  -H "Content-Type: application/json" \\
  -d '{"amount": 1000, "currency": "EGP", "order_id": "ORD_123"}'`} />
          </GlassCard>
        </div>
      )}

      {/* Endpoints Tab */}
      {activeTab === 'endpoints' && (
        <div className="space-y-8">
          {categories.map(cat => (
            <div key={cat} className="space-y-3">
              <h2 className="text-lg font-bold flex items-center gap-2 text-white">
                {cat === 'Payments' && <CreditCard size={18} className="text-[#8b5cf6]" />}
                {cat === 'Withdrawals' && <Wallet size={18} className="text-[#fbbf24]" />}
                {cat === 'Merchants' && <Building2 size={18} className="text-[#6ee7b7]" />}
                {cat}
              </h2>
              {endpoints.filter(e => e.category === cat).map(ep => (
                <EndpointCard key={ep.path + ep.method} endpoint={ep} />
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Statuses Tab */}
      {activeTab === 'statuses' && (
        <div className="space-y-4">
          <GlassCard className="p-5">
            <h3 className="text-sm font-bold mb-4 text-white">Transaction Status Codes</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {statusList.map(s => (
                <div key={s.status} className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 rounded-xl">
                  <s.icon size={18} className={s.color} />
                  <div>
                    <div className="text-sm font-bold font-mono text-white">{s.status}</div>
                    <div className="text-xs text-gray-400">{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}