import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Wallet,
  TrendingUp,
  AlertTriangle,
  Plus,
  Settings,
  DollarSign,
  Calendar,
  Activity,
  AlertCircle,
  Upload
} from 'lucide-react';
import { useState } from 'react';

interface WalletData {
  id: string;
  provider: string;
  providerLogo: string;
  walletNumber: string;
  dailyLimit: number;
  monthlyLimit: number;
  dailyUsed: number;
  monthlyUsed: number;
  status: 'active' | 'warning' | 'critical';
  balance: number;
  transactions: number;
}

const walletsData: WalletData[] = [
  {
    id: '4523',
    provider: 'Stripe',
    providerLogo: '💳',
    walletNumber: '**** **** **** 4523',
    dailyLimit: 50000,
    monthlyLimit: 1000000,
    dailyUsed: 42500,
    monthlyUsed: 678000,
    status: 'warning',
    balance: 284500,
    transactions: 1247
  },
  {
    id: '4524',
    provider: 'PayPal',
    providerLogo: '🅿️',
    walletNumber: '**** **** **** 4524',
    dailyLimit: 35000,
    monthlyLimit: 750000,
    dailyUsed: 18900,
    monthlyUsed: 445000,
    status: 'active',
    balance: 156780,
    transactions: 892
  },
  {
    id: '4525',
    provider: 'Square',
    providerLogo: '⬛',
    walletNumber: '**** **** **** 4525',
    dailyLimit: 40000,
    monthlyLimit: 900000,
    dailyUsed: 38500,
    monthlyUsed: 823000,
    status: 'critical',
    balance: 92340,
    transactions: 654
  },
  {
    id: '4526',
    provider: 'Adyen',
    providerLogo: '🅰️',
    walletNumber: '**** **** **** 4526',
    dailyLimit: 60000,
    monthlyLimit: 1200000,
    dailyUsed: 12300,
    monthlyUsed: 289000,
    status: 'active',
    balance: 421890,
    transactions: 1567
  },
  {
    id: '4527',
    provider: 'Braintree',
    providerLogo: '🌳',
    walletNumber: '**** **** **** 4527',
    dailyLimit: 45000,
    monthlyLimit: 950000,
    dailyUsed: 29800,
    monthlyUsed: 567000,
    status: 'active',
    balance: 198560,
    transactions: 987
  },
  {
    id: '4528',
    provider: 'Authorize.Net',
    providerLogo: '🔐',
    walletNumber: '**** **** **** 4528',
    dailyLimit: 30000,
    monthlyLimit: 700000,
    dailyUsed: 27500,
    monthlyUsed: 645000,
    status: 'warning',
    balance: 134670,
    transactions: 723
  }
];

function CircularGauge({ percentage, size = 120, strokeWidth = 12 }: { percentage: number; size?: number; strokeWidth?: number }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  const color = percentage >= 90 ? '#f87171' : percentage >= 70 ? '#fbbf24' : '#6ee7b7';

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="rgba(255, 255, 255, 0.1)"
          strokeWidth={strokeWidth}
          fill="none"
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: 'easeOut' }}
          style={{ filter: `drop-shadow(0 0 8px ${color})` }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center flex-col">
        <span className="text-2xl font-bold text-white">{Math.round(percentage)}%</span>
        <span className="text-xs text-gray-400">Used</span>
      </div>
    </div>
  );
}

export function Wallets() {
  const [selectedPeriod, setSelectedPeriod] = useState<'daily' | 'monthly'>('daily');

  const totalBalance = walletsData.reduce((sum, wallet) => sum + wallet.balance, 0);
  const totalTransactions = walletsData.reduce((sum, wallet) => sum + wallet.transactions, 0);
  const activeWallets = walletsData.filter(w => w.status === 'active').length;
  const warningWallets = walletsData.filter(w => w.status === 'warning' || w.status === 'critical').length;

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Wallet Allocation System</h1>
          <p className="text-gray-400">Monitor wallet capacity and usage in real-time</p>
        </div>
        <motion.button
          className="px-6 py-3 rounded-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-medium flex items-center gap-2"
          whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
          whileTap={{ scale: 0.95 }}
        >
          <Plus className="w-5 h-5" />
          Add Wallet
        </motion.button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <Wallet className="w-6 h-6 text-[#6ee7b7]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Balance</p>
            <h3 className="text-3xl font-semibold text-white">
              ${totalBalance.toLocaleString()}
            </h3>
            <p className="text-xs text-gray-500">Across all wallets</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <Activity className="w-6 h-6 text-[#8b5cf6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Transactions</p>
            <h3 className="text-3xl font-semibold text-white">
              {totalTransactions.toLocaleString()}
            </h3>
            <p className="text-xs text-gray-500">This month</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#2563eb]/20">
              <TrendingUp className="w-6 h-6 text-[#3b82f6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Active Wallets</p>
            <h3 className="text-3xl font-semibold text-white">
              {activeWallets}
            </h3>
            <p className="text-xs text-gray-500">Operating normally</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <AlertTriangle className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Needs Attention</p>
            <h3 className="text-3xl font-semibold text-white">
              {warningWallets}
            </h3>
            <p className="text-xs text-gray-500">High usage alerts</p>
          </div>
        </GlassCard>
      </div>

      {/* Period Toggle */}
      <div className="flex items-center gap-4">
        <span className="text-sm text-gray-400">View limits:</span>
        <div className="flex gap-2 bg-white/5 p-1 rounded-xl">
          <motion.button
            onClick={() => setSelectedPeriod('daily')}
            className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedPeriod === 'daily'
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white'
                : 'text-gray-400 hover:text-white'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Calendar className="w-4 h-4 inline mr-2" />
            Daily Limits
          </motion.button>
          <motion.button
            onClick={() => setSelectedPeriod('monthly')}
            className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedPeriod === 'monthly'
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white'
                : 'text-gray-400 hover:text-white'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Calendar className="w-4 h-4 inline mr-2" />
            Monthly Limits
          </motion.button>
        </div>
      </div>

      {/* Wallet Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {walletsData.map((wallet, index) => {
          const usagePercentage = selectedPeriod === 'daily'
            ? (wallet.dailyUsed / wallet.dailyLimit) * 100
            : (wallet.monthlyUsed / wallet.monthlyLimit) * 100;

          const availableAmount = selectedPeriod === 'daily'
            ? wallet.dailyLimit - wallet.dailyUsed
            : wallet.monthlyLimit - wallet.monthlyUsed;

          const statusColors = {
            active: { bg: 'bg-[#6ee7b7]/10', border: 'border-[#6ee7b7]/30', text: 'text-[#6ee7b7]' },
            warning: { bg: 'bg-[#fbbf24]/10', border: 'border-[#fbbf24]/30', text: 'text-[#fbbf24]' },
            critical: { bg: 'bg-[#f87171]/10', border: 'border-[#f87171]/30', text: 'text-[#f87171]' }
          };

          const colors = statusColors[wallet.status];

          return (
            <motion.div
              key={wallet.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard hover className="p-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-3xl">
                      {wallet.providerLogo}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-white">{wallet.provider}</h3>
                      <p className="text-sm text-gray-400 font-mono">{wallet.walletNumber}</p>
                      <div className={`inline-flex items-center gap-1 mt-2 px-2 py-1 rounded-full ${colors.bg} border ${colors.border}`}>
                        <div className={`w-2 h-2 rounded-full ${wallet.status === 'active' ? 'bg-[#6ee7b7]' : wallet.status === 'warning' ? 'bg-[#fbbf24]' : 'bg-[#f87171]'}`} style={{ boxShadow: `0 0 8px ${wallet.status === 'active' ? '#6ee7b7' : wallet.status === 'warning' ? '#fbbf24' : '#f87171'}` }} />
                        <span className={`text-xs font-medium capitalize ${colors.text}`}>
                          {wallet.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
                  >
                    <Settings className="w-5 h-5 text-gray-400" />
                  </motion.button>
                </div>

                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Balance</span>
                      <span className="text-lg font-semibold text-white">
                        ${wallet.balance.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-400">Transactions</span>
                      <span className="text-lg font-semibold text-white">
                        {wallet.transactions}
                      </span>
                    </div>
                    {selectedPeriod === 'daily' ? (
                      <>
                        <div className="flex items-center justify-between pt-3 border-t border-white/10">
                          <span className="text-sm text-gray-400">Daily Limit</span>
                          <span className="text-sm font-medium text-white">
                            ${wallet.dailyLimit.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-400">Daily Used</span>
                          <span className="text-sm font-medium text-[#8b5cf6]">
                            ${wallet.dailyUsed.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-400">Available</span>
                          <span className="text-sm font-semibold text-[#6ee7b7]">
                            ${availableAmount.toLocaleString()}
                          </span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center justify-between pt-3 border-t border-white/10">
                          <span className="text-sm text-gray-400">Monthly Limit</span>
                          <span className="text-sm font-medium text-white">
                            ${wallet.monthlyLimit.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-400">Monthly Used</span>
                          <span className="text-sm font-medium text-[#8b5cf6]">
                            ${wallet.monthlyUsed.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-400">Available</span>
                          <span className="text-sm font-semibold text-[#6ee7b7]">
                            ${availableAmount.toLocaleString()}
                          </span>
                        </div>
                      </>
                    )}
                  </div>

                  <div className="flex items-center justify-center">
                    <CircularGauge percentage={usagePercentage} />
                  </div>
                </div>

                {/* Usage Bar */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Capacity Usage</span>
                    <span className={`font-semibold ${usagePercentage >= 90 ? 'text-[#f87171]' : usagePercentage >= 70 ? 'text-[#fbbf24]' : 'text-[#6ee7b7]'}`}>
                      {Math.round(usagePercentage)}%
                    </span>
                  </div>
                  <div className="relative w-full h-3 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${
                        usagePercentage >= 90
                          ? 'bg-gradient-to-r from-[#f87171] to-[#ef4444]'
                          : usagePercentage >= 70
                          ? 'bg-gradient-to-r from-[#fbbf24] to-[#f59e0b]'
                          : 'bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4]'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${usagePercentage}%` }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      style={{
                        boxShadow: `0 0 12px ${
                          usagePercentage >= 90 ? '#f87171' : usagePercentage >= 70 ? '#fbbf24' : '#6ee7b7'
                        }`
                      }}
                    />
                  </div>
                </div>

                {/* Warning Message */}
                {wallet.status !== 'active' && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`mt-4 p-3 rounded-lg ${colors.bg} border ${colors.border} flex items-start gap-2`}
                  >
                    <AlertTriangle className={`w-4 h-4 flex-shrink-0 mt-0.5 ${colors.text}`} />
                    <p className="text-xs text-white">
                      {wallet.status === 'critical'
                        ? 'Critical: Wallet approaching limit. Consider load balancing.'
                        : 'Warning: High usage detected. Monitor closely.'}
                    </p>
                  </motion.div>
                )}
              </GlassCard>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}