import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  TrendingUp,
  Eye,
  Ban,
  Activity,
  User,
  DollarSign,
  MapPin,
  Clock
} from 'lucide-react';
import { useState } from 'react';

interface RiskAlert {
  id: string;
  type: 'fraud' | 'suspicious' | 'high-value' | 'velocity' | 'chargeback';
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  description: string;
  merchant: string;
  amount?: number;
  timestamp: string;
  location?: string;
  status: 'active' | 'investigating' | 'resolved' | 'blocked';
}

const mockAlerts: RiskAlert[] = [
  {
    id: 'RISK-001',
    type: 'fraud',
    severity: 'critical',
    title: 'Multiple Failed Transactions',
    description: 'Same card attempted 15 transactions in 5 minutes',
    merchant: 'TechStore Electronics',
    amount: 25000,
    timestamp: '2026-03-17 11:45',
    location: 'Cairo, Egypt',
    status: 'active'
  },
  {
    id: 'RISK-002',
    type: 'high-value',
    severity: 'high',
    title: 'Unusual High-Value Transaction',
    description: 'Transaction 10x higher than average for this merchant',
    merchant: 'Fashion Hub',
    amount: 150000,
    timestamp: '2026-03-17 10:30',
    location: 'Alexandria, Egypt',
    status: 'investigating'
  },
  {
    id: 'RISK-003',
    type: 'velocity',
    severity: 'medium',
    title: 'Velocity Rule Triggered',
    description: 'Customer exceeded 5 transactions per hour limit',
    merchant: 'SuperMart Egypt',
    amount: 8500,
    timestamp: '2026-03-17 09:15',
    location: 'Giza, Egypt',
    status: 'investigating'
  },
  {
    id: 'RISK-004',
    type: 'chargeback',
    severity: 'high',
    title: 'Chargeback Risk Detected',
    description: 'Customer has high chargeback history',
    merchant: 'Food Delivery Co.',
    amount: 3200,
    timestamp: '2026-03-17 08:00',
    location: 'Cairo, Egypt',
    status: 'resolved'
  },
  {
    id: 'RISK-005',
    type: 'suspicious',
    severity: 'critical',
    title: 'IP Address Mismatch',
    description: 'Payment from different country than billing address',
    merchant: 'Beauty Palace',
    amount: 45000,
    timestamp: '2026-03-16 23:30',
    location: 'Unknown',
    status: 'blocked'
  }
];

export function Risk() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'active' | 'investigating' | 'resolved' | 'blocked'>('all');

  const filteredAlerts = filter === 'all' 
    ? mockAlerts 
    : mockAlerts.filter(a => a.status === filter);

  const criticalCount = mockAlerts.filter(a => a.severity === 'critical' && a.status === 'active').length;
  const activeCount = mockAlerts.filter(a => a.status === 'active').length;

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'from-red-600 to-red-500';
      case 'high': return 'from-orange-600 to-orange-500';
      case 'medium': return 'from-yellow-600 to-yellow-500';
      case 'low': return 'from-blue-600 to-blue-500';
      default: return 'from-gray-600 to-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'fraud': return Ban;
      case 'suspicious': return AlertTriangle;
      case 'high-value': return DollarSign;
      case 'velocity': return TrendingUp;
      case 'chargeback': return XCircle;
      default: return Shield;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-red-400';
      case 'investigating': return 'text-yellow-400';
      case 'resolved': return 'text-green-400';
      case 'blocked': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-white mb-2">Risk & Fraud Management</h1>
            <p className="text-gray-400">Monitor and manage security threats</p>
          </div>
          <div className="flex items-center gap-3">
            {criticalCount > 0 && (
              <div className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600/20 to-red-500/20 border border-red-500/30 animate-pulse">
                <p className="text-sm text-red-300">Critical Alerts</p>
                <p className="text-2xl font-bold text-red-400">{criticalCount}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { 
            label: 'Active Alerts', 
            value: activeCount, 
            icon: AlertTriangle, 
            color: 'from-[#ef4444] to-[#dc2626]' 
          },
          { 
            label: 'Investigating', 
            value: mockAlerts.filter(a => a.status === 'investigating').length, 
            icon: Eye, 
            color: 'from-[#f59e0b] to-[#d97706]' 
          },
          { 
            label: 'Resolved Today', 
            value: mockAlerts.filter(a => a.status === 'resolved').length, 
            icon: CheckCircle, 
            color: 'from-[#10b981] to-[#059669]' 
          },
          { 
            label: 'Blocked', 
            value: mockAlerts.filter(a => a.status === 'blocked').length, 
            icon: Ban, 
            color: 'from-[#64748b] to-[#475569]' 
          }
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {['all', 'active', 'investigating', 'resolved', 'blocked'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status as any)}
            className={`px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap ${
              filter === status
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-violet-500/30'
                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {/* Risk Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.map((alert, index) => {
          const TypeIcon = getTypeIcon(alert.type);
          
          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden hover:border-white/20 transition-all group"
            >
              {/* Severity Indicator */}
              <div className={`absolute top-0 left-0 w-1 h-full bg-gradient-to-b ${getSeverityColor(alert.severity)}`} />
              
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 ml-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${getSeverityColor(alert.severity)} flex items-center justify-center flex-shrink-0`}>
                    <TypeIcon className="w-7 h-7 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{alert.title}</h3>
                      <span className={`text-xs font-medium px-3 py-1 rounded-full ${getStatusColor(alert.status)} bg-white/10`}>
                        {alert.status}
                      </span>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                        alert.severity === 'critical' ? 'bg-red-500/20 text-red-300' :
                        alert.severity === 'high' ? 'bg-orange-500/20 text-orange-300' :
                        alert.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                        'bg-blue-500/20 text-blue-300'
                      }`}>
                        {alert.severity}
                      </span>
                    </div>
                    
                    <p className="text-gray-400 mb-3">{alert.description}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Merchant</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <User className="w-4 h-4" />
                          {alert.merchant}
                        </p>
                      </div>
                      {alert.amount && (
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Amount</p>
                          <p className="text-sm text-red-300 font-medium flex items-center gap-1">
                            <DollarSign className="w-4 h-4" />
                            {alert.amount.toLocaleString()} EGP
                          </p>
                        </div>
                      )}
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Location</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {alert.location}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Time</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {alert.timestamp}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  {alert.status === 'active' && (
                    <>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#f59e0b] to-[#d97706] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-yellow-500/30 transition-shadow"
                      >
                        <Eye className="w-4 h-4" />
                        Investigate
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ef4444] to-[#dc2626] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-red-500/30 transition-shadow"
                      >
                        <Ban className="w-4 h-4" />
                        Block
                      </motion.button>
                    </>
                  )}
                  {alert.status === 'investigating' && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#10b981] to-[#059669] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-green-500/30 transition-shadow"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Resolve
                    </motion.button>
                  )}
                  {(alert.status === 'resolved' || alert.status === 'blocked') && (
                    <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5">
                      <Activity className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-400">View Details</span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
