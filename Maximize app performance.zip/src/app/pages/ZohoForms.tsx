import { useState, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { GlassCard } from '../components/GlassCard';
import { 
  Search, 
  Download, 
  Filter, 
  Calendar,
  DollarSign,
  TrendingUp,
  Users,
  CreditCard,
  Phone,
  Mail,
  Building2,
  ArrowUpRight,
  ArrowDownRight,
  X
} from 'lucide-react';
import { motion } from 'motion/react';

// Import CSV data
import csvData from '../../imports/On_target_Zoho_Forms_1_.csv?raw';

interface Transaction {
  recordId: string;
  paymentDate: string;
  chooseForm: string;
  time: string;
  referrerName: string;
  email: string;
  egp: number;
  bankMethod: string;
  modifiedTime: string;
  transactionTypeSell: string;
  phone: string;
  rate: string;
  mobileWallet: string;
  submittedLanguage: string;
  transactionTypeWithdrawal: string;
  ipAddress: string;
  usd: number;
  transactionTypeDeposit: string;
  transactionTypeBuy: string;
  addedTime: string;
  name: string;
  addedEmailId: string;
}

function parseCSV(csv: string): Transaction[] {
  const lines = csv.trim().split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    const values = line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g) || [];
    const cleanValues = values.map(v => v.replace(/^"|"$/g, '').trim());
    
    const egpMatch = cleanValues[6]?.match(/[\d.]+/);
    const usdMatch = cleanValues[16]?.match(/[\d.]+/);
    
    return {
      recordId: cleanValues[0] || '',
      paymentDate: cleanValues[1] || '',
      chooseForm: cleanValues[2] || '',
      time: cleanValues[3] || '',
      referrerName: cleanValues[4] || '',
      email: cleanValues[5] || '',
      egp: egpMatch ? parseFloat(egpMatch[0]) : 0,
      bankMethod: cleanValues[7] || '',
      modifiedTime: cleanValues[8] || '',
      transactionTypeSell: cleanValues[9] || '',
      phone: cleanValues[10] || '',
      rate: cleanValues[11] || '',
      mobileWallet: cleanValues[12] || '',
      submittedLanguage: cleanValues[13] || '',
      transactionTypeWithdrawal: cleanValues[14] || '',
      ipAddress: cleanValues[15] || '',
      usd: usdMatch ? parseFloat(usdMatch[0]) : 0,
      transactionTypeDeposit: cleanValues[17] || '',
      transactionTypeBuy: cleanValues[18] || '',
      addedTime: cleanValues[19] || '',
      name: cleanValues[20] || '',
      addedEmailId: cleanValues[21] || ''
    };
  }).filter(t => t.recordId && t.name);
}

export function ZohoForms() {
  const { t, language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterMethod, setFilterMethod] = useState<string>('all');

  const transactions = useMemo(() => parseCSV(csvData), []);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      const matchesSearch = 
        tx.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tx.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tx.phone.includes(searchTerm) ||
        tx.recordId.includes(searchTerm);

      const txType = tx.transactionTypeBuy || tx.transactionTypeSell || 
                     tx.transactionTypeDeposit || tx.transactionTypeWithdrawal || '';
      const matchesType = filterType === 'all' || txType.toLowerCase().includes(filterType.toLowerCase());

      const method = tx.bankMethod || tx.mobileWallet || '';
      const matchesMethod = filterMethod === 'all' || method.toLowerCase().includes(filterMethod.toLowerCase());

      return matchesSearch && matchesType && matchesMethod;
    });
  }, [transactions, searchTerm, filterType, filterMethod]);

  const stats = useMemo(() => {
    const totalUSD = transactions.reduce((sum, tx) => sum + tx.usd, 0);
    const totalEGP = transactions.reduce((sum, tx) => sum + tx.egp, 0);
    const uniqueCustomers = new Set(transactions.map(tx => tx.email).filter(Boolean)).size;
    const avgRate = transactions.filter(tx => tx.rate).length > 0 
      ? transactions.reduce((sum, tx) => {
          const rateMatch = tx.rate.match(/[\d.]+/);
          return sum + (rateMatch ? parseFloat(rateMatch[0]) : 0);
        }, 0) / transactions.filter(tx => tx.rate).length
      : 0;

    return { totalUSD, totalEGP, uniqueCustomers, avgRate };
  }, [transactions]);

  const getTransactionType = (tx: Transaction) => {
    if (tx.transactionTypeBuy) return { type: 'Buy', icon: ArrowDownRight, color: 'text-[#6ee7b7]' };
    if (tx.transactionTypeSell) return { type: 'Sell', icon: ArrowUpRight, color: 'text-[#fbbf24]' };
    if (tx.transactionTypeDeposit) return { type: 'Deposit', icon: ArrowDownRight, color: 'text-[#3b82f6]' };
    if (tx.transactionTypeWithdrawal) return { type: 'Withdrawal', icon: ArrowUpRight, color: 'text-[#8b5cf6]' };
    return { type: 'N/A', icon: CreditCard, color: 'text-gray-400' };
  };

  const exportToCSV = () => {
    const csv = [
      'Record ID,Name,Email,Phone,USD,EGP,Type,Method,Date',
      ...filteredTransactions.map(tx => {
        const { type } = getTransactionType(tx);
        return `${tx.recordId},"${tx.name}","${tx.email}",${tx.phone},${tx.usd},${tx.egp},${type},"${tx.bankMethod || tx.mobileWallet}","${tx.paymentDate}"`;
      })
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zoho-forms-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Zoho Forms Data
          </h1>
          <p className="text-gray-400">
            Exchange transaction records from Zoho Forms
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={exportToCSV}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg hover:shadow-xl transition-all"
        >
          <Download className="w-4 h-4" />
          Export CSV
        </motion.button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#3b82f6]/5">
              <DollarSign className="w-6 h-6 text-[#3b82f6]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Total USD</p>
              <p className="text-xl font-bold text-white">
                ${stats.totalUSD.toLocaleString('en-US', { maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#6ee7b7]/5">
              <TrendingUp className="w-6 h-6 text-[#6ee7b7]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Total EGP</p>
              <p className="text-xl font-bold text-white">
                {stats.totalEGP.toLocaleString('en-US', { maximumFractionDigits: 2 })} EGP
              </p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#8b5cf6]/5">
              <Users className="w-6 h-6 text-[#8b5cf6]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Customers</p>
              <p className="text-xl font-bold text-white">{stats.uniqueCustomers}</p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#fbbf24]/5">
              <CreditCard className="w-6 h-6 text-[#fbbf24]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Avg Rate</p>
              <p className="text-xl font-bold text-white">
                {stats.avgRate.toFixed(2)} EGP
              </p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, email, phone, or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-10 py-2 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/50"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Type Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/50 appearance-none cursor-pointer"
            >
              <option value="all">All Types</option>
              <option value="buy">Buy</option>
              <option value="sell">Sell</option>
              <option value="deposit">Deposit</option>
              <option value="withdrawal">Withdrawal</option>
            </select>
          </div>

          {/* Method Filter */}
          <div className="relative">
            <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <select
              value={filterMethod}
              onChange={(e) => setFilterMethod(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/50 appearance-none cursor-pointer"
            >
              <option value="all">All Methods</option>
              <option value="bank">Bank</option>
              <option value="vodafone">Vodafone</option>
              <option value="insta">Instapay</option>
            </select>
          </div>
        </div>

        <div className="mt-3 text-sm text-gray-400">
          Showing {filteredTransactions.length} of {transactions.length} transactions
        </div>
      </GlassCard>

      {/* Transactions Table */}
      <GlassCard className="p-4 overflow-x-auto">
        <div className="min-w-[900px]">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-2 text-xs font-semibold text-gray-400">DATE</th>
                <th className="text-left py-3 px-2 text-xs font-semibold text-gray-400">CUSTOMER</th>
                <th className="text-left py-3 px-2 text-xs font-semibold text-gray-400">CONTACT</th>
                <th className="text-left py-3 px-2 text-xs font-semibold text-gray-400">TYPE</th>
                <th className="text-right py-3 px-2 text-xs font-semibold text-gray-400">USD</th>
                <th className="text-right py-3 px-2 text-xs font-semibold text-gray-400">EGP</th>
                <th className="text-right py-3 px-2 text-xs font-semibold text-gray-400">RATE</th>
                <th className="text-left py-3 px-2 text-xs font-semibold text-gray-400">METHOD</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((tx, index) => {
                const { type, icon: Icon, color } = getTransactionType(tx);
                const rateMatch = tx.rate.match(/[\d.]+/);
                const rate = rateMatch ? parseFloat(rateMatch[0]) : 0;

                return (
                  <motion.tr
                    key={tx.recordId}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.02 }}
                    className="border-b border-white/5 hover:bg-white/5 transition-colors"
                  >
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <div>
                          <div className="text-sm text-white">{tx.paymentDate.split(',')[0]}</div>
                          <div className="text-xs text-gray-500">{tx.time}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <div>
                        <div className="text-sm font-medium text-white">{tx.name}</div>
                        <div className="text-xs text-gray-500">{tx.email || 'N/A'}</div>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-2">
                        <Phone className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-300">{tx.phone || 'N/A'}</span>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <div className={`flex items-center gap-2 ${color}`}>
                        <Icon className="w-4 h-4" />
                        <span className="text-sm font-medium">{type}</span>
                      </div>
                    </td>
                    <td className="py-3 px-2 text-right">
                      <div className="text-sm font-semibold text-white">
                        ${tx.usd.toLocaleString('en-US', { maximumFractionDigits: 2 })}
                      </div>
                    </td>
                    <td className="py-3 px-2 text-right">
                      <div className="text-sm text-gray-300">
                        {tx.egp.toLocaleString('en-US', { maximumFractionDigits: 2 })} EGP
                      </div>
                    </td>
                    <td className="py-3 px-2 text-right">
                      <div className="text-sm text-[#6ee7b7]">
                        {rate > 0 ? rate.toFixed(2) : 'N/A'}
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <div className="text-xs px-2 py-1 rounded-lg bg-white/5 text-gray-300 inline-block">
                        {tx.bankMethod || tx.mobileWallet || 'N/A'}
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>

          {filteredTransactions.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400">No transactions found</p>
            </div>
          )}
        </div>
      </GlassCard>
    </div>
  );
}
