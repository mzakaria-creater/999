import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  ArrowLeft,
  Building2,
  Mail,
  Globe,
  Phone,
  MapPin,
  Calendar,
  CheckCircle,
  XCircle,
  AlertCircle,
  Key,
  Copy,
  RefreshCw,
  Eye,
  EyeOff,
  CreditCard,
  Banknote,
  Wallet,
  DollarSign,
  TrendingUp,
  Activity,
  Settings,
  Shield,
  Crown,
  Star,
  Zap,
  Edit,
  Save,
  X,
  Plus,
  Trash2,
  Link as LinkIcon,
  Code,
  Lock,
  Unlock,
  AlertTriangle
} from 'lucide-react';
import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { toast } from 'sonner';

type MerchantTier = 'starter' | 'growth' | 'professional' | 'enterprise';
type ApiKeyStatus = 'active' | 'inactive' | 'revoked';

interface MerchantData {
  id: string;
  name: string;
  businessName: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  city: string;
  country: string;
  registrationDate: string;
  status: 'active' | 'inactive' | 'suspended';
  tier: MerchantTier;
  volume: {
    monthly: number;
    total: number;
  };
  transactions: {
    monthly: number;
    total: number;
  };
  fees: {
    transactionFee: number;
    monthlyFee: number;
  };
  apiKeys: {
    id: string;
    name: string;
    key: string;
    status: ApiKeyStatus;
    createdDate: string;
    lastUsed: string;
    permissions: string[];
  }[];
  paymentMethods: {
    id: string;
    name: string;
    type: string;
    enabled: boolean;
    config: any;
  }[];
  checkoutConfig: {
    redirectUrl: string;
    webhookUrl: string;
    successUrl: string;
    cancelUrl: string;
    theme: string;
    language: string;
    currencies: string[];
  };
}

const tierConfig = {
  starter: {
    name: 'Starter',
    icon: Zap,
    color: 'from-[#6ee7b7] to-[#06b6d4]',
    textColor: 'text-[#6ee7b7]',
    bgColor: 'bg-[#6ee7b7]/10',
    borderColor: 'border-[#6ee7b7]/30',
    limits: {
      monthlyVolume: 10000,
      transactionFee: 2.9,
      monthlyFee: 0,
    }
  },
  growth: {
    name: 'Growth',
    icon: TrendingUp,
    color: 'from-[#3b82f6] to-[#2563eb]',
    textColor: 'text-[#3b82f6]',
    bgColor: 'bg-[#3b82f6]/10',
    borderColor: 'border-[#3b82f6]/30',
    limits: {
      monthlyVolume: 50000,
      transactionFee: 2.5,
      monthlyFee: 49,
    }
  },
  professional: {
    name: 'Professional',
    icon: Star,
    color: 'from-[#8b5cf6] to-[#6366f1]',
    textColor: 'text-[#8b5cf6]',
    bgColor: 'bg-[#8b5cf6]/10',
    borderColor: 'border-[#8b5cf6]/30',
    limits: {
      monthlyVolume: 200000,
      transactionFee: 2.2,
      monthlyFee: 199,
    }
  },
  enterprise: {
    name: 'Enterprise',
    icon: Crown,
    color: 'from-[#fbbf24] to-[#f59e0b]',
    textColor: 'text-[#fbbf24]',
    bgColor: 'bg-[#fbbf24]/10',
    borderColor: 'border-[#fbbf24]/30',
    limits: {
      monthlyVolume: 999999999,
      transactionFee: 1.9,
      monthlyFee: 499,
    }
  }
};

// Mock data
const mockMerchant: MerchantData = {
  id: 'MCH-1001',
  name: 'TechStore Electronics',
  businessName: 'TechStore Inc.',
  email: 'admin@techstore.com',
  phone: '+1 (555) 123-4567',
  website: 'https://techstore.com',
  address: '123 Tech Street',
  city: 'San Francisco, CA 94105',
  country: 'United States',
  registrationDate: '2025-08-15',
  status: 'active',
  tier: 'professional',
  volume: {
    monthly: 145230,
    total: 1245680
  },
  transactions: {
    monthly: 1247,
    total: 8934
  },
  fees: {
    transactionFee: 2.2,
    monthlyFee: 199
  },
  apiKeys: [
    {
      id: 'key-1',
      name: 'Production API Key',
      key: 'sk_live_51H8xJ2eZvKYlo2C9W8H9f3mP5Q6R7sT8uV9w0X1y2Z3a4B5c6D7e8F9g0H',
      status: 'active',
      createdDate: '2025-08-15',
      lastUsed: '2 hours ago',
      permissions: ['read', 'write', 'delete']
    },
    {
      id: 'key-2',
      name: 'Development API Key',
      key: 'sk_test_51K3mL4fAwPBlm3D0X9I0g4nQ6S7R8tU9vW0x1Y2z3A4b5C6d7E8f9G0h1I',
      status: 'active',
      createdDate: '2025-09-20',
      lastUsed: '1 day ago',
      permissions: ['read', 'write']
    },
    {
      id: 'key-3',
      name: 'Legacy API Key',
      key: 'sk_live_51M5oN6gByQCnm4E1Y0J1h5oR7T8S9uV0wX1y2Z3a4B5c6D7e8F9g0H1i2J',
      status: 'revoked',
      createdDate: '2025-06-10',
      lastUsed: '30 days ago',
      permissions: ['read']
    }
  ],
  paymentMethods: [
    {
      id: 'pm-1',
      name: 'Credit/Debit Cards',
      type: 'card',
      enabled: true,
      config: {
        brands: ['visa', 'mastercard', 'amex'],
        currency: 'USD'
      }
    },
    {
      id: 'pm-2',
      name: 'Bank Transfer',
      type: 'bank_transfer',
      enabled: true,
      config: {
        banks: ['Chase', 'Bank of America', 'Wells Fargo'],
        processingDays: 2
      }
    },
    {
      id: 'pm-3',
      name: 'Digital Wallets',
      type: 'wallet',
      enabled: true,
      config: {
        providers: ['Apple Pay', 'Google Pay', 'PayPal']
      }
    },
    {
      id: 'pm-4',
      name: 'Cryptocurrency',
      type: 'crypto',
      enabled: false,
      config: {
        currencies: ['BTC', 'ETH', 'USDT']
      }
    }
  ],
  checkoutConfig: {
    redirectUrl: 'https://techstore.com/payment/callback',
    webhookUrl: 'https://techstore.com/api/webhooks/payment',
    successUrl: 'https://techstore.com/payment/success',
    cancelUrl: 'https://techstore.com/payment/cancel',
    theme: 'dark',
    language: 'en',
    currencies: ['USD', 'EUR', 'GBP']
  }
};

export function MerchantDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [merchant, setMerchant] = useState<MerchantData>(mockMerchant);
  const [activeTab, setActiveTab] = useState<'overview' | 'api-keys' | 'payment-methods' | 'checkout'>('overview');
  const [isEditing, setIsEditing] = useState(false);
  const [showNewApiKeyModal, setShowNewApiKeyModal] = useState(false);
  const [showNewPaymentMethodModal, setShowNewPaymentMethodModal] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [showTierModal, setShowTierModal] = useState(false);
  
  const [editedMerchant, setEditedMerchant] = useState(merchant);
  const [newApiKey, setNewApiKey] = useState({
    name: '',
    permissions: [] as string[]
  });

  const tierInfo = tierConfig[merchant.tier];
  const TierIcon = tierInfo.icon;

  const statusConfig = {
    active: {
      bg: 'bg-[#6ee7b7]/10',
      text: 'text-[#6ee7b7]',
      border: 'border-[#6ee7b7]/30',
      icon: CheckCircle
    },
    inactive: {
      bg: 'bg-[#9ca3af]/10',
      text: 'text-[#9ca3af]',
      border: 'border-[#9ca3af]/30',
      icon: AlertCircle
    },
    suspended: {
      bg: 'bg-[#f87171]/10',
      text: 'text-[#f87171]',
      border: 'border-[#f87171]/30',
      icon: XCircle
    },
    revoked: {
      bg: 'bg-[#f87171]/10',
      text: 'text-[#f87171]',
      border: 'border-[#f87171]/30',
      icon: Lock
    }
  };

  const toggleKeyVisibility = (keyId: string) => {
    setVisibleKeys(prev => {
      const newSet = new Set(prev);
      if (newSet.has(keyId)) {
        newSet.delete(keyId);
      } else {
        newSet.add(keyId);
      }
      return newSet;
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const generateNewApiKey = () => {
    const newKey = {
      id: `key-${Date.now()}`,
      name: newApiKey.name,
      key: `sk_live_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`,
      status: 'active' as ApiKeyStatus,
      createdDate: new Date().toISOString().split('T')[0],
      lastUsed: 'Never',
      permissions: newApiKey.permissions
    };

    setMerchant(prev => ({
      ...prev,
      apiKeys: [...prev.apiKeys, newKey]
    }));

    toast.success('API Key generated successfully!');
    setShowNewApiKeyModal(false);
    setNewApiKey({ name: '', permissions: [] });
  };

  const revokeApiKey = (keyId: string) => {
    setMerchant(prev => ({
      ...prev,
      apiKeys: prev.apiKeys.map(key =>
        key.id === keyId ? { ...key, status: 'revoked' as ApiKeyStatus } : key
      )
    }));
    toast.success('API Key revoked successfully');
  };

  const togglePaymentMethod = (methodId: string) => {
    setMerchant(prev => ({
      ...prev,
      paymentMethods: prev.paymentMethods.map(method =>
        method.id === methodId ? { ...method, enabled: !method.enabled } : method
      )
    }));
    toast.success('Payment method updated');
  };

  const saveMerchantChanges = () => {
    setMerchant(editedMerchant);
    setIsEditing(false);
    toast.success('Merchant profile updated successfully!');
  };

  const changeTier = (newTier: MerchantTier) => {
    setMerchant(prev => ({ ...prev, tier: newTier }));
    setShowTierModal(false);
    toast.success(`Merchant tier updated to ${tierConfig[newTier].name}`);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Building2 },
    { id: 'api-keys', label: 'API Keys', icon: Key },
    { id: 'payment-methods', label: 'Payment Methods', icon: CreditCard },
    { id: 'checkout', label: 'Checkout Config', icon: Settings }
  ];

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <motion.button
            onClick={() => navigate('/merchants')}
            whileHover={{ scale: 1.05, x: -5 }}
            whileTap={{ scale: 0.95 }}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-semibold text-white">{merchant.name}</h1>
              {!isEditing ? (
                <motion.button
                  onClick={() => {
                    setIsEditing(true);
                    setEditedMerchant(merchant);
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-all"
                >
                  <Edit className="w-4 h-4 text-gray-400" />
                </motion.button>
              ) : (
                <div className="flex items-center gap-2">
                  <motion.button
                    onClick={saveMerchantChanges}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white text-sm font-medium"
                  >
                    <Save className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    onClick={() => setIsEditing(false)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white text-sm"
                  >
                    <X className="w-4 h-4" />
                  </motion.button>
                </div>
              )}
            </div>
            <p className="text-gray-400 mt-1">Merchant ID: {merchant.id}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Status Badge */}
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${statusConfig[merchant.status].bg} ${statusConfig[merchant.status].text} border ${statusConfig[merchant.status].border}`}>
            {(() => {
              const StatusIcon = statusConfig[merchant.status].icon;
              return <StatusIcon className="w-4 h-4" />;
            })()}
            <span className="text-sm font-medium capitalize">{merchant.status}</span>
          </div>

          {/* Tier Badge */}
          <motion.button
            onClick={() => setShowTierModal(true)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${tierInfo.bgColor} ${tierInfo.textColor} border ${tierInfo.borderColor}`}
          >
            <TierIcon className="w-4 h-4" />
            <span className="text-sm font-medium">{tierInfo.name} Tier</span>
          </motion.button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <DollarSign className="w-6 h-6 text-[#8b5cf6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Monthly Volume</p>
            <h3 className="text-3xl font-semibold text-white">${(merchant.volume.monthly / 1000).toFixed(1)}k</h3>
            <p className="text-xs text-gray-500">Total: ${(merchant.volume.total / 1000).toFixed(0)}k</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <Activity className="w-6 h-6 text-[#6ee7b7]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Transactions</p>
            <h3 className="text-3xl font-semibold text-white">{merchant.transactions.monthly.toLocaleString()}</h3>
            <p className="text-xs text-gray-500">Total: {merchant.transactions.total.toLocaleString()}</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <TrendingUp className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Transaction Fee</p>
            <h3 className="text-3xl font-semibold text-white">{merchant.fees.transactionFee}%</h3>
            <p className="text-xs text-gray-500">Monthly: ${merchant.fees.monthlyFee}</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#2563eb]/20">
              <CreditCard className="w-6 h-6 text-[#3b82f6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Payment Methods</p>
            <h3 className="text-3xl font-semibold text-white">{merchant.paymentMethods.filter(m => m.enabled).length}</h3>
            <p className="text-xs text-gray-500">of {merchant.paymentMethods.length} enabled</p>
          </div>
        </GlassCard>
      </div>

      {/* Tabs */}
      <GlassCard className="p-2">
        <div className="flex items-center gap-2">
          {tabs.map((tab) => {
            const TabIcon = tab.icon;
            return (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-medium transition-all relative ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                    : 'text-gray-400 hover:bg-white/5'
                }`}
              >
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-gradient-to-r from-[#8b5cf6]/10 to-[#3b82f6]/10 rounded-xl"
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <TabIcon className="w-5 h-5 relative z-10" />
                <span className="relative z-10">{tab.label}</span>
              </motion.button>
            );
          })}
        </div>
      </GlassCard>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {activeTab === 'overview' && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Business Information */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-[#8b5cf6]" />
                Business Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Business Name</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editedMerchant.businessName}
                      onChange={(e) => setEditedMerchant({ ...editedMerchant, businessName: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  ) : (
                    <p className="text-white font-medium">{merchant.businessName}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Address
                  </label>
                  {isEditing ? (
                    <input
                      type="email"
                      value={editedMerchant.email}
                      onChange={(e) => setEditedMerchant({ ...editedMerchant, email: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  ) : (
                    <p className="text-white font-medium">{merchant.email}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone Number
                  </label>
                  {isEditing ? (
                    <input
                      type="tel"
                      value={editedMerchant.phone}
                      onChange={(e) => setEditedMerchant({ ...editedMerchant, phone: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  ) : (
                    <p className="text-white font-medium">{merchant.phone}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    Website
                  </label>
                  {isEditing ? (
                    <input
                      type="url"
                      value={editedMerchant.website}
                      onChange={(e) => setEditedMerchant({ ...editedMerchant, website: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  ) : (
                    <a href={merchant.website} target="_blank" rel="noopener noreferrer" className="text-[#8b5cf6] hover:underline font-medium">
                      {merchant.website}
                    </a>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Address
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editedMerchant.address}
                      onChange={(e) => setEditedMerchant({ ...editedMerchant, address: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  ) : (
                    <p className="text-white font-medium">{merchant.address}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    City & Country
                  </label>
                  <p className="text-white font-medium">{merchant.city}, {merchant.country}</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Registration Date
                  </label>
                  <p className="text-white font-medium">{new Date(merchant.registrationDate).toLocaleDateString()}</p>
                </div>
              </div>
            </GlassCard>

            {/* Tier Information */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <Crown className="w-5 h-5 text-[#fbbf24]" />
                Tier Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Current Tier</label>
                  <div className={`flex items-center gap-2 px-4 py-3 rounded-xl ${tierInfo.bgColor} border ${tierInfo.borderColor}`}>
                    <TierIcon className={`w-5 h-5 ${tierInfo.textColor}`} />
                    <span className={`font-semibold ${tierInfo.textColor}`}>{tierInfo.name}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Monthly Volume Limit</label>
                  <p className="text-white font-semibold text-lg">
                    {tierInfo.limits.monthlyVolume === 999999999 ? 'Unlimited' : `$${tierInfo.limits.monthlyVolume.toLocaleString()}`}
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Transaction Fee</label>
                  <p className="text-white font-semibold text-lg">{tierInfo.limits.transactionFee}%</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Monthly Fee</label>
                  <p className="text-white font-semibold text-lg">
                    {tierInfo.limits.monthlyFee === 0 ? 'Free' : `$${tierInfo.limits.monthlyFee}`}
                  </p>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {activeTab === 'api-keys' && (
          <motion.div
            key="api-keys"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-white">API Keys</h2>
                <p className="text-gray-400 text-sm mt-1">Manage API keys for integrations</p>
              </div>
              <motion.button
                onClick={() => setShowNewApiKeyModal(true)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Generate New Key
              </motion.button>
            </div>

            <div className="space-y-4">
              {merchant.apiKeys.map((apiKey) => {
                const keyConfig = statusConfig[apiKey.status];
                const KeyStatusIcon = keyConfig.icon;
                const isVisible = visibleKeys.has(apiKey.id);

                return (
                  <GlassCard key={apiKey.id} className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-semibold text-white">{apiKey.name}</h3>
                          <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full ${keyConfig.bg} ${keyConfig.text} border ${keyConfig.border}`}>
                            <KeyStatusIcon className="w-3 h-3" />
                            <span className="text-xs font-medium capitalize">{apiKey.status}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 mb-3">
                          <code className="px-3 py-2 bg-black/30 rounded-lg text-sm font-mono text-gray-300 flex-1">
                            {isVisible ? apiKey.key : apiKey.key.substring(0, 20) + '•'.repeat(40)}
                          </code>
                          <motion.button
                            onClick={() => toggleKeyVisibility(apiKey.id)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10"
                          >
                            {isVisible ? <EyeOff className="w-4 h-4 text-gray-400" /> : <Eye className="w-4 h-4 text-gray-400" />}
                          </motion.button>
                          <motion.button
                            onClick={() => copyToClipboard(apiKey.key)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10"
                          >
                            <Copy className="w-4 h-4 text-gray-400" />
                          </motion.button>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-400">
                          <span>Created: {apiKey.createdDate}</span>
                          <span>•</span>
                          <span>Last used: {apiKey.lastUsed}</span>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-3">
                          {apiKey.permissions.map((permission) => (
                            <span key={permission} className="px-2 py-1 rounded-md bg-white/5 text-xs text-gray-300">
                              {permission}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        {apiKey.status !== 'revoked' && (
                          <motion.button
                            onClick={() => revokeApiKey(apiKey.id)}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-500"
                          >
                            <Lock className="w-4 h-4" />
                          </motion.button>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </motion.div>
        )}

        {activeTab === 'payment-methods' && (
          <motion.div
            key="payment-methods"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-white">Payment Methods</h2>
                <p className="text-gray-400 text-sm mt-1">Configure accepted payment methods</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {merchant.paymentMethods.map((method) => {
                const icons = {
                  card: CreditCard,
                  bank_transfer: Banknote,
                  wallet: Wallet,
                  crypto: DollarSign
                };
                const MethodIcon = icons[method.type as keyof typeof icons];

                return (
                  <GlassCard key={method.id} className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-3 rounded-xl ${method.enabled ? 'bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20' : 'bg-white/5'}`}>
                          <MethodIcon className={`w-6 h-6 ${method.enabled ? 'text-[#8b5cf6]' : 'text-gray-400'}`} />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-white">{method.name}</h3>
                          <p className="text-sm text-gray-400 capitalize">{method.type.replace('_', ' ')}</p>
                        </div>
                      </div>
                      <motion.button
                        onClick={() => togglePaymentMethod(method.id)}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className={`p-2 rounded-lg transition-all ${
                          method.enabled
                            ? 'bg-[#6ee7b7]/10 border border-[#6ee7b7]/30 text-[#6ee7b7]'
                            : 'bg-white/5 border border-white/10 text-gray-400'
                        }`}
                      >
                        {method.enabled ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                      </motion.button>
                    </div>

                    <div className="space-y-2">
                      {method.type === 'card' && (
                        <div className="flex flex-wrap gap-2">
                          {method.config.brands.map((brand: string) => (
                            <span key={brand} className="px-3 py-1 rounded-full bg-white/5 text-xs text-gray-300 capitalize">
                              {brand}
                            </span>
                          ))}
                        </div>
                      )}
                      {method.type === 'bank_transfer' && (
                        <p className="text-sm text-gray-400">Processing: {method.config.processingDays} days</p>
                      )}
                      {method.type === 'wallet' && (
                        <div className="flex flex-wrap gap-2">
                          {method.config.providers.map((provider: string) => (
                            <span key={provider} className="px-3 py-1 rounded-full bg-white/5 text-xs text-gray-300">
                              {provider}
                            </span>
                          ))}
                        </div>
                      )}
                      {method.type === 'crypto' && (
                        <div className="flex flex-wrap gap-2">
                          {method.config.currencies.map((currency: string) => (
                            <span key={currency} className="px-3 py-1 rounded-full bg-white/5 text-xs text-gray-300 font-mono">
                              {currency}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </motion.div>
        )}

        {activeTab === 'checkout' && (
          <motion.div
            key="checkout"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#8b5cf6]" />
                Checkout Configuration
              </h2>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400 flex items-center gap-2">
                      <LinkIcon className="w-4 h-4" />
                      Redirect URL
                    </label>
                    <input
                      type="url"
                      value={merchant.checkoutConfig.redirectUrl}
                      onChange={(e) => setMerchant({
                        ...merchant,
                        checkoutConfig: { ...merchant.checkoutConfig, redirectUrl: e.target.value }
                      })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-400 flex items-center gap-2">
                      <Code className="w-4 h-4" />
                      Webhook URL
                    </label>
                    <input
                      type="url"
                      value={merchant.checkoutConfig.webhookUrl}
                      onChange={(e) => setMerchant({
                        ...merchant,
                        checkoutConfig: { ...merchant.checkoutConfig, webhookUrl: e.target.value }
                      })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-400 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      Success URL
                    </label>
                    <input
                      type="url"
                      value={merchant.checkoutConfig.successUrl}
                      onChange={(e) => setMerchant({
                        ...merchant,
                        checkoutConfig: { ...merchant.checkoutConfig, successUrl: e.target.value }
                      })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-400 flex items-center gap-2">
                      <XCircle className="w-4 h-4" />
                      Cancel URL
                    </label>
                    <input
                      type="url"
                      value={merchant.checkoutConfig.cancelUrl}
                      onChange={(e) => setMerchant({
                        ...merchant,
                        checkoutConfig: { ...merchant.checkoutConfig, cancelUrl: e.target.value }
                      })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Theme</label>
                    <select
                      value={merchant.checkoutConfig.theme}
                      onChange={(e) => setMerchant({
                        ...merchant,
                        checkoutConfig: { ...merchant.checkoutConfig, theme: e.target.value }
                      })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                      <option value="auto">Auto</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Language</label>
                    <select
                      value={merchant.checkoutConfig.language}
                      onChange={(e) => setMerchant({
                        ...merchant,
                        checkoutConfig: { ...merchant.checkoutConfig, language: e.target.value }
                      })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    >
                      <option value="en">English</option>
                      <option value="ar">Arabic</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Supported Currencies</label>
                  <div className="flex flex-wrap gap-2">
                    {merchant.checkoutConfig.currencies.map((currency) => (
                      <span key={currency} className="px-4 py-2 rounded-full bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30 text-white font-mono text-sm">
                        {currency}
                      </span>
                    ))}
                  </div>
                </div>

                <motion.button
                  onClick={() => toast.success('Checkout configuration saved!')}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium"
                >
                  Save Configuration
                </motion.button>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* New API Key Modal */}
      <AnimatePresence>
        {showNewApiKeyModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
              onClick={() => setShowNewApiKeyModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
              <div className="w-full max-w-lg bg-[#1a1d23] border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
                <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#8b5cf6]/10 to-[#3b82f6]/10">
                  <h2 className="text-xl font-semibold text-white">Generate New API Key</h2>
                  <motion.button
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowNewApiKeyModal(false)}
                    className="p-2 rounded-lg hover:bg-white/10 transition-all"
                  >
                    <X className="w-5 h-5 text-gray-400" />
                  </motion.button>
                </div>

                <div className="p-6 space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Key Name</label>
                    <input
                      type="text"
                      value={newApiKey.name}
                      onChange={(e) => setNewApiKey({ ...newApiKey, name: e.target.value })}
                      placeholder="e.g., Production Key, Development Key"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Permissions</label>
                    <div className="flex flex-wrap gap-2">
                      {['read', 'write', 'delete'].map((permission) => (
                        <motion.button
                          key={permission}
                          onClick={() => {
                            setNewApiKey(prev => ({
                              ...prev,
                              permissions: prev.permissions.includes(permission)
                                ? prev.permissions.filter(p => p !== permission)
                                : [...prev.permissions, permission]
                            }));
                          }}
                          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            newApiKey.permissions.includes(permission)
                              ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                              : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                          }`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {permission}
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-[#fbbf24]/10 border border-[#fbbf24]/30">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-[#fbbf24] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-[#fbbf24] font-medium mb-1">Important Security Note</p>
                        <p className="text-xs text-gray-400">
                          Make sure to copy your API key now. You won't be able to see it again after closing this dialog.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-6 py-4 border-t border-white/10 flex items-center justify-end gap-3 bg-white/5">
                  <motion.button
                    onClick={() => setShowNewApiKeyModal(false)}
                    className="px-6 py-3 rounded-full bg-white/5 text-white font-medium hover:bg-white/10 transition-all"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Cancel
                  </motion.button>
                  <motion.button
                    onClick={generateNewApiKey}
                    disabled={!newApiKey.name || newApiKey.permissions.length === 0}
                    className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                    whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Generate Key
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Tier Change Modal */}
      <AnimatePresence>
        {showTierModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
              onClick={() => setShowTierModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
              <div className="w-full max-w-4xl bg-[#1a1d23] border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
                <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#8b5cf6]/10 to-[#3b82f6]/10">
                  <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                    <Crown className="w-5 h-5 text-[#fbbf24]" />
                    Change Merchant Tier
                  </h2>
                  <motion.button
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowTierModal(false)}
                    className="p-2 rounded-lg hover:bg-white/10 transition-all"
                  >
                    <X className="w-5 h-5 text-gray-400" />
                  </motion.button>
                </div>

                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {(Object.keys(tierConfig) as MerchantTier[]).map((tierKey) => {
                      const tier = tierConfig[tierKey];
                      const TierIconComponent = tier.icon;
                      const isCurrentTier = tierKey === merchant.tier;

                      return (
                        <motion.button
                          key={tierKey}
                          onClick={() => changeTier(tierKey)}
                          whileHover={{ scale: 1.05, y: -5 }}
                          whileTap={{ scale: 0.95 }}
                          className={`p-6 rounded-2xl border-2 transition-all ${
                            isCurrentTier
                              ? `${tier.bgColor} ${tier.borderColor}`
                              : 'bg-white/5 border-white/10 hover:border-white/20'
                          }`}
                        >
                          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tier.color} flex items-center justify-center mb-4 mx-auto`}>
                            <TierIconComponent className="w-6 h-6 text-white" />
                          </div>
                          <h3 className={`text-lg font-bold mb-2 ${tier.textColor}`}>{tier.name}</h3>
                          <div className="space-y-2 text-sm">
                            <p className="text-gray-400">
                              Volume: <span className="text-white font-medium">
                                {tier.limits.monthlyVolume === 999999999 ? 'Unlimited' : `$${tier.limits.monthlyVolume.toLocaleString()}`}
                              </span>
                            </p>
                            <p className="text-gray-400">
                              Fee: <span className="text-white font-medium">{tier.limits.transactionFee}%</span>
                            </p>
                            <p className="text-gray-400">
                              Monthly: <span className="text-white font-medium">
                                {tier.limits.monthlyFee === 0 ? 'Free' : `$${tier.limits.monthlyFee}`}
                              </span>
                            </p>
                          </div>
                          {isCurrentTier && (
                            <div className="mt-4 px-3 py-1 rounded-full bg-white/10 text-xs text-white font-medium">
                              Current Tier
                            </div>
                          )}
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
