import { motion } from 'motion/react';
import { useState } from 'react';
import { 
  Palette, 
  Globe, 
  Bell, 
  Lock, 
  User, 
  CreditCard,
  Smartphone,
  Moon,
  Sun,
  Zap,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useMobileTheme, MobileTheme } from '../context/MobileThemeContext';
import { MobileAppCard } from '../components/MobileAppCard';

export default function MobileSettings() {
  const { direction, language, setLanguage } = useLanguage();
  const { theme, setTheme, availableThemes, config } = useMobileTheme();
  const [showThemeSelector, setShowThemeSelector] = useState(false);

  const getThemeIcon = (themeName: MobileTheme) => {
    const icons: Record<MobileTheme, typeof Moon> = {
      'dark': Moon,
      'light': Sun,
      'violet-dark': Zap,
      'blue-dark': Zap,
      'mint-dark': Zap,
      'amber-dark': Zap,
      'cyber-dark': Zap,
      'neon-dark': Zap
    };
    return icons[themeName] || Palette;
  };

  const getThemePreview = (themeName: MobileTheme) => {
    const previews: Record<MobileTheme, string> = {
      'dark': 'linear-gradient(135deg, #1a1d23 0%, #252932 100%)',
      'light': 'linear-gradient(135deg, #ffffff 0%, #f9fafb 100%)',
      'violet-dark': 'linear-gradient(135deg, #2d1b4e 0%, #3d2b5e 100%)',
      'blue-dark': 'linear-gradient(135deg, #1a2744 0%, #2a3754 100%)',
      'mint-dark': 'linear-gradient(135deg, #1a3830 0%, #2a4840 100%)',
      'amber-dark': 'linear-gradient(135deg, #3a2a1a 0%, #4a3a2a 100%)',
      'cyber-dark': 'linear-gradient(135deg, #1a0f3d 0%, #2a1f4d 100%)',
      'neon-dark': 'linear-gradient(135deg, #1a0028 0%, #2a0038 100%)'
    };
    return previews[themeName];
  };

  return (
    <div className="pb-4">
      {/* Header */}
      <div className="px-4 pt-4 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
            <Palette className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">
              {direction === 'rtl' ? 'الإعدادات' : 'Settings'}
            </h1>
            <p className="text-sm text-gray-400 mt-0.5">
              {direction === 'rtl' ? 'تخصيص تجربتك' : 'Customize your experience'}
            </p>
          </div>
        </div>
      </div>

      {/* Theme Selector */}
      <div className="px-4 mb-6">
        <div className="mb-3">
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
            {direction === 'rtl' ? 'المظهر' : 'Appearance'}
          </h2>
        </div>
        
        <MobileAppCard gradient>
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowThemeSelector(!showThemeSelector)}
            className="w-full flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                <Palette className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <div className="text-white font-medium">
                  {direction === 'rtl' ? 'سمة التطبيق' : 'App Theme'}
                </div>
                <div className="text-sm text-gray-400 mt-0.5">
                  {availableThemes.find(t => t.value === theme)?.label}
                </div>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${showThemeSelector ? 'rotate-90' : ''} ${direction === 'rtl' ? 'rotate-180' : ''}`} />
          </motion.button>

          {showThemeSelector && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t border-white/10"
            >
              <div className="grid grid-cols-2 gap-3">
                {availableThemes.map((t) => {
                  const ThemeIcon = getThemeIcon(t.value);
                  const isActive = theme === t.value;

                  return (
                    <motion.button
                      key={t.value}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        setTheme(t.value);
                        setTimeout(() => setShowThemeSelector(false), 300);
                      }}
                      className={`relative p-4 rounded-2xl border-2 transition-all ${
                        isActive
                          ? 'border-[#8b5cf6] bg-[#8b5cf6]/10'
                          : 'border-white/10 bg-white/5 hover:border-white/20'
                      }`}
                      style={{
                        background: isActive ? undefined : getThemePreview(t.value)
                      }}
                    >
                      {isActive && (
                        <motion.div
                          layoutId="activeTheme"
                          className="absolute top-2 right-2 w-6 h-6 rounded-full bg-[#8b5cf6] flex items-center justify-center"
                          transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                        >
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        </motion.div>
                      )}
                      
                      <div className="flex flex-col items-center gap-2">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          isActive ? 'bg-[#8b5cf6]' : 'bg-white/10'
                        }`}>
                          <ThemeIcon className={`w-5 h-5 ${
                            isActive ? 'text-white' : 'text-gray-300'
                          }`} />
                        </div>
                        <div className={`text-xs font-medium text-center ${
                          isActive ? 'text-white' : 'text-gray-300'
                        }`}>
                          {t.label}
                        </div>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </MobileAppCard>
      </div>

      {/* Language */}
      <div className="px-4 mb-6">
        <div className="mb-3">
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
            {direction === 'rtl' ? 'اللغة' : 'Language'}
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => setLanguage('en')}
            className={`p-4 rounded-2xl border-2 transition-all ${
              language === 'en'
                ? 'border-[#8b5cf6] bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20'
                : 'border-white/10 bg-white/5'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                language === 'en' ? 'bg-[#8b5cf6]' : 'bg-white/10'
              }`}>
                <Globe className={`w-5 h-5 ${
                  language === 'en' ? 'text-white' : 'text-gray-300'
                }`} />
              </div>
              <div className="text-left">
                <div className={`font-medium ${
                  language === 'en' ? 'text-white' : 'text-gray-300'
                }`}>
                  English
                </div>
                <div className="text-xs text-gray-500">EN</div>
              </div>
            </div>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => setLanguage('ar')}
            className={`p-4 rounded-2xl border-2 transition-all ${
              language === 'ar'
                ? 'border-[#8b5cf6] bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20'
                : 'border-white/10 bg-white/5'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                language === 'ar' ? 'bg-[#8b5cf6]' : 'bg-white/10'
              }`}>
                <Globe className={`w-5 h-5 ${
                  language === 'ar' ? 'text-white' : 'text-gray-300'
                }`} />
              </div>
              <div className="text-left">
                <div className={`font-medium ${
                  language === 'ar' ? 'text-white' : 'text-gray-300'
                }`}>
                  العربية
                </div>
                <div className="text-xs text-gray-500">AR</div>
              </div>
            </div>
          </motion.button>
        </div>
      </div>

      {/* Other Settings */}
      <div className="px-4 mb-6">
        <div className="mb-3">
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
            {direction === 'rtl' ? 'الحساب والأمان' : 'Account & Security'}
          </h2>
        </div>

        <div className="space-y-3">
          <MobileAppCard gradient onClick={() => {}}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <User className="w-5 h-5 text-blue-400" />
              </div>
              <div className="flex-1">
                <div className="text-white font-medium">
                  {direction === 'rtl' ? 'معلومات الملف الشخصي' : 'Profile Information'}
                </div>
                <div className="text-sm text-gray-400 mt-0.5">
                  {direction === 'rtl' ? 'تحديث التفاصيل الخاصة بك' : 'Update your details'}
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'rotate-180' : ''}`} />
            </div>
          </MobileAppCard>

          <MobileAppCard gradient onClick={() => {}}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Lock className="w-5 h-5 text-purple-400" />
              </div>
              <div className="flex-1">
                <div className="text-white font-medium">
                  {direction === 'rtl' ? 'الأمان والخصوصية' : 'Security & Privacy'}
                </div>
                <div className="text-sm text-gray-400 mt-0.5">
                  {direction === 'rtl' ? 'إدارة إعدادات الأمان' : 'Manage security settings'}
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'rotate-180' : ''}`} />
            </div>
          </MobileAppCard>

          <MobileAppCard gradient onClick={() => {}}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
                <Bell className="w-5 h-5 text-green-400" />
              </div>
              <div className="flex-1">
                <div className="text-white font-medium">
                  {direction === 'rtl' ? 'الإشعارات' : 'Notifications'}
                </div>
                <div className="text-sm text-gray-400 mt-0.5">
                  {direction === 'rtl' ? 'إدارة تفضيلات الإشعارات' : 'Manage notification preferences'}
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'rotate-180' : ''}`} />
            </div>
          </MobileAppCard>

          <MobileAppCard gradient onClick={() => {}}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-amber-400" />
              </div>
              <div className="flex-1">
                <div className="text-white font-medium">
                  {direction === 'rtl' ? 'طرق الدفع' : 'Payment Methods'}
                </div>
                <div className="text-sm text-gray-400 mt-0.5">
                  {direction === 'rtl' ? 'إدارة طرق الدفع' : 'Manage payment methods'}
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'rotate-180' : ''}`} />
            </div>
          </MobileAppCard>
        </div>
      </div>

      {/* App Info */}
      <div className="px-4 mb-8">
        <MobileAppCard>
          <div className="text-center py-4">
            <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
              <Smartphone className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-white font-bold text-lg mb-1">OnTarget PSP</h3>
            <p className="text-gray-400 text-sm mb-2">Version 1.0.0</p>
            <p className="text-gray-500 text-xs">
              {direction === 'rtl' 
                ? '© 2026 OnTarget PSP. جميع الحقوق محفوظة.'
                : '© 2026 OnTarget PSP. All rights reserved.'}
            </p>
          </div>
        </MobileAppCard>
      </div>
    </div>
  );
}
