import { AreaChart, Area, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import { useState, useEffect, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import { FxRatesWidget } from '../components/FxRatesWidget';
import { AnimatedButton } from '../components/AnimatedButton';
import { HoverCard3D } from '../components/HoverCard3D';
import { AnimatedChartWrapper, StaggerContainer, StaggerItem } from '../components/AnimatedChart';
import { DashboardCardSkeleton, TransactionSkeleton } from '../components/SkeletonLoader';
import { useConfetti } from '../components/ConfettiEffect';
import {
  DollarSign,
  TrendingUp,
  Wallet,
  Users,
  ArrowUpRight,
  TrendingDown,
  Activity,
  CreditCard,
  AlertCircle,
  Download
} from 'lucide-react';

const revenueData = [
  { date: 'Mar 7', amount: 45000 },
  { date: 'Mar 8', amount: 52000 },
  { date: 'Mar 9', amount: 48000 },
  { date: 'Mar 10', amount: 61000 },
  { date: 'Mar 11', amount: 55000 },
  { date: 'Mar 12', amount: 67000 },
  { date: 'Mar 13', amount: 73000 },
];

const paymentMethods = [
  { name: 'Credit Card', value: 45, color: '#8b5cf6' },
  { name: 'Bank Transfer', value: 30, color: '#3b82f6' },
  { name: 'E-Wallet', value: 25, color: '#6ee7b7' },
];

const liveTransactions = [
  { id: 'TX-8372', merchant: 'TechStore', amount: 1250.00, status: 'success', time: '2 min ago' },
  { id: 'TX-8371', merchant: 'FashionHub', amount: 890.50, status: 'success', time: '5 min ago' },
  { id: 'TX-8370', merchant: 'GadgetWorld', amount: 2340.00, status: 'pending', time: '7 min ago' },
  { id: 'TX-8369', merchant: 'BookStore', amount: 145.00, status: 'success', time: '9 min ago' },
  { id: 'TX-8368', merchant: 'SportGear', amount: 567.80, status: 'failed', time: '12 min ago' },
];

const alerts = [
  { id: 'alert-1', type: 'warning', message: 'Wallet #4523 approaching daily limit (85% used)', time: '15 min ago' },
  { id: 'alert-2', type: 'info', message: 'New merchant registration pending approval', time: '1 hour ago' },
  { id: 'alert-3', type: 'success', message: 'Monthly settlement completed successfully', time: '2 hours ago' },
];

const merchantActivity = [
  { name: 'TechStore', volume: 45230, transactions: 234, status: 'active' },
  { name: 'FashionHub', volume: 38940, transactions: 189, status: 'active' },
  { name: 'GadgetWorld', volume: 29450, transactions: 156, status: 'active' },
  { name: 'BookStore', volume: 18920, transactions: 98, status: 'active' },
];

function AnimatedCounter({ value, prefix = '', suffix = '' }: { value: number; prefix?: string; suffix?: string }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const duration = 1000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value]);

  return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
}

export function Dashboard() {
  const { t } = useLanguage();
  const areaGradientId = useMemo(() => `area-gradient-${Math.random().toString(36).substring(2, 15)}`, []);
  const pieChartId = useMemo(() => `pie-chart-${Math.random().toString(36).substring(2, 15)}`, []);
  const { fireConfetti } = useConfetti();

  const handleExport = () => {
    fireConfetti('success');
    // Export logic here
  };

  return (
    <div className="p-4 sm:p-8 space-y-6 sm:space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-white mb-2">{t('dashboard.title')}</h1>
          <p className="text-sm sm:text-base text-gray-400">{t('dashboard.subtitle')}</p>
        </div>
        <AnimatedButton onClick={handleExport} ripple lift>
          <Download className="w-4 h-4 sm:w-5 sm:h-5" />
          {t('dashboard.exportReport')}
        </AnimatedButton>
      </div>

      {/* FX Rates Widget */}
      <FxRatesWidget />

      {/* Revenue Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <GlassCard hover className="p-4 sm:p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-[#8b5cf6]" />
            </div>
            <div className="flex items-center gap-1 text-[#6ee7b7] text-xs sm:text-sm">
              <ArrowUpRight className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>+12.5%</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-xs sm:text-sm">{t('dashboard.totalRevenue')}</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-white">
              $<AnimatedCounter value={73000} />
            </h3>
            <p className="text-xs text-gray-500">{t('dashboard.last7Days')}</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-4 sm:p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-[#6ee7b7]" />
            </div>
            <div className="flex items-center gap-1 text-[#6ee7b7] text-xs sm:text-sm">
              <ArrowUpRight className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>+8.2%</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-xs sm:text-sm">{t('dashboard.transactions')}</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-white">
              <AnimatedCounter value={1247} />
            </h3>
            <p className="text-xs text-gray-500">{t('dashboard.last7Days')}</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-4 sm:p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <Wallet className="w-5 h-5 sm:w-6 sm:h-6 text-[#fbbf24]" />
            </div>
            <div className="flex items-center gap-1 text-[#fbbf24] text-xs sm:text-sm">
              <TrendingDown className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>-3.1%</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-xs sm:text-sm">{t('dashboard.walletBalance')}</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-white">
              $<AnimatedCounter value={284500} />
            </h3>
            <p className="text-xs text-gray-500">{t('dashboard.availableFunds')}</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-4 sm:p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-2 sm:p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#2563eb]/20">
              <Users className="w-5 h-5 sm:w-6 sm:h-6 text-[#3b82f6]" />
            </div>
            <div className="flex items-center gap-1 text-[#6ee7b7] text-xs sm:text-sm">
              <ArrowUpRight className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>+5.7%</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-xs sm:text-sm">{t('dashboard.activeMerchants')}</p>
            <h3 className="text-2xl sm:text-3xl font-semibold text-white">
              <AnimatedCounter value={147} />
            </h3>
            <p className="text-xs text-gray-500">{t('dashboard.thisMonth')}</p>
          </div>
        </GlassCard>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <GlassCard className="p-4 sm:p-6 lg:col-span-2">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
            <div>
              <h2 className="text-lg sm:text-xl font-semibold text-white mb-1">{t('dashboard.revenueVolume')}</h2>
              <p className="text-xs sm:text-sm text-gray-400">{t('dashboard.dailyVolume')}</p>
            </div>
            <div className="flex gap-2">
              <button className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white text-xs sm:text-sm border border-[#8b5cf6]/30">
                {t('dashboard.7days')}
              </button>
              <button className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-white/5 text-gray-400 text-xs sm:text-sm hover:bg-white/10 transition-all">
                {t('dashboard.30days')}
              </button>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id={areaGradientId} x1="0" y1="0" x2="0" y2="1">
                  <stop key="stop-1" offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                  <stop key="stop-2" offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="date" 
                stroke="#9ca3af" 
                fontSize={10}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="#9ca3af" 
                fontSize={10}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1a1d23',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  color: '#fff'
                }}
              />
              <Area
                type="monotone"
                dataKey="amount"
                stroke="#8b5cf6"
                strokeWidth={3}
                fill={`url(#${areaGradientId})`}
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="p-4 sm:p-6">
          <h2 className="text-lg sm:text-xl font-semibold text-white mb-1">{t('dashboard.paymentMethods')}</h2>
          <p className="text-xs sm:text-sm text-gray-400 mb-6">{t('dashboard.distribution')}</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie
                data={paymentMethods}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={70}
                paddingAngle={5}
                dataKey="value"
                isAnimationActive={false}
              >
                {paymentMethods.map((entry, index) => (
                  <Cell key={`cell-${entry.name}-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-3 mt-6">
            {paymentMethods.map((method) => (
              <div key={method.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: method.color, boxShadow: `0 0 8px ${method.color}` }}
                  />
                  <span className="text-xs sm:text-sm text-gray-300">{t(`payment.${method.name.toLowerCase().replace(' ', '')}`)}</span>
                </div>
                <span className="text-xs sm:text-sm font-semibold text-white">{method.value}%</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Live Transactions & Merchant Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        <GlassCard className="p-4 sm:p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Live Transactions</h2>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#6ee7b7] animate-pulse" style={{ boxShadow: '0 0 8px #6ee7b7' }} />
              <span className="text-xs text-gray-400">Real-time</span>
            </div>
          </div>
          <div className="space-y-3">
            {liveTransactions.map((tx, index) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    tx.status === 'success' ? 'bg-[#6ee7b7]/20' :
                    tx.status === 'pending' ? 'bg-[#fbbf24]/20' :
                    'bg-[#f87171]/20'
                  }`}>
                    <CreditCard className={`w-5 h-5 ${
                      tx.status === 'success' ? 'text-[#6ee7b7]' :
                      tx.status === 'pending' ? 'text-[#fbbf24]' :
                      'text-[#f87171]'
                    }`} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{tx.id}</p>
                    <p className="text-xs text-gray-400">{tx.merchant}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-white">${tx.amount.toFixed(2)}</p>
                  <p className="text-xs text-gray-400">{tx.time}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-4 sm:p-6">
          <h2 className="text-xl font-semibold text-white mb-6">Merchant Activity</h2>
          <div className="space-y-4">
            {merchantActivity.map((merchant, index) => (
              <motion.div
                key={merchant.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-white font-semibold text-xs">
                      {merchant.name.substring(0, 2)}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">{merchant.name}</p>
                      <p className="text-xs text-gray-400">{merchant.transactions} transactions</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-white">${merchant.volume.toLocaleString()}</p>
                  </div>
                </div>
                <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4]"
                    initial={{ width: 0 }}
                    animate={{ width: `${(merchant.volume / 50000) * 100}%` }}
                    transition={{ delay: index * 0.1 + 0.3, duration: 0.8 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Alerts Panel */}
      <GlassCard className="p-4 sm:p-6">
        <h2 className="text-xl font-semibold text-white mb-6">System Alerts</h2>
        <div className="space-y-3">
          {alerts.map((alert, index) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`flex items-start gap-4 p-4 rounded-xl ${
                alert.type === 'warning' ? 'bg-[#fbbf24]/10 border border-[#fbbf24]/20' :
                alert.type === 'info' ? 'bg-[#3b82f6]/10 border border-[#3b82f6]/20' :
                'bg-[#6ee7b7]/10 border border-[#6ee7b7]/20'
              }`}
            >
              <AlertCircle className={`w-5 h-5 flex-shrink-0 ${
                alert.type === 'warning' ? 'text-[#fbbf24]' :
                alert.type === 'info' ? 'text-[#3b82f6]' :
                'text-[#6ee7b7]'
              }`} />
              <div className="flex-1">
                <p className="text-sm text-white">{alert.message}</p>
                <p className="text-xs text-gray-400 mt-1">{alert.time}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}