import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';

// Transaction type definition
interface Transaction {
  type: number; // 1 = Deposit, 0 = Payout
  txId: string;
  amount: number;
  paymentType: string;
  merchant: string;
  subMerchant: string;
  date: string;
  time: string;
  internalId: string;
  approvedBy: string;
  imageUrl: string;
  isNew?: boolean;
}

// Seed data
const SEED_DATA: Transaction[] = [
  [1, "138396783", 528.68, "Mobile Wallet", "NGPay-PayMaxis-Prod", "NGPay-PayMaxis-Trusteo-Prod-EGP-MWallet", "2026-03-18", "07:46", "19d016968110491d", "Operator - Eslam_ontarget", "https://mavenconsulanting.s3.ap-south-1.amazonaws.com/P2P-SS/138396783_20260318131647.jpg"],
  [1, "138395822", 210.0, "Mobile Wallet", "NGPay-PayCord-Prod", "NGPay-PayCord-Prod-EGP", "2026-03-18", "07:11", "19d014a059f9599e", "BUSINESS OWNER - Hicham", ""],
  [0, "30841027", 10000.0, "Mobile Wallet", "NGPay-PayCord-Prod", "NGPay-PayCord-Prod-EGP", "2026-03-18", "07:11", "19d014993d4d79f9", "BUSINESS OWNER - Hicham", ""],
  [1, "138381123", 490.0, "Mobile Wallet", "NGPay-PayCord-Prod", "NGPay-PayCord-Prod-EGP", "2026-03-18", "07:11", "19d014972270d3a6", "BUSINESS OWNER - Hicham", ""],
  [1, "138381378", 500.0, "Mobile Wallet", "NGPay-PayCord-Prod", "NGPay-PayCord-Prod-EGP", "2026-03-18", "07:11", "19d01493852a8017", "BUSINESS OWNER - Hicham", ""],
].map((row) => ({
  type: row[0] as number,
  txId: row[1] as string,
  amount: row[2] as number,
  paymentType: row[3] as string,
  merchant: row[4] as string,
  subMerchant: row[5] as string,
  date: row[6] as string,
  time: row[7] as string,
  internalId: row[8] as string,
  approvedBy: row[9] as string,
  imageUrl: row[10] as string,
}));

type SortField = 'type' | 'txId' | 'amount' | 'paymentType' | 'merchant' | 'approvedBy' | 'date' | 'time';

export default function NGPayDashboard() {
  const { t } = useLanguage();

  // State
  const [transactions, setTransactions] = useState<Transaction[]>(SEED_DATA);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>(SEED_DATA);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [pollInterval, setPollInterval] = useState(30);
  const [polling, setPolling] = useState(false);
  const [lastFetch, setLastFetch] = useState<string>('never');
  const [fetchStatus, setFetchStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('Idle');
  const [newCount, setNewCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Filters
  const [dateFrom, setDateFrom] = useState('2026-01-01');
  const [dateTo, setDateTo] = useState('2026-03-18');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [paymentMethodFilter, setPaymentMethodFilter] = useState('');
  const [merchantFilter, setMerchantFilter] = useState('');

  const pollTimerRef = useRef<NodeJS.Timeout | null>(null);
  const itemsPerPage = 50;

  // Calculate summary stats
  const summary = filteredTransactions.reduce(
    (acc, tx) => {
      if (tx.type === 1) {
        acc.deposits += tx.amount;
      } else {
        acc.payouts += tx.amount;
      }
      acc.total = acc.deposits - acc.payouts;
      return acc;
    },
    { deposits: 0, payouts: 0, total: 0, count: filteredTransactions.length }
  );

  // Get unique merchants
  const merchants = Array.from(new Set(transactions.map((t) => t.merchant))).sort();

  // Fetch from n8n webhook
  const fetchNow = async () => {
    if (!webhookUrl.trim()) {
      setFetchStatus('error');
      setStatusMessage('Enter n8n webhook URL');
      return;
    }

    setFetchStatus('loading');
    setStatusMessage('Fetching...');

    try {
      const response = await fetch(webhookUrl);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      
      const data = await response.json();
      const newTransactions = Array.isArray(data) ? data : [data];
      
      // Mark new transactions
      const markedNew = newTransactions.map((tx: any) => ({
        ...tx,
        isNew: true,
      }));

      setTransactions((prev) => [...markedNew, ...prev]);
      setNewCount((prev) => prev + markedNew.length);
      setFetchStatus('success');
      setStatusMessage(`Fetched ${markedNew.length} new transactions`);
      setLastFetch(new Date().toLocaleTimeString());

      // Show toast
      showToast('Success', `Fetched ${markedNew.length} new transactions`);
    } catch (error: any) {
      setFetchStatus('error');
      setStatusMessage(`Error: ${error.message}`);
      showToast('Error', error.message);
    }
  };

  // Toggle polling
  const togglePoll = () => {
    if (polling) {
      // Stop polling
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
      setPolling(false);
      setStatusMessage('Idle');
    } else {
      // Start polling
      setPolling(true);
      fetchNow();
      pollTimerRef.current = setInterval(fetchNow, pollInterval * 1000);
      setStatusMessage('Polling...');
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
      }
    };
  }, []);

  // Filter and sort transactions
  useEffect(() => {
    let filtered = transactions.filter((tx) => {
      // Date filter
      if (tx.date < dateFrom || tx.date > dateTo) return false;

      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        if (
          !tx.txId.toLowerCase().includes(query) &&
          !tx.merchant.toLowerCase().includes(query) &&
          !tx.approvedBy.toLowerCase().includes(query)
        ) {
          return false;
        }
      }

      // Type filter
      if (typeFilter && tx.type.toString() !== typeFilter) return false;

      // Payment method filter
      if (paymentMethodFilter && tx.paymentType !== paymentMethodFilter) return false;

      // Merchant filter
      if (merchantFilter && tx.merchant !== merchantFilter) return false;

      return true;
    });

    // Sort
    filtered.sort((a, b) => {
      let aVal: any = a[sortField];
      let bVal: any = b[sortField];

      if (sortField === 'amount') {
        aVal = parseFloat(aVal);
        bVal = parseFloat(bVal);
      }

      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    setFilteredTransactions(filtered);
    setCurrentPage(1);
  }, [transactions, dateFrom, dateTo, searchQuery, typeFilter, paymentMethodFilter, merchantFilter, sortField, sortDirection]);

  // Handle sort
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // Reset filters
  const resetFilters = () => {
    setDateFrom('2026-01-01');
    setDateTo('2026-03-18');
    setSearchQuery('');
    setTypeFilter('');
    setPaymentMethodFilter('');
    setMerchantFilter('');
  };

  // Export JSON
  const copyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(filteredTransactions, null, 2));
    showToast('Success', 'JSON copied to clipboard');
  };

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(filteredTransactions, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ngpay-transactions-${new Date().toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Success', 'JSON file downloaded');
  };

  // Toast notification
  const [toast, setToast] = useState<{ show: boolean; title: string; message: string }>({
    show: false,
    title: '',
    message: '',
  });

  const showToast = (title: string, message: string) => {
    setToast({ show: true, title, message });
    setTimeout(() => setToast({ show: false, title: '', message: '' }), 5000);
  };

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="min-h-screen" style={{ background: '#0f1117', color: '#e2e8f0', fontFamily: 'Inter, sans-serif' }}>
      {/* Toast */}
      {toast.show && (
        <div className="fixed top-4 right-4 z-50 bg-[#1e2333] border border-emerald-500 rounded-lg p-4 shadow-2xl min-w-[240px] animate-slideIn">
          <div className="flex justify-between items-center mb-2">
            <span className="font-semibold text-emerald-400 text-sm">{toast.title}</span>
            <button onClick={() => setToast({ ...toast, show: false })} className="text-slate-500 hover:text-slate-300">
              ✕
            </button>
          </div>
          <div className="text-xs text-slate-300">{toast.message}</div>
        </div>
      )}

      {/* Top Bar */}
      <div className="bg-[#181c25] border-b border-[#262d3d] px-5 h-[52px] flex items-center gap-3 sticky top-0 z-10">
        <div className="flex items-center gap-2 font-semibold text-white">
          <div
            className={`w-2 h-2 rounded-full bg-emerald-500 ${polling ? 'animate-pulse' : ''}`}
            style={{
              boxShadow: polling ? '0 0 14px rgba(16, 185, 129, 0.7)' : '0 0 4px rgba(16, 185, 129, 0.7)',
            }}
          />
          <span className="text-sm">NGPay 2026 · Live Dashboard</span>
        </div>

        <div className="flex gap-2 ml-auto flex-wrap">
          <span className="px-3 py-1 rounded-full text-[11px] font-medium bg-[#052e16] text-emerald-400 border border-[#065f46]">
            {summary.deposits.toLocaleString()} Deposits
          </span>
          <span className="px-3 py-1 rounded-full text-[11px] font-medium bg-[#1c1400] text-amber-400 border border-[#78350f]">
            {summary.payouts.toLocaleString()} Payouts
          </span>
          <span className="px-3 py-1 rounded-full text-[11px] font-medium bg-[#0c1a3a] text-blue-400 border border-[#1e3a5f]">
            {filteredTransactions.length} Total
          </span>
          {newCount > 0 && (
            <span className="px-3 py-1 rounded-full text-[11px] font-medium bg-[#2d0707] text-red-400 border border-[#7f1d1d]">
              {newCount} New
            </span>
          )}
        </div>
      </div>

      {/* N8N Live Bar */}
      <div className="bg-[#1e2333] border-b border-[#262d3d] px-5 py-2 flex gap-2 items-center flex-wrap text-xs">
        <div className="flex items-center gap-2">
          <div
            className={`w-[7px] h-[7px] rounded-full ${
              fetchStatus === 'loading'
                ? 'bg-blue-500 animate-pulse'
                : fetchStatus === 'error'
                ? 'bg-red-500'
                : fetchStatus === 'success'
                ? 'bg-emerald-500'
                : 'bg-slate-500'
            }`}
          />
          <span className="font-medium text-[11px]">{statusMessage}</span>
        </div>

        <span className="text-slate-500 text-[11px]">n8n URL:</span>
        <input
          type="url"
          value={webhookUrl}
          onChange={(e) => setWebhookUrl(e.target.value)}
          placeholder="https://your-n8n.com/webhook/ngpay-transactions"
          className="min-w-[260px] h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-[11px] focus:border-blue-500 outline-none font-mono"
        />

        <span className="text-slate-500 text-[11px]">Every</span>
        <input
          type="number"
          value={pollInterval}
          onChange={(e) => setPollInterval(parseInt(e.target.value) || 30)}
          min="5"
          className="w-16 h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        />
        <span className="text-slate-500 text-[11px]">sec</span>

        <button
          onClick={togglePoll}
          className={`h-[30px] px-3 rounded-md text-xs font-medium border transition-all ${
            polling
              ? 'bg-[#2d0707] text-red-400 border-[#7f1d1d] hover:bg-[#450a0a]'
              : 'bg-[#064e3b] text-emerald-400 border-[#065f46] hover:bg-[#065f46]'
          }`}
        >
          {polling ? '⏹ Stop' : '▶ Start polling'}
        </button>

        <button
          onClick={fetchNow}
          className="h-[30px] px-3 rounded-md text-xs font-medium border bg-[#0c1a3a] text-blue-400 border-[#1e3a5f] hover:bg-[#1e3a5f] transition-all"
        >
          ⟳ Fetch now
        </button>

        <button
          onClick={copyJSON}
          className="h-[30px] px-3 rounded-md text-xs font-medium border bg-[#1e2333] text-slate-300 border-[#262d3d] hover:bg-[#181c25] transition-all"
        >
          Copy JSON
        </button>

        <button
          onClick={downloadJSON}
          className="h-[30px] px-3 rounded-md text-xs font-medium border bg-[#1e2333] text-slate-300 border-[#262d3d] hover:bg-[#181c25] transition-all"
        >
          ↓ Download
        </button>

        <span className="ml-auto text-[10px] text-slate-500">
          Last fetch: <span className="text-slate-400">{lastFetch}</span>
        </span>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-5 gap-[1px] bg-[#262d3d]">
        <div className="bg-[#181c25] p-4">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Records (filtered)</div>
          <div className="text-xl font-semibold text-white font-mono">{summary.count}</div>
          <div className="text-[10px] text-slate-500 mt-1">Jan 1 – Mar 18, 2026</div>
        </div>

        <div className="bg-[#181c25] p-4">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Deposits EGP</div>
          <div className="text-xl font-semibold text-emerald-400 font-mono">
            {summary.deposits.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Filtered total</div>
        </div>

        <div className="bg-[#181c25] p-4">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Payouts EGP</div>
          <div className="text-xl font-semibold text-amber-400 font-mono">
            {summary.payouts.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Filtered total</div>
        </div>

        <div className="bg-[#181c25] p-4">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Net EGP</div>
          <div className="text-xl font-semibold text-white font-mono">{summary.total.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500 mt-1">Dep − Pay</div>
        </div>

        <div className="bg-[#181c25] p-4 border-t-2 border-emerald-500">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">New from n8n</div>
          <div className="text-xl font-semibold text-emerald-400 font-mono">{newCount}</div>
          <div className="text-[10px] text-slate-500 mt-1">This session</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-[#1e2333] border-b border-[#262d3d] px-5 py-2 flex gap-2 flex-wrap items-center text-xs">
        <span className="text-slate-500 text-[11px]">From:</span>
        <input
          type="date"
          value={dateFrom}
          onChange={(e) => setDateFrom(e.target.value)}
          className="h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        />

        <span className="text-slate-500 text-[11px]">To:</span>
        <input
          type="date"
          value={dateTo}
          onChange={(e) => setDateTo(e.target.value)}
          className="h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        />

        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Tx ID, merchant, approver..."
          className="min-w-[185px] h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        />

        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        >
          <option value="">All types</option>
          <option value="1">Deposit</option>
          <option value="0">Payout</option>
        </select>

        <select
          value={paymentMethodFilter}
          onChange={(e) => setPaymentMethodFilter(e.target.value)}
          className="h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        >
          <option value="">All payment</option>
          <option>Mobile Wallet</option>
          <option>InstaPay</option>
          <option>WireTransfer</option>
        </select>

        <select
          value={merchantFilter}
          onChange={(e) => setMerchantFilter(e.target.value)}
          className="h-[30px] px-3 bg-[#181c25] border border-[#262d3d] rounded-md text-[#e2e8f0] text-xs focus:border-blue-500 outline-none"
        >
          <option value="">All merchants</option>
          {merchants.map((merchant) => (
            <option key={merchant} value={merchant}>
              {merchant}
            </option>
          ))}
        </select>

        <button
          onClick={resetFilters}
          className="h-[30px] px-3 rounded-md text-xs font-medium border bg-[#1e2333] text-slate-300 border-[#262d3d] hover:bg-[#181c25] transition-all"
        >
          Reset
        </button>

        <div className="ml-auto flex gap-2 items-center">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="h-[30px] px-3 rounded-md text-xs font-medium border bg-[#1e2333] text-slate-300 border-[#262d3d] hover:bg-[#181c25] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            ← Prev
          </button>
          <span className="text-[11px] text-slate-500 whitespace-nowrap">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="h-[30px] px-3 rounded-md text-xs font-medium border bg-[#1e2333] text-slate-300 border-[#262d3d] hover:bg-[#181c25] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next →
          </button>
        </div>
      </div>

      {/* Table Meta */}
      <div className="px-5 py-2 bg-[#181c25] border-b border-[#262d3d] flex gap-3 items-center text-[11px] text-slate-500">
        <span>
          Showing {paginatedTransactions.length} of {filteredTransactions.length} transactions
        </span>
      </div>

      {/* Table */}
      <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-340px)]">
        <table className="w-full border-collapse min-w-[1120px]">
          <thead>
            <tr>
              <th
                onClick={() => handleSort('type')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Type {sortField === 'type' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th
                onClick={() => handleSort('txId')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Tx ID {sortField === 'txId' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th
                onClick={() => handleSort('amount')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Amount (EGP) {sortField === 'amount' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th
                onClick={() => handleSort('paymentType')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Payment {sortField === 'paymentType' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th
                onClick={() => handleSort('merchant')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Merchant {sortField === 'merchant' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2]">
                Sub Merchant
              </th>
              <th
                onClick={() => handleSort('approvedBy')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Approved By {sortField === 'approvedBy' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th
                onClick={() => handleSort('date')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Date {sortField === 'date' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th
                onClick={() => handleSort('time')}
                className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2] cursor-pointer hover:text-slate-300 select-none"
              >
                Time {sortField === 'time' && (sortDirection === 'asc' ? ' ↑' : ' ↓')}
              </th>
              <th className="bg-[#1e2333] px-3 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wider border-b border-[#262d3d] sticky top-0 z-[2]">
                Image
              </th>
            </tr>
          </thead>
          <tbody>
            {paginatedTransactions.map((tx, index) => (
              <tr
                key={tx.internalId + index}
                className={`border-b border-[#1a1f2e] hover:bg-[#1a2030] transition-colors ${
                  tx.isNew ? 'bg-[#052e16]' : ''
                }`}
              >
                <td className="px-3 py-2 text-slate-400">
                  {tx.isNew && (
                    <span className="inline-block bg-emerald-500 text-black text-[9px] font-bold px-1 rounded mr-1 font-mono">
                      NEW
                    </span>
                  )}
                  <span
                    className={`px-2 py-1 rounded text-[10px] font-bold font-mono ${
                      tx.type === 1
                        ? 'bg-[#052e16] text-emerald-400'
                        : 'bg-[#1c1400] text-amber-400'
                    }`}
                  >
                    {tx.type === 1 ? 'DEP' : 'PAY'}
                  </span>
                </td>
                <td className="px-3 py-2 text-slate-300 font-mono text-[11px]">{tx.txId}</td>
                <td className="px-3 py-2 text-slate-200 font-mono text-xs font-medium">
                  {tx.amount.toLocaleString()}
                </td>
                <td className="px-3 py-2 text-slate-400 text-[11px]">{tx.paymentType}</td>
                <td className="px-3 py-2 text-slate-400 text-[11px]">{tx.merchant}</td>
                <td className="px-3 py-2 text-slate-500 text-[11px]">{tx.subMerchant}</td>
                <td className="px-3 py-2 text-purple-400 text-[11px] font-medium">{tx.approvedBy}</td>
                <td className="px-3 py-2 text-slate-400 text-[11px]">{tx.date}</td>
                <td className="px-3 py-2 text-slate-400 text-[11px]">{tx.time}</td>
                <td className="px-3 py-2">
                  {tx.imageUrl && (
                    <a
                      href={tx.imageUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-400 text-[11px] hover:underline"
                    >
                      View
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
