import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  TrendingUp, 
  TrendingDown,
  RefreshCw,
  DollarSign,
  Euro,
  Banknote,
  ArrowUpRight,
  ArrowDownRight,
  Activity
} from 'lucide-react';
import { useState, useEffect } from 'react';

interface ExchangeRate {
  currency: string;
  symbol: string;
  rate: number;
  change: number;
  trend: 'up' | 'down';
  icon: any;
  color: string;
}

export function LiveRates() {
  const { t } = useLanguage();
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [autoRefresh, setAutoRefresh] = useState(true);

  const [rates, setRates] = useState<ExchangeRate[]>([
    { currency: 'USD', symbol: '$', rate: 30.85, change: 0.12, trend: 'up', icon: DollarSign, color: 'from-green-500 to-emerald-500' },
    { currency: 'EUR', symbol: '€', rate: 33.42, change: -0.08, trend: 'down', icon: Euro, color: 'from-blue-500 to-cyan-500' },
    { currency: 'GBP', symbol: '£', rate: 39.15, change: 0.25, trend: 'up', icon: Banknote, color: 'from-purple-500 to-violet-500' },
    { currency: 'SAR', symbol: 'ر.س', rate: 8.23, change: 0.05, trend: 'up', icon: Banknote, color: 'from-yellow-500 to-amber-500' },
    { currency: 'AED', symbol: 'د.إ', rate: 8.40, change: -0.03, trend: 'down', icon: Banknote, color: 'from-orange-500 to-red-500' },
    { currency: 'KWD', symbol: 'د.ك', rate: 100.45, change: 0.32, trend: 'up', icon: Banknote, color: 'from-teal-500 to-cyan-500' }
  ]);

  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        // Simulate rate updates
        setRates(prev => prev.map(rate => ({
          ...rate,
          rate: rate.rate + (Math.random() - 0.5) * 0.1,
          change: (Math.random() - 0.5) * 0.5,
          trend: Math.random() > 0.5 ? 'up' : 'down'
        })));
        setLastUpdate(new Date());
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const handleRefresh = () => {
    setRates(prev => prev.map(rate => ({
      ...rate,
      rate: rate.rate + (Math.random() - 0.5) * 0.2,
      change: (Math.random() - 0.5) * 0.5,
      trend: Math.random() > 0.5 ? 'up' : 'down'
    })));
    setLastUpdate(new Date());
  };

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-white mb-2">Live Exchange Rates</h1>
            <p className="text-gray-400">Real-time currency exchange rates (EGP base)</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10">
              <Activity className={`w-4 h-4 ${autoRefresh ? 'text-green-400 animate-pulse' : 'text-gray-400'}`} />
              <span className="text-sm text-gray-300">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </span>
            </div>
            <motion.button
              whileHover={{ scale: 1.05, rotate: 180 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleRefresh}
              className="p-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg hover:shadow-violet-500/30 transition-shadow"
            >
              <RefreshCw className="w-5 h-5" />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Auto Refresh Toggle */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 p-4 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-white font-medium">Auto-Refresh</h3>
              <p className="text-sm text-gray-400">Update rates every 5 seconds</p>
            </div>
          </div>
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`relative w-14 h-7 rounded-full transition-colors ${
              autoRefresh ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6]' : 'bg-gray-600'
            }`}
          >
            <motion.div
              animate={{ x: autoRefresh ? 28 : 2 }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
              className="absolute top-1 w-5 h-5 bg-white rounded-full shadow-lg"
            />
          </button>
        </div>
      </motion.div>

      {/* Rates Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rates.map((rate, index) => {
          const Icon = rate.icon;
          const TrendIcon = rate.trend === 'up' ? TrendingUp : TrendingDown;
          const ChangeIcon = rate.trend === 'up' ? ArrowUpRight : ArrowDownRight;
          
          return (
            <motion.div
              key={rate.currency}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden hover:border-white/20 transition-all group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-5 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${rate.color})` }} />
              
              <div className="relative">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${rate.color} flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">{rate.currency}</h3>
                      <p className="text-sm text-gray-400">to EGP</p>
                    </div>
                  </div>
                  <TrendIcon className={`w-6 h-6 ${rate.trend === 'up' ? 'text-green-400' : 'text-red-400'}`} />
                </div>

                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-3xl font-bold text-white mb-1">
                      {rate.rate.toFixed(2)}
                    </p>
                    <div className={`flex items-center gap-1 text-sm font-medium ${
                      rate.trend === 'up' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      <ChangeIcon className="w-4 h-4" />
                      {Math.abs(rate.change).toFixed(2)}%
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-gray-400">1 {rate.currency}</p>
                    <p className="text-xs text-gray-500">{rate.symbol} {rate.rate.toFixed(2)} EGP</p>
                  </div>
                </div>

                {/* Mini Chart Placeholder */}
                <div className="mt-4 h-12 flex items-end gap-1">
                  {[...Array(12)].map((_, i) => (
                    <div
                      key={i}
                      className={`flex-1 rounded-t ${rate.trend === 'up' ? 'bg-green-500/30' : 'bg-red-500/30'}`}
                      style={{ height: `${Math.random() * 100}%` }}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Exchange Calculator */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-8 p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
      >
        <h2 className="text-2xl font-semibold text-white mb-6">Quick Exchange Calculator</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">From</label>
            <div className="flex gap-2">
              <select className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors">
                <option value="EGP">EGP - Egyptian Pound</option>
                <option value="USD">USD - US Dollar</option>
                <option value="EUR">EUR - Euro</option>
                <option value="GBP">GBP - British Pound</option>
              </select>
              <input
                type="number"
                placeholder="0.00"
                className="w-32 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">To</label>
            <div className="flex gap-2">
              <select className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors">
                <option value="USD">USD - US Dollar</option>
                <option value="EGP">EGP - Egyptian Pound</option>
                <option value="EUR">EUR - Euro</option>
                <option value="GBP">GBP - British Pound</option>
              </select>
              <input
                type="number"
                placeholder="0.00"
                readOnly
                className="w-32 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 cursor-not-allowed"
              />
            </div>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="mt-6 w-full px-6 py-4 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
        >
          <RefreshCw className="w-5 h-5" />
          Convert
        </motion.button>
      </motion.div>
    </div>
  );
}
