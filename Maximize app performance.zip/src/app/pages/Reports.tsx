import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  BarChart3, 
  Download, 
  TrendingUp,
  Calendar,
  FileText,
  DollarSign,
  Users,
  ShoppingBag,
  PieChart,
  Activity,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { useState } from 'react';

interface Report {
  id: string;
  name: string;
  category: 'financial' | 'operational' | 'merchant' | 'transaction';
  description: string;
  lastGenerated: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'on-demand';
  format: 'PDF' | 'Excel' | 'CSV';
  size?: string;
}

const mockReports: Report[] = [
  {
    id: 'RPT-001',
    name: 'Transaction Summary Report',
    category: 'transaction',
    description: 'Daily transaction volumes, success rates, and revenue breakdown',
    lastGenerated: '2026-03-17 08:00',
    frequency: 'daily',
    format: 'PDF',
    size: '2.4 MB'
  },
  {
    id: 'RPT-002',
    name: 'Merchant Performance Report',
    category: 'merchant',
    description: 'Top merchants by volume, revenue trends, and growth metrics',
    lastGenerated: '2026-03-17 07:30',
    frequency: 'daily',
    format: 'Excel',
    size: '1.8 MB'
  },
  {
    id: 'RPT-003',
    name: 'Monthly Financial Statement',
    category: 'financial',
    description: 'Complete financial overview including settlements, fees, and reconciliation',
    lastGenerated: '2026-03-01',
    frequency: 'monthly',
    format: 'PDF',
    size: '5.2 MB'
  },
  {
    id: 'RPT-004',
    name: 'Payment Methods Analysis',
    category: 'operational',
    description: 'Usage statistics for all payment methods and conversion rates',
    lastGenerated: '2026-03-10',
    frequency: 'weekly',
    format: 'Excel',
    size: '3.1 MB'
  },
  {
    id: 'RPT-005',
    name: 'Risk & Fraud Report',
    category: 'operational',
    description: 'Security incidents, blocked transactions, and fraud patterns',
    lastGenerated: '2026-03-17 06:00',
    frequency: 'daily',
    format: 'PDF',
    size: '1.5 MB'
  },
  {
    id: 'RPT-006',
    name: 'Settlement Reconciliation',
    category: 'financial',
    description: 'Detailed settlement breakdown with merchant-wise distribution',
    lastGenerated: '2026-03-16',
    frequency: 'daily',
    format: 'Excel',
    size: '4.3 MB'
  }
];

const quickStats = [
  { label: 'Total Revenue', value: '₤2.4M', change: '+12.5%', trend: 'up', icon: DollarSign, color: 'from-[#10b981] to-[#059669]' },
  { label: 'Total Transactions', value: '45.2K', change: '+8.3%', trend: 'up', icon: Activity, color: 'from-[#3b82f6] to-[#2563eb]' },
  { label: 'Active Merchants', value: '1,234', change: '+5.7%', trend: 'up', icon: Users, color: 'from-[#8b5cf6] to-[#7c3aed]' },
  { label: 'Avg. Transaction', value: '₤53', change: '-2.1%', trend: 'down', icon: ShoppingBag, color: 'from-[#f59e0b] to-[#d97706]' }
];

export function Reports() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'financial' | 'operational' | 'merchant' | 'transaction'>('all');

  const filteredReports = filter === 'all' 
    ? mockReports 
    : mockReports.filter(r => r.category === filter);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'financial': return 'from-green-600 to-emerald-600';
      case 'operational': return 'from-blue-600 to-cyan-600';
      case 'merchant': return 'from-purple-600 to-violet-600';
      case 'transaction': return 'from-orange-600 to-amber-600';
      default: return 'from-gray-600 to-gray-500';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'financial': return DollarSign;
      case 'operational': return Activity;
      case 'merchant': return Users;
      case 'transaction': return BarChart3;
      default: return FileText;
    }
  };

  const getFormatColor = (format: string) => {
    switch (format) {
      case 'PDF': return 'bg-red-500/20 text-red-300';
      case 'Excel': return 'bg-green-500/20 text-green-300';
      case 'CSV': return 'bg-blue-500/20 text-blue-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-white mb-2">Reports & Analytics</h1>
            <p className="text-gray-400">Generate and download business intelligence reports</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
          >
            <FileText className="w-5 h-5" />
            Generate Custom Report
          </motion.button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          const TrendIcon = stat.trend === 'up' ? ArrowUpRight : ArrowDownRight;
          
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className={`text-sm font-medium flex items-center gap-1 ${
                    stat.trend === 'up' ? 'text-green-400' : 'text-red-400'
                  }`}>
                    <TrendIcon className="w-4 h-4" />
                    {stat.change}
                  </span>
                </div>
                <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {['all', 'financial', 'operational', 'merchant', 'transaction'].map((category) => (
          <button
            key={category}
            onClick={() => setFilter(category as any)}
            className={`px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap ${
              filter === category
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-violet-500/30'
                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredReports.map((report, index) => {
          const CategoryIcon = getCategoryIcon(report.category);
          
          return (
            <motion.div
              key={report.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden hover:border-white/20 transition-all group"
            >
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${getCategoryColor(report.category)} flex items-center justify-center flex-shrink-0`}>
                  <CategoryIcon className="w-7 h-7 text-white" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-lg font-semibold text-white">{report.name}</h3>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${getFormatColor(report.format)}`}>
                      {report.format}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-400 mb-4 leading-relaxed">{report.description}</p>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Frequency</p>
                      <p className="text-sm text-gray-300 font-medium flex items-center gap-1 capitalize">
                        <Calendar className="w-4 h-4" />
                        {report.frequency}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Last Generated</p>
                      <p className="text-sm text-gray-300 font-medium">{report.lastGenerated}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-1 px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
                    >
                      <Download className="w-4 h-4" />
                      Download {report.size && `(${report.size})`}
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium border border-white/10 transition-all"
                    >
                      <TrendingUp className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Custom Report Builder */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-8 p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
      >
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
              <PieChart className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white mb-1">Custom Report Builder</h3>
              <p className="text-gray-400">Create tailored reports with specific metrics and date ranges</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
          >
            <FileText className="w-5 h-5" />
            Build Custom Report
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
