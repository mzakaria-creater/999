import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  CreditCard,
  Link as LinkIcon,
  QrCode,
  FileText,
  Code,
  Lock,
  ShieldCheck,
  CheckCircle,
  Smartphone,
  Eye
} from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { WalletTransactionDetails } from '../components/WalletTransactionDetails';

type PaymentPageType = 'hosted' | 'link' | 'qr' | 'invoice' | 'widget' | 'mobilewallet';
type TransactionStatus = 'pending' | 'completed' | 'failed' | 'reviewing';

export function PaymentPages() {
  const { t, language } = useLanguage();
  const [selectedType, setSelectedType] = useState<PaymentPageType>('hosted');
  const [mobileWalletStep, setMobileWalletStep] = useState<1 | 2>(1);
  const [walletPhone, setWalletPhone] = useState('');
  const [walletAmount, setWalletAmount] = useState('');
  const [walletProvider, setWalletProvider] = useState<{
    name: string;
    logo: string;
    ussd: string;
    color: string;
    nameAr: string;
  } | null>(null);
  const [showTransactionDetails, setShowTransactionDetails] = useState(false);
  const [transactionData, setTransactionData] = useState<{
    id: string;
    phone: string;
    amount: string;
    provider: {
      name: string;
      nameAr: string;
      logo: string;
      color: string;
    };
    status: TransactionStatus;
    date: string;
    ussdCode: string;
  } | null>(null);

  const paymentTypes = [
    { id: 'hosted' as const, name: t('paymentPages.hosted'), icon: CreditCard, description: t('paymentPages.hostedDesc') },
    { id: 'link' as const, name: t('paymentPages.link'), icon: LinkIcon, description: t('paymentPages.linkDesc') },
    { id: 'qr' as const, name: t('paymentPages.qr'), icon: QrCode, description: t('paymentPages.qrDesc') },
    { id: 'invoice' as const, name: t('paymentPages.invoice'), icon: FileText, description: t('paymentPages.invoiceDesc') },
    { id: 'widget' as const, name: t('paymentPages.widget'), icon: Code, description: t('paymentPages.widgetDesc') },
    { id: 'mobilewallet' as const, name: t('paymentPages.mobileWallet'), icon: Smartphone, description: t('paymentPages.mobileWalletDesc') }
  ];

  const walletConfig: Record<string, { name: string; logo: string; ussd: string; color: string; nameAr: string }> = {
    '010': { 
      name: 'Vodafone Cash', 
      nameAr: 'فودافون كاش',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/a/af/Vodafone_Logo.png', 
      ussd: '*9*7*', 
      color: '#e60000' 
    },
    '011': { 
      name: 'Etisalat Cash', 
      nameAr: 'اتصالات كاش',
      logo: 'https://i.ibb.co/L8P4rD3/etisalat-cash.png', 
      ussd: '*777*1*', 
      color: '#719917' 
    },
    '012': { 
      name: 'Orange Money', 
      nameAr: 'أورانج موني',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Orange_logo.svg/1024px-Orange_logo.svg.png', 
      ussd: '*115*1*', 
      color: '#ff7900' 
    },
    '015': { 
      name: 'WE Pay', 
      nameAr: 'وي باي',
      logo: 'https://i.ibb.co/v4S8FwX/we-pay.png', 
      ussd: '*990*1*', 
      color: '#4c0099' 
    }
  };

  const handlePhoneInput = (value: string) => {
    setWalletPhone(value);
    const prefix = value.substring(0, 3);
    if (walletConfig[prefix]) {
      setWalletProvider(walletConfig[prefix]);
    } else {
      setWalletProvider(null);
    }
  };

  const generateWalletPayment = () => {
    if (walletPhone.length >= 11 && parseFloat(walletAmount) > 0 && walletProvider) {
      setMobileWalletStep(2);
      const transactionId = Math.random().toString(36).substr(2, 9);
      const transactionDate = new Date().toISOString().slice(0, 10);
      const transactionStatus: TransactionStatus = 'pending';
      const transactionUssdCode = `${walletProvider.ussd}${walletPhone}*${walletAmount}#`;

      setTransactionData({
        id: transactionId,
        phone: walletPhone,
        amount: walletAmount,
        provider: {
          name: walletProvider.name,
          nameAr: walletProvider.nameAr,
          logo: walletProvider.logo,
          color: walletProvider.color
        },
        status: transactionStatus,
        date: transactionDate,
        ussdCode: transactionUssdCode
      });
    } else {
      alert(t('paymentPages.walletValidationError'));
    }
  };

  const resetWalletPayment = () => {
    setMobileWalletStep(1);
    setWalletPhone('');
    setWalletAmount('');
    setWalletProvider(null);
    setTransactionData(null);
    setShowTransactionDetails(false);
  };

  const getUssdCode = () => {
    if (!walletProvider) return '';
    return `${walletProvider.ussd}${walletPhone}*${walletAmount}#`;
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">Multi Payment Pages</h1>
        <p className="text-gray-400">Modern payment interfaces for every use case</p>
      </div>

      {/* Payment Type Tabs */}
      <div className="flex flex-wrap gap-3">
        {paymentTypes.map((type) => {
          const Icon = type.icon;
          const isActive = selectedType === type.id;

          return (
            <motion.button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`flex items-center gap-3 px-6 py-4 rounded-2xl transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30'
                  : 'bg-white/5 border border-white/10 hover:bg-white/10'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className={`p-2 rounded-lg ${isActive ? 'bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6]' : 'bg-white/10'}`}>
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-400'}`} />
              </div>
              <div className="text-left">
                <p className={`text-sm font-medium ${isActive ? 'text-white' : 'text-gray-300'}`}>
                  {type.name}
                </p>
                <p className={`text-xs ${isActive ? 'text-gray-300' : 'text-gray-500'}`}>
                  {type.description}
                </p>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Payment Page Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Live Preview */}
        <GlassCard className="p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Live Preview</h2>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#6ee7b7]/10 border border-[#6ee7b7]/30">
              <div className="w-2 h-2 rounded-full bg-[#6ee7b7] animate-pulse" style={{ boxShadow: '0 0 8px #6ee7b7' }} />
              <span className="text-xs text-[#6ee7b7] font-medium">Live</span>
            </div>
          </div>

          {/* Hosted Payment Page */}
          {selectedType === 'hosted' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                  <span className="text-3xl">💳</span>
                </div>
                <h3 className="text-2xl font-semibold text-white mb-2">Complete Your Payment</h3>
                <p className="text-gray-400">Secure checkout powered by OnTarget PSP</p>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Product</span>
                  <span className="text-sm font-medium text-white">Premium Subscription</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Amount</span>
                  <span className="text-2xl font-bold text-white">$299.00</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Card Number</label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="1234 5678 9012 3456"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                    <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-300">Expiry Date</label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-gray-300">CVV</label>
                    <input
                      type="text"
                      placeholder="123"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                    />
                  </div>
                </div>

                <motion.button
                  className="w-full py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold"
                  whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
                  whileTap={{ scale: 0.98 }}
                >
                  Pay $299.00
                </motion.button>

                <div className="flex items-center justify-center gap-4 text-xs text-gray-400">
                  <div className="flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>Secure Payment</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>256-bit SSL</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Payment Link Page */}
          {selectedType === 'link' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#6ee7b7] to-[#06b6d4] flex items-center justify-center">
                  <LinkIcon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-white mb-2">Payment Request</h3>
                <p className="text-gray-400">Complete payment via secure link</p>
              </div>

              <div className="p-6 rounded-xl bg-gradient-to-br from-[#6ee7b7]/10 to-[#06b6d4]/10 border border-[#6ee7b7]/20">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-gray-400">Invoice #INV-2024-001</p>
                    <p className="text-lg font-semibold text-white">TechStore Electronics</p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-[#6ee7b7]" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold text-white">$1,250.00</span>
                  <span className="text-gray-400">USD</span>
                </div>
              </div>

              <div className="space-y-3 p-4 rounded-xl bg-white/5">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Description</span>
                  <span className="text-white">Product Purchase</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Due Date</span>
                  <span className="text-white">March 20, 2026</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Status</span>
                  <span className="px-3 py-1 rounded-full bg-[#fbbf24]/10 text-[#fbbf24] text-xs">Pending</span>
                </div>
              </div>

              <motion.button
                className="w-full py-4 rounded-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-semibold"
                whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
                whileTap={{ scale: 0.98 }}
              >
                Pay Now
              </motion.button>
            </motion.div>
          )}

          {/* QR Payment Page */}
          {selectedType === 'qr' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6 text-center"
            >
              <div className="mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] flex items-center justify-center">
                  <QrCode className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-white mb-2">Scan to Pay</h3>
                <p className="text-gray-400">Use your mobile wallet to complete payment</p>
              </div>

              <div className="mx-auto w-64 h-64 p-4 rounded-2xl bg-white flex items-center justify-center">
                <div className="w-full h-full bg-gradient-to-br from-[#8b5cf6] via-[#3b82f6] to-[#6ee7b7] opacity-20 rounded-xl" />
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Payment Amount</span>
                  <span className="text-2xl font-bold text-white">$149.99</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Merchant</span>
                  <span className="text-sm font-medium text-white">GadgetWorld</span>
                </div>
              </div>

              <p className="text-xs text-gray-400">
                QR code expires in 15:00 minutes
              </p>
            </motion.div>
          )}

          {/* Invoice Payment Page */}
          {selectedType === 'invoice' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#3b82f6] to-[#2563eb] flex items-center justify-center">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-white mb-2">Invoice Payment</h3>
                <p className="text-gray-400">Professional invoice for business transactions</p>
              </div>

              <div className="p-6 rounded-xl bg-white/5 border border-white/10 space-y-4">
                <div className="flex items-start justify-between pb-4 border-b border-white/10">
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-1">Invoice #2024-001</h4>
                    <p className="text-sm text-gray-400">Issued: March 13, 2026</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-400 mb-1">Due Date</p>
                    <p className="text-sm font-medium text-white">March 27, 2026</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Web Development Services</span>
                    <span className="text-white">$2,500.00</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Design Consultation</span>
                    <span className="text-white">$750.00</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Hosting Setup</span>
                    <span className="text-white">$250.00</span>
                  </div>
                  <div className="flex items-center justify-between text-sm pt-3 border-t border-white/10">
                    <span className="text-gray-400">Subtotal</span>
                    <span className="text-white">$3,500.00</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Tax (10%)</span>
                    <span className="text-white">$350.00</span>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="text-lg font-semibold text-white">Total Due</span>
                    <span className="text-2xl font-bold text-white">$3,850.00</span>
                  </div>
                </div>
              </div>

              <motion.button
                className="w-full py-4 rounded-full bg-gradient-to-r from-[#3b82f6] to-[#2563eb] text-white font-semibold"
                whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(59, 130, 246, 0.5)' }}
                whileTap={{ scale: 0.98 }}
              >
                Pay Invoice
              </motion.button>
            </motion.div>
          )}

          {/* Embedded Widget Page */}
          {selectedType === 'widget' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#6ee7b7] to-[#06b6d4] flex items-center justify-center">
                  <Code className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-white mb-2">Embedded Widget</h3>
                <p className="text-gray-400">Seamless integration into your website</p>
              </div>

              <div className="p-6 rounded-xl bg-gradient-to-br from-white/5 to-white/10 border border-white/10">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Selected Plan</span>
                    <span className="px-3 py-1 rounded-full bg-[#8b5cf6]/20 text-[#8b5cf6] text-sm font-medium">Pro</span>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-white">$29</span>
                    <span className="text-gray-400">/month</span>
                  </div>

                  <div className="space-y-2">
                    {['Unlimited Projects', 'Priority Support', 'Advanced Analytics', 'Custom Domain'].map((feature) => (
                      <div key={feature} className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-[#6ee7b7]" />
                        <span className="text-sm text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-3 pt-4 border-t border-white/10">
                    <input
                      type="email"
                      placeholder="Email address"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#6ee7b7] focus:ring-2 focus:ring-[#6ee7b7]/20"
                    />
                    <input
                      type="text"
                      placeholder="Card number"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#6ee7b7] focus:ring-2 focus:ring-[#6ee7b7]/20"
                    />
                  </div>

                  <motion.button
                    className="w-full py-3 rounded-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-semibold text-sm"
                    whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Subscribe Now
                  </motion.button>

                  <p className="text-xs text-center text-gray-400">
                    Powered by OnTarget PSP
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Mobile Wallet Payment Page */}
          {selectedType === 'mobilewallet' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {mobileWalletStep === 1 ? (
                <>
                  {/* Step 1: Input Form */}
                  <div className="text-center mb-6">
                    <div 
                      className="w-16 h-16 mx-auto mb-4 rounded-xl flex items-center justify-center transition-all duration-300"
                      style={{
                        background: walletProvider 
                          ? `linear-gradient(135deg, ${walletProvider.color}, ${walletProvider.color}dd)` 
                          : 'linear-gradient(135deg, #6ee7b7, #06b6d4)'
                      }}
                    >
                      {walletProvider && walletProvider.logo ? (
                        <img 
                          src={walletProvider.logo} 
                          alt={language === 'ar' ? walletProvider.nameAr : walletProvider.name}
                          className="w-10 h-10 object-contain"
                        />
                      ) : (
                        <Smartphone className="w-8 h-8 text-white" />
                      )}
                    </div>
                    <h3 className="text-2xl font-semibold text-white mb-2">
                      {walletProvider 
                        ? (language === 'ar' ? walletProvider.nameAr : walletProvider.name)
                        : t('paymentPages.mobileWallet')
                      }
                    </h3>
                    <p className="text-gray-400">{t('paymentPages.mobileWalletDesc')}</p>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">{t('paymentPages.walletPhoneLabel')}</label>
                      <input
                        type="tel"
                        value={walletPhone}
                        onChange={(e) => handlePhoneInput(e.target.value)}
                        placeholder={t('paymentPages.walletPhonePlaceholder')}
                        maxLength={11}
                        className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#6ee7b7] focus:ring-2 focus:ring-[#6ee7b7]/20"
                        dir="ltr"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">{t('paymentPages.walletAmountLabel')}</label>
                      <input
                        type="number"
                        value={walletAmount}
                        onChange={(e) => setWalletAmount(e.target.value)}
                        placeholder={t('paymentPages.walletAmountPlaceholder')}
                        className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#6ee7b7] focus:ring-2 focus:ring-[#6ee7b7]/20"
                        dir="ltr"
                      />
                    </div>

                    <motion.button
                      className="w-full py-4 rounded-full text-white font-semibold"
                      style={{
                        background: walletProvider 
                          ? `linear-gradient(to right, ${walletProvider.color}, ${walletProvider.color}dd)` 
                          : 'linear-gradient(to right, #6ee7b7, #06b6d4)'
                      }}
                      whileHover={{ scale: 1.02, boxShadow: `0 0 30px ${walletProvider?.color || '#6ee7b7'}80` }}
                      whileTap={{ scale: 0.98 }}
                      onClick={generateWalletPayment}
                    >
                      {t('paymentPages.walletGenerate')}
                    </motion.button>
                  </div>
                </>
              ) : (
                <>
                  {/* Step 2: Payment Details */}
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-semibold text-[#6ee7b7] mb-2">{t('paymentPages.walletReady')}</h2>
                    <p className="text-gray-400 text-sm">{t('paymentPages.walletScanOrPress')}</p>
                  </div>

                  {/* QR Code Display */}
                  <div className="flex justify-center mb-6">
                    <div className="p-4 rounded-2xl bg-white inline-block">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=tel:${encodeURIComponent(getUssdCode())}`}
                        alt="QR Code" 
                        className="w-40 h-40"
                      />
                    </div>
                  </div>

                  {/* USSD Code Display */}
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
                    <p className="text-sm text-gray-400 mb-2">USSD Code</p>
                    <p className="text-xl font-mono text-white font-bold tracking-wider" dir="ltr">
                      {getUssdCode()}
                    </p>
                  </div>

                  {/* Dial Button */}
                  <motion.a
                    href={`tel:${encodeURIComponent(getUssdCode())}`}
                    className="block w-full py-4 rounded-full text-white font-semibold text-center"
                    style={{
                      background: walletProvider 
                        ? `linear-gradient(to right, ${walletProvider.color}, ${walletProvider.color}dd)` 
                        : 'linear-gradient(to right, #6ee7b7, #06b6d4)'
                    }}
                    whileHover={{ scale: 1.02, boxShadow: `0 0 30px ${walletProvider?.color || '#6ee7b7'}80` }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {t('paymentPages.walletDialNow')}
                  </motion.a>

                  {/* Edit Button */}
                  <button
                    onClick={resetWalletPayment}
                    className="w-full text-center text-sm text-gray-400 hover:text-white transition-colors"
                  >
                    {t('paymentPages.walletEditDetails')}
                  </button>

                  {/* View Transaction Details Button */}
                  {transactionData && (
                    <motion.button
                      onClick={() => setShowTransactionDetails(true)}
                      className="w-full py-3 px-6 rounded-xl bg-[#3b82f6]/20 border border-[#3b82f6]/30 text-[#3b82f6] font-medium flex items-center justify-center gap-2 hover:bg-[#3b82f6]/30 transition-colors"
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <Eye className="w-4 h-4" />
                      {t('walletTransaction.viewDetails')}
                    </motion.button>
                  )}
                </>
              )}
            </motion.div>
          )}
        </GlassCard>

        {/* Configuration Panel */}
        <GlassCard className="p-8">
          <h2 className="text-xl font-semibold text-white mb-6">Configuration</h2>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm text-gray-300">Payment Page URL</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={`https://pay.ontarget.io/${selectedType}/abc123`}
                  readOnly
                  className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium"
                >
                  Copy
                </motion.button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-300">Merchant</label>
              <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20">
                <option>TechStore Electronics</option>
                <option>FashionHub</option>
                <option>GadgetWorld</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-300">Currency</label>
              <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20">
                <option>USD - US Dollar</option>
                <option>EUR - Euro</option>
                <option>GBP - British Pound</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-300">Success Redirect URL</label>
              <input
                type="url"
                placeholder="https://yoursite.com/success"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm text-gray-300">Cancel Redirect URL</label>
              <input
                type="url"
                placeholder="https://yoursite.com/cancel"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
              />
            </div>

            <div className="pt-4 border-t border-white/10 space-y-3">
              <label className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Enable Test Mode</span>
                <div className="relative">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-white/10 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#8b5cf6]/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-[#8b5cf6] peer-checked:to-[#3b82f6]"></div>
                </div>
              </label>

              <label className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Collect Billing Address</span>
                <div className="relative">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-white/10 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#8b5cf6]/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-[#8b5cf6] peer-checked:to-[#3b82f6]"></div>
                </div>
              </label>

              <label className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Send Email Receipt</span>
                <div className="relative">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-white/10 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#8b5cf6]/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-[#8b5cf6] peer-checked:to-[#3b82f6]"></div>
                </div>
              </label>
            </div>

            <motion.button
              className="w-full py-4 rounded-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-semibold"
              whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
              whileTap={{ scale: 0.98 }}
            >
              Save Configuration
            </motion.button>
          </div>
        </GlassCard>
      </div>

      {/* Transaction Details Modal */}
      <WalletTransactionDetails
        isOpen={showTransactionDetails}
        transaction={transactionData}
        onClose={() => setShowTransactionDetails(false)}
      />
    </div>
  );
}