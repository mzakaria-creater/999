import { useState, useEffect } from 'react';
import { GlassCard } from '../components/GlassCard';
import { motion } from 'motion/react';
import {
  Zap,
  TrendingUp,
  TrendingDown,
  Bitcoin,
  DollarSign,
  RefreshCw,
  Bell,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Settings,
  BarChart3
} from 'lucide-react';
import { withdrawalService, type WithdrawalRequest } from '../services/automated_withdrawals';
import { exchangeRateService } from '../services/exchange_rate';
import { cryptoPriceService, type CryptoPrice } from '../services/crypto_price';
import { useLanguage } from '../context/LanguageContext';

export function AutomationCenter() {
  const { t } = useLanguage();
  const [cryptoPrices, setCryptoPrices] = useState<CryptoPrice[]>([]);
  const [exchangeRates, setExchangeRates] = useState<any[]>([]);
  const [withdrawalStats, setWithdrawalStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => {
      refreshPrices();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Load crypto prices
      const cryptos = cryptoPriceService.getPopularCryptos();
      setCryptoPrices(cryptos);

      // Load exchange rates
      const rates = exchangeRateService.getPopularPairs();
      setExchangeRates(rates);

      // Load withdrawal stats
      const stats = withdrawalService.getStatistics();
      setWithdrawalStats(stats);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshPrices = async () => {
    try {
      await cryptoPriceService.fetchLivePrices();
      const cryptos = cryptoPriceService.getPopularCryptos();
      setCryptoPrices(cryptos);

      const rates = exchangeRateService.getPopularPairs();
      setExchangeRates(rates);
    } catch (error) {
      console.error('Failed to refresh prices:', error);
    }
  };

  const formatPrice = (price: number): string => {
    if (price >= 1000) {
      return price.toLocaleString('en-US', { maximumFractionDigits: 2 });
    }
    return price.toFixed(2);
  };

  const formatChange = (change: number): string => {
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Automation Center
          </h1>
          <p className="text-gray-400">
            Real-time monitoring and automation dashboard
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={refreshPrices}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg hover:shadow-xl transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          Refresh
        </motion.button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#6ee7b7]/5">
              <Zap className="w-6 h-6 text-[#6ee7b7]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Active Rules</p>
              <p className="text-xl font-bold text-white">
                {withdrawalService.getRules().filter(r => r.enabled).length}
              </p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#3b82f6]/5">
              <Clock className="w-6 h-6 text-[#3b82f6]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Pending</p>
              <p className="text-xl font-bold text-white">
                {withdrawalStats?.pending || 0}
              </p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#8b5cf6]/5">
              <CheckCircle className="w-6 h-6 text-[#8b5cf6]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Completed</p>
              <p className="text-xl font-bold text-white">
                {withdrawalStats?.completed || 0}
              </p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#fbbf24]/5">
              <Activity className="w-6 h-6 text-[#fbbf24]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Live Feeds</p>
              <p className="text-xl font-bold text-white">
                {cryptoPrices.length + exchangeRates.length}
              </p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Crypto Prices */}
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Bitcoin className="w-5 h-5 text-[#f7931a]" />
            <h2 className="text-lg font-bold text-white">Cryptocurrency Prices</h2>
          </div>
          <span className="text-xs text-gray-400">Live • Updates every 30s</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {cryptoPrices.slice(0, 6).map((crypto, index) => (
            <motion.div
              key={crypto.symbol}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-bold text-white">{crypto.symbol}</h3>
                  <p className="text-xs text-gray-400">{crypto.name}</p>
                </div>
                <div className={`flex items-center gap-1 text-sm font-semibold ${
                  crypto.priceChangePercent24h >= 0 ? 'text-[#6ee7b7]' : 'text-[#f87171]'
                }`}>
                  {crypto.priceChangePercent24h >= 0 ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {formatChange(crypto.priceChangePercent24h)}
                </div>
              </div>
              <div className="text-xl font-bold text-white">
                ${formatPrice(crypto.price)}
              </div>
              <div className="text-xs text-gray-400 mt-1">
                Vol: ${(crypto.volume24h / 1000000000).toFixed(2)}B
              </div>
            </motion.div>
          ))}
        </div>
      </GlassCard>

      {/* Exchange Rates */}
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-[#6ee7b7]" />
            <h2 className="text-lg font-bold text-white">Exchange Rates</h2>
          </div>
          <span className="text-xs text-gray-400">Live • Auto-updated</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {exchangeRates.slice(0, 8).map((rate, index) => {
            const trend = exchangeRateService.getTrend(rate.from, rate.to);
            const change = exchangeRateService.getChangePercent(rate.from, rate.to, 1);
            
            return (
              <motion.div
                key={`${rate.from}-${rate.to}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.03 }}
                className="p-3 rounded-xl bg-white/5 border border-white/10"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-white">
                    {rate.from}/{rate.to}
                  </span>
                  {trend !== 'stable' && (
                    <div className={`${trend === 'up' ? 'text-[#6ee7b7]' : 'text-[#f87171]'}`}>
                      {trend === 'up' ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                    </div>
                  )}
                </div>
                <div className="text-lg font-bold text-white">
                  {rate.rate.toFixed(4)}
                </div>
                <div className={`text-xs ${change >= 0 ? 'text-[#6ee7b7]' : 'text-[#f87171]'}`}>
                  {formatChange(change)}
                </div>
              </motion.div>
            );
          })}
        </div>
      </GlassCard>

      {/* Withdrawal Automation */}
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#8b5cf6]" />
            <h2 className="text-lg font-bold text-white">Withdrawal Automation</h2>
          </div>
          <button className="text-sm text-[#8b5cf6] hover:text-[#a78bfa] flex items-center gap-1">
            <Settings className="w-4 h-4" />
            Configure Rules
          </button>
        </div>

        <div className="space-y-3">
          {withdrawalService.getRules().slice(0, 3).map((rule, index) => (
            <motion.div
              key={rule.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-xl bg-white/5 border border-white/10"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-white">{rule.name}</h3>
                    {rule.enabled ? (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-[#6ee7b7]/20 text-[#6ee7b7]">
                        Active
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-gray-500/20 text-gray-400">
                        Inactive
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div>
                      <p className="text-gray-400 text-xs">Range</p>
                      <p className="text-white">
                        ${rule.minAmount} - ${rule.maxAmount}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Currency</p>
                      <p className="text-white">{rule.currency}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Method</p>
                      <p className="text-white capitalize">{rule.paymentMethod}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Auto-Approve</p>
                      <p className="text-white">{rule.autoApprove ? 'Yes' : 'No'}</p>
                    </div>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-lg text-xs font-semibold ${
                  rule.priority === 'high' ? 'bg-[#f87171]/20 text-[#f87171]' :
                  rule.priority === 'medium' ? 'bg-[#fbbf24]/20 text-[#fbbf24]' :
                  'bg-gray-500/20 text-gray-400'
                }`}>
                  {rule.priority.toUpperCase()}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {withdrawalStats && (
          <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="text-center p-3 rounded-lg bg-white/5">
              <p className="text-xs text-gray-400 mb-1">Total</p>
              <p className="text-lg font-bold text-white">{withdrawalStats.total}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-white/5">
              <p className="text-xs text-gray-400 mb-1">Pending</p>
              <p className="text-lg font-bold text-[#fbbf24]">{withdrawalStats.pending}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-white/5">
              <p className="text-xs text-gray-400 mb-1">Approved</p>
              <p className="text-lg font-bold text-[#3b82f6]">{withdrawalStats.approved}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-white/5">
              <p className="text-xs text-gray-400 mb-1">Completed</p>
              <p className="text-lg font-bold text-[#6ee7b7]">{withdrawalStats.completed}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-white/5">
              <p className="text-xs text-gray-400 mb-1">Rejected</p>
              <p className="text-lg font-bold text-[#f87171]">{withdrawalStats.rejected}</p>
            </div>
          </div>
        )}
      </GlassCard>

      {/* Market Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassCard className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-[#6ee7b7]" />
            <h2 className="text-lg font-bold text-white">Top Gainers (24h)</h2>
          </div>
          <div className="space-y-2">
            {cryptoPriceService.getTopGainers(5).map((crypto, index) => (
              <div
                key={crypto.symbol}
                className="flex items-center justify-between p-3 rounded-lg bg-white/5"
              >
                <div className="flex items-center gap-3">
                  <span className="text-gray-400 text-sm w-6">{index + 1}</span>
                  <div>
                    <p className="font-semibold text-white">{crypto.symbol}</p>
                    <p className="text-xs text-gray-400">{crypto.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-white">${formatPrice(crypto.price)}</p>
                  <p className="text-sm text-[#6ee7b7]">
                    {formatChange(crypto.priceChangePercent24h)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingDown className="w-5 h-5 text-[#f87171]" />
            <h2 className="text-lg font-bold text-white">Top Losers (24h)</h2>
          </div>
          <div className="space-y-2">
            {cryptoPriceService.getTopLosers(5).map((crypto, index) => (
              <div
                key={crypto.symbol}
                className="flex items-center justify-between p-3 rounded-lg bg-white/5"
              >
                <div className="flex items-center gap-3">
                  <span className="text-gray-400 text-sm w-6">{index + 1}</span>
                  <div>
                    <p className="font-semibold text-white">{crypto.symbol}</p>
                    <p className="text-xs text-gray-400">{crypto.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-white">${formatPrice(crypto.price)}</p>
                  <p className="text-sm text-[#f87171]">
                    {formatChange(crypto.priceChangePercent24h)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
