import { useState } from 'react';
import { Search, Plus, Eye, TrendingUp, TrendingDown, DollarSign, CreditCard, Activity } from 'lucide-react';
import { merchants } from '../data/seedData';

export default function NewMerchants() {
  const [selectedMerchant, setSelectedMerchant] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredMerchants = merchants.filter(m =>
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Merchants</h1>
          <p className="text-blue-200">{filteredMerchants.length} active merchants</p>
        </div>
        <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-2 transition-colors font-medium">
          <Plus className="w-5 h-5" />
          Add Merchant
        </button>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-400" />
          <input
            type="text"
            placeholder="Search merchants..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Merchants Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredMerchants.map((merchant) => (
          <div
            key={merchant.id}
            className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 hover:border-blue-500/50 transition-all cursor-pointer"
            onClick={() => setSelectedMerchant(merchant)}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="text-4xl">{merchant.logo}</div>
                <div>
                  <h3 className="text-lg font-semibold text-white">{merchant.name}</h3>
                  <p className="text-sm text-blue-300">{merchant.id}</p>
                </div>
              </div>
              <StatusBadge status={merchant.status} />
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <StatItem
                label="Balance"
                value={`${merchant.balance.toLocaleString()} ${merchant.currency}`}
                icon={<DollarSign className="w-4 h-4" />}
              />
              <StatItem
                label="Success Rate"
                value={`${merchant.successRate}%`}
                icon={<Activity className="w-4 h-4" />}
              />
            </div>

            {/* Monthly Volume */}
            <div className="p-3 bg-slate-900/50 rounded-lg mb-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-blue-300">Monthly Volume</span>
                <span className="text-xs text-green-400 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  +12%
                </span>
              </div>
              <div className="text-white font-semibold">
                {merchant.monthlyVolume.toLocaleString()} {merchant.currency}
              </div>
            </div>

            {/* Payment Methods */}
            <div className="flex flex-wrap gap-2 mb-4">
              {merchant.paymentMethods.slice(0, 3).map((pm) => (
                <span key={pm} className="px-2 py-1 bg-blue-600/20 text-blue-300 text-xs rounded">
                  {pm.replace('_', ' ')}
                </span>
              ))}
              {merchant.paymentMethods.length > 3 && (
                <span className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
                  +{merchant.paymentMethods.length - 3}
                </span>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between text-xs text-blue-300">
              <span>{merchant.totalTransactions.toLocaleString()} transactions</span>
              <button className="flex items-center gap-1 hover:text-blue-400 transition-colors">
                <Eye className="w-3 h-3" />
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Merchant Profile Modal */}
      {selectedMerchant && (
        <MerchantProfileModal
          merchant={selectedMerchant}
          onClose={() => setSelectedMerchant(null)}
        />
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: any = {
    active: { bg: 'bg-green-500/20', text: 'text-green-400', label: 'Active' },
    suspended: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'Suspended' },
    pending: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', label: 'Pending' },
  };

  const { bg, text, label } = config[status] || config.active;

  return (
    <span className={`px-3 py-1 rounded-full text-xs font-medium ${bg} ${text}`}>
      {label}
    </span>
  );
}

function StatItem({ label, value, icon }: any) {
  return (
    <div>
      <div className="flex items-center gap-1 text-xs text-blue-300 mb-1">
        {icon}
        {label}
      </div>
      <div className="text-white font-semibold text-sm">{value}</div>
    </div>
  );
}

function MerchantProfileModal({ merchant, onClose }: any) {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-slate-700 flex items-center justify-between sticky top-0 bg-slate-800 z-10">
          <div className="flex items-center gap-4">
            <div className="text-5xl">{merchant.logo}</div>
            <div>
              <h2 className="text-2xl font-bold text-white mb-1">{merchant.name}</h2>
              <p className="text-blue-300">{merchant.email}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors text-slate-400"
          >
            ✕
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-slate-700 px-6">
          <div className="flex gap-4">
            {['overview', 'payment-methods', 'corridors', 'api', 'analytics'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-3 font-medium border-b-2 transition-colors ${
                  activeTab === tab
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                {tab.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-6">
                <MetricCard
                  title="Total Balance"
                  value={`${merchant.balance.toLocaleString()} ${merchant.currency}`}
                  change="+5.2%"
                  positive
                />
                <MetricCard
                  title="Monthly Volume"
                  value={`${merchant.monthlyVolume.toLocaleString()} ${merchant.currency}`}
                  change="+12.8%"
                  positive
                />
                <MetricCard
                  title="Success Rate"
                  value={`${merchant.successRate}%`}
                  change="+2.1%"
                  positive
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <InfoField label="Type" value={merchant.type.toUpperCase()} />
                <InfoField label="Country" value={merchant.country} />
                <InfoField label="Phone" value={merchant.phone} />
                <InfoField label="Settlements" value={merchant.settlements} />
                <InfoField label="Total Transactions" value={merchant.totalTransactions.toLocaleString()} />
                <InfoField label="Average Ticket" value={`$${merchant.averageTicket}`} />
              </div>
            </div>
          )}

          {activeTab === 'payment-methods' && (
            <div className="grid grid-cols-2 gap-4">
              {merchant.paymentMethods.map((pm: string) => (
                <div key={pm} className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-white font-medium">{pm.replace('_', ' ').toUpperCase()}</span>
                    <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">Enabled</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'corridors' && (
            <div className="space-y-3">
              {merchant.corridors.map((corridor: string) => (
                <div key={corridor} className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg flex items-center justify-between">
                  <div>
                    <div className="text-white font-medium">{corridor}</div>
                    <div className="text-xs text-blue-300 mt-1">Active corridor</div>
                  </div>
                  <div className="text-right">
                    <div className="text-white font-semibold">Rate: 1.0</div>
                    <div className="text-xs text-blue-300">Markup: 2.5%</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'api' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                <div className="text-xs text-blue-300 mb-2">API Key</div>
                <div className="font-mono text-white">{merchant.apiKey}</div>
              </div>
              <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                <div className="text-xs text-blue-300 mb-2">Webhook URL</div>
                <div className="font-mono text-white break-all">{merchant.webhookUrl}</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                  <div className="text-xs text-blue-300 mb-2">Webhook Status</div>
                  <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">Active</span>
                </div>
                <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                  <div className="text-xs text-blue-300 mb-2">Last Webhook</div>
                  <div className="text-white">2024-03-22 16:33:20</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="grid grid-cols-2 gap-6">
              <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                <div className="text-blue-300 text-sm mb-3">Transaction Breakdown</div>
                <div className="space-y-2">
                  <AnalyticsBar label="Completed" value={85} color="green" />
                  <AnalyticsBar label="Pending" value={10} color="yellow" />
                  <AnalyticsBar label="Failed" value={5} color="red" />
                </div>
              </div>
              <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
                <div className="text-blue-300 text-sm mb-3">Payment Method Split</div>
                <div className="space-y-2">
                  {merchant.paymentMethods.slice(0, 3).map((pm: string, idx: number) => (
                    <AnalyticsBar
                      key={pm}
                      label={pm.replace('_', ' ')}
                      value={[45, 30, 25][idx]}
                      color="blue"
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, change, positive }: any) {
  return (
    <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
      <div className="text-xs text-blue-300 mb-2">{title}</div>
      <div className="text-2xl font-bold text-white mb-1">{value}</div>
      <div className={`text-xs flex items-center gap-1 ${positive ? 'text-green-400' : 'text-red-400'}`}>
        {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
        {change}
      </div>
    </div>
  );
}

function InfoField({ label, value }: any) {
  return (
    <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
      <div className="text-xs text-blue-300 mb-1">{label}</div>
      <div className="text-white font-medium">{value}</div>
    </div>
  );
}

function AnalyticsBar({ label, value, color }: any) {
  const colors: any = {
    green: 'bg-green-500',
    yellow: 'bg-yellow-500',
    red: 'bg-red-500',
    blue: 'bg-blue-500',
  };

  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="text-slate-300">{label}</span>
        <span className="text-white font-medium">{value}%</span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2">
        <div
          className={`h-2 rounded-full ${colors[color]}`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
