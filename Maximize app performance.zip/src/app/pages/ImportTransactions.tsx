import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { useState } from 'react';
import { 
  Upload, 
  Download, 
  FileText, 
  CheckCircle, 
  AlertCircle,
  X,
  FileSpreadsheet,
  ArrowRight,
  AlertTriangle
} from 'lucide-react';

export function ImportTransactions() {
  const { t } = useLanguage();
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [imported, setImported] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setImported(false);
      setErrors([]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && (droppedFile.type.includes('csv') || droppedFile.type.includes('sheet') || droppedFile.type.includes('excel'))) {
      setFile(droppedFile);
      setImported(false);
      setErrors([]);
    }
  };

  const handleImport = async () => {
    if (!file) return;
    
    setImporting(true);
    setProgress(0);
    setErrors([]);

    // Simulate import process
    const steps = [
      { progress: 20, message: 'Analyzing file...' },
      { progress: 40, message: 'Validating data...' },
      { progress: 60, message: 'Processing transactions...' },
      { progress: 80, message: 'Importing to database...' },
      { progress: 100, message: 'Complete!' }
    ];

    for (const step of steps) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setProgress(step.progress);
    }

    // Simulate some validation errors
    if (Math.random() > 0.7) {
      setErrors([
        'Row 15: Invalid date format (use YYYY-MM-DD)',
        'Row 23: Amount exceeds maximum limit',
        'Row 34: Missing merchant ID'
      ]);
    }

    setImporting(false);
    setImported(true);
  };

  const downloadTemplate = () => {
    // Simulate template download
    const csvContent = `Transaction ID,Merchant,Amount,Currency,Status,Payment Method,Wallet,Date,Time,Customer Email
TXN-001,SuperMart Egypt,1250.00,EGP,success,Credit Card,WAL-4523,2026-03-17,14:30:00,customer@email.com
TXN-002,TechStore,890.50,EGP,pending,InstaPay,WAL-7821,2026-03-17,15:45:00,user@example.com`;
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transaction_import_template.csv';
    a.click();
  };

  return (
    <div className="p-4 sm:p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-white mb-2">{t('import.title')}</h1>
        <p className="text-gray-400">{t('import.subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* File Upload Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <div
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              className="border-2 border-dashed border-white/20 rounded-2xl p-12 text-center hover:border-[#8b5cf6]/50 transition-all"
            >
              {!file ? (
                <div>
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 flex items-center justify-center">
                    <Upload className="w-10 h-10 text-[#8b5cf6]" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">{t('import.dragDrop')}</h3>
                  <p className="text-gray-400 mb-6">{t('import.or')}</p>
                  <label className="inline-block">
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <motion.span
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium cursor-pointer inline-flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
                    >
                      <FileSpreadsheet className="w-5 h-5" />
                      {t('import.browse')}
                    </motion.span>
                  </label>
                  <p className="text-sm text-gray-500 mt-4">{t('import.supportedFormats')}</p>
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-center gap-4 mb-6">
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center">
                      <FileText className="w-8 h-8 text-green-400" />
                    </div>
                    <div className="text-left">
                      <h4 className="text-lg font-semibold text-white">{file.name}</h4>
                      <p className="text-sm text-gray-400">{(file.size / 1024).toFixed(2)} KB</p>
                    </div>
                    <button
                      onClick={() => setFile(null)}
                      className="ml-auto p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {!importing && !imported && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleImport}
                      className="px-8 py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium inline-flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
                    >
                      <Upload className="w-5 h-5" />
                      {t('import.importTransactions')}
                    </motion.button>
                  )}

                  {importing && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-center gap-2 text-[#8b5cf6]">
                        <div className="w-5 h-5 border-2 border-[#8b5cf6] border-t-transparent rounded-full animate-spin" />
                        <span className="font-medium">{t('import.importing')}</span>
                      </div>
                      <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          className="h-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6]"
                        />
                      </div>
                      <p className="text-sm text-gray-400">{progress}% Complete</p>
                    </div>
                  )}

                  {imported && errors.length === 0 && (
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
                        <CheckCircle className="w-8 h-8 text-green-400" />
                      </div>
                      <h4 className="text-xl font-semibold text-white">{t('import.success')}</h4>
                      <p className="text-gray-400">Successfully imported 125 transactions</p>
                    </div>
                  )}

                  {errors.length > 0 && (
                    <div className="mt-6 p-4 rounded-xl bg-red-500/10 border border-red-500/30">
                      <div className="flex items-center gap-2 mb-3">
                        <AlertCircle className="w-5 h-5 text-red-400" />
                        <h4 className="font-semibold text-red-400">{t('import.validationErrors')}</h4>
                      </div>
                      <ul className="space-y-2 text-sm text-red-300">
                        {errors.map((error, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            {error}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* Instructions & Template */}
        <div className="space-y-6">
          {/* Download Template */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center mb-4">
              <Download className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">{t('import.downloadTemplate')}</h3>
            <p className="text-sm text-gray-400 mb-4">Get the CSV template with correct headers and example data</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={downloadTemplate}
              className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
            >
              <Download className="w-5 h-5" />
              Download Template
            </motion.button>
          </motion.div>

          {/* Instructions */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#8b5cf6]" />
              {t('import.uploadInstructions')}
            </h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 mt-0.5 text-[#8b5cf6] flex-shrink-0" />
                <span>{t('import.instruction1')}</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 mt-0.5 text-[#8b5cf6] flex-shrink-0" />
                <span>{t('import.instruction2')}</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 mt-0.5 text-[#8b5cf6] flex-shrink-0" />
                <span>{t('import.instruction3')}</span>
              </li>
              <li className="flex items-start gap-2">
                <ArrowRight className="w-4 h-4 mt-0.5 text-[#8b5cf6] flex-shrink-0" />
                <span>{t('import.instruction4')}</span>
              </li>
            </ul>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
