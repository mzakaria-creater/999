import { useState } from 'react';
import { Wallet, AlertTriangle, CheckCircle, TrendingUp, Activity, DollarSign, Clock } from 'lucide-react';
import { wallets } from '../data/seedData';

export default function NewWallets() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white mb-2">Wallet Management</h1>
        <p className="text-blue-200">Monitor and manage payment wallet capacity</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <SummaryCard
          title="Total Wallets"
          value="6"
          subtitle="5 active, 1 suspended"
          icon={<Wallet className="w-6 h-6" />}
          color="blue"
        />
        <SummaryCard
          title="Total Capacity"
          value="$12.6M"
          subtitle="Across all wallets"
          icon={<DollarSign className="w-6 h-6" />}
          color="green"
        />
        <SummaryCard
          title="Critical Wallets"
          value="2"
          subtitle=">95% capacity"
          icon={<AlertTriangle className="w-6 h-6" />}
          color="red"
        />
        <SummaryCard
          title="Warning Wallets"
          value="1"
          subtitle=">80% capacity"
          icon={<Activity className="w-6 h-6" />}
          color="yellow"
        />
      </div>

      {/* Wallet Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {wallets.map((wallet) => {
          const percentage = (wallet.balance / wallet.capacity) * 100;
          const isCritical = percentage >= 95;
          const isWarning = percentage >= 80 && percentage < 95;
          const dailyPercentage = (wallet.dailyUsed / wallet.dailyLimit) * 100;

          return (
            <div
              key={wallet.id}
              className={`bg-slate-800/50 backdrop-blur-xl border rounded-2xl p-6 transition-all ${
                isCritical
                  ? 'border-red-500/50'
                  : isWarning
                  ? 'border-yellow-500/50'
                  : 'border-slate-700/50 hover:border-blue-500/50'
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-xl ${
                    isCritical
                      ? 'bg-red-600/20 text-red-400'
                      : isWarning
                      ? 'bg-yellow-600/20 text-yellow-400'
                      : 'bg-blue-600/20 text-blue-400'
                  }`}>
                    <Wallet className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{wallet.name}</h3>
                    <p className="text-sm text-blue-300">{wallet.provider.replace('_', ' ').toUpperCase()}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <StatusBadge status={wallet.status} />
                  {isCritical && (
                    <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      CRITICAL
                    </span>
                  )}
                  {isWarning && !isCritical && (
                    <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      WARNING
                    </span>
                  )}
                </div>
              </div>

              {/* Main Capacity */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-blue-200">Wallet Capacity</span>
                  <span className="text-sm text-white font-semibold">
                    {percentage.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-3 mb-2">
                  <div
                    className={`h-3 rounded-full transition-all ${
                      isCritical
                        ? 'bg-gradient-to-r from-red-500 to-red-600'
                        : isWarning
                        ? 'bg-gradient-to-r from-yellow-500 to-yellow-600'
                        : 'bg-gradient-to-r from-green-500 to-green-600'
                    }`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-blue-300">
                  <span>{wallet.balance.toLocaleString()} {wallet.currency}</span>
                  <span>{wallet.capacity.toLocaleString()} {wallet.currency}</span>
                </div>
              </div>

              {/* Daily Limit */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-blue-200">Daily Limit Usage</span>
                  <span className="text-sm text-white font-semibold">
                    {dailyPercentage.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2 mb-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all"
                    style={{ width: `${dailyPercentage}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-blue-300">
                  <span>{wallet.dailyUsed.toLocaleString()} {wallet.currency} used today</span>
                  <span>Limit: {wallet.dailyLimit.toLocaleString()}</span>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <StatBox
                  label="Monthly Volume"
                  value={`${(wallet.monthlyVolume / 1000).toFixed(0)}K ${wallet.currency}`}
                  icon={<TrendingUp className="w-4 h-4" />}
                />
                <StatBox
                  label="Last Transaction"
                  value={new Date(wallet.lastTransaction).toLocaleTimeString()}
                  icon={<Clock className="w-4 h-4" />}
                />
              </div>

              {/* Wallet Number */}
              <div className="p-3 bg-slate-900/50 rounded-lg">
                <div className="text-xs text-blue-300 mb-1">Wallet Number</div>
                <div className="font-mono text-white text-sm">{wallet.number}</div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-4">
                <button className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors">
                  View Transactions
                </button>
                <button className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm font-medium transition-colors">
                  Settings
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pool Summary */}
      <div className="mt-8 bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-6">Wallet Pools by Provider</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <PoolCard
            provider="Vodafone Cash"
            wallets={2}
            totalCapacity={1000000}
            totalBalance={610000}
            currency="EGP"
            color="red"
          />
          <PoolCard
            provider="Bank Transfer"
            wallets={1}
            totalCapacity={10000000}
            totalBalance={2500000}
            currency="EGP"
            color="blue"
          />
          <PoolCard
            provider="STC Pay"
            wallets={1}
            totalCapacity={200000}
            totalBalance={180000}
            currency="SAR"
            color="purple"
          />
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: any = {
    active: { bg: 'bg-green-500/20', text: 'text-green-400', label: 'Active', icon: CheckCircle },
    suspended: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'Suspended', icon: AlertTriangle },
  };

  const { bg, text, label, icon: Icon } = config[status] || config.active;

  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded ${bg} ${text} text-xs font-medium`}>
      <Icon className="w-3 h-3" />
      {label}
    </span>
  );
}

function SummaryCard({ title, value, subtitle, icon, color }: any) {
  const colors: any = {
    blue: 'bg-blue-600/20 text-blue-400',
    green: 'bg-green-600/20 text-green-400',
    red: 'bg-red-600/20 text-red-400',
    yellow: 'bg-yellow-600/20 text-yellow-400',
  };

  return (
    <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6">
      <div className={`p-3 rounded-xl ${colors[color]} inline-block mb-4`}>
        {icon}
      </div>
      <div className="text-2xl font-bold text-white mb-1">{value}</div>
      <div className="text-sm text-blue-200 mb-1">{title}</div>
      <div className="text-xs text-blue-300">{subtitle}</div>
    </div>
  );
}

function StatBox({ label, value, icon }: any) {
  return (
    <div className="p-3 bg-slate-900/50 rounded-lg">
      <div className="flex items-center gap-1.5 text-xs text-blue-300 mb-1">
        {icon}
        {label}
      </div>
      <div className="text-white font-semibold text-sm">{value}</div>
    </div>
  );
}

function PoolCard({ provider, wallets, totalCapacity, totalBalance, currency, color }: any) {
  const percentage = (totalBalance / totalCapacity) * 100;
  const colors: any = {
    red: 'from-red-500 to-red-600',
    blue: 'from-blue-500 to-blue-600',
    purple: 'from-purple-500 to-purple-600',
  };

  return (
    <div className="p-6 bg-slate-900/50 border border-slate-700 rounded-xl">
      <h4 className="text-white font-semibold mb-4">{provider}</h4>
      <div className="text-xs text-blue-300 mb-2">
        {wallets} wallet{wallets > 1 ? 's' : ''} • {percentage.toFixed(1)}% capacity
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2.5 mb-3">
        <div
          className={`h-2.5 rounded-full bg-gradient-to-r ${colors[color]}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
      <div className="flex items-center justify-between text-sm">
        <span className="text-blue-200">{totalBalance.toLocaleString()} {currency}</span>
        <span className="text-blue-300">/ {totalCapacity.toLocaleString()}</span>
      </div>
    </div>
  );
}
