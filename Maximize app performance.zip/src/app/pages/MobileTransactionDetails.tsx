import { motion } from 'motion/react';
import { useParams, useNavigate } from 'react-router';
import { 
  CheckCircle2,
  Clock,
  XCircle,
  AlertCircle,
  Copy,
  Download,
  Share2,
  Eye,
  ImageIcon,
  User,
  CreditCard,
  Calendar,
  Building2,
  Shield,
  FileText,
  ChevronRight
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { MobileAppCard } from '../components/MobileAppCard';
import { useState } from 'react';

interface TransactionDetail {
  id: string;
  reference: string;
  amount: number;
  currency: string;
  status: 'completed' | 'pending' | 'failed' | 'review';
  merchant: string;
  customer: string;
  paymentMethod: string;
  date: string;
  timestamp: string;
  proofOfPayment?: string;
  notes?: string;
}

const mockTransaction: TransactionDetail = {
  id: 'REF-20250313-001',
  reference: 'REF-20250313-001',
  amount: 3780.00,
  currency: 'USD',
  status: 'completed',
  merchant: 'GlobalPay Ltd',
  customer: 'Michael Brown',
  paymentMethod: 'Bank Transfer',
  date: 'Mar 13, 2025',
  timestamp: 'Mar 13, 2025 at 06:00 PM',
  notes: 'Payment for invoice #INV-2025-0313',
};

export default function MobileTransactionDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, direction } = useLanguage();
  const [showProof, setShowProof] = useState(false);
  const [copied, setCopied] = useState(false);

  const transaction = mockTransaction;

  const getStatusConfig = (status: TransactionDetail['status']) => {
    const configs = {
      completed: {
        icon: CheckCircle2,
        color: 'text-green-400',
        bgColor: 'bg-green-400/20',
        borderColor: 'border-green-400/30',
        label: direction === 'rtl' ? 'مكتمل' : 'Completed'
      },
      pending: {
        icon: Clock,
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-400/20',
        borderColor: 'border-yellow-400/30',
        label: direction === 'rtl' ? 'قيد الانتظار' : 'Pending'
      },
      failed: {
        icon: XCircle,
        color: 'text-red-400',
        bgColor: 'bg-red-400/20',
        borderColor: 'border-red-400/30',
        label: direction === 'rtl' ? 'فشل' : 'Failed'
      },
      review: {
        icon: AlertCircle,
        color: 'text-blue-400',
        bgColor: 'bg-blue-400/20',
        borderColor: 'border-blue-400/30',
        label: direction === 'rtl' ? 'قيد المراجعة' : 'Under Review'
      }
    };
    return configs[status];
  };

  const statusConfig = getStatusConfig(transaction.status);
  const StatusIcon = statusConfig.icon;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const auditTrail = [
    {
      action: 'Transaction Created',
      timestamp: 'Mar 13, 2025 at 05:55 PM',
      user: 'System',
      details: 'Payment request initiated'
    },
    {
      action: 'Payment Verified',
      timestamp: 'Mar 13, 2025 at 05:58 PM',
      user: 'Payment Gateway',
      details: 'Bank transfer confirmed'
    },
    {
      action: 'Transaction Completed',
      timestamp: 'Mar 13, 2025 at 06:00 PM',
      user: 'System',
      details: 'Funds transferred successfully'
    }
  ];

  return (
    <div className="pb-4">
      {/* Status Header */}
      <div className="px-4 pt-4 pb-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`p-6 rounded-3xl border ${statusConfig.bgColor} ${statusConfig.borderColor}`}
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-2xl ${statusConfig.bgColor} border ${statusConfig.borderColor} flex items-center justify-center`}>
                <StatusIcon className={`w-6 h-6 ${statusConfig.color}`} />
              </div>
              <div>
                <div className={`text-lg font-bold ${statusConfig.color} mb-1`}>
                  {statusConfig.label}
                </div>
                <div className="text-xs text-gray-400">
                  {direction === 'rtl' ? 'حالة المعاملة' : 'Transaction Status'}
                </div>
              </div>
            </div>
            <motion.button
              whileTap={{ scale: 0.9 }}
              className={`px-4 py-2 rounded-xl ${statusConfig.bgColor} border ${statusConfig.borderColor} ${statusConfig.color} text-sm font-medium`}
            >
              {direction === 'rtl' ? 'تغيير الحالة' : 'Change Status'}
            </motion.button>
          </div>

          {/* Amount Display */}
          <div className="text-center py-4">
            <div className="text-sm text-gray-400 mb-2">
              {direction === 'rtl' ? 'المبلغ' : 'Amount'}
            </div>
            <div className="text-5xl font-bold text-white mb-1">
              ${transaction.amount.toFixed(2)}
            </div>
            <div className="text-sm text-gray-500">
              {transaction.currency}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Transaction Details */}
      <div className="px-4 mb-4">
        <MobileAppCard gradient>
          <div className="grid grid-cols-2 gap-4">
            {/* Reference */}
            <div className="col-span-2">
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs text-gray-500">
                  {direction === 'rtl' ? 'الرقم المرجعي' : 'Reference'}
                </div>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => copyToClipboard(transaction.reference)}
                  className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                >
                  <Copy className={`w-4 h-4 ${copied ? 'text-green-400' : 'text-gray-400'}`} />
                </motion.button>
              </div>
              <div className="font-mono text-base text-white font-medium">
                {transaction.reference}
              </div>
            </div>

            {/* Merchant */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="w-4 h-4 text-gray-500" />
                <div className="text-xs text-gray-500">
                  {direction === 'rtl' ? 'التاجر' : 'Merchant'}
                </div>
              </div>
              <div className="text-white font-medium">
                {transaction.merchant}
              </div>
            </div>

            {/* Customer */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <User className="w-4 h-4 text-gray-500" />
                <div className="text-xs text-gray-500">
                  {direction === 'rtl' ? 'العميل' : 'Customer'}
                </div>
              </div>
              <div className="text-white font-medium">
                {transaction.customer}
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="w-4 h-4 text-gray-500" />
                <div className="text-xs text-gray-500">
                  {direction === 'rtl' ? 'طريقة الدفع' : 'Payment Method'}
                </div>
              </div>
              <div className="text-white font-medium">
                {transaction.paymentMethod}
              </div>
            </div>

            {/* Date */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <div className="text-xs text-gray-500">
                  {direction === 'rtl' ? 'التاريخ' : 'Date'}
                </div>
              </div>
              <div className="text-white font-medium">
                {transaction.timestamp}
              </div>
            </div>
          </div>
        </MobileAppCard>
      </div>

      {/* Proof of Payment */}
      <div className="px-4 mb-4">
        <MobileAppCard gradient>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#8b5cf6]" />
              <div className="text-white font-semibold">
                {direction === 'rtl' ? 'إثبات الدفع' : 'Proof of Payment'}
              </div>
            </div>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowProof(!showProof)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
            >
              <Eye className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-300">
                {direction === 'rtl' ? 'عرض' : 'View'}
              </span>
            </motion.button>
          </div>

          {showProof ? (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="rounded-2xl bg-gradient-to-br from-[#1a1d23] to-[#252932] border border-white/10 p-8 flex items-center justify-center"
            >
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-4">
                  <ImageIcon className="w-10 h-10 text-gray-500" />
                </div>
                <p className="text-gray-400 text-sm">
                  {direction === 'rtl' ? 'إثبات الدفع سيتم عرضه هنا' : 'Payment proof will be displayed here'}
                </p>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="mt-4 px-4 py-2 rounded-lg bg-[#8b5cf6]/20 border border-[#8b5cf6]/30 text-[#8b5cf6] text-sm font-medium hover:bg-[#8b5cf6]/30 transition-colors"
                >
                  <Download className="w-4 h-4 inline-block mr-2" />
                  {direction === 'rtl' ? 'تحميل' : 'Download'}
                </motion.button>
              </div>
            </motion.div>
          ) : (
            <div className="rounded-2xl bg-gradient-to-br from-[#1a1d23] to-[#252932] border border-white/10 aspect-video flex items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                <ImageIcon className="w-8 h-8 text-gray-500" />
              </div>
            </div>
          )}
        </MobileAppCard>
      </div>

      {/* Notes */}
      {transaction.notes && (
        <div className="px-4 mb-4">
          <MobileAppCard gradient>
            <div className="flex items-center gap-2 mb-3">
              <FileText className="w-5 h-5 text-[#8b5cf6]" />
              <div className="text-white font-semibold">
                {direction === 'rtl' ? 'ملاحظات' : 'Notes'}
              </div>
            </div>
            <div className="p-3 rounded-xl bg-white/5 border border-white/10">
              <p className="text-gray-300 text-sm leading-relaxed">
                {transaction.notes}
              </p>
            </div>
          </MobileAppCard>
        </div>
      )}

      {/* Audit Trail */}
      <div className="px-4 mb-4">
        <MobileAppCard gradient>
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-[#8b5cf6]" />
            <div className="text-white font-semibold">
              {direction === 'rtl' ? 'سجل التدقيق' : 'Audit Trail'}
            </div>
          </div>

          {auditTrail.length > 0 ? (
            <div className="space-y-3">
              {auditTrail.map((entry, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/10"
                >
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-medium text-sm mb-1">
                      {entry.action}
                    </div>
                    <div className="text-gray-400 text-xs mb-1">
                      {entry.details}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <User className="w-3 h-3" />
                      <span>{entry.user}</span>
                      <span>•</span>
                      <span>{entry.timestamp}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center">
              <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-3">
                <FileText className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400 text-sm">
                {direction === 'rtl' 
                  ? 'لا توجد إدخالات تدقيق لهذه المعاملة.'
                  : 'No audit entries for this transaction.'
                }
              </p>
            </div>
          )}
        </MobileAppCard>
      </div>

      {/* Action Buttons */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-2 gap-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            className="py-3.5 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30 text-white font-medium hover:from-[#8b5cf6]/30 hover:to-[#3b82f6]/30 transition-all flex items-center justify-center gap-2"
          >
            <Download className="w-5 h-5" />
            <span>{direction === 'rtl' ? 'تحميل' : 'Download'}</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.97 }}
            className="py-3.5 rounded-2xl bg-white/5 border border-white/10 text-white font-medium hover:bg-white/10 transition-all flex items-center justify-center gap-2"
          >
            <Share2 className="w-5 h-5" />
            <span>{direction === 'rtl' ? 'مشاركة' : 'Share'}</span>
          </motion.button>
        </div>
      </div>

      {/* Additional Actions */}
      <div className="px-4 mb-8">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate(`/mobile/customers/CUST-001`)}
          className="w-full py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 active:bg-white/15 transition-all flex items-center justify-center gap-2 group"
        >
          <User className="w-4 h-4 text-gray-400 group-hover:text-[#8b5cf6] transition-colors" />
          <span className="text-sm text-gray-300 group-hover:text-white transition-colors">
            {direction === 'rtl' ? 'عرض ملف العميل' : 'View Customer Profile'}
          </span>
          <ChevronRight className={`w-4 h-4 text-gray-400 group-hover:text-[#8b5cf6] transition-colors ${direction === 'rtl' ? 'rotate-180' : ''}`} />
        </motion.button>
      </div>
    </div>
  );
}