import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { useState } from 'react';
import { 
  Shield, 
  CheckCircle, 
  XCircle,
  Save,
  User,
  Eye,
  Edit,
  Trash2,
  Plus
} from 'lucide-react';

interface Permission {
  id: string;
  name: string;
  description: string;
  category: string;
}

interface Role {
  id: string;
  name: string;
  description: string;
  color: string;
  permissions: string[];
}

export function EditRole() {
  const { t } = useLanguage();
  const [selectedRole, setSelectedRole] = useState<string>('admin');

  const roles: Role[] = [
    {
      id: 'owner',
      name: 'Owner',
      description: 'Full system access and control',
      color: 'from-[#ef4444] to-[#dc2626]',
      permissions: ['all']
    },
    {
      id: 'admin',
      name: 'Admin',
      description: 'Administrative access with restrictions',
      color: 'from-[#8b5cf6] to-[#7c3aed]',
      permissions: ['dashboard.view', 'transactions.view', 'transactions.edit', 'merchants.view', 'merchants.edit', 'users.view', 'users.edit']
    },
    {
      id: 'finance',
      name: 'Finance',
      description: 'Financial data and reports access',
      color: 'from-[#f59e0b] to-[#d97706]',
      permissions: ['dashboard.view', 'transactions.view', 'reports.view', 'settlement.view', 'payouts.view']
    },
    {
      id: 'operations',
      name: 'Operations',
      description: 'Day-to-day operations management',
      color: 'from-[#3b82f6] to-[#2563eb]',
      permissions: ['dashboard.view', 'transactions.view', 'merchants.view', 'wallets.view', 'wallets.edit']
    },
    {
      id: 'merchant',
      name: 'Merchant',
      description: 'Limited merchant portal access',
      color: 'from-[#10b981] to-[#059669]',
      permissions: ['dashboard.view', 'transactions.view', 'reports.view']
    },
    {
      id: 'viewer',
      name: 'Viewer',
      description: 'Read-only access to reports',
      color: 'from-[#64748b] to-[#475569]',
      permissions: ['dashboard.view', 'reports.view']
    }
  ];

  const permissions: Permission[] = [
    { id: 'dashboard.view', name: 'View Dashboard', description: 'Access to main dashboard', category: 'Dashboard' },
    { id: 'transactions.view', name: 'View Transactions', description: 'View transaction history', category: 'Transactions' },
    { id: 'transactions.edit', name: 'Edit Transactions', description: 'Modify transaction details', category: 'Transactions' },
    { id: 'transactions.refund', name: 'Refund Transactions', description: 'Process refunds', category: 'Transactions' },
    { id: 'merchants.view', name: 'View Merchants', description: 'View merchant list', category: 'Merchants' },
    { id: 'merchants.edit', name: 'Edit Merchants', description: 'Modify merchant details', category: 'Merchants' },
    { id: 'merchants.delete', name: 'Delete Merchants', description: 'Remove merchants', category: 'Merchants' },
    { id: 'wallets.view', name: 'View Wallets', description: 'View wallet information', category: 'Wallets' },
    { id: 'wallets.edit', name: 'Edit Wallets', description: 'Modify wallet settings', category: 'Wallets' },
    { id: 'users.view', name: 'View Users', description: 'View user list', category: 'Users' },
    { id: 'users.edit', name: 'Edit Users', description: 'Modify user details', category: 'Users' },
    { id: 'users.delete', name: 'Delete Users', description: 'Remove users', category: 'Users' },
    { id: 'reports.view', name: 'View Reports', description: 'Access reports and analytics', category: 'Reports' },
    { id: 'settlement.view', name: 'View Settlement', description: 'Access settlement data', category: 'Finance' },
    { id: 'payouts.view', name: 'View Payouts', description: 'Access payout information', category: 'Finance' },
    { id: 'settings.edit', name: 'Edit Settings', description: 'Modify system settings', category: 'Settings' }
  ];

  const currentRole = roles.find(r => r.id === selectedRole);
  const [activePermissions, setActivePermissions] = useState<string[]>(currentRole?.permissions || []);

  const togglePermission = (permissionId: string) => {
    if (selectedRole === 'owner') return; // Owner has all permissions
    
    setActivePermissions(prev => 
      prev.includes(permissionId)
        ? prev.filter(p => p !== permissionId)
        : [...prev, permissionId]
    );
  };

  const hasPermission = (permissionId: string) => {
    if (currentRole?.permissions.includes('all')) return true;
    return activePermissions.includes(permissionId);
  };

  const groupedPermissions = permissions.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {} as Record<string, Permission[]>);

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-white mb-2">Edit Roles & Permissions</h1>
        <p className="text-gray-400">Configure role-based access control</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Roles Sidebar */}
        <div className="lg:col-span-1">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <h2 className="text-lg font-semibold text-white mb-4">Roles</h2>
            <div className="space-y-2">
              {roles.map(role => (
                <button
                  key={role.id}
                  onClick={() => {
                    setSelectedRole(role.id);
                    setActivePermissions(role.permissions);
                  }}
                  className={`w-full p-4 rounded-xl text-left transition-all ${
                    selectedRole === role.id
                      ? 'bg-gradient-to-r ' + role.color + ' text-white shadow-lg'
                      : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-1">
                    <Shield className="w-5 h-5" />
                    <span className="font-semibold">{role.name}</span>
                  </div>
                  <p className={`text-xs ${selectedRole === role.id ? 'text-white/70' : 'text-gray-500'}`}>
                    {role.description}
                  </p>
                </button>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full mt-4 px-4 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Create Role
            </motion.button>
          </motion.div>
        </div>

        {/* Permissions Panel */}
        <div className="lg:col-span-3">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            {/* Role Header */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${currentRole?.color} flex items-center justify-center`}>
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold text-white">{currentRole?.name}</h2>
                  <p className="text-gray-400">{currentRole?.description}</p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#10b981] to-[#059669] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-green-500/30 transition-shadow"
              >
                <Save className="w-5 h-5" />
                Save Changes
              </motion.button>
            </div>

            {/* Permissions Grid */}
            <div className="space-y-6">
              {Object.entries(groupedPermissions).map(([category, perms]) => (
                <div key={category}>
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <div className="w-1 h-6 bg-gradient-to-b from-[#8b5cf6] to-[#3b82f6] rounded-full" />
                    {category}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {perms.map(permission => {
                      const isActive = hasPermission(permission.id);
                      const isDisabled = selectedRole === 'owner';
                      
                      return (
                        <motion.button
                          key={permission.id}
                          onClick={() => togglePermission(permission.id)}
                          disabled={isDisabled}
                          whileHover={!isDisabled ? { scale: 1.02 } : {}}
                          whileTap={!isDisabled ? { scale: 0.98 } : {}}
                          className={`p-4 rounded-xl text-left transition-all ${
                            isActive
                              ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 border-2 border-[#8b5cf6]'
                              : 'bg-white/5 border-2 border-white/10 hover:border-white/20'
                          } ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                          <div className="flex items-start gap-3">
                            <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 ${
                              isActive ? 'bg-[#8b5cf6]' : 'bg-white/10'
                            }`}>
                              {isActive ? (
                                <CheckCircle className="w-4 h-4 text-white" />
                              ) : (
                                <XCircle className="w-4 h-4 text-gray-500" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className={`font-semibold mb-1 ${isActive ? 'text-white' : 'text-gray-400'}`}>
                                {permission.name}
                              </h4>
                              <p className={`text-xs ${isActive ? 'text-gray-300' : 'text-gray-500'}`}>
                                {permission.description}
                              </p>
                            </div>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="mt-8 p-6 rounded-xl bg-gradient-to-r from-[#8b5cf6]/10 to-[#3b82f6]/10 border border-[#8b5cf6]/30">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-white font-semibold mb-1">Permissions Summary</h4>
                  <p className="text-sm text-gray-400">
                    {selectedRole === 'owner' 
                      ? 'All permissions granted (Owner role)'
                      : `${activePermissions.length} of ${permissions.length} permissions enabled`
                    }
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-white">
                    {selectedRole === 'owner' ? '100' : Math.round((activePermissions.length / permissions.length) * 100)}%
                  </p>
                  <p className="text-sm text-gray-400">Coverage</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
