import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Code,
  Copy,
  ExternalLink,
  Check,
  FileCode,
  Settings,
  Eye
} from 'lucide-react';
import { useState } from 'react';

const codeSnippets = {
  html: `<!-- OnTarget PSP Payment Widget -->
<div id="ontarget-payment"></div>
<script src="https://cdn.ontarget.io/widget.js"></script>
<script>
  OnTarget.init({
    apiKey: 'pk_live_51H8x...',
    amount: 2999,
    currency: 'USD',
    elementId: 'ontarget-payment',
    onSuccess: function(payment) {
      console.log('Payment successful:', payment);
    },
    onError: function(error) {
      console.error('Payment failed:', error);
    }
  });
</script>`,

  react: `import { OnTargetWidget } from '@ontarget/react';

function CheckoutPage() {
  const handleSuccess = (payment) => {
    console.log('Payment successful:', payment);
  };

  const handleError = (error) => {
    console.error('Payment failed:', error);
  };

  return (
    <OnTargetWidget
      apiKey="pk_live_51H8x..."
      amount={2999}
      currency="USD"
      onSuccess={handleSuccess}
      onError={handleError}
      theme="dark"
    />
  );
}`,

  javascript: `// Initialize OnTarget Payment Gateway
const ontarget = new OnTarget('pk_live_51H8x...');

// Create payment session
ontarget.createPayment({
  amount: 2999,
  currency: 'USD',
  description: 'Premium Subscription',
  metadata: {
    orderId: 'ORD-12345',
    customerId: 'CUST-67890'
  }
}).then(payment => {
  console.log('Payment created:', payment);
  
  // Redirect to checkout
  ontarget.redirectToCheckout({
    sessionId: payment.id
  });
}).catch(error => {
  console.error('Error:', error);
});`
};

export function EmbedIntegration() {
  const [selectedLanguage, setSelectedLanguage] = useState<'html' | 'react' | 'javascript'>('html');
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(codeSnippets[selectedLanguage]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">Embed Integration</h1>
        <p className="text-gray-400">Integrate payment widgets into your website</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Integration Preview */}
        <GlassCard className="p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Widget Preview</h2>
            <div className="flex items-center gap-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
              >
                <Settings className="w-5 h-5 text-gray-400" />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
              >
                <Eye className="w-5 h-5 text-gray-400" />
              </motion.button>
            </div>
          </div>

          {/* Widget Preview Frame */}
          <div className="rounded-2xl bg-gradient-to-br from-white/10 to-white/5 border border-white/10 p-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Widget Header */}
              <div className="text-center">
                <h3 className="text-2xl font-semibold text-white mb-2">Secure Checkout</h3>
                <p className="text-sm text-gray-400">Complete your purchase</p>
              </div>

              {/* Order Summary */}
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Premium Plan (Annual)</span>
                  <span className="text-sm font-medium text-white">$299.00</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-400">Tax</span>
                  <span className="text-sm font-medium text-white">$29.90</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  <span className="text-sm font-semibold text-white">Total</span>
                  <span className="text-xl font-bold text-white">$328.90</span>
                </div>
              </div>

              {/* Payment Form */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Email</label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 text-sm"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Card Information</label>
                  <input
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 text-sm"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="MM / YY"
                      className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 text-sm"
                    />
                    <input
                      type="text"
                      placeholder="CVC"
                      className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 text-sm"
                    />
                  </div>
                </div>

                <motion.button
                  className="w-full py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold text-sm"
                  whileHover={{ scale: 1.02, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
                  whileTap={{ scale: 0.98 }}
                >
                  Pay $328.90
                </motion.button>

                <p className="text-xs text-center text-gray-400">
                  Powered by <span className="text-[#8b5cf6] font-medium">OnTarget PSP</span>
                </p>
              </div>
            </motion.div>
          </div>

          <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-[#6ee7b7]/10 to-[#06b6d4]/10 border border-[#6ee7b7]/20">
            <div className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#6ee7b7] flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-white mb-1">Widget Features</h4>
                <ul className="text-xs text-gray-300 space-y-1">
                  <li>• Fully responsive and mobile-optimized</li>
                  <li>• Customizable theme and branding</li>
                  <li>• PCI DSS compliant security</li>
                  <li>• Real-time validation and error handling</li>
                </ul>
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Code Integration */}
        <GlassCard className="p-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Integration Code</h2>
            <motion.button
              onClick={copyToClipboard}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white text-sm font-medium"
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
              whileTap={{ scale: 0.95 }}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy Code
                </>
              )}
            </motion.button>
          </div>

          {/* Language Tabs */}
          <div className="flex gap-2 mb-4">
            {(['html', 'react', 'javascript'] as const).map((lang) => (
              <motion.button
                key={lang}
                onClick={() => setSelectedLanguage(lang)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedLanguage === lang
                    ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {lang.toUpperCase()}
              </motion.button>
            ))}
          </div>

          {/* Code Block */}
          <div className="relative">
            <pre className="p-4 rounded-xl bg-[#0d0e11] border border-white/10 overflow-x-auto">
              <code className="text-sm text-gray-300 font-mono leading-relaxed">
                {codeSnippets[selectedLanguage]}
              </code>
            </pre>
          </div>

          {/* Integration Steps */}
          <div className="mt-6 space-y-4">
            <h3 className="text-lg font-semibold text-white">Integration Steps</h3>
            
            <div className="space-y-3">
              {[
                { step: 1, title: 'Get your API Keys', description: 'Navigate to Settings → API Keys to retrieve your public key' },
                { step: 2, title: 'Install the SDK', description: 'Add the OnTarget SDK to your project using npm or CDN' },
                { step: 3, title: 'Add the widget code', description: 'Copy and paste the integration code into your checkout page' },
                { step: 4, title: 'Test the integration', description: 'Use test mode to verify payment flow works correctly' }
              ].map((item) => (
                <motion.div
                  key={item.step}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: item.step * 0.1 }}
                  className="flex gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-white font-bold text-sm">
                    {item.step}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-400">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Resources */}
          <div className="mt-6 pt-6 border-t border-white/10">
            <h3 className="text-lg font-semibold text-white mb-4">Resources</h3>
            <div className="space-y-2">
              {[
                { name: 'Full Documentation', icon: FileCode },
                { name: 'API Reference', icon: Code },
                { name: 'Live Examples', icon: ExternalLink }
              ].map((resource) => {
                const Icon = resource.icon;
                return (
                  <motion.button
                    key={resource.name}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all text-left"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-[#8b5cf6]" />
                      <span className="text-sm text-white">{resource.name}</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-gray-400" />
                  </motion.button>
                );
              })}
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Configuration Options */}
      <GlassCard className="p-8">
        <h2 className="text-xl font-semibold text-white mb-6">Widget Configuration</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-sm text-gray-300">Theme</label>
            <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20">
              <option>Dark</option>
              <option>Light</option>
              <option>Auto</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-300">Primary Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                defaultValue="#8b5cf6"
                className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
              />
              <input
                type="text"
                defaultValue="#8b5cf6"
                className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-300">Border Radius</label>
            <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20">
              <option>Small (4px)</option>
              <option>Medium (8px)</option>
              <option>Large (16px)</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-300">Payment Methods</label>
            <div className="flex flex-wrap gap-2">
              {['Cards', 'Bank', 'Wallet'].map((method) => (
                <label
                  key={method}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                >
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-sm text-white">{method}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-300">Language</label>
            <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20">
              <option>English</option>
              <option>Spanish</option>
              <option>French</option>
              <option>German</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-300">Button Text</label>
            <input
              type="text"
              defaultValue="Pay Now"
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
            />
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end">
          <motion.button
            className="px-8 py-3 rounded-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-semibold"
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
            whileTap={{ scale: 0.95 }}
          >
            Update Configuration
          </motion.button>
        </div>
      </GlassCard>
    </div>
  );
}
