import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  User, 
  DollarSign,
  AlertTriangle,
  CheckSquare,
  FileText
} from 'lucide-react';
import { useState } from 'react';

interface ApprovalRequest {
  id: string;
  type: 'merchant' | 'withdrawal' | 'config' | 'user';
  title: string;
  description: string;
  requestedBy: string;
  amount?: string;
  date: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'approved' | 'rejected';
}

const mockApprovals: ApprovalRequest[] = [
  {
    id: 'APR-001',
    type: 'merchant',
    title: 'New Merchant Registration',
    description: 'TechStore Electronics - E-commerce platform',
    requestedBy: 'Ahmed Hassan',
    date: '2026-03-17 09:30',
    priority: 'high',
    status: 'pending'
  },
  {
    id: 'APR-002',
    type: 'withdrawal',
    title: 'Large Withdrawal Request',
    description: 'Merchant payout to SuperMart',
    requestedBy: 'Sarah Mohamed',
    amount: '$45,000',
    date: '2026-03-17 10:15',
    priority: 'high',
    status: 'pending'
  },
  {
    id: 'APR-003',
    type: 'config',
    title: 'Payment Method Configuration',
    description: 'Enable Binance Pay for all merchants',
    requestedBy: 'Omar Ali',
    date: '2026-03-17 11:00',
    priority: 'medium',
    status: 'pending'
  },
  {
    id: 'APR-004',
    type: 'user',
    title: 'New Admin User Access',
    description: 'Grant admin privileges to Mona Ibrahim',
    requestedBy: 'Khaled Youssef',
    date: '2026-03-16 16:45',
    priority: 'medium',
    status: 'approved'
  },
  {
    id: 'APR-005',
    type: 'withdrawal',
    title: 'Settlement Request',
    description: 'Monthly settlement to MegaShop',
    requestedBy: 'Fatima Nasser',
    amount: '$28,500',
    date: '2026-03-16 14:20',
    priority: 'low',
    status: 'approved'
  }
];

export function Approvals() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const filteredApprovals = filter === 'all' 
    ? mockApprovals 
    : mockApprovals.filter(a => a.status === filter);

  const pendingCount = mockApprovals.filter(a => a.status === 'pending').length;

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'merchant': return User;
      case 'withdrawal': return DollarSign;
      case 'config': return FileText;
      case 'user': return User;
      default: return CheckSquare;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'from-red-500 to-orange-500';
      case 'medium': return 'from-yellow-500 to-amber-500';
      case 'low': return 'from-blue-500 to-cyan-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'approved': return 'text-green-400';
      case 'rejected': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-white mb-2">Approvals Center</h1>
            <p className="text-gray-400">Review and manage pending approval requests</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30">
              <p className="text-sm text-gray-400">Pending Requests</p>
              <p className="text-2xl font-bold text-white">{pendingCount}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Requests', value: mockApprovals.length, icon: CheckSquare, color: 'from-[#8b5cf6] to-[#7c3aed]' },
          { label: 'Pending', value: pendingCount, icon: Clock, color: 'from-[#f59e0b] to-[#d97706]' },
          { label: 'Approved Today', value: 2, icon: CheckCircle, color: 'from-[#10b981] to-[#059669]' },
          { label: 'High Priority', value: 2, icon: AlertTriangle, color: 'from-[#ef4444] to-[#dc2626]' }
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {['all', 'pending', 'approved', 'rejected'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status as any)}
            className={`px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap ${
              filter === status
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-violet-500/30'
                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {/* Approvals List */}
      <div className="space-y-4">
        {filteredApprovals.map((approval, index) => {
          const TypeIcon = getTypeIcon(approval.type);
          
          return (
            <motion.div
              key={approval.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden hover:border-white/20 transition-all group"
            >
              {/* Priority Indicator */}
              <div className={`absolute top-0 left-0 w-1 h-full bg-gradient-to-b ${getPriorityColor(approval.priority)}`} />
              
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 ml-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getPriorityColor(approval.priority)} flex items-center justify-center flex-shrink-0`}>
                    <TypeIcon className="w-6 h-6 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{approval.title}</h3>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${getStatusColor(approval.status)} bg-white/10`}>
                        {approval.status}
                      </span>
                    </div>
                    <p className="text-gray-400 mb-2">{approval.description}</p>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {approval.requestedBy}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {approval.date}
                      </span>
                      {approval.amount && (
                        <span className="flex items-center gap-1 text-green-400 font-medium">
                          <DollarSign className="w-4 h-4" />
                          {approval.amount}
                        </span>
                      )}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        approval.priority === 'high' ? 'bg-red-500/20 text-red-300' :
                        approval.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                        'bg-blue-500/20 text-blue-300'
                      }`}>
                        {approval.priority} priority
                      </span>
                    </div>
                  </div>
                </div>

                {approval.status === 'pending' && (
                  <div className="flex items-center gap-2">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#10b981] to-[#059669] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-green-500/30 transition-shadow"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Approve
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ef4444] to-[#dc2626] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-red-500/30 transition-shadow"
                    >
                      <XCircle className="w-4 h-4" />
                      Reject
                    </motion.button>
                  </div>
                )}

                {approval.status === 'approved' && (
                  <div className="flex items-center gap-2 text-green-400">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">Approved</span>
                  </div>
                )}

                {approval.status === 'rejected' && (
                  <div className="flex items-center gap-2 text-red-400">
                    <XCircle className="w-5 h-5" />
                    <span className="font-medium">Rejected</span>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
