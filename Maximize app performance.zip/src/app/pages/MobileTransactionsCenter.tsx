import { motion } from 'motion/react';
import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  Download,
  RefreshCw,
  Search,
  SlidersHorizontal,
  CheckCircle2,
  Clock,
  XCircle,
  AlertCircle,
  ChevronRight,
  Eye,
  Bitcoin
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { MobileAppCard } from '../components/MobileAppCard';

interface Transaction {
  id: string;
  reference: string;
  name: string;
  phone: string;
  currency: string;
  amount: number;
  paymentMethod: string;
  country: string;
  countryFlag?: string;
  status: 'completed' | 'pending' | 'failed' | 'review';
  timestamp: string;
  date: string;
}

const mockTransactions: Transaction[] = [
  {
    id: 'TXN-2024-88421',
    reference: 'TXN-2024-88421',
    name: 'Ahmed Hassan',
    phone: '+20 100 123 4567',
    currency: 'EGP',
    amount: 5200,
    paymentMethod: 'Vodafone Cash',
    country: 'Egypt',
    countryFlag: 'egypt',
    status: 'completed',
    timestamp: '2024-03-15 14:32',
    date: '2024-03-15'
  },
  {
    id: 'TXN-2024-88420',
    reference: 'TXN-2024-88420',
    name: 'Sara Al-Rashid',
    phone: '+966 50 234 5678',
    currency: 'SAR',
    amount: 1800,
    paymentMethod: 'STC Pay',
    country: 'Saudi Arabia',
    countryFlag: 'saudi',
    status: 'pending',
    timestamp: '2024-03-15 14:28',
    date: '2024-03-15'
  },
  {
    id: 'TXN-2024-88419',
    reference: 'TXN-2024-88419',
    name: 'Mohamed Ali',
    phone: '+971 50 345 6789',
    currency: 'AED',
    amount: 3400,
    paymentMethod: 'Bank Transfer',
    country: 'UAE',
    countryFlag: 'uae',
    status: 'completed',
    timestamp: '2024-03-15 13:45',
    date: '2024-03-15'
  },
  {
    id: 'TXN-2024-88418',
    reference: 'TXN-2024-88418',
    name: 'Layla Ibrahim',
    phone: '+20 111 456 7890',
    currency: 'EGP',
    amount: 2100,
    paymentMethod: 'Instapay',
    country: 'Egypt',
    countryFlag: 'egypt',
    status: 'failed',
    timestamp: '2024-03-15 12:20',
    date: '2024-03-15'
  },
  {
    id: 'TXN-2024-88417',
    reference: 'TXN-2024-88417',
    name: 'Fatima Al-Zahra',
    phone: '+966 55 567 8901',
    currency: 'SAR',
    amount: 4200,
    paymentMethod: 'Mada Card',
    country: 'Saudi Arabia',
    countryFlag: 'saudi',
    status: 'review',
    timestamp: '2024-03-15 11:10',
    date: '2024-03-15'
  },
  {
    id: 'TXN-2024-88416',
    reference: 'TXN-2024-88416',
    name: 'Youssef Khaled',
    phone: '+20 122 678 9012',
    currency: 'EGP',
    amount: 1550,
    paymentMethod: 'Vodafone Cash',
    country: 'Egypt',
    countryFlag: 'egypt',
    status: 'completed',
    timestamp: '2024-03-15 10:05',
    date: '2024-03-15'
  },
  {
    id: 'TXN-2024-88415',
    reference: 'TXN-2024-88415',
    name: 'Noor Abdullah',
    phone: '+971 52 789 0123',
    currency: 'AED',
    amount: 2800,
    paymentMethod: 'Apple Pay',
    country: 'UAE',
    countryFlag: 'uae',
    status: 'completed',
    timestamp: '2024-03-14 18:22',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88414',
    reference: 'TXN-2024-88414',
    name: 'Omar Mansour',
    phone: '+966 54 890 1234',
    currency: 'SAR',
    amount: 5600,
    paymentMethod: 'STC Pay',
    country: 'Saudi Arabia',
    countryFlag: 'saudi',
    status: 'pending',
    timestamp: '2024-03-14 16:45',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88413',
    reference: 'TXN-2024-88413',
    name: 'Mariam Hassan',
    phone: '+20 100 901 2345',
    currency: 'EGP',
    amount: 3200,
    paymentMethod: 'Credit Card',
    country: 'Egypt',
    countryFlag: 'egypt',
    status: 'completed',
    timestamp: '2024-03-14 15:10',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88412',
    reference: 'TXN-2024-88412',
    name: 'Ali Mohammed',
    phone: '+971 50 012 3456',
    currency: 'AED',
    amount: 4100,
    paymentMethod: 'Bank Transfer',
    country: 'UAE',
    countryFlag: 'uae',
    status: 'review',
    timestamp: '2024-03-14 14:30',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88411',
    reference: 'TXN-2024-88411',
    name: 'Huda Saleh',
    phone: '+966 53 123 4567',
    currency: 'SAR',
    amount: 2700,
    paymentMethod: 'Mada Card',
    country: 'Saudi Arabia',
    countryFlag: 'saudi',
    status: 'completed',
    timestamp: '2024-03-14 13:15',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88410',
    reference: 'TXN-2024-88410',
    name: 'Khaled Ahmed',
    phone: '+20 111 234 5678',
    currency: 'EGP',
    amount: 1900,
    paymentMethod: 'Vodafone Cash',
    country: 'Egypt',
    countryFlag: 'egypt',
    status: 'failed',
    timestamp: '2024-03-14 11:50',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88409',
    reference: 'TXN-2024-88409',
    name: 'Aisha Mahmoud',
    phone: '+971 55 345 6789',
    currency: 'AED',
    amount: 3900,
    paymentMethod: 'Apple Pay',
    country: 'UAE',
    countryFlag: 'uae',
    status: 'completed',
    timestamp: '2024-03-14 10:25',
    date: '2024-03-14'
  },
  {
    id: 'TXN-2024-88408',
    reference: 'TXN-2024-88408',
    name: 'Hassan Ibrahim',
    phone: '+966 50 456 7890',
    currency: 'SAR',
    amount: 5100,
    paymentMethod: 'STC Pay',
    country: 'Saudi Arabia',
    countryFlag: 'saudi',
    status: 'completed',
    timestamp: '2024-03-13 17:40',
    date: '2024-03-13'
  },
  {
    id: 'TXN-2024-88407',
    reference: 'TXN-2024-88407',
    name: 'Salma Youssef',
    phone: '+20 122 567 8901',
    currency: 'EGP',
    amount: 2400,
    paymentMethod: 'Instapay',
    country: 'Egypt',
    countryFlag: 'egypt',
    status: 'pending',
    timestamp: '2024-03-13 16:15',
    date: '2024-03-13'
  },
];

export default function MobileTransactionsCenter() {
  const navigate = useNavigate();
  const { t, direction } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'completed' | 'pending' | 'failed' | 'review'>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedTransactions, setSelectedTransactions] = useState<string[]>([]);

  // Calculate stats
  const stats = {
    total: mockTransactions.length,
    completed: mockTransactions.filter(t => t.status === 'completed').length,
    pending: mockTransactions.filter(t => t.status === 'pending').length,
    failed: mockTransactions.filter(t => t.status === 'failed').length,
    review: mockTransactions.filter(t => t.status === 'review').length,
    volume: mockTransactions
      .filter(t => t.currency === 'EGP')
      .reduce((sum, t) => sum + t.amount, 0) / 1000
  };

  // Filter transactions
  const filteredTransactions = mockTransactions.filter(transaction => {
    const matchesSearch = 
      transaction.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.phone.includes(searchQuery) ||
      transaction.reference.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = activeFilter === 'all' || transaction.status === activeFilter;
    
    return matchesSearch && matchesFilter;
  });

  const getStatusConfig = (status: Transaction['status']) => {
    const configs = {
      completed: {
        icon: CheckCircle2,
        color: 'text-green-400',
        bgColor: 'bg-green-400/10',
        label: t('transactions.completed'),
        labelAr: 'مكتمل'
      },
      pending: {
        icon: Clock,
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-400/10',
        label: t('transactions.pending'),
        labelAr: 'قيد الانتظار'
      },
      failed: {
        icon: XCircle,
        color: 'text-red-400',
        bgColor: 'bg-red-400/10',
        label: t('transactions.failed'),
        labelAr: 'فشل'
      },
      review: {
        icon: AlertCircle,
        color: 'text-blue-400',
        bgColor: 'bg-blue-400/10',
        label: 'Review/Hold',
        labelAr: 'مراجعة'
      }
    };
    return configs[status];
  };

  const getCountryFlag = (country: string) => {
    const flags: Record<string, string> = {
      'egypt': '🇪🇬',
      'saudi': '🇸🇦',
      'uae': '🇦🇪'
    };
    return flags[country] || '🌍';
  };

  const toggleTransaction = (id: string) => {
    setSelectedTransactions(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  return (
    <div className="pb-4">
      {/* Header Section */}
      <div className="px-4 pt-4 pb-6">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
              <Bitcoin className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">
                {direction === 'rtl' ? 'معاملات PSP' : 'Txs psp'}
              </h1>
              <p className="text-sm text-gray-400 mt-0.5">
                {direction === 'rtl' 
                  ? `${stats.total} معاملة • مدفوعات P2P متعددة العملات`
                  : `${stats.total} transactions • Multi-currency P2P payments`
                }
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="p-2.5 rounded-xl bg-white/5 border border-white/10 active:bg-white/10"
            >
              <Download className="w-5 h-5 text-gray-300" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="p-2.5 rounded-xl bg-white/5 border border-white/10 active:bg-white/10"
            >
              <RefreshCw className="w-5 h-5 text-gray-300" />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-3 gap-3 mb-3">
          <motion.div
            whileTap={{ scale: 0.97 }}
            onClick={() => setActiveFilter('all')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 border-[#8b5cf6]/50'
                : 'bg-white/5 border-white/10'
            }`}
          >
            <div className="text-4xl font-bold text-white mb-1">{stats.total}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">
              {direction === 'rtl' ? 'الإجمالي' : 'TOTAL'}
            </div>
          </motion.div>

          <motion.div
            whileTap={{ scale: 0.97 }}
            onClick={() => setActiveFilter('completed')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              activeFilter === 'completed'
                ? 'bg-gradient-to-br from-green-400/20 to-green-500/20 border-green-400/50'
                : 'bg-white/5 border-white/10'
            }`}
          >
            <div className="text-4xl font-bold text-green-400 mb-1">{stats.completed}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">
              {direction === 'rtl' ? 'مكتمل' : 'COMPLETED'}
            </div>
          </motion.div>

          <motion.div
            whileTap={{ scale: 0.97 }}
            onClick={() => setActiveFilter('pending')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              activeFilter === 'pending'
                ? 'bg-gradient-to-br from-yellow-400/20 to-yellow-500/20 border-yellow-400/50'
                : 'bg-white/5 border-white/10'
            }`}
          >
            <div className="text-4xl font-bold text-yellow-400 mb-1">{stats.pending}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">
              {direction === 'rtl' ? 'معلق' : 'PENDING'}
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <motion.div
            whileTap={{ scale: 0.97 }}
            onClick={() => setActiveFilter('failed')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              activeFilter === 'failed'
                ? 'bg-gradient-to-br from-red-400/20 to-red-500/20 border-red-400/50'
                : 'bg-white/5 border-white/10'
            }`}
          >
            <div className="text-4xl font-bold text-red-400 mb-1">{stats.failed}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">
              {direction === 'rtl' ? 'فشل' : 'FAILED'}
            </div>
          </motion.div>

          <motion.div
            whileTap={{ scale: 0.97 }}
            onClick={() => setActiveFilter('review')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              activeFilter === 'review'
                ? 'bg-gradient-to-br from-blue-400/20 to-blue-500/20 border-blue-400/50'
                : 'bg-white/5 border-white/10'
            }`}
          >
            <div className="text-4xl font-bold text-blue-400 mb-1">{stats.review}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">
              {direction === 'rtl' ? 'مراجعة' : 'REVIEW/HOLD'}
            </div>
          </motion.div>

          <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-400/20 to-purple-500/20 border border-purple-400/50">
            <div className="text-2xl font-bold text-purple-300 mb-1">{stats.volume.toFixed(1)}K</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">
              {direction === 'rtl' ? 'حجم EGP' : 'EGP VOLUME'}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Filters */}
      <div className="px-4 mb-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-white/10 flex-shrink-0">
            <span className="text-sm text-gray-300">🇪🇬</span>
            <span className="text-sm text-gray-300">Egypt — Today</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-white/10 flex-shrink-0">
            <AlertCircle className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-gray-300">
              {direction === 'rtl' ? 'مراجعة معلقة' : 'Pending Review'}
            </span>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-white/10 flex-shrink-0">
            <Bitcoin className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-gray-300">
              {direction === 'rtl' ? 'معاملات العملات المشفرة' : 'Crypto Transactions'}
            </span>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="px-4 mb-4">
        <div className="flex items-center gap-2">
          <div className="flex-1 relative">
            <Search className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'right-3' : 'left-3'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={direction === 'rtl' ? 'ابحث بالهاتف، البريد الإلكتروني، الرقم المرجعي...' : 'Search by phone, email, ID or ref...'}
              className={`w-full h-12 ${direction === 'rtl' ? 'pr-10 pl-4' : 'pl-10 pr-4'} rounded-2xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]/50 focus:bg-white/10 transition-all`}
            />
          </div>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowFilters(!showFilters)}
            className="h-12 px-4 rounded-2xl bg-white/5 border border-white/10 active:bg-white/10 flex items-center gap-2"
          >
            <SlidersHorizontal className="w-5 h-5 text-gray-300" />
            <span className="text-sm text-gray-300">
              {direction === 'rtl' ? 'تصفية' : 'Filter'}
            </span>
          </motion.button>
        </div>
      </div>

      {/* Transactions List */}
      <div className="px-4 space-y-3">
        {filteredTransactions.map((transaction, index) => {
          const statusConfig = getStatusConfig(transaction.status);
          const StatusIcon = statusConfig.icon;

          return (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03 }}
            >
              <MobileAppCard gradient>
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex-shrink-0">
                    <input
                      type="checkbox"
                      className="w-5 h-5 rounded-lg border-2 border-white/20 bg-white/5 checked:bg-[#8b5cf6] checked:border-[#8b5cf6] transition-all cursor-pointer"
                      checked={selectedTransactions.includes(transaction.id)}
                      onChange={() => toggleTransaction(transaction.id)}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <div className="font-mono text-sm text-[#8b5cf6] font-medium">
                        {transaction.reference}
                      </div>
                      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg ${statusConfig.bgColor}`}>
                        <StatusIcon className={`w-3.5 h-3.5 ${statusConfig.color}`} />
                        <span className={`text-xs font-medium ${statusConfig.color}`}>
                          {direction === 'rtl' ? statusConfig.labelAr : statusConfig.label}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <div className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'الاسم' : 'Name'}
                    </div>
                    <div className="text-white font-medium">{transaction.name}</div>
                    <div className="text-xs text-gray-400 mt-0.5">{transaction.phone}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'المبلغ' : 'Amount'}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="px-2 py-0.5 rounded bg-[#8b5cf6]/20 border border-[#8b5cf6]/30">
                        <span className="text-xs font-bold text-[#8b5cf6]">{transaction.currency}</span>
                      </div>
                      <div className="text-xl font-bold text-white">
                        {transaction.amount.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'طريقة الدفع' : 'Payment Method'}
                    </div>
                    <div className="text-sm text-gray-300">{transaction.paymentMethod}</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'التاريخ' : 'Date'}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-lg">{getCountryFlag(transaction.countryFlag || '')}</span>
                      <span className="text-sm text-gray-300">{transaction.country}</span>
                    </div>
                    <div className="text-xs text-gray-500 mt-0.5">{transaction.timestamp}</div>
                  </div>
                </div>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => navigate(`/mobile/transactions/${transaction.id}`)}
                  className="w-full py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 active:bg-white/15 transition-all flex items-center justify-center gap-2 group"
                >
                  <Eye className="w-4 h-4 text-gray-400 group-hover:text-[#8b5cf6] transition-colors" />
                  <span className="text-sm text-gray-300 group-hover:text-white transition-colors">
                    {direction === 'rtl' ? 'عرض التفاصيل' : 'View Details'}
                  </span>
                  <ChevronRight className={`w-4 h-4 text-gray-400 group-hover:text-[#8b5cf6] transition-colors ${direction === 'rtl' ? 'rotate-180' : ''}`} />
                </motion.button>
              </MobileAppCard>
            </motion.div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredTransactions.length === 0 && (
        <div className="px-4 py-16 text-center">
          <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-4">
            <Search className="w-10 h-10 text-gray-500" />
          </div>
          <p className="text-gray-400 text-lg font-medium mb-2">
            {direction === 'rtl' ? 'لم يتم العثور على معاملات' : 'No transactions found'}
          </p>
          <p className="text-gray-500 text-sm">
            {direction === 'rtl' 
              ? 'جرب تعديل معايير البحث أو الفلتر'
              : 'Try adjusting your search or filter criteria'
            }
          </p>
        </div>
      )}

      {/* Load More */}
      {filteredTransactions.length > 0 && (
        <div className="px-4 mt-6 mb-8">
          <motion.button
            whileTap={{ scale: 0.98 }}
            className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30 text-white font-medium hover:from-[#8b5cf6]/30 hover:to-[#3b82f6]/30 transition-all"
          >
            {direction === 'rtl' ? 'تحميل المزيد من المعاملات' : 'Load More Transactions'}
          </motion.button>
        </div>
      )}
    </div>
  );
}
