import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  Send, 
  Clock, 
  CheckCircle, 
  XCircle,
  DollarSign,
  User,
  Building2,
  Calendar,
  TrendingUp,
  AlertCircle,
  Download
} from 'lucide-react';
import { useState } from 'react';

interface Payout {
  id: string;
  recipient: string;
  amount: number;
  currency: string;
  method: string;
  status: 'completed' | 'pending' | 'processing' | 'failed';
  requestedDate: string;
  completedDate?: string;
  reference: string;
  destination: string;
  fee: number;
}

const mockPayouts: Payout[] = [
  {
    id: 'PAY-001',
    recipient: 'Mohamed Ali',
    amount: 15000,
    currency: 'EGP',
    method: 'Bank Transfer',
    status: 'completed',
    requestedDate: '2026-03-17 09:00',
    completedDate: '2026-03-17 09:45',
    reference: 'REF-2026-001',
    destination: 'Bank Account ****4523',
    fee: 50
  },
  {
    id: 'PAY-002',
    recipient: 'Sara Ahmed',
    amount: 25000,
    currency: 'EGP',
    method: 'InstaPay',
    status: 'processing',
    requestedDate: '2026-03-17 10:30',
    reference: 'REF-2026-002',
    destination: 'InstaPay: sara.ahmed@example.com',
    fee: 25
  },
  {
    id: 'PAY-003',
    recipient: 'Ahmed Hassan Store',
    amount: 45000,
    currency: 'EGP',
    method: 'Vodafone Cash',
    status: 'pending',
    requestedDate: '2026-03-17 11:15',
    reference: 'REF-2026-003',
    destination: 'Vodafone Cash: 0100-123-4567',
    fee: 75
  },
  {
    id: 'PAY-004',
    recipient: 'Fatima Store',
    amount: 8500,
    currency: 'EGP',
    method: 'Bank Transfer',
    status: 'completed',
    requestedDate: '2026-03-16 14:20',
    completedDate: '2026-03-16 15:10',
    reference: 'REF-2026-004',
    destination: 'Bank Account ****7821',
    fee: 40
  },
  {
    id: 'PAY-005',
    recipient: 'Omar Electronics',
    amount: 12000,
    currency: 'EGP',
    method: 'InstaPay',
    status: 'failed',
    requestedDate: '2026-03-17 08:00',
    reference: 'REF-2026-005',
    destination: 'InstaPay: omar.elec@example.com',
    fee: 20
  }
];

export function Payouts() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'completed' | 'pending' | 'processing' | 'failed'>('all');

  const filteredPayouts = filter === 'all' 
    ? mockPayouts 
    : mockPayouts.filter(p => p.status === filter);

  const totalPaidOut = mockPayouts
    .filter(p => p.status === 'completed')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalPending = mockPayouts
    .filter(p => p.status === 'pending' || p.status === 'processing')
    .reduce((sum, p) => sum + p.amount, 0);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'pending': return Clock;
      case 'processing': return TrendingUp;
      case 'failed': return XCircle;
      default: return Clock;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'from-green-500 to-emerald-500';
      case 'pending': return 'from-yellow-500 to-amber-500';
      case 'processing': return 'from-blue-500 to-cyan-500';
      case 'failed': return 'from-red-500 to-orange-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'Bank Transfer': return 'bg-blue-500/20 text-blue-300';
      case 'InstaPay': return 'bg-purple-500/20 text-purple-300';
      case 'Vodafone Cash': return 'bg-red-500/20 text-red-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-white mb-2">Payouts Management</h1>
            <p className="text-gray-400">Process and track merchant payouts</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
          >
            <Send className="w-5 h-5" />
            New Payout
          </motion.button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { 
            label: 'Total Paid Out', 
            value: `${totalPaidOut.toLocaleString()} EGP`, 
            icon: CheckCircle, 
            color: 'from-[#10b981] to-[#059669]' 
          },
          { 
            label: 'Pending Payouts', 
            value: `${totalPending.toLocaleString()} EGP`, 
            icon: Clock, 
            color: 'from-[#f59e0b] to-[#d97706]' 
          },
          { 
            label: 'Total Payouts', 
            value: mockPayouts.length, 
            icon: Send, 
            color: 'from-[#8b5cf6] to-[#7c3aed]' 
          },
          { 
            label: 'Total Fees', 
            value: `${mockPayouts.reduce((sum, p) => sum + p.fee, 0).toLocaleString()} EGP`, 
            icon: DollarSign, 
            color: 'from-[#3b82f6] to-[#2563eb]' 
          }
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {['all', 'completed', 'processing', 'pending', 'failed'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status as any)}
            className={`px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap ${
              filter === status
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-violet-500/30'
                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {/* Payouts List */}
      <div className="space-y-4">
        {filteredPayouts.map((payout, index) => {
          const StatusIcon = getStatusIcon(payout.status);
          
          return (
            <motion.div
              key={payout.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden hover:border-white/20 transition-all group"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${getStatusColor(payout.status)} flex items-center justify-center flex-shrink-0`}>
                    <StatusIcon className="w-7 h-7 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{payout.recipient}</h3>
                      <span className="text-xs font-medium px-3 py-1 rounded-full bg-white/10 text-gray-300">
                        {payout.id}
                      </span>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${getMethodColor(payout.method)}`}>
                        {payout.method}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-3">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Reference</p>
                        <p className="text-sm text-gray-300 font-medium">{payout.reference}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Destination</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <Building2 className="w-4 h-4" />
                          {payout.destination}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Requested</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {payout.requestedDate}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-white">
                          {payout.amount.toLocaleString()} {payout.currency}
                        </span>
                        <span className="text-sm text-gray-400">
                          (Fee: {payout.fee.toLocaleString()} {payout.currency})
                        </span>
                      </div>
                      {payout.completedDate && (
                        <span className="text-sm text-green-400 flex items-center gap-1">
                          <CheckCircle className="w-4 h-4" />
                          Completed: {payout.completedDate}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  {payout.status === 'completed' && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium flex items-center gap-2 border border-white/10 transition-all"
                    >
                      <Download className="w-4 h-4" />
                      Receipt
                    </motion.button>
                  )}
                  {payout.status === 'pending' && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#10b981] to-[#059669] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-green-500/30 transition-shadow"
                    >
                      <Send className="w-4 h-4" />
                      Process
                    </motion.button>
                  )}
                  {payout.status === 'failed' && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#f59e0b] to-[#d97706] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-yellow-500/30 transition-shadow"
                    >
                      <AlertCircle className="w-4 h-4" />
                      Retry
                    </motion.button>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
