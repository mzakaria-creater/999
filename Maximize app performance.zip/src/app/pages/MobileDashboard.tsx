import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ArrowUpRight, 
  ArrowDownRight,
  Receipt,
  Wallet,
  CreditCard,
  BarChart3,
  Activity,
  Users,
  Shield,
  Zap
} from 'lucide-react';
import { MobileAppCard, MobileAppSection, MobileListItem, MobileStatsCard } from '../components/MobileAppCard';
import { useLanguage } from '../context/LanguageContext';
import { useRole } from '../context/RoleContext';
import { dashboardStats, liveTransactions } from '../data/sharedData';

export default function MobileDashboard() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { role } = useRole();

  const recentTransactions = liveTransactions.map((tx, index) => ({
    id: index + 1,
    merchant: tx.merchant,
    amount: tx.status === 'success' ? `-$${tx.amount.toFixed(2)}` : tx.status === 'pending' ? `$${tx.amount.toFixed(2)}` : `-$${tx.amount.toFixed(2)}`,
    time: tx.time,
    status: tx.status,
    icon: index === 0 ? '🛒' : index === 1 ? '💼' : index === 2 ? '🎬' : '🚗',
  }));

  const quickActions = [
    { 
      id: 1, 
      label: t('dashboard.sendMoney'), 
      icon: <ArrowUpRight className="w-5 h-5" />,
      color: 'from-[#8b5cf6] to-[#7c4ee8]',
      path: '/mobile/transactions'
    },
    { 
      id: 2, 
      label: t('dashboard.requestMoney'), 
      icon: <ArrowDownRight className="w-5 h-5" />,
      color: 'from-[#3b82f6] to-[#2563eb]',
      path: '/mobile/wallets'
    },
    { 
      id: 3, 
      label: t('dashboard.topUp'), 
      icon: <Wallet className="w-5 h-5" />,
      color: 'from-[#6ee7b7] to-[#34d399]',
      path: '/mobile/wallets'
    },
    { 
      id: 4, 
      label: t('dashboard.analytics'), 
      icon: <BarChart3 className="w-5 h-5" />,
      color: 'from-[#fbbf24] to-[#f59e0b]',
      path: '/dashboard'
    },
  ];

  return (
    <div className="pb-4">
      {/* Hero Balance Card */}
      <div className="px-4 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-[#8b5cf6] via-[#7c4ee8] to-[#3b82f6]"
          style={{
            boxShadow: '0 20px 60px rgba(139, 92, 246, 0.4)',
          }}
        >
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-8">
              <div>
                <p className="text-white/80 text-sm mb-1">{t('dashboard.totalBalance')}</p>
                <h2 className="text-white text-4xl font-bold">${(dashboardStats.walletBalance / 1000).toFixed(1)}k</h2>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-3 border border-white/20">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-6 h-6 rounded-lg bg-green-400/20 flex items-center justify-center">
                    <TrendingUp className="w-3.5 h-3.5 text-green-300" />
                  </div>
                  <span className="text-white/70 text-xs">{t('dashboard.revenue')}</span>
                </div>
                <p className="text-white text-lg font-bold">${(dashboardStats.totalRevenue / 1000).toFixed(0)}k</p>
              </div>
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-3 border border-white/20">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-6 h-6 rounded-lg bg-blue-400/20 flex items-center justify-center">
                    <Receipt className="w-3.5 h-3.5 text-blue-300" />
                  </div>
                  <span className="text-white/70 text-xs">{t('dashboard.transactions')}</span>
                </div>
                <p className="text-white text-lg font-bold">{dashboardStats.transactions.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action, index) => (
            <motion.button
              key={action.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => navigate(action.path)}
              className="flex flex-col items-center gap-2"
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${action.color} flex items-center justify-center shadow-lg`}>
                {action.icon}
              </div>
              <span className="text-gray-300 text-xs text-center leading-tight">{action.label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Stats Overview */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-2 gap-3">
          <MobileStatsCard
            label={t('dashboard.totalTransactions')}
            value={dashboardStats.transactions}
            change={{ value: '+12%', isPositive: true }}
            icon={<Receipt className="w-5 h-5" />}
            gradient="blue"
          />
          <MobileStatsCard
            label={t('dashboard.activeWallets')}
            value="24"
            change={{ value: '+5%', isPositive: true }}
            icon={<Wallet className="w-5 h-5" />}
            gradient="mint"
          />
        </div>
      </div>

      {/* Recent Transactions */}
      <MobileAppSection 
        title={t('dashboard.recentTransactions')}
        action={{
          label: t('common.viewAll'),
          onClick: () => navigate('/transactions')
        }}
      >
        {recentTransactions.map((transaction) => (
          <MobileListItem
            key={transaction.id}
            icon={
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#1a1d23] to-[#252932] border border-white/10 flex items-center justify-center text-2xl">
                {transaction.icon}
              </div>
            }
            title={transaction.merchant}
            subtitle={transaction.time}
            value={transaction.amount}
            badge={
              transaction.status === 'pending' 
                ? { text: t('common.pending'), variant: 'warning' }
                : undefined
            }
            onClick={() => navigate('/transactions')}
          />
        ))}
      </MobileAppSection>

      {/* Quick Links */}
      <MobileAppSection title={t('dashboard.quickLinks')}>
        <MobileAppCard gradient onClick={() => navigate('/merchants')} showChevron>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-medium text-sm">{t('nav.merchants')}</p>
              <p className="text-gray-400 text-xs">{t('dashboard.manageMerchants')}</p>
            </div>
          </div>
        </MobileAppCard>

        <MobileAppCard gradient onClick={() => navigate('/payment-methods')} showChevron>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#3b82f6] to-[#2563eb] flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-medium text-sm">{t('nav.paymentMethods')}</p>
              <p className="text-gray-400 text-xs">{t('dashboard.configurePayments')}</p>
            </div>
          </div>
        </MobileAppCard>

        <MobileAppCard gradient onClick={() => navigate('/risk')} showChevron>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6ee7b7] to-[#34d399] flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-medium text-sm">{t('nav.risk')}</p>
              <p className="text-gray-400 text-xs">{t('dashboard.securityMonitoring')}</p>
            </div>
          </div>
        </MobileAppCard>
      </MobileAppSection>

      {/* Activity Feed */}
      <div className="px-4 mb-6">
        <MobileAppCard gradient>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-white font-medium text-sm">{t('dashboard.systemActivity')}</p>
              <p className="text-gray-400 text-xs">{t('dashboard.realtimeUpdates')}</p>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-green-400 text-xs font-medium">Live</span>
            </div>
          </div>
          <div className="space-y-2">
            {[
              { text: 'New transaction processed', time: '1m ago' },
              { text: 'Payment gateway updated', time: '5m ago' },
              { text: 'Wallet balance changed', time: '12m ago' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center justify-between py-2 border-t border-white/5 first:border-t-0">
                <p className="text-gray-300 text-xs">{activity.text}</p>
                <p className="text-gray-500 text-xs">{activity.time}</p>
              </div>
            ))}
          </div>
        </MobileAppCard>
      </div>
    </div>
  );
}