import { motion } from 'motion/react';
import { useState } from 'react';
import { GlassCard } from '../components/GlassCard';
import {
  Plus,
  Users,
  Shield,
  Edit2,
  Trash2,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Mail,
  Phone,
  Calendar,
  Key
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'Owner' | 'Admin' | 'Finance' | 'Operations' | 'Merchant' | 'Viewer';
  status: 'active' | 'inactive';
  createdAt: string;
  lastLogin: string;
  permissions: string[];
}

const mockUsers: User[] = [
  {
    id: 'USR-001',
    name: 'Ahmed Mohamed',
    email: 'ahmed@ontargetpsp.com',
    phone: '+20 100 123 4567',
    role: 'Owner',
    status: 'active',
    createdAt: '2026-01-01',
    lastLogin: '2026-03-16 10:30',
    permissions: ['all']
  },
  {
    id: 'USR-002',
    name: 'Sara Hassan',
    email: 'sara@ontargetpsp.com',
    phone: '+20 111 234 5678',
    role: 'Admin',
    status: 'active',
    createdAt: '2026-01-05',
    lastLogin: '2026-03-16 09:15',
    permissions: ['manage_users', 'view_reports', 'manage_merchants']
  },
  {
    id: 'USR-003',
    name: 'Omar Khaled',
    email: 'omar@ontargetpsp.com',
    phone: '+20 122 345 6789',
    role: 'Finance',
    status: 'active',
    createdAt: '2026-01-10',
    lastLogin: '2026-03-15 18:45',
    permissions: ['view_transactions', 'manage_wallets', 'view_reports']
  },
  {
    id: 'USR-004',
    name: 'Fatima Ali',
    email: 'fatima@ontargetpsp.com',
    phone: '+20 100 456 7890',
    role: 'Operations',
    status: 'active',
    createdAt: '2026-01-15',
    lastLogin: '2026-03-16 08:20',
    permissions: ['manage_transactions', 'manage_merchants']
  },
  {
    id: 'USR-005',
    name: 'Youssef Ibrahim',
    email: 'youssef@merchant.com',
    phone: '+20 111 567 8901',
    role: 'Merchant',
    status: 'active',
    createdAt: '2026-02-01',
    lastLogin: '2026-03-16 07:10',
    permissions: ['view_own_transactions', 'manage_payment_methods']
  },
  {
    id: 'USR-006',
    name: 'Layla Mahmoud',
    email: 'layla@ontargetpsp.com',
    phone: '+20 122 678 9012',
    role: 'Viewer',
    status: 'inactive',
    createdAt: '2026-02-15',
    lastLogin: '2026-03-10 16:30',
    permissions: ['view_reports']
  }
];

const rolePermissions = {
  Owner: ['all'],
  Admin: ['manage_users', 'view_reports', 'manage_merchants', 'manage_transactions', 'manage_wallets'],
  Finance: ['view_transactions', 'manage_wallets', 'view_reports', 'manage_settlement'],
  Operations: ['manage_transactions', 'manage_merchants', 'view_reports'],
  Merchant: ['view_own_transactions', 'manage_payment_methods', 'view_own_reports'],
  Viewer: ['view_reports', 'view_transactions']
};

export function UserManagement() {
  const { t, direction } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedRole, setSelectedRole] = useState<string>('all');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);

  const filteredUsers = mockUsers.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.phone.includes(searchQuery);
    
    const matchesRole = selectedRole === 'all' || user.role === selectedRole;
    
    return matchesSearch && matchesRole;
  });

  const stats = {
    totalUsers: mockUsers.length,
    activeUsers: mockUsers.filter(u => u.status === 'active').length,
    inactiveUsers: mockUsers.filter(u => u.status === 'inactive').length,
    merchants: mockUsers.filter(u => u.role === 'Merchant').length
  };

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      Owner: 'from-purple-400 to-purple-600',
      Admin: 'from-blue-400 to-blue-600',
      Finance: 'from-green-400 to-green-600',
      Operations: 'from-yellow-400 to-yellow-600',
      Merchant: 'from-orange-400 to-orange-600',
      Viewer: 'from-gray-400 to-gray-600'
    };
    return colors[role] || 'from-gray-400 to-gray-600';
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'Owner': return '👑';
      case 'Admin': return '🛡️';
      case 'Finance': return '💰';
      case 'Operations': return '⚙️';
      case 'Merchant': return '🏪';
      case 'Viewer': return '👁️';
      default: return '👤';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f1117] via-[#1a1d23] to-[#0f1117] p-4 md:p-8" dir={direction}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              {direction === 'rtl' ? 'إدارة المستخدمين' : 'User Management'}
            </h1>
            <p className="text-gray-400">
              {direction === 'rtl' 
                ? 'إدارة المستخدمين والأدوار والصلاحيات'
                : 'Manage users, roles, and permissions'
              }
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowCreateModal(true)}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold flex items-center gap-2 shadow-lg shadow-[#8b5cf6]/20"
          >
            <Plus className="w-5 h-5" />
            <span>{direction === 'rtl' ? 'إضافة مستخدم' : 'Add User'}</span>
          </motion.button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'إجمالي المستخدمين' : 'Total Users'}
                </p>
                <p className="text-3xl font-bold text-white">{stats.totalUsers}</p>
              </div>
              <Users className="w-10 h-10 text-[#8b5cf6]" />
            </div>
          </GlassCard>

          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'نشط' : 'Active'}
                </p>
                <p className="text-3xl font-bold text-green-400">{stats.activeUsers}</p>
              </div>
              <CheckCircle2 className="w-10 h-10 text-green-400" />
            </div>
          </GlassCard>

          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'غير نشط' : 'Inactive'}
                </p>
                <p className="text-3xl font-bold text-red-400">{stats.inactiveUsers}</p>
              </div>
              <XCircle className="w-10 h-10 text-red-400" />
            </div>
          </GlassCard>

          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'التجار' : 'Merchants'}
                </p>
                <p className="text-3xl font-bold text-orange-400">{stats.merchants}</p>
              </div>
              <Shield className="w-10 h-10 text-orange-400" />
            </div>
          </GlassCard>
        </div>

        {/* Search and Filter */}
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'right-4' : 'left-4'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={direction === 'rtl' ? 'ابحث عن مستخدم...' : 'Search users...'}
              className={`w-full h-14 ${direction === 'rtl' ? 'pr-12 pl-4' : 'pl-12 pr-4'} rounded-2xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]/50 focus:bg-white/10 transition-all`}
            />
          </div>
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="h-14 px-6 rounded-2xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
          >
            <option value="all">{direction === 'rtl' ? 'كل الأدوار' : 'All Roles'}</option>
            <option value="Owner">{direction === 'rtl' ? 'مالك' : 'Owner'}</option>
            <option value="Admin">{direction === 'rtl' ? 'مدير' : 'Admin'}</option>
            <option value="Finance">{direction === 'rtl' ? 'مالي' : 'Finance'}</option>
            <option value="Operations">{direction === 'rtl' ? 'عمليات' : 'Operations'}</option>
            <option value="Merchant">{direction === 'rtl' ? 'تاجر' : 'Merchant'}</option>
            <option value="Viewer">{direction === 'rtl' ? 'مشاهد' : 'Viewer'}</option>
          </select>
        </div>
      </div>

      {/* Users List */}
      <div className="space-y-4">
        {filteredUsers.map((user, index) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <GlassCard className="hover:border-[#8b5cf6]/30 transition-all">
              <div className="flex items-center gap-6">
                {/* Avatar */}
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${getRoleColor(user.role)} flex items-center justify-center text-3xl`}>
                  {getRoleIcon(user.role)}
                </div>

                {/* User Info */}
                <div className="flex-1 grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div>
                    <p className="text-white font-bold text-lg mb-1">{user.name}</p>
                    <p className="text-sm text-gray-400 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5" />
                      {user.email}
                    </p>
                    <p className="text-sm text-gray-400 flex items-center gap-1.5 mt-1">
                      <Phone className="w-3.5 h-3.5" />
                      {user.phone}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'الدور' : 'Role'}
                    </p>
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r ${getRoleColor(user.role)} text-white font-semibold text-sm`}>
                      <span>{getRoleIcon(user.role)}</span>
                      {user.role}
                    </span>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'الحالة' : 'Status'}
                    </p>
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold ${
                      user.status === 'active' 
                        ? 'bg-green-400/20 text-green-400 border border-green-400/30'
                        : 'bg-red-400/20 text-red-400 border border-red-400/30'
                    }`}>
                      {user.status === 'active' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                      {user.status === 'active' 
                        ? (direction === 'rtl' ? 'نشط' : 'Active')
                        : (direction === 'rtl' ? 'غير نشط' : 'Inactive')
                      }
                    </span>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'تاريخ الإنشاء' : 'Created'}
                    </p>
                    <p className="text-sm text-gray-300 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      {user.createdAt}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {direction === 'rtl' ? 'آخر دخول: ' : 'Last login: '}{user.lastLogin}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">
                      {direction === 'rtl' ? 'الصلاحيات' : 'Permissions'}
                    </p>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        setSelectedUser(user);
                        setShowPermissionsModal(true);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-sm text-gray-300"
                    >
                      <Key className="w-3.5 h-3.5" />
                      {user.permissions.length} {direction === 'rtl' ? 'صلاحية' : 'perms'}
                    </motion.button>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
                  >
                    <Edit2 className="w-4 h-4 text-blue-400" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-red-500/20 transition-all"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </motion.button>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Create User Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl w-full bg-[#1a1d23] border border-white/10 rounded-3xl p-8"
          >
            <h2 className="text-2xl font-bold text-white mb-6">
              {direction === 'rtl' ? 'إضافة مستخدم جديد' : 'Add New User'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الاسم الكامل' : 'Full Name'}
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل الاسم' : 'Enter name'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'البريد الإلكتروني' : 'Email'}
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل البريد' : 'Enter email'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'رقم الهاتف' : 'Phone'}
                </label>
                <input
                  type="tel"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder="+20 100 000 0000"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الدور' : 'Role'}
                </label>
                <select className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50">
                  <option value="Admin">Admin</option>
                  <option value="Finance">Finance</option>
                  <option value="Operations">Operations</option>
                  <option value="Merchant">Merchant</option>
                  <option value="Viewer">Viewer</option>
                </select>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 font-medium hover:bg-white/10 transition-all"
              >
                {direction === 'rtl' ? 'إلغاء' : 'Cancel'}
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg shadow-[#8b5cf6]/20"
              >
                {direction === 'rtl' ? 'إضافة المستخدم' : 'Add User'}
              </motion.button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Permissions Modal */}
      {showPermissionsModal && selectedUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl w-full bg-[#1a1d23] border border-white/10 rounded-3xl p-8"
          >
            <h2 className="text-2xl font-bold text-white mb-2">
              {direction === 'rtl' ? 'إدارة الصلاحيات' : 'Manage Permissions'}
            </h2>
            <p className="text-gray-400 mb-6">
              {selectedUser.name} - {selectedUser.role}
            </p>
            
            <div className="space-y-3 mb-6 max-h-96 overflow-y-auto">
              {rolePermissions[selectedUser.role as keyof typeof rolePermissions].map((permission) => (
                <div key={permission} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      defaultChecked={selectedUser.permissions.includes(permission) || permission === 'all'}
                      className="w-5 h-5 rounded-lg border-2 border-white/20 bg-white/5 checked:bg-[#8b5cf6] checked:border-[#8b5cf6] cursor-pointer"
                    />
                    <div>
                      <p className="text-white font-medium">{permission.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className="text-xs text-gray-400">
                        {direction === 'rtl' ? 'صلاحية' : 'Permission'} - {selectedUser.role}
                      </p>
                    </div>
                  </div>
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                </div>
              ))}
            </div>
            
            <div className="flex items-center gap-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowPermissionsModal(false)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 font-medium hover:bg-white/10 transition-all"
              >
                {direction === 'rtl' ? 'إلغاء' : 'Cancel'}
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg shadow-[#8b5cf6]/20"
              >
                {direction === 'rtl' ? 'حفظ التغييرات' : 'Save Changes'}
              </motion.button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
