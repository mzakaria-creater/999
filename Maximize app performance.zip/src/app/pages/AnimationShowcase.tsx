import { useState } from 'react';
import { AnimatedButton } from '../components/AnimatedButton';
import { HoverCard3D, MagneticButton, FloatingCard } from '../components/HoverCard3D';
import { SwipeableCard } from '../components/SwipeableCard';
import { useConfetti } from '../components/ConfettiEffect';
import { DashboardCardSkeleton, TransactionSkeleton, ChartSkeleton } from '../components/SkeletonLoader';
import { StaggerContainer, StaggerItem } from '../components/AnimatedChart';
import { GlassCard } from '../components/GlassCard';
import { motion } from 'motion/react';
import {
  Sparkles,
  Zap,
  Rocket,
  Download,
  Heart,
  Star,
  ChevronRight,
} from 'lucide-react';

export function AnimationShowcase() {
  const { fireConfetti } = useConfetti();
  const [showSkeleton, setShowSkeleton] = useState(false);
  const [counter, setCounter] = useState(0);

  const demoCards = [
    { id: 1, title: 'Revenue', value: '$73,000', icon: Sparkles, color: 'from-[#8b5cf6] to-[#3b82f6]' },
    { id: 2, title: 'Transactions', value: '1,247', icon: Zap, color: 'from-[#6ee7b7] to-[#06b6d4]' },
    { id: 3, title: 'Merchants', value: '147', icon: Rocket, color: 'from-[#fbbf24] to-[#f59e0b]' },
  ];

  return (
    <div className="p-8 space-y-12 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <h1 className="text-5xl font-bold text-white flex items-center justify-center gap-3">
          <Sparkles className="w-12 h-12 text-[#8b5cf6]" />
          Animation Showcase
          <Sparkles className="w-12 h-12 text-[#3b82f6]" />
        </h1>
        <p className="text-xl text-gray-400">
          Explore all the advanced animations in OnTarget PSP
        </p>
      </motion.div>

      {/* Section 1: Animated Buttons */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#8b5cf6] to-[#3b82f6] rounded-full" />
          1. Animated Buttons
        </motion.h2>
        
        <GlassCard className="p-8">
          <div className="flex flex-wrap gap-4 items-center justify-center">
            <AnimatedButton
              variant="primary"
              ripple
              lift
              onClick={() => fireConfetti('success')}
            >
              <Sparkles className="w-5 h-5" />
              Primary with Confetti
            </AnimatedButton>

            <AnimatedButton
              variant="secondary"
              ripple
              lift
            >
              <Download className="w-5 h-5" />
              Secondary Button
            </AnimatedButton>

            <AnimatedButton
              variant="ghost"
              ripple
              lift
            >
              <Heart className="w-5 h-5" />
              Ghost Button
            </AnimatedButton>

            <AnimatedButton
              variant="primary"
              ripple={false}
              lift
            >
              No Ripple
            </AnimatedButton>

            <AnimatedButton
              variant="primary"
              ripple
              lift={false}
            >
              No Lift
            </AnimatedButton>
          </div>
          <p className="text-sm text-gray-400 text-center mt-4">
            Click any button to see ripple effects. Hover to see lift animation. First button fires confetti! 🎉
          </p>
        </GlassCard>
      </section>

      {/* Section 2: Confetti Types */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#6ee7b7] to-[#06b6d4] rounded-full" />
          2. Confetti Effects
        </motion.h2>
        
        <GlassCard className="p-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <AnimatedButton onClick={() => fireConfetti('success')}>
              🎉 Success
            </AnimatedButton>
            <AnimatedButton onClick={() => fireConfetti('celebration')}>
              🎊 Celebration
            </AnimatedButton>
            <AnimatedButton onClick={() => fireConfetti('burst')}>
              💥 Burst
            </AnimatedButton>
            <AnimatedButton onClick={() => fireConfetti('rain')}>
              🌧️ Rain
            </AnimatedButton>
          </div>
          <p className="text-sm text-gray-400 text-center mt-4">
            Click each button to see different confetti patterns
          </p>
        </GlassCard>
      </section>

      {/* Section 3: 3D Hover Cards */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#fbbf24] to-[#f59e0b] rounded-full" />
          3. 3D Hover Effects
        </motion.h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {demoCards.map((card) => {
            const Icon = card.icon;
            return (
              <HoverCard3D key={card.id} intensity={15} shine scale>
                <GlassCard className="p-6 h-full">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${card.color} w-fit mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-sm text-gray-400 mb-2">{card.title}</p>
                  <h3 className="text-3xl font-bold text-white">{card.value}</h3>
                </GlassCard>
              </HoverCard3D>
            );
          })}
        </div>
        <p className="text-sm text-gray-400 text-center">
          Hover over cards to see 3D tilt effect (Desktop only)
        </p>
      </section>

      {/* Section 4: Loading Skeletons */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#f87171] to-[#dc2626] rounded-full" />
          4. Loading Skeletons
        </motion.h2>
        
        <GlassCard className="p-8 space-y-6">
          <div className="flex justify-center">
            <AnimatedButton
              onClick={() => {
                setShowSkeleton(true);
                setTimeout(() => setShowSkeleton(false), 3000);
              }}
            >
              Toggle Loading State (3s)
            </AnimatedButton>
          </div>

          {showSkeleton ? (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-6">
                <DashboardCardSkeleton />
                <DashboardCardSkeleton />
                <DashboardCardSkeleton />
              </div>
              <div className="space-y-3">
                <TransactionSkeleton />
                <TransactionSkeleton />
                <TransactionSkeleton />
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-400">Content loaded! Click button above to see skeletons.</p>
            </div>
          )}
        </GlassCard>
      </section>

      {/* Section 5: Stagger Animation */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#ec4899] to-[#db2777] rounded-full" />
          5. Stagger Animations
        </motion.h2>
        
        <StaggerContainer staggerDelay={0.1}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((num) => (
              <StaggerItem key={num}>
                <GlassCard className="p-6 text-center hover:bg-white/10 transition-all cursor-pointer">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl font-bold text-white">{num}</span>
                  </div>
                  <p className="text-white font-medium">Item {num}</p>
                  <p className="text-sm text-gray-400 mt-1">Staggered reveal</p>
                </GlassCard>
              </StaggerItem>
            ))}
          </div>
        </StaggerContainer>
        <p className="text-sm text-gray-400 text-center">
          Items appear one by one. Refresh page to see again.
        </p>
      </section>

      {/* Section 6: Swipeable Cards (Mobile) */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#06b6d4] to-[#0891b2] rounded-full" />
          6. Swipeable Cards (Mobile)
        </motion.h2>
        
        <GlassCard className="p-8">
          <div className="space-y-4 max-w-md mx-auto">
            {[1, 2, 3].map((num) => (
              <SwipeableCard
                key={num}
                leftAction="delete"
                rightAction="approve"
                onSwipeLeft={() => {
                  console.log(`Deleted item ${num}`);
                }}
                onSwipeRight={() => {
                  fireConfetti('success');
                  console.log(`Approved item ${num}`);
                }}
              >
                <GlassCard className="p-6 bg-white/10">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">Transaction #{num}</p>
                      <p className="text-sm text-gray-400">Swipe to interact</p>
                    </div>
                    <Star className="w-6 h-6 text-[#fbbf24]" />
                  </div>
                </GlassCard>
              </SwipeableCard>
            ))}
          </div>
          <p className="text-sm text-gray-400 text-center mt-6">
            On mobile: Swipe left to delete, right to approve. On desktop: Try dragging!
          </p>
        </GlassCard>
      </section>

      {/* Section 7: Floating Card */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#a78bfa] to-[#8b5cf6] rounded-full" />
          7. Floating Animation
        </motion.h2>
        
        <div className="flex justify-center">
          <FloatingCard className="max-w-sm">
            <GlassCard className="p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center mx-auto mb-4">
                <Rocket className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Floating Card</h3>
              <p className="text-gray-400">
                This card gently floats up and down continuously
              </p>
            </GlassCard>
          </FloatingCard>
        </div>
      </section>

      {/* Section 8: Magnetic Button */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#22c55e] to-[#16a34a] rounded-full" />
          8. Magnetic Button
        </motion.h2>
        
        <GlassCard className="p-12">
          <div className="flex justify-center">
            <MagneticButton
              strength={0.4}
              className="px-8 py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium text-lg shadow-lg shadow-violet-500/30"
            >
              <div className="flex items-center gap-3">
                <Zap className="w-6 h-6" />
                Hover Over Me!
                <ChevronRight className="w-6 h-6" />
              </div>
            </MagneticButton>
          </div>
          <p className="text-sm text-gray-400 text-center mt-6">
            Move your cursor near the button - it will follow your mouse! (Desktop only)
          </p>
        </GlassCard>
      </section>

      {/* Counter Demo */}
      <section className="space-y-6">
        <motion.h2
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-3xl font-semibold text-white flex items-center gap-3"
        >
          <div className="w-2 h-8 bg-gradient-to-b from-[#f59e0b] to-[#d97706] rounded-full" />
          9. Interactive Counter
        </motion.h2>
        
        <GlassCard className="p-12 text-center">
          <motion.div
            key={counter}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="mb-6"
          >
            <h3 className="text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6]">
              {counter}
            </h3>
          </motion.div>
          <div className="flex gap-4 justify-center">
            <AnimatedButton
              onClick={() => setCounter(counter - 1)}
              variant="secondary"
            >
              Decrease
            </AnimatedButton>
            <AnimatedButton
              onClick={() => setCounter(counter + 1)}
            >
              Increase
            </AnimatedButton>
            <AnimatedButton
              onClick={() => {
                setCounter(0);
                fireConfetti('burst');
              }}
              variant="ghost"
            >
              Reset
            </AnimatedButton>
          </div>
        </GlassCard>
      </section>

      {/* Footer */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="text-center pt-12 pb-6 space-y-4"
      >
        <div className="flex items-center justify-center gap-2 text-gray-400">
          <div className="h-px bg-gradient-to-r from-transparent via-white/20 to-transparent flex-1" />
          <Sparkles className="w-5 h-5" />
          <div className="h-px bg-gradient-to-r from-transparent via-white/20 to-transparent flex-1" />
        </div>
        <p className="text-gray-400">
          All animations are production-ready and optimized for performance
        </p>
        <p className="text-sm text-gray-500">
          Built with Motion · Glassmorphism · 2026 Design Trends
        </p>
      </motion.div>
    </div>
  );
}
