import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { useState, useEffect } from 'react';
import { 
  Activity, 
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  ShoppingBag,
  Zap,
  AlertTriangle,
  CheckCircle,
  Clock,
  Globe,
  Smartphone,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Radio
} from 'lucide-react';

interface LiveTransaction {
  id: string;
  merchant: string;
  amount: number;
  currency: string;
  method: string;
  status: 'success' | 'pending' | 'failed';
  timestamp: Date;
  country: string;
}

interface LiveStats {
  revenue: number;
  transactions: number;
  activeUsers: number;
  successRate: number;
  avgAmount: number;
}

export function LiveMonitor() {
  const { t, language } = useLanguage();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [liveTransactions, setLiveTransactions] = useState<LiveTransaction[]>([]);
  const [stats, setStats] = useState<LiveStats>({
    revenue: 245780,
    transactions: 1247,
    activeUsers: 342,
    successRate: 94.2,
    avgAmount: 197
  });

  const [revenueChange, setRevenueChange] = useState(0);
  const [transactionChange, setTransactionChange] = useState(0);

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Simulate live transactions
  useEffect(() => {
    const merchants = ['SuperMart Egypt', 'TechStore', 'Fashion Hub', 'Food Delivery', 'Beauty Palace', 'MegaShop', 'ElectroWorld'];
    const methods = ['Credit Card', 'InstaPay', 'Vodafone Cash', 'Bank Transfer', 'Fawry'];
    const countries = ['Egypt', 'Saudi Arabia', 'UAE', 'Kuwait', 'Qatar'];
    const statuses: ('success' | 'pending' | 'failed')[] = ['success', 'success', 'success', 'success', 'pending', 'failed'];

    const interval = setInterval(() => {
      const newTransaction: LiveTransaction = {
        id: `TXN-${Date.now()}`,
        merchant: merchants[Math.floor(Math.random() * merchants.length)],
        amount: Math.floor(Math.random() * 5000) + 50,
        currency: 'EGP',
        method: methods[Math.floor(Math.random() * methods.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
        timestamp: new Date(),
        country: countries[Math.floor(Math.random() * countries.length)]
      };

      setLiveTransactions(prev => [newTransaction, ...prev.slice(0, 19)]);

      // Update stats
      setStats(prev => ({
        revenue: prev.revenue + (newTransaction.status === 'success' ? newTransaction.amount : 0),
        transactions: prev.transactions + 1,
        activeUsers: prev.activeUsers + (Math.random() > 0.7 ? 1 : 0),
        successRate: ((prev.transactions * prev.successRate / 100 + (newTransaction.status === 'success' ? 1 : 0)) / (prev.transactions + 1)) * 100,
        avgAmount: (prev.avgAmount * prev.transactions + newTransaction.amount) / (prev.transactions + 1)
      }));

      // Random changes
      setRevenueChange((Math.random() - 0.5) * 2);
      setTransactionChange((Math.random() - 0.5) * 10);
    }, 3000); // New transaction every 3 seconds

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500/20 text-green-400';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400';
      case 'failed': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getMethodIcon = (method: string) => {
    if (method.includes('Card')) return CreditCard;
    if (method.includes('InstaPay')) return Smartphone;
    return DollarSign;
  };

  return (
    <div className="p-4 sm:p-8 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#ef4444] to-[#dc2626] flex items-center justify-center">
                <Radio className="w-6 h-6 text-white animate-pulse" />
              </div>
              <div>
                <h1 className="text-3xl font-semibold text-white">{t('nav.liveMonitor')}</h1>
                <p className="text-gray-400">{t('dashboard.monitorSubtitle')}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-500/20 to-orange-500/20 border border-red-500/30">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm font-medium text-red-300">LIVE</span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-400">Current Time</p>
              <p className="text-lg font-mono font-semibold text-white">
                {currentTime.toLocaleTimeString(language === 'ar' ? 'ar-EG' : 'en-US')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {[
          { 
            label: t('dashboard.liveRevenue'), 
            value: `${stats.revenue.toLocaleString()} EGP`,
            change: revenueChange,
            icon: DollarSign, 
            color: 'from-[#10b981] to-[#059669]' 
          },
          { 
            label: t('dashboard.transactions'), 
            value: stats.transactions.toLocaleString(),
            change: transactionChange,
            icon: Activity, 
            color: 'from-[#3b82f6] to-[#2563eb]' 
          },
          { 
            label: t('dashboard.activeUsers'), 
            value: stats.activeUsers.toLocaleString(),
            change: 2.3,
            icon: Users, 
            color: 'from-[#8b5cf6] to-[#7c3aed]' 
          },
          { 
            label: t('dashboard.successRate'), 
            value: `${stats.successRate.toFixed(1)}%`,
            change: 0.8,
            icon: CheckCircle, 
            color: 'from-[#10b981] to-[#059669]' 
          },
          { 
            label: t('dashboard.avgAmount'), 
            value: `${Math.floor(stats.avgAmount)} EGP`,
            change: -1.2,
            icon: ShoppingBag, 
            color: 'from-[#f59e0b] to-[#d97706]' 
          }
        ].map((stat, index) => {
          const Icon = stat.icon;
          const ChangeIcon = stat.change >= 0 ? TrendingUp : TrendingDown;
          
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <motion.div
                    animate={{ 
                      y: stat.change >= 0 ? [-2, 0, -2] : [2, 0, 2]
                    }}
                    transition={{ 
                      repeat: Infinity, 
                      duration: 2,
                      ease: "easeInOut"
                    }}
                    className={`flex items-center gap-1 text-sm font-medium ${
                      stat.change >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    <ChangeIcon className="w-4 h-4" />
                    {Math.abs(stat.change).toFixed(1)}%
                  </motion.div>
                </div>
                <p className="text-2xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live Transaction Feed */}
        <div className="lg:col-span-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                  <Activity className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-white">{t('dashboard.liveFeed')}</h2>
                  <p className="text-sm text-gray-400">{t('dashboard.realTimeUpdates')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-500/20 border border-green-500/30">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-xs font-medium text-green-300">Active</span>
              </div>
            </div>

            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
              <AnimatePresence mode="popLayout">
                {liveTransactions.map((txn, index) => {
                  const MethodIcon = getMethodIcon(txn.method);
                  const timeDiff = Math.floor((new Date().getTime() - txn.timestamp.getTime()) / 1000);
                  
                  return (
                    <motion.div
                      key={txn.id}
                      initial={{ opacity: 0, x: -50, scale: 0.9 }}
                      animate={{ opacity: 1, x: 0, scale: 1 }}
                      exit={{ opacity: 0, x: 50, scale: 0.9 }}
                      transition={{ duration: 0.3 }}
                      className="relative p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all group"
                    >
                      {index === 0 && (
                        <div className="absolute -top-1 -right-1 px-2 py-0.5 rounded-full bg-gradient-to-r from-red-500 to-orange-500 text-xs font-bold text-white animate-pulse">
                          NEW
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${
                            txn.status === 'success' ? 'from-green-500 to-emerald-500' :
                            txn.status === 'pending' ? 'from-yellow-500 to-amber-500' :
                            'from-red-500 to-orange-500'
                          } flex items-center justify-center flex-shrink-0`}>
                            <MethodIcon className="w-5 h-5 text-white" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="text-sm font-semibold text-white truncate">{txn.merchant}</h4>
                              <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(txn.status)} whitespace-nowrap`}>
                                {txn.status}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-xs text-gray-400">
                              <span className="font-mono">{txn.id}</span>
                              <span className="flex items-center gap-1">
                                <Globe className="w-3 h-3" />
                                {txn.country}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {timeDiff}s ago
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="text-right flex-shrink-0">
                          <p className="text-lg font-bold text-white">
                            {txn.amount.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-400">{txn.currency}</p>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>

        {/* System Status & Alerts */}
        <div className="space-y-6">
          {/* System Health */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-green-400" />
              {t('dashboard.systemHealth')}
            </h3>
            <div className="space-y-3">
              {[
                { name: 'API Gateway', status: 99.9, color: 'green' },
                { name: 'Database', status: 100, color: 'green' },
                { name: 'Payment Processors', status: 98.5, color: 'green' },
                { name: 'Webhook Service', status: 97.2, color: 'yellow' }
              ].map((service, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300">{service.name}</span>
                    <span className={`font-semibold ${
                      service.color === 'green' ? 'text-green-400' : 'text-yellow-400'
                    }`}>
                      {service.status}%
                    </span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${service.status}%` }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      className={`h-full bg-gradient-to-r ${
                        service.color === 'green' 
                          ? 'from-green-500 to-emerald-500' 
                          : 'from-yellow-500 to-amber-500'
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Live Alerts */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              {t('dashboard.recentAlerts')}
            </h3>
            <div className="space-y-3">
              {[
                { type: 'warning', message: 'High transaction volume detected', time: '2m ago' },
                { type: 'info', message: 'New merchant registered', time: '15m ago' },
                { type: 'success', message: 'Daily backup completed', time: '1h ago' }
              ].map((alert, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg ${
                    alert.type === 'warning' ? 'bg-yellow-500/10 border border-yellow-500/30' :
                    alert.type === 'info' ? 'bg-blue-500/10 border border-blue-500/30' :
                    'bg-green-500/10 border border-green-500/30'
                  }`}
                >
                  <p className={`text-sm font-medium mb-1 ${
                    alert.type === 'warning' ? 'text-yellow-300' :
                    alert.type === 'info' ? 'text-blue-300' :
                    'text-green-300'
                  }`}>
                    {alert.message}
                  </p>
                  <p className="text-xs text-gray-500">{alert.time}</p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <h3 className="text-lg font-semibold text-white mb-4">{t('dashboard.todaysSummary')}</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">{t('dashboard.peakHour')}</span>
                <span className="text-sm font-semibold text-white">14:00 - 15:00</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">{t('dashboard.topMerchant')}</span>
                <span className="text-sm font-semibold text-white">SuperMart</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">{t('dashboard.topMethod')}</span>
                <span className="text-sm font-semibold text-white">Credit Card</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">{t('dashboard.avgResponse')}</span>
                <span className="text-sm font-semibold text-green-400">125ms</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.5);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.7);
        }
      `}</style>
    </div>
  );
}
