import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Plus,
  Search,
  MoreVertical,
  Check,
  X as XIcon,
  Globe,
  DollarSign,
  Settings,
  Smartphone,
  Building,
  CreditCard as CreditCardIcon,
  Wallet as WalletIcon,
  Send,
  ExternalLink,
  Filter
} from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

interface PaymentMethod {
  id: string;
  name: string;
  nameAr?: string;
  logo: string;
  type: 'wallet' | 'bank' | 'gateway' | 'telegram';
  country: string;
  countryCode: string;
  flag: string;
  currency: string;
  status: 'active' | 'inactive';
  fees: {
    fixed: number;
    percentage: number;
  };
  limits: {
    min: number;
    max: number;
  };
  integration: string;
  telegramBot?: string;
}

const paymentMethodsData: PaymentMethod[] = [
  // Egypt - Mobile Wallets
  {
    id: 'PM-001',
    name: 'Vodafone Cash',
    nameAr: 'فودافون كاش',
    logo: '📱',
    type: 'wallet',
    country: 'Egypt',
    countryCode: 'EG',
    flag: '🇪🇬',
    currency: 'EGP',
    status: 'active',
    fees: { fixed: 2, percentage: 1.5 },
    limits: { min: 10, max: 50000 },
    integration: 'API',
    telegramBot: '@VodafoneCashBot'
  },
  {
    id: 'PM-002',
    name: 'Orange Cash',
    nameAr: 'أورنج كاش',
    logo: '🍊',
    type: 'wallet',
    country: 'Egypt',
    countryCode: 'EG',
    flag: '🇪🇬',
    currency: 'EGP',
    status: 'active',
    fees: { fixed: 2, percentage: 1.5 },
    limits: { min: 10, max: 50000 },
    integration: 'API'
  },
  {
    id: 'PM-003',
    name: 'Etisalat Cash',
    nameAr: 'اتصالات كاش',
    logo: '💚',
    type: 'wallet',
    country: 'Egypt',
    countryCode: 'EG',
    flag: '🇪🇬',
    currency: 'EGP',
    status: 'active',
    fees: { fixed: 2, percentage: 1.5 },
    limits: { min: 10, max: 50000 },
    integration: 'API'
  },
  {
    id: 'PM-004',
    name: 'WE Pay',
    nameAr: 'وي باي',
    logo: '💜',
    type: 'wallet',
    country: 'Egypt',
    countryCode: 'EG',
    flag: '🇪🇬',
    currency: 'EGP',
    status: 'active',
    fees: { fixed: 2, percentage: 1.5 },
    limits: { min: 10, max: 50000 },
    integration: 'API'
  },
  // Egypt - Bank & Others
  {
    id: 'PM-005',
    name: 'InstaPay',
    nameAr: 'انستاباي',
    logo: '⚡',
    type: 'bank',
    country: 'Egypt',
    countryCode: 'EG',
    flag: '🇪🇬',
    currency: 'EGP',
    status: 'active',
    fees: { fixed: 0, percentage: 0.5 },
    limits: { min: 1, max: 400000 },
    integration: 'Gateway'
  },
  {
    id: 'PM-006',
    name: 'Fawry',
    nameAr: 'فوري',
    logo: '🏪',
    type: 'gateway',
    country: 'Egypt',
    countryCode: 'EG',
    flag: '🇪🇬',
    currency: 'EGP',
    status: 'active',
    fees: { fixed: 3, percentage: 1.0 },
    limits: { min: 10, max: 100000 },
    integration: 'Gateway'
  },
  // Saudi Arabia
  {
    id: 'PM-007',
    name: 'STC Pay',
    nameAr: 'STC باي',
    logo: '💚',
    type: 'wallet',
    country: 'Saudi Arabia',
    countryCode: 'SA',
    flag: '🇸🇦',
    currency: 'SAR',
    status: 'active',
    fees: { fixed: 0, percentage: 1.2 },
    limits: { min: 20, max: 100000 },
    integration: 'API',
    telegramBot: '@STCPayBot'
  },
  {
    id: 'PM-008',
    name: 'Mada',
    nameAr: 'مدى',
    logo: '💳',
    type: 'gateway',
    country: 'Saudi Arabia',
    countryCode: 'SA',
    flag: '🇸🇦',
    currency: 'SAR',
    status: 'active',
    fees: { fixed: 0, percentage: 1.5 },
    limits: { min: 10, max: 200000 },
    integration: 'Gateway'
  },
  {
    id: 'PM-009',
    name: 'SADAD',
    nameAr: 'سداد',
    logo: '🏦',
    type: 'bank',
    country: 'Saudi Arabia',
    countryCode: 'SA',
    flag: '🇸🇦',
    currency: 'SAR',
    status: 'active',
    fees: { fixed: 2, percentage: 0.5 },
    limits: { min: 50, max: 500000 },
    integration: 'Gateway'
  },
  // UAE
  {
    id: 'PM-010',
    name: 'Apple Pay',
    nameAr: 'آبل باي',
    logo: '🍎',
    type: 'gateway',
    country: 'UAE',
    countryCode: 'AE',
    flag: '🇦🇪',
    currency: 'AED',
    status: 'active',
    fees: { fixed: 0, percentage: 2.5 },
    limits: { min: 1, max: 50000 },
    integration: 'Gateway'
  },
  {
    id: 'PM-011',
    name: 'Beam Wallet',
    nameAr: 'بيم والت',
    logo: '💰',
    type: 'wallet',
    country: 'UAE',
    countryCode: 'AE',
    flag: '🇦🇪',
    currency: 'AED',
    status: 'active',
    fees: { fixed: 1, percentage: 1.5 },
    limits: { min: 5, max: 30000 },
    integration: 'API'
  },
  // Telegram Integration
  {
    id: 'PM-TG-001',
    name: 'Telegram Payments',
    nameAr: 'مدفوعات تيليجرام',
    logo: '✈️',
    type: 'telegram',
    country: 'Global',
    countryCode: 'GLOBAL',
    flag: '🌍',
    currency: 'Multi',
    status: 'active',
    fees: { fixed: 0, percentage: 0 },
    limits: { min: 1, max: 1000000 },
    integration: 'Telegram Bot API',
    telegramBot: '@OnTargetPayBot'
  },
  // Kuwait
  {
    id: 'PM-012',
    name: 'KNET',
    nameAr: 'كي نت',
    logo: '💳',
    type: 'gateway',
    country: 'Kuwait',
    countryCode: 'KW',
    flag: '🇰🇼',
    currency: 'KWD',
    status: 'active',
    fees: { fixed: 0.5, percentage: 1.0 },
    limits: { min: 1, max: 50000 },
    integration: 'Gateway'
  },
  // Qatar
  {
    id: 'PM-013',
    name: 'QPay',
    nameAr: 'كيو باي',
    logo: '💳',
    type: 'wallet',
    country: 'Qatar',
    countryCode: 'QA',
    flag: '🇶🇦',
    currency: 'QAR',
    status: 'active',
    fees: { fixed: 1, percentage: 1.5 },
    limits: { min: 10, max: 50000 },
    integration: 'API'
  },
  {
    id: 'PM-014',
    name: 'Ooredoo Money',
    nameAr: 'أوريدو موني',
    logo: '📱',
    type: 'wallet',
    country: 'Qatar',
    countryCode: 'QA',
    flag: '🇶🇦',
    currency: 'QAR',
    status: 'active',
    fees: { fixed: 2, percentage: 1.2 },
    limits: { min: 10, max: 30000 },
    integration: 'API'
  }
];

const typeConfig = {
  wallet: { bg: 'bg-[#8b5cf6]/10', text: 'text-[#8b5cf6]', border: 'border-[#8b5cf6]/30', icon: Smartphone },
  bank: { bg: 'bg-[#3b82f6]/10', text: 'text-[#3b82f6]', border: 'border-[#3b82f6]/30', icon: Building },
  gateway: { bg: 'bg-[#6ee7b7]/10', text: 'text-[#6ee7b7]', border: 'border-[#6ee7b7]/30', icon: CreditCardIcon },
  telegram: { bg: 'bg-blue-400/10', text: 'text-blue-400', border: 'border-blue-400/30', icon: Send }
};

export function PaymentMethods() {
  const { language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');

  const filteredMethods = paymentMethodsData.filter(method => {
    const matchesSearch = method.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         method.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (method.nameAr && method.nameAr.includes(searchQuery));
    const matchesType = selectedType === 'all' || method.type === selectedType;
    const matchesCountry = selectedCountry === 'all' || method.countryCode === selectedCountry;
    return matchesSearch && matchesType && matchesCountry;
  });

  const activeMethods = paymentMethodsData.filter(m => m.status === 'active').length;
  const totalMethods = paymentMethodsData.length;
  const countries = [...new Set(paymentMethodsData.map(m => m.countryCode))].length;

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Payment Methods</h1>
          <p className="text-gray-400">Manage and configure payment methods across MENA region</p>
        </div>
        <motion.button
          onClick={() => setShowCreateModal(true)}
          className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2"
          whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
          whileTap={{ scale: 0.95 }}
        >
          <Plus className="w-5 h-5" />
          Add Method
        </motion.button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <CreditCardIcon className="w-6 h-6 text-[#8b5cf6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Methods</p>
            <h3 className="text-3xl font-semibold text-white">{totalMethods}</h3>
            <p className="text-xs text-gray-500">Payment options</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <Check className="w-6 h-6 text-[#6ee7b7]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Active Methods</p>
            <h3 className="text-3xl font-semibold text-white">{activeMethods}</h3>
            <p className="text-xs text-gray-500">Currently enabled</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <Globe className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Countries</p>
            <h3 className="text-3xl font-semibold text-white">{countries}</h3>
            <p className="text-xs text-gray-500">Supported regions</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-blue-400/20 to-blue-600/20">
              <Send className="w-6 h-6 text-blue-400" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Telegram</p>
            <h3 className="text-3xl font-semibold text-white">1</h3>
            <p className="text-xs text-gray-500">Bot integration</p>
          </div>
        </GlassCard>
      </div>

      {/* Filters */}
      <GlassCard className="p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search payment methods..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
            />
          </div>

          <select
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
            className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
          >
            <option value="all">All Countries</option>
            <option value="EG">🇪🇬 Egypt</option>
            <option value="SA">🇸🇦 Saudi Arabia</option>
            <option value="AE">🇦🇪 UAE</option>
            <option value="KW">🇰🇼 Kuwait</option>
            <option value="QA">🇶🇦 Qatar</option>
            <option value="GLOBAL">🌍 Global</option>
          </select>

          <div className="flex gap-2">
            {['all', 'wallet', 'bank', 'gateway', 'telegram'].map((type) => (
              <motion.button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  selectedType === type
                    ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                    : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {type === 'telegram' ? '✈️ Telegram' : type.charAt(0).toUpperCase() + type.slice(1)}
              </motion.button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Payment Methods Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMethods.map((method, index) => {
          const config = typeConfig[method.type];
          const TypeIcon = config.icon;
          
          return (
            <motion.div
              key={method.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard hover className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-14 h-14 rounded-xl ${method.type === 'telegram' ? 'bg-gradient-to-br from-blue-400 to-blue-600' : 'bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6]'} flex items-center justify-center text-3xl`}>
                      {method.logo}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">
                        {language === 'ar' && method.nameAr ? method.nameAr : method.name}
                      </h3>
                      <p className="text-xs text-gray-400 font-mono">{method.id}</p>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-lg hover:bg-white/10 transition-all"
                  >
                    <MoreVertical className="w-5 h-5 text-gray-400" />
                  </motion.button>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Type</span>
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${config.bg} ${config.text} border ${config.border}`}>
                      <TypeIcon className="w-3 h-3" />
                      <span className="text-xs font-medium capitalize">{method.type}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Country</span>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{method.flag}</span>
                      <span className="text-sm text-white">{method.country}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Currency</span>
                    <span className="text-sm font-semibold text-white">{method.currency}</span>
                  </div>

                  {method.telegramBot && (
                    <div className="flex items-center justify-between pt-2 border-t border-white/10">
                      <span className="text-sm text-gray-400">Bot</span>
                      <motion.a
                        href={`https://t.me/${method.telegramBot.replace('@', '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300"
                        whileHover={{ scale: 1.05 }}
                      >
                        {method.telegramBot}
                        <ExternalLink className="w-3 h-3" />
                      </motion.a>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="text-sm text-gray-400">Fees</span>
                    <span className="text-sm font-semibold text-white">
                      {method.fees.fixed > 0 && `${method.fees.fixed} + `}{method.fees.percentage}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Limits</span>
                    <span className="text-sm text-white">
                      {method.limits.min} - {method.limits.max.toLocaleString()}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Integration</span>
                    <span className="text-xs px-2 py-1 rounded-md bg-white/5 text-gray-300">
                      {method.integration}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${method.status === 'active' ? 'bg-[#6ee7b7]' : 'bg-gray-500'}`} 
                         style={{ boxShadow: method.status === 'active' ? '0 0 8px #6ee7b7' : 'none' }} />
                    <span className={`text-sm font-medium ${method.status === 'active' ? 'text-[#6ee7b7]' : 'text-gray-500'}`}>
                      {method.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
                  >
                    <Settings className="w-4 h-4 text-gray-400" />
                  </motion.button>
                </div>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
