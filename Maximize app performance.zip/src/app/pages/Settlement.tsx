import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  CheckCircle,
  Clock,
  AlertCircle,
  Download,
  Building2,
  CreditCard,
  ArrowUpRight
} from 'lucide-react';
import { useState } from 'react';

interface Settlement {
  id: string;
  merchant: string;
  amount: number;
  currency: string;
  period: string;
  transactionCount: number;
  status: 'completed' | 'pending' | 'processing' | 'failed';
  settlementDate: string;
  bankAccount: string;
  fee: number;
}

const mockSettlements: Settlement[] = [
  {
    id: 'STL-001',
    merchant: 'SuperMart Egypt',
    amount: 125400,
    currency: 'EGP',
    period: 'March 1-15, 2026',
    transactionCount: 1247,
    status: 'completed',
    settlementDate: '2026-03-16',
    bankAccount: '****4523',
    fee: 1254
  },
  {
    id: 'STL-002',
    merchant: 'TechStore Electronics',
    amount: 89200,
    currency: 'EGP',
    period: 'March 1-15, 2026',
    transactionCount: 563,
    status: 'processing',
    settlementDate: '2026-03-17',
    bankAccount: '****7821',
    fee: 892
  },
  {
    id: 'STL-003',
    merchant: 'Fashion Hub',
    amount: 67500,
    currency: 'EGP',
    period: 'March 1-15, 2026',
    transactionCount: 892,
    status: 'pending',
    settlementDate: '2026-03-18',
    bankAccount: '****3456',
    fee: 675
  },
  {
    id: 'STL-004',
    merchant: 'Food Delivery Co.',
    amount: 156800,
    currency: 'EGP',
    period: 'March 1-15, 2026',
    transactionCount: 2341,
    status: 'completed',
    settlementDate: '2026-03-16',
    bankAccount: '****9012',
    fee: 1568
  },
  {
    id: 'STL-005',
    merchant: 'Beauty Palace',
    amount: 43200,
    currency: 'EGP',
    period: 'March 1-15, 2026',
    transactionCount: 445,
    status: 'failed',
    settlementDate: '2026-03-17',
    bankAccount: '****6789',
    fee: 432
  }
];

export function Settlement() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'completed' | 'pending' | 'processing' | 'failed'>('all');

  const filteredSettlements = filter === 'all' 
    ? mockSettlements 
    : mockSettlements.filter(s => s.status === filter);

  const totalSettled = mockSettlements
    .filter(s => s.status === 'completed')
    .reduce((sum, s) => sum + s.amount, 0);

  const totalPending = mockSettlements
    .filter(s => s.status === 'pending' || s.status === 'processing')
    .reduce((sum, s) => sum + s.amount, 0);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'pending': return Clock;
      case 'processing': return TrendingUp;
      case 'failed': return AlertCircle;
      default: return Clock;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'from-green-500 to-emerald-500';
      case 'pending': return 'from-yellow-500 to-amber-500';
      case 'processing': return 'from-blue-500 to-cyan-500';
      case 'failed': return 'from-red-500 to-orange-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-white mb-2">Settlement Management</h1>
            <p className="text-gray-400">Track and manage merchant settlements</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
          >
            <Download className="w-5 h-5" />
            Export Report
          </motion.button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { 
            label: 'Total Settled', 
            value: `${totalSettled.toLocaleString()} EGP`, 
            icon: CheckCircle, 
            color: 'from-[#10b981] to-[#059669]',
            trend: '+12.5%'
          },
          { 
            label: 'Pending Settlement', 
            value: `${totalPending.toLocaleString()} EGP`, 
            icon: Clock, 
            color: 'from-[#f59e0b] to-[#d97706]',
            trend: '+5.2%'
          },
          { 
            label: 'This Month', 
            value: `${mockSettlements.length}`, 
            icon: Calendar, 
            color: 'from-[#8b5cf6] to-[#7c3aed]',
            trend: '+8.1%'
          },
          { 
            label: 'Total Fees', 
            value: `${mockSettlements.reduce((sum, s) => sum + s.fee, 0).toLocaleString()} EGP`, 
            icon: DollarSign, 
            color: 'from-[#3b82f6] to-[#2563eb]',
            trend: '+3.7%'
          }
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-xs font-medium text-green-400 flex items-center gap-1">
                    <ArrowUpRight className="w-3 h-3" />
                    {stat.trend}
                  </span>
                </div>
                <p className="text-2xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {['all', 'completed', 'processing', 'pending', 'failed'].map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status as any)}
            className={`px-4 py-2 rounded-xl font-medium transition-all whitespace-nowrap ${
              filter === status
                ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-violet-500/30'
                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      {/* Settlements List */}
      <div className="space-y-4">
        {filteredSettlements.map((settlement, index) => {
          const StatusIcon = getStatusIcon(settlement.status);
          
          return (
            <motion.div
              key={settlement.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden hover:border-white/20 transition-all group"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${getStatusColor(settlement.status)} flex items-center justify-center flex-shrink-0`}>
                    <StatusIcon className="w-7 h-7 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{settlement.merchant}</h3>
                      <span className="text-xs font-medium px-3 py-1 rounded-full bg-white/10 text-gray-300">
                        {settlement.id}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Period</p>
                        <p className="text-sm text-gray-300 font-medium">{settlement.period}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Transactions</p>
                        <p className="text-sm text-gray-300 font-medium">{settlement.transactionCount.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Bank Account</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <CreditCard className="w-4 h-4" />
                          {settlement.bankAccount}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Settlement Date</p>
                        <p className="text-sm text-gray-300 font-medium flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {settlement.settlementDate}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-white">
                          {settlement.amount.toLocaleString()} {settlement.currency}
                        </span>
                        <span className="text-sm text-gray-400">
                          (Fee: {settlement.fee.toLocaleString()} {settlement.currency})
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium flex items-center gap-2 border border-white/10 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
                  >
                    <Building2 className="w-4 h-4" />
                    View Details
                  </motion.button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
