import { motion } from 'motion/react';
import { useState } from 'react';
import { GlassCard } from '../components/GlassCard';
import {
  Plus,
  Users,
  Wallet,
  ChevronRight,
  Search,
  Filter,
  Edit2,
  Trash2,
  DollarSign,
  TrendingUp,
  Building2,
  CheckCircle2,
  Upload
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface WalletPool {
  id: string;
  name: string;
  description: string;
  totalBalance: number;
  currency: string;
  merchantCount: number;
  merchants: string[];
  status: 'active' | 'inactive';
  createdAt: string;
  allocation: {
    allocated: number;
    available: number;
  };
}

const mockPools: WalletPool[] = [
  {
    id: 'POOL-001',
    name: 'Egypt Merchants Pool',
    description: 'Main wallet pool for Egyptian merchants',
    totalBalance: 2500000,
    currency: 'EGP',
    merchantCount: 24,
    merchants: ['TechStore Electronics', 'FashionHub', 'GadgetWorld', 'BookStore'],
    status: 'active',
    createdAt: '2026-01-15',
    allocation: {
      allocated: 1800000,
      available: 700000
    }
  },
  {
    id: 'POOL-002',
    name: 'Saudi Arabia Premium Pool',
    description: 'Premium merchants in KSA region',
    totalBalance: 5000000,
    currency: 'SAR',
    merchantCount: 18,
    merchants: ['Luxury Mall', 'Tech Kingdom', 'Fashion Gallery'],
    status: 'active',
    createdAt: '2026-01-20',
    allocation: {
      allocated: 3200000,
      available: 1800000
    }
  },
  {
    id: 'POOL-003',
    name: 'UAE VIP Pool',
    description: 'High-value merchants in UAE',
    totalBalance: 8500000,
    currency: 'AED',
    merchantCount: 12,
    merchants: ['Dubai Mall Shops', 'Emirates Stores', 'Abu Dhabi Retail'],
    status: 'active',
    createdAt: '2026-02-01',
    allocation: {
      allocated: 6000000,
      available: 2500000
    }
  },
  {
    id: 'POOL-004',
    name: 'Multi-Currency Pool',
    description: 'Cross-border payment pool',
    totalBalance: 1500000,
    currency: 'USD',
    merchantCount: 8,
    merchants: ['Global Tech', 'International Fashion'],
    status: 'inactive',
    createdAt: '2026-02-10',
    allocation: {
      allocated: 900000,
      available: 600000
    }
  }
];

export function WalletPools() {
  const { t, direction } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedPool, setSelectedPool] = useState<WalletPool | null>(null);

  const filteredPools = mockPools.filter(pool =>
    pool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    pool.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const stats = {
    totalPools: mockPools.length,
    activePools: mockPools.filter(p => p.status === 'active').length,
    totalMerchants: mockPools.reduce((sum, p) => sum + p.merchantCount, 0),
    totalBalance: mockPools.reduce((sum, p) => sum + p.totalBalance, 0)
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f1117] via-[#1a1d23] to-[#0f1117] p-4 md:p-8" dir={direction}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              {direction === 'rtl' ? 'مجموعات المحافظ' : 'Wallet Pools'}
            </h1>
            <p className="text-gray-400">
              {direction === 'rtl' 
                ? 'إدارة مجموعات المحافظ وتعيين التجار'
                : 'Manage wallet groups and assign merchants'
              }
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowCreateModal(true)}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold flex items-center gap-2 shadow-lg shadow-[#8b5cf6]/20"
          >
            <Plus className="w-5 h-5" />
            <span>{direction === 'rtl' ? 'إنشاء مجموعة جديدة' : 'Create New Pool'}</span>
          </motion.button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'إجمالي المجموعات' : 'Total Pools'}
                </p>
                <p className="text-3xl font-bold text-white">{stats.totalPools}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 flex items-center justify-center">
                <Wallet className="w-6 h-6 text-[#8b5cf6]" />
              </div>
            </div>
          </GlassCard>

          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'مجموعات نشطة' : 'Active Pools'}
                </p>
                <p className="text-3xl font-bold text-green-400">{stats.activePools}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400/20 to-green-500/20 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-400" />
              </div>
            </div>
          </GlassCard>

          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'إجمالي التجار' : 'Total Merchants'}
                </p>
                <p className="text-3xl font-bold text-white">{stats.totalMerchants}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400/20 to-blue-500/20 flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-400" />
              </div>
            </div>
          </GlassCard>

          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm mb-1">
                  {direction === 'rtl' ? 'الرصيد الإجمالي' : 'Total Balance'}
                </p>
                <p className="text-2xl font-bold text-white">
                  ${(stats.totalBalance / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400/20 to-yellow-500/20 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-yellow-400" />
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Search and Filter */}
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'right-4' : 'left-4'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={direction === 'rtl' ? 'ابحث عن مجموعة...' : 'Search pools...'}
              className={`w-full h-14 ${direction === 'rtl' ? 'pr-12 pl-4' : 'pl-12 pr-4'} rounded-2xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]/50 focus:bg-white/10 transition-all`}
            />
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="h-14 px-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all flex items-center gap-2"
          >
            <Filter className="w-5 h-5 text-gray-300" />
            <span className="text-gray-300">{direction === 'rtl' ? 'تصفية' : 'Filter'}</span>
          </motion.button>
        </div>
      </div>

      {/* Pools Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredPools.map((pool, index) => (
          <motion.div
            key={pool.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <GlassCard className="hover:border-[#8b5cf6]/30 transition-all cursor-pointer group">
              {/* Pool Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                    <Wallet className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">{pool.name}</h3>
                    <p className="text-sm text-gray-400">{pool.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        pool.status === 'active' 
                          ? 'bg-green-400/20 text-green-400 border border-green-400/30'
                          : 'bg-gray-400/20 text-gray-400 border border-gray-400/30'
                      }`}>
                        {pool.status === 'active' 
                          ? (direction === 'rtl' ? 'نشط' : 'Active')
                          : (direction === 'rtl' ? 'غير نشط' : 'Inactive')
                        }
                      </span>
                      <span className="text-xs text-gray-500">
                        {direction === 'rtl' ? 'تم الإنشاء: ' : 'Created: '}{pool.createdAt}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
                  >
                    <Edit2 className="w-4 h-4 text-gray-400" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-xl bg-white/5 hover:bg-red-500/20 transition-all"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </motion.button>
                </div>
              </div>

              {/* Balance Info */}
              <div className="grid grid-cols-3 gap-4 mb-4 p-4 rounded-xl bg-white/5 border border-white/10">
                <div>
                  <p className="text-xs text-gray-500 mb-1">
                    {direction === 'rtl' ? 'الرصيد الكلي' : 'Total Balance'}
                  </p>
                  <p className="text-lg font-bold text-white">
                    {pool.totalBalance.toLocaleString()} <span className="text-sm text-[#8b5cf6]">{pool.currency}</span>
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">
                    {direction === 'rtl' ? 'مخصص' : 'Allocated'}
                  </p>
                  <p className="text-lg font-bold text-yellow-400">
                    {pool.allocation.allocated.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">
                    {direction === 'rtl' ? 'متاح' : 'Available'}
                  </p>
                  <p className="text-lg font-bold text-green-400">
                    {pool.allocation.available.toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Merchants */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-gray-400" />
                    <p className="text-sm text-gray-400">
                      {direction === 'rtl' ? 'التجار المعينون' : 'Assigned Merchants'}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-[#8b5cf6]">
                    {pool.merchantCount} {direction === 'rtl' ? 'تاجر' : 'merchants'}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {pool.merchants.slice(0, 3).map((merchant, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-xs text-gray-300"
                    >
                      {merchant}
                    </span>
                  ))}
                  {pool.merchantCount > 3 && (
                    <span className="px-3 py-1 rounded-lg bg-[#8b5cf6]/20 border border-[#8b5cf6]/30 text-xs text-[#8b5cf6] font-semibold">
                      +{pool.merchantCount - 3} {direction === 'rtl' ? 'المزيد' : 'more'}
                    </span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedPool(pool)}
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30 text-white font-medium hover:from-[#8b5cf6]/30 hover:to-[#3b82f6]/30 transition-all flex items-center justify-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  <span>{direction === 'rtl' ? 'إدارة التجار' : 'Manage Merchants'}</span>
                  <ChevronRight className={`w-4 h-4 ${direction === 'rtl' ? 'rotate-180' : ''}`} />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-6 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
                >
                  <DollarSign className="w-5 h-5 text-gray-300" />
                </motion.button>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Create Pool Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl w-full bg-[#1a1d23] border border-white/10 rounded-3xl p-8"
          >
            <h2 className="text-2xl font-bold text-white mb-6">
              {direction === 'rtl' ? 'إنشاء مجموعة محفظة جديدة' : 'Create New Wallet Pool'}
            </h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'اسم المجموعة' : 'Pool Name'}
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل اسم المجموعة' : 'Enter pool name'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الوصف' : 'Description'}
                </label>
                <textarea
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50 resize-none"
                  rows={3}
                  placeholder={direction === 'rtl' ? 'أدخل الوصف' : 'Enter description'}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">
                    {direction === 'rtl' ? 'العملة' : 'Currency'}
                  </label>
                  <select className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50">
                    <option value="EGP">EGP - Egyptian Pound</option>
                    <option value="SAR">SAR - Saudi Riyal</option>
                    <option value="AED">AED - UAE Dirham</option>
                    <option value="USD">USD - US Dollar</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm text-gray-400 mb-2">
                    {direction === 'rtl' ? 'الرصيد الأولي' : 'Initial Balance'}
                  </label>
                  <input
                    type="number"
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                    placeholder="0.00"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowCreateModal(false)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 font-medium hover:bg-white/10 transition-all"
              >
                {direction === 'rtl' ? 'إلغاء' : 'Cancel'}
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg shadow-[#8b5cf6]/20"
              >
                {direction === 'rtl' ? 'إنشاء المجموعة' : 'Create Pool'}
              </motion.button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
