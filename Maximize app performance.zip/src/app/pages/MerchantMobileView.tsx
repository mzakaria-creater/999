import { motion } from 'motion/react';
import { X, Globe, Calendar, Users, TrendingUp, CheckCircle, Clock, XCircle, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { GlassCard } from '../components/GlassCard';
import { MobileStatusBar } from '../components/MobileStatusBar';
import { FxRateBar } from '../components/FxRateBar';
import { useState } from 'react';

interface MerchantData {
  id: string;
  name: string;
  legalName: string;
  country: string;
  flag: string;
  merchantId: string;
  status: 'active' | 'pending_kyc' | 'suspended';
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  volumeToday: number;
  joined: string;
  group: string;
  apiVersion: string;
}

const merchants: MerchantData[] = [
  {
    id: '1',
    name: 'CashPlus Maroc',
    legalName: 'CashPlus SARL Morocco',
    country: 'Egypt',
    flag: '🇪🇬',
    merchantId: 'EG-2023-091244',
    status: 'pending_kyc',
    tier: 'bronze',
    volumeToday: 223800,
    joined: 'Sep 2023',
    group: 'North Africa',
    apiVersion: 'v2.4',
  },
  {
    id: '2',
    name: 'Delta Digital',
    legalName: 'Delta Digital Payments Corp',
    country: 'Egypt',
    flag: '🇪🇬',
    merchantId: 'EG-2020-051882',
    status: 'suspended',
    tier: 'silver',
    volumeToday: 0,
    joined: 'Aug 2020',
    group: 'BNPL Egypt',
    apiVersion: 'v2.4',
  },
  {
    id: '3',
    name: 'NGPay Financial',
    legalName: 'NGPay Financial Group',
    country: 'Egypt',
    flag: '🇪🇬',
    merchantId: 'MID-30041',
    status: 'active',
    tier: 'gold',
    volumeToday: 1250000,
    joined: 'Jan 2022',
    group: 'Egypt PSP',
    apiVersion: 'v2.4',
  },
];

const paymentMethods = [
  {
    id: '1',
    name: 'Vodafone Cash',
    type: 'Mobile Wallet',
    icon: 'VO',
    color: 'bg-red-500',
    deposit: true,
    withdrawal: true,
    enabled: true,
  },
  {
    id: '2',
    name: 'Orange Cash',
    type: 'Mobile Wallet',
    icon: 'OR',
    color: 'bg-orange-500',
    deposit: true,
    withdrawal: false,
    enabled: true,
  },
  {
    id: '3',
    name: 'InstaPay',
    type: 'Bank Transfer',
    icon: 'IN',
    color: 'bg-blue-500',
    deposit: true,
    withdrawal: true,
    enabled: true,
  },
  {
    id: '4',
    name: 'Fawry',
    type: 'Cash Network',
    icon: 'FA',
    color: 'bg-yellow-600',
    deposit: true,
    withdrawal: true,
    enabled: true,
  },
  {
    id: '5',
    name: 'Banque Misr',
    type: 'Bank Card',
    icon: 'BA',
    color: 'bg-indigo-500',
    deposit: true,
    withdrawal: true,
    enabled: true,
  },
  {
    id: '6',
    name: 'CIB',
    type: 'Bank Card',
    icon: 'CI',
    color: 'bg-purple-500',
    deposit: false,
    withdrawal: true,
    enabled: true,
  },
];

export default function MerchantMobileView() {
  const { t, direction } = useLanguage();
  const [selectedMerchant, setSelectedMerchant] = useState(merchants[0]);
  const [activeTab, setActiveTab] = useState<'overview' | 'payment-methods' | 'corridors' | 'api'>('payment-methods');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/10 text-green-400 border-green-400/30';
      case 'pending_kyc':
        return 'bg-yellow-500/10 text-yellow-400 border-yellow-400/30';
      case 'suspended':
        return 'bg-red-500/10 text-red-400 border-red-400/30';
      default:
        return 'bg-gray-500/10 text-gray-400 border-gray-400/30';
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'platinum':
        return 'bg-gray-200 text-gray-800';
      case 'gold':
        return 'bg-yellow-400 text-yellow-900';
      case 'silver':
        return 'bg-gray-300 text-gray-700';
      case 'bronze':
        return 'bg-orange-400 text-orange-900';
      default:
        return 'bg-gray-400 text-gray-700';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-EG', {
      style: 'currency',
      currency: 'EGP',
      minimumFractionDigits: 1,
      maximumFractionDigits: 1,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Mobile Status Bar */}
      <MobileStatusBar />

      {/* FX Rate Bar */}
      <FxRateBar />

      {/* Merchant Header */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 border-b border-white/10">
        <div className="px-4 py-4">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              {/* Merchant Avatar */}
              <div className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center">
                <span className="text-xl font-bold text-white">
                  {selectedMerchant.name.substring(0, 2).toUpperCase()}
                </span>
              </div>

              <div>
                <h1 className="text-lg font-bold text-white mb-0.5">
                  {selectedMerchant.name}
                </h1>
                <p className="text-xs text-white/70">
                  {selectedMerchant.legalName}
                </p>
              </div>
            </div>

            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <X className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Merchant Info Row */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-lg px-2.5 py-1.5 border border-white/20">
              <span className="text-base">{selectedMerchant.flag}</span>
              <span className="text-xs font-medium text-white">
                {selectedMerchant.country}
              </span>
            </div>

            <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-lg px-2.5 py-1.5 border border-white/20">
              <span className="text-[10px] font-mono text-white/70">
                {selectedMerchant.merchantId}
              </span>
            </div>

            <div className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 border ${getStatusColor(selectedMerchant.status)}`}>
              <span className="text-xs font-semibold capitalize">
                {selectedMerchant.status === 'pending_kyc' ? 'Pending KYC' : selectedMerchant.status}
              </span>
            </div>
          </div>

          {/* Tier Badge */}
          <div className="mt-3">
            <div className={`inline-flex items-center gap-1.5 ${getTierColor(selectedMerchant.tier)} rounded-full px-3 py-1`}>
              <div className="w-2 h-2 rounded-full bg-current opacity-50" />
              <span className="text-xs font-bold capitalize">
                {selectedMerchant.tier}
              </span>
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-px bg-white/10">
          <div className="bg-blue-700/30 backdrop-blur-sm px-4 py-3 text-center">
            <div className="text-[10px] font-medium text-white/60 mb-1">
              VOLUME TODAY
            </div>
            <div className="text-base font-bold text-white">
              {formatCurrency(selectedMerchant.volumeToday)}
            </div>
          </div>

          <div className="bg-blue-700/30 backdrop-blur-sm px-4 py-3 text-center border-x border-white/10">
            <div className="text-[10px] font-medium text-white/60 mb-1">
              JOINED
            </div>
            <div className="text-base font-bold text-white">
              {selectedMerchant.joined}
            </div>
          </div>

          <div className="bg-blue-700/30 backdrop-blur-sm px-4 py-3 text-center">
            <div className="text-[10px] font-medium text-white/60 mb-1">
              GROUP
            </div>
            <div className="text-sm font-bold text-white">
              {selectedMerchant.group}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 px-4 py-2 overflow-x-auto">
          {[
            { id: 'overview', label: 'Overview', icon: TrendingUp },
            { id: 'payment-methods', label: 'Payment Methods', icon: CheckCircle },
            { id: 'corridors', label: 'Corridors', icon: Globe },
            { id: 'api', label: 'API & Docs', icon: Users },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white text-blue-700'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-4">
        {activeTab === 'payment-methods' && (
          <div className="space-y-3">
            {paymentMethods.map((method, index) => (
              <motion.div
                key={method.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <GlassCard className="p-4">
                  <div className="flex items-center gap-3">
                    {/* Method Icon */}
                    <div className={`w-12 h-12 ${method.color} rounded-xl flex items-center justify-center`}>
                      <span className="text-base font-bold text-white">
                        {method.icon}
                      </span>
                    </div>

                    {/* Method Info */}
                    <div className="flex-1">
                      <h3 className="text-sm font-bold text-white mb-0.5">
                        {method.name}
                      </h3>
                      <p className="text-xs text-white/60">
                        {method.type}
                      </p>
                    </div>

                    {/* Capabilities */}
                    <div className="flex items-center gap-2">
                      {method.deposit && (
                        <div className="flex items-center gap-1 text-green-400">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span className="text-[10px] font-semibold">Deposit</span>
                        </div>
                      )}
                      {method.withdrawal && (
                        <div className="flex items-center gap-1 text-green-400">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span className="text-[10px] font-semibold">Withdrawal</span>
                        </div>
                      )}
                    </div>

                    {/* Toggle */}
                    <button
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        method.enabled ? 'bg-blue-600' : 'bg-gray-600'
                      }`}
                    >
                      <motion.div
                        className="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-lg"
                        animate={{ x: method.enabled ? 26 : 2 }}
                        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      />
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'overview' && (
          <div className="space-y-4">
            <GlassCard className="p-4">
              <h3 className="text-sm font-bold text-white mb-3">Volume - Last 7 Days</h3>
              <div className="h-32 flex items-end gap-2">
                {[42, 58, 45, 72, 65, 88, 95].map((height, index) => (
                  <div key={index} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className="w-full bg-gradient-to-t from-blue-600 to-cyan-400 rounded-t-lg"
                      style={{ height: `${height}%` }}
                    />
                    <span className="text-[9px] text-white/50">
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][index]}
                    </span>
                  </div>
                ))}
              </div>
            </GlassCard>

            <div className="grid grid-cols-2 gap-3">
              <GlassCard className="p-4">
                <div className="text-xs text-white/60 mb-1">Success Rate</div>
                <div className="text-2xl font-bold text-green-400">97.3%</div>
              </GlassCard>

              <GlassCard className="p-4">
                <div className="text-xs text-white/60 mb-1">Avg Transaction</div>
                <div className="text-2xl font-bold text-white">EGP 1,840</div>
              </GlassCard>

              <GlassCard className="p-4">
                <div className="text-xs text-white/60 mb-1">Complaints</div>
                <div className="text-2xl font-bold text-orange-400">3 open</div>
              </GlassCard>

              <GlassCard className="p-4">
                <div className="text-xs text-white/60 mb-1">Chargebacks</div>
                <div className="text-2xl font-bold text-white">0.12%</div>
              </GlassCard>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-xl border-t border-white/10">
        <div className="grid grid-cols-5 gap-1 px-2 py-2">
          {[
            { icon: '🏠', label: 'Dashboard', active: false },
            { icon: '💳', label: 'Transactions', active: false },
            { icon: '🏪', label: 'Merchants', active: true },
            { icon: '👛', label: 'Wallets', active: false },
            { icon: '☰', label: 'nav.more', active: false },
          ].map((item, index) => (
            <button
              key={index}
              className={`flex flex-col items-center gap-1 py-2 rounded-lg transition-colors ${
                item.active ? 'bg-white/10' : 'hover:bg-white/5'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className={`text-[10px] font-semibold ${
                item.active ? 'text-white' : 'text-white/60'
              }`}>
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
