import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { GlassCard } from '../components/GlassCard';
import { motion, AnimatePresence } from 'motion/react';
import {
  CreditCard,
  Smartphone,
  Bitcoin,
  Zap,
  CheckCircle,
  XCircle,
  ArrowLeft,
  Loader,
  AlertCircle,
  ExternalLink,
  Copy,
  QrCode,
  Phone,
  Mail,
  DollarSign,
  Info
} from 'lucide-react';
import {
  paymentService,
  type PaymentProvider,
  type PaymentRequest,
  type PaymentResponse
} from '../services/payment_service';
import { useLanguage } from '../context/LanguageContext';

const PROVIDER_ICONS: Record<PaymentProvider, any> = {
  paypal: CreditCard,
  binance: Bitcoin,
  okx: Bitcoin,
  vodafone: Smartphone,
  instapay: Zap
};

const PROVIDER_COLORS: Record<PaymentProvider, string> = {
  paypal: 'from-[#0070ba] to-[#003087]',
  binance: 'from-[#f3ba2f] to-[#f0b90b]',
  okx: 'from-[#0052ff] to-[#00419e]',
  vodafone: 'from-[#e60000] to-[#c00000]',
  instapay: 'from-[#6ee7b7] to-[#059669]'
};

export function PaymentCheckout() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // Payment state
  const [selectedProvider, setSelectedProvider] = useState<PaymentProvider | null>(null);
  const [amount, setAmount] = useState<string>(searchParams.get('amount') || '');
  const [currency, setCurrency] = useState<string>(searchParams.get('currency') || 'USD');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [description, setDescription] = useState('');
  
  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentResponse, setPaymentResponse] = useState<PaymentResponse | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Available payment methods
  const [availableMethods, setAvailableMethods] = useState(
    paymentService.getPaymentMethods()
  );

  useEffect(() => {
    // Update available methods based on currency
    setAvailableMethods(paymentService.getPaymentMethods(currency));
  }, [currency]);

  const handleAmountChange = (value: string) => {
    // Only allow numbers and decimal point
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    }
  };

  const calculateFees = () => {
    if (!selectedProvider || !amount) return 0;
    return paymentService.calculateFees(parseFloat(amount), selectedProvider);
  };

  const calculateTotal = () => {
    if (!selectedProvider || !amount) return 0;
    return paymentService.calculateTotal(parseFloat(amount), selectedProvider);
  };

  const handlePayment = async () => {
    if (!selectedProvider || !amount) {
      setError('Please select payment method and enter amount');
      return;
    }

    const method = paymentService.getPaymentMethod(selectedProvider);
    if (!method) return;

    // Validate required fields
    if (selectedProvider === 'vodafone' && !customerPhone) {
      setError('Phone number required for Vodafone Cash');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const request: PaymentRequest = {
        id: `pay_${Date.now()}`,
        amount: parseFloat(amount),
        currency,
        provider: selectedProvider,
        merchantId: 'merchant_123',
        customerEmail: customerEmail || undefined,
        customerPhone: customerPhone || undefined,
        description: description || `Payment via ${method.displayName}`,
        returnUrl: window.location.origin + '/payment-success',
        cancelUrl: window.location.origin + '/payment-checkout',
        webhookUrl: window.location.origin + '/api/webhooks/payment'
      };

      const response = await paymentService.createPayment(request);
      setPaymentResponse(response);

      if (response.success) {
        // Redirect to payment URL if available
        if (response.paymentUrl) {
          window.location.href = response.paymentUrl;
        } else {
          // Show success with QR code or reference
          setShowSuccess(true);
        }
      } else {
        setError(response.error || response.message);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payment failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Show toast notification
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  if (showSuccess && paymentResponse) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full max-w-lg"
        >
          <GlassCard className="p-8 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring' }}
              className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-[#6ee7b7] to-[#059669] flex items-center justify-center"
            >
              <CheckCircle className="w-10 h-10 text-white" />
            </motion.div>

            <h2 className="text-2xl font-bold text-white mb-2">
              Payment Initiated
            </h2>
            <p className="text-gray-400 mb-6">
              {paymentResponse.message}
            </p>

            {paymentResponse.qrCode && (
              <div className="mb-6 p-4 rounded-xl bg-white">
                <div className="w-48 h-48 mx-auto bg-gray-200 rounded-xl flex items-center justify-center">
                  <QrCode className="w-12 h-12 text-gray-400" />
                  <p className="text-xs text-gray-500 ml-2">QR Code</p>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Scan with your app
                </p>
              </div>
            )}

            {paymentResponse.reference && (
              <div className="mb-6">
                <p className="text-sm text-gray-400 mb-2">Reference Number</p>
                <div className="flex items-center gap-2 justify-center">
                  <code className="px-4 py-2 rounded-lg bg-white/10 text-white font-mono">
                    {paymentResponse.reference}
                  </code>
                  <button
                    onClick={() => copyToClipboard(paymentResponse.reference!)}
                    className="p-2 rounded-lg hover:bg-white/10 transition-colors"
                  >
                    <Copy className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-2 mb-6 text-left">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Amount</span>
                <span className="text-white font-semibold">
                  {formatCurrency(paymentResponse.amount)} {paymentResponse.currency}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Transaction ID</span>
                <span className="text-white font-mono text-xs">
                  {paymentResponse.transactionId}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Status</span>
                <span className="px-2 py-1 rounded-full text-xs bg-[#fbbf24]/20 text-[#fbbf24]">
                  {paymentResponse.status}
                </span>
              </div>
            </div>

            <button
              onClick={() => navigate('/transactions')}
              className="w-full px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold hover:shadow-xl transition-all"
            >
              View Transaction
            </button>
          </GlassCard>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate(-1)}
          className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Payment Checkout
          </h1>
          <p className="text-gray-400">
            Choose your preferred payment method
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payment Methods */}
        <div className="lg:col-span-2 space-y-4">
          <GlassCard className="p-6">
            <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Select Payment Method
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {availableMethods.map((method, index) => {
                const Icon = PROVIDER_ICONS[method.id];
                const isSelected = selectedProvider === method.id;

                return (
                  <motion.button
                    key={method.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => setSelectedProvider(method.id)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      isSelected
                        ? 'border-[#8b5cf6] bg-white/10'
                        : 'border-white/10 hover:border-white/20 bg-white/5'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg bg-gradient-to-br ${PROVIDER_COLORS[method.id]}`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-white mb-1">
                          {method.displayName}
                        </h3>
                        <p className="text-xs text-gray-400 mb-2">
                          {method.description}
                        </p>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <span className="px-2 py-0.5 rounded-full bg-white/10 text-gray-300">
                            {method.processingTime}
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-white/10 text-gray-300">
                            {method.fees.percentage}% fee
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </GlassCard>

          {/* Payment Details */}
          <GlassCard className="p-6">
            <h2 className="text-lg font-bold text-white mb-4">
              Payment Details
            </h2>

            <div className="space-y-4">
              {/* Amount */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Amount *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={amount}
                    onChange={(e) => handleAmountChange(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-4 py-3 pl-12 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]"
                  />
                  <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                </div>
              </div>

              {/* Currency */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Currency *
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]"
                >
                  <option value="USD">USD - US Dollar</option>
                  <option value="EUR">EUR - Euro</option>
                  <option value="GBP">GBP - British Pound</option>
                  <option value="EGP">EGP - Egyptian Pound</option>
                  <option value="USDT">USDT - Tether</option>
                  <option value="BTC">BTC - Bitcoin</option>
                </select>
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Email
                </label>
                <div className="relative">
                  <input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 pl-12 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]"
                  />
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                </div>
              </div>

              {/* Phone (required for Vodafone) */}
              {selectedProvider === 'vodafone' && (
                <div>
                  <label className="block text-sm text-gray-400 mb-2">
                    Phone Number *
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+20 1234567890"
                      className="w-full px-4 py-3 pl-12 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6]"
                    />
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  </div>
                </div>
              )}

              {/* Description */}
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Description (Optional)
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Payment for..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] resize-none"
                />
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-6 space-y-4">
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-white mb-4">
                Order Summary
              </h2>

              {selectedProvider && amount && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-3"
                >
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Subtotal</span>
                    <span className="text-white">
                      {formatCurrency(parseFloat(amount))} {currency}
                    </span>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Processing Fee</span>
                    <span className="text-white">
                      {formatCurrency(calculateFees())} {currency}
                    </span>
                  </div>

                  <div className="h-px bg-white/10 my-3" />

                  <div className="flex justify-between">
                    <span className="text-white font-semibold">Total</span>
                    <span className="text-xl font-bold text-white">
                      {formatCurrency(calculateTotal())} {currency}
                    </span>
                  </div>
                </motion.div>
              )}

              {!selectedProvider && (
                <div className="text-center py-8 text-gray-400 text-sm">
                  Select a payment method to see details
                </div>
              )}
            </GlassCard>

            {/* Error Message */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <GlassCard className="p-4 border-2 border-[#f87171]/50 bg-[#f87171]/10">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-[#f87171] flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-white">{error}</p>
                    </div>
                  </GlassCard>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Pay Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handlePayment}
              disabled={!selectedProvider || !amount || isProcessing}
              className="w-full px-6 py-4 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <Loader className="w-5 h-5 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Pay {amount && formatCurrency(calculateTotal())} {currency}
                </>
              )}
            </motion.button>

            {/* Security Info */}
            <GlassCard className="p-4 bg-white/5">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-[#6ee7b7] flex-shrink-0 mt-0.5" />
                <p className="text-xs text-gray-400">
                  Your payment is secure and encrypted. We never store your payment credentials.
                </p>
              </div>
            </GlassCard>
          </div>
        </div>
      </div>
    </div>
  );
}
