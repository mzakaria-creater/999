import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  Shield,
  HelpCircle,
  ArrowRight
} from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useRole, UserRole } from '../context/RoleContext';

// Mock user database for demo
const mockUsers = [
  { email: 'owner@ontarget.io', password: 'demo', role: 'Owner' as UserRole, name: 'John Owner', merchantId: null },
  { email: 'admin@ontarget.io', password: 'demo', role: 'Admin' as UserRole, name: 'Jane Admin', merchantId: null },
  { email: 'finance@ontarget.io', password: 'demo', role: 'Finance' as UserRole, name: 'Bob Finance', merchantId: null },
  { email: 'ops@ontarget.io', password: 'demo', role: 'Operations' as UserRole, name: 'Sarah Operations', merchantId: null },
  { email: 'merchant@ontarget.io', password: 'demo', role: 'Merchant' as UserRole, name: 'Mike Merchant', merchantId: 'MCH-1001' },
  { email: 'viewer@ontarget.io', password: 'demo', role: 'Viewer' as UserRole, name: 'Lisa Viewer', merchantId: null }
];

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const navigate = useNavigate();
  const { setRole } = useRole();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      const user = mockUsers.find(u => u.email === email && u.password === password);
      
      if (user) {
        // Set role in context
        setRole(user.role);
        
        // Store user data
        localStorage.setItem('user', JSON.stringify({
          email: user.email,
          name: user.name,
          role: user.role,
          merchantId: user.merchantId
        }));

        if (rememberMe) {
          localStorage.setItem('rememberMe', 'true');
        }

        // Navigate to dashboard
        navigate('/');
      } else {
        setError('Invalid email or password');
      }
      
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#121417] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 -left-48 w-96 h-96 bg-[#8b5cf6] rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-pulse" />
        <div className="absolute bottom-1/4 -right-48 w-96 h-96 bg-[#3b82f6] rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#6ee7b7] rounded-full mix-blend-multiply filter blur-[128px] opacity-10 animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo and Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center shadow-2xl" style={{ boxShadow: '0 0 60px rgba(139, 92, 246, 0.4)' }}>
            <span className="text-white font-bold text-3xl">OT</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">OnTarget PSP</h1>
          <p className="text-gray-400">Payment Gateway Platform</p>
        </motion.div>

        {/* Login Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <GlassCard className="p-8">
            <h2 className="text-2xl font-semibold text-white mb-2">Welcome Back</h2>
            <p className="text-gray-400 text-sm mb-6">Sign in to access your dashboard</p>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 rounded-xl bg-[#f87171]/10 border border-[#f87171]/30 flex items-start gap-3"
              >
                <Lock className="w-5 h-5 text-[#f87171] flex-shrink-0 mt-0.5" />
                <p className="text-sm text-[#f87171]">{error}</p>
              </motion.div>
            )}

            <form onSubmit={handleLogin} className="space-y-6">
              {/* Email Field */}
              <div className="space-y-2">
                <label className="text-sm text-gray-300 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                />
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <label className="text-sm text-gray-300 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded bg-white/5 border-white/10 text-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
                  />
                  <span className="text-sm text-gray-300">Remember me</span>
                </label>
                <button
                  type="button"
                  className="text-sm text-[#8b5cf6] hover:text-[#7c4ee4] transition-colors"
                >
                  Forgot password?
                </button>
              </div>

              {/* Login Button */}
              <motion.button
                type="submit"
                disabled={isLoading}
                className="w-full py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                whileHover={!isLoading ? { scale: 1.02, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' } : {}}
                whileTap={!isLoading ? { scale: 0.98 } : {}}
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    Sign In
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </motion.button>
            </form>

            {/* Role-Aware Note */}
            <div className="mt-6 pt-6 border-t border-white/10">
              <div className="flex items-start gap-3 p-4 rounded-xl bg-gradient-to-r from-[#6ee7b7]/10 to-[#06b6d4]/10 border border-[#6ee7b7]/20">
                <Shield className="w-5 h-5 text-[#6ee7b7] flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-white mb-1">Secure Role-Based Access</h4>
                  <p className="text-xs text-gray-400">
                    Upon login, the system automatically detects your role and permissions, directing you to the appropriate dashboard with customized access.
                  </p>
                </div>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Support Contact */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mt-6 text-center"
        >
          <button className="flex items-center gap-2 mx-auto text-sm text-gray-400 hover:text-white transition-colors">
            <HelpCircle className="w-4 h-4" />
            Need help? Contact support
          </button>
        </motion.div>

        {/* Demo Credentials */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-6"
        >
          <GlassCard className="p-4">
            <h4 className="text-xs font-semibold text-gray-400 mb-3 uppercase">Demo Credentials</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {mockUsers.map((user) => (
                <motion.button
                  key={user.email}
                  onClick={() => {
                    setEmail(user.email);
                    setPassword(user.password);
                  }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all text-left"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <p className="text-white font-medium">{user.role}</p>
                  <p className="text-gray-400 text-[10px] truncate">{user.email}</p>
                </motion.button>
              ))}
            </div>
            <p className="text-[10px] text-gray-500 mt-2 text-center">
              Click any role to autofill credentials • Password: demo
            </p>
          </GlassCard>
        </motion.div>
      </div>
    </div>
  );
}
