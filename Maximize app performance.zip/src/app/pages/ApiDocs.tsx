import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Code,
  Copy,
  Check,
  Key,
  Send,
  Book,
  Terminal,
  Shield
} from 'lucide-react';
import { useState } from 'react';

interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  category: string;
}

const apiEndpoints: ApiEndpoint[] = [
  { method: 'POST', path: '/v1/payments', description: 'Create a new payment', category: 'Payments' },
  { method: 'GET', path: '/v1/payments/:id', description: 'Retrieve payment details', category: 'Payments' },
  { method: 'GET', path: '/v1/payments', description: 'List all payments', category: 'Payments' },
  { method: 'POST', path: '/v1/refunds', description: 'Create a refund', category: 'Refunds' },
  { method: 'GET', path: '/v1/refunds/:id', description: 'Retrieve refund details', category: 'Refunds' },
  { method: 'POST', path: '/v1/customers', description: 'Create a customer', category: 'Customers' },
  { method: 'GET', path: '/v1/customers/:id', description: 'Retrieve customer details', category: 'Customers' },
  { method: 'GET', path: '/v1/transactions', description: 'List all transactions', category: 'Transactions' },
  { method: 'POST', path: '/v1/webhooks', description: 'Configure webhooks', category: 'Webhooks' },
];

const codeExamples = {
  createPayment: `curl https://api.ontarget.io/v1/payments \\
  -u sk_live_51H8x...: \\
  -d amount=2999 \\
  -d currency=usd \\
  -d description="Premium subscription" \\
  -d customer="cus_abc123"`,

  retrievePayment: `curl https://api.ontarget.io/v1/payments/pay_1234 \\
  -u sk_live_51H8x...:`,

  createRefund: `curl https://api.ontarget.io/v1/refunds \\
  -u sk_live_51H8x...: \\
  -d payment="pay_1234" \\
  -d amount=1000 \\
  -d reason="customer_request"`
};

const responseExamples = {
  createPayment: `{
  "id": "pay_1234567890",
  "object": "payment",
  "amount": 2999,
  "currency": "usd",
  "status": "succeeded",
  "created": 1710345600,
  "description": "Premium subscription",
  "customer": "cus_abc123",
  "payment_method": "card_xyz789"
}`,

  error: `{
  "error": {
    "type": "invalid_request_error",
    "message": "Invalid API key provided",
    "code": "invalid_api_key"
  }
}`
};

export function ApiDocs() {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', ...Array.from(new Set(apiEndpoints.map(e => e.category)))];
  
  const filteredEndpoints = selectedCategory === 'All' 
    ? apiEndpoints 
    : apiEndpoints.filter(e => e.category === selectedCategory);

  const copyCode = (code: string, section: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const methodColors = {
    GET: { bg: 'bg-[#6ee7b7]/10', text: 'text-[#6ee7b7]', border: 'border-[#6ee7b7]/30' },
    POST: { bg: 'bg-[#3b82f6]/10', text: 'text-[#3b82f6]', border: 'border-[#3b82f6]/30' },
    PUT: { bg: 'bg-[#fbbf24]/10', text: 'text-[#fbbf24]', border: 'border-[#fbbf24]/30' },
    DELETE: { bg: 'bg-[#f87171]/10', text: 'text-[#f87171]', border: 'border-[#f87171]/30' }
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">API Documentation</h1>
        <p className="text-gray-400">Complete API reference for OnTarget PSP integration</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <Code className="w-6 h-6 text-[#8b5cf6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">API Version</p>
            <h3 className="text-2xl font-semibold text-white">v1.0</h3>
            <p className="text-xs text-gray-500">Latest stable</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <Terminal className="w-6 h-6 text-[#6ee7b7]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Endpoints</p>
            <h3 className="text-2xl font-semibold text-white">{apiEndpoints.length}</h3>
            <p className="text-xs text-gray-500">Available APIs</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <Book className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Libraries</p>
            <h3 className="text-2xl font-semibold text-white">6</h3>
            <p className="text-xs text-gray-500">SDKs available</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#f87171]/20 to-[#ef4444]/20">
              <Shield className="w-6 h-6 text-[#f87171]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Uptime</p>
            <h3 className="text-2xl font-semibold text-white">99.99%</h3>
            <p className="text-xs text-gray-500">Last 30 days</p>
          </div>
        </GlassCard>
      </div>

      {/* API Keys Section */}
      <GlassCard className="p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6]">
            <Key className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-white">API Keys</h2>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-gray-300">Publishable Key (Public)</label>
              <span className="text-xs text-gray-400">Use in client-side code</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value="pk_live_51H8x7Y2eZvKYlo2C..."
                readOnly
                className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white font-mono text-sm focus:outline-none"
              />
              <motion.button
                onClick={() => copyCode('pk_live_51H8x7Y2eZvKYlo2C...', 'public-key')}
                className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {copiedSection === 'public-key' ? (
                  <Check className="w-5 h-5 text-[#6ee7b7]" />
                ) : (
                  <Copy className="w-5 h-5 text-gray-400" />
                )}
              </motion.button>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-gray-300">Secret Key (Private)</label>
              <span className="text-xs text-gray-400">Use in server-side code only</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="password"
                value="sk_live_51H8x7Y2eZvKYlo2C..."
                readOnly
                className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white font-mono text-sm focus:outline-none"
              />
              <motion.button
                onClick={() => copyCode('sk_live_51H8x7Y2eZvKYlo2C...', 'secret-key')}
                className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {copiedSection === 'secret-key' ? (
                  <Check className="w-5 h-5 text-[#6ee7b7]" />
                ) : (
                  <Copy className="w-5 h-5 text-gray-400" />
                )}
              </motion.button>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* API Endpoints */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-white">API Endpoints</h2>
          <div className="flex gap-2">
            {categories.map((category) => (
              <motion.button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          {filteredEndpoints.map((endpoint, index) => {
            const colors = methodColors[endpoint.method];
            
            return (
              <motion.div
                key={`${endpoint.method}-${endpoint.path}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <GlassCard className="p-6 hover:bg-white/10 transition-all cursor-pointer">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div className={`px-3 py-1 rounded-lg ${colors.bg} ${colors.text} border ${colors.border} font-mono text-xs font-semibold`}>
                        {endpoint.method}
                      </div>
                      <div className="flex-1">
                        <code className="text-sm text-white font-mono">{endpoint.path}</code>
                        <p className="text-sm text-gray-400 mt-1">{endpoint.description}</p>
                      </div>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="p-2 rounded-lg hover:bg-white/5 transition-all"
                    >
                      <Send className="w-4 h-4 text-gray-400" />
                    </motion.button>
                  </div>
                </GlassCard>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Code Examples */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Request Example */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Request Example</h3>
            <motion.button
              onClick={() => copyCode(codeExamples.createPayment, 'request')}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {copiedSection === 'request' ? (
                <Check className="w-4 h-4 text-[#6ee7b7]" />
              ) : (
                <Copy className="w-4 h-4 text-gray-400" />
              )}
            </motion.button>
          </div>
          <pre className="p-4 rounded-xl bg-[#0d0e11] border border-white/10 overflow-x-auto">
            <code className="text-sm text-gray-300 font-mono leading-relaxed">
              {codeExamples.createPayment}
            </code>
          </pre>
        </GlassCard>

        {/* Response Example */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Response Example</h3>
            <motion.button
              onClick={() => copyCode(responseExamples.createPayment, 'response')}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {copiedSection === 'response' ? (
                <Check className="w-4 h-4 text-[#6ee7b7]" />
              ) : (
                <Copy className="w-4 h-4 text-gray-400" />
              )}
            </motion.button>
          </div>
          <pre className="p-4 rounded-xl bg-[#0d0e11] border border-white/10 overflow-x-auto">
            <code className="text-sm text-gray-300 font-mono leading-relaxed">
              {responseExamples.createPayment}
            </code>
          </pre>
        </GlassCard>
      </div>

      {/* SDKs */}
      <GlassCard className="p-8">
        <h2 className="text-xl font-semibold text-white mb-6">Official SDKs</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { name: 'Node.js', install: 'npm install @ontarget/node', color: 'from-[#68a063] to-[#44883e]' },
            { name: 'Python', install: 'pip install ontarget', color: 'from-[#3776ab] to-[#ffd343]' },
            { name: 'Ruby', install: 'gem install ontarget', color: 'from-[#cc342d] to-[#a91401]' },
            { name: 'PHP', install: 'composer require ontarget/ontarget-php', color: 'from-[#777bb3] to-[#4f5b93]' },
            { name: 'Go', install: 'go get github.com/ontarget/ontarget-go', color: 'from-[#00add8] to-[#007d9c]' },
            { name: 'Java', install: 'implementation "com.ontarget:ontarget-java"', color: 'from-[#f89820] to-[#c7511f]' }
          ].map((sdk) => (
            <motion.div
              key={sdk.name}
              className="p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${sdk.color} flex items-center justify-center mb-3`}>
                <Code className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-sm font-semibold text-white mb-2">{sdk.name}</h4>
              <code className="text-xs text-gray-400 font-mono block truncate">{sdk.install}</code>
            </motion.div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}
