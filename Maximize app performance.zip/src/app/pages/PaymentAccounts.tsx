import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import { Plus, TrendingUp, Wallet, AlertTriangle, DollarSign } from 'lucide-react';

export function PaymentAccounts() {
  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Payment Accounts</h1>
          <p className="text-gray-400">Manage wallets, bank accounts, and settlement accounts</p>
        </div>
        <motion.button
          className="px-6 py-3 rounded-full bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-medium flex items-center gap-2"
          whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(110, 231, 183, 0.5)' }}
          whileTap={{ scale: 0.95 }}
        >
          <Plus className="w-5 h-5" />
          Add Account
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <Wallet className="w-6 h-6 text-[#8b5cf6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Accounts</p>
            <h3 className="text-3xl font-semibold text-white">24</h3>
            <p className="text-xs text-gray-500">Configured</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <TrendingUp className="w-6 h-6 text-[#6ee7b7]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Active</p>
            <h3 className="text-3xl font-semibold text-white">18</h3>
            <p className="text-xs text-gray-500">Operational</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <DollarSign className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Capacity</p>
            <h3 className="text-3xl font-semibold text-white">$2.4M</h3>
            <p className="text-xs text-gray-500">Daily limits</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#f87171]/20 to-[#ef4444]/20">
              <AlertTriangle className="w-6 h-6 text-[#f87171]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Needs Attention</p>
            <h3 className="text-3xl font-semibold text-white">3</h3>
            <p className="text-xs text-gray-500">High usage</p>
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 flex items-center justify-center">
            <Wallet className="w-8 h-8 text-[#8b5cf6]" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Payment Accounts Management</h3>
          <p className="text-gray-400 mb-6">Configure wallets, bank accounts, InstaPay handles, and settlement accounts with limits, routing rules, and merchant assignments.</p>
          <motion.button
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium"
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
            whileTap={{ scale: 0.95 }}
          >
            Configure Accounts
          </motion.button>
        </div>
      </GlassCard>
    </div>
  );
}
