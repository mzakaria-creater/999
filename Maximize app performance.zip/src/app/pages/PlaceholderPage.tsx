import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import { LucideIcon } from 'lucide-react';

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon: LucideIcon;
  actionText?: string;
}

export function PlaceholderPage({ title, description, icon: Icon, actionText = 'Get Started' }: PlaceholderPageProps) {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-white mb-2">{title}</h1>
        <p className="text-gray-400">{description}</p>
      </div>

      <GlassCard className="p-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 flex items-center justify-center">
            <Icon className="w-10 h-10 text-[#8b5cf6]" />
          </div>
          <h3 className="text-2xl font-semibold text-white mb-3">{title}</h3>
          <p className="text-gray-400 mb-8 leading-relaxed">{description}</p>
          <motion.button
            className="px-8 py-4 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium text-lg"
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
            whileTap={{ scale: 0.95 }}
          >
            {actionText}
          </motion.button>
        </div>
      </GlassCard>
    </div>
  );
}
