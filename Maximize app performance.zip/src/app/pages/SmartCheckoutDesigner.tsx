import { useState } from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import {
  Smartphone,
  Settings,
  Copy,
  Download,
  Eye,
  Code,
  CheckCircle,
  Clock,
  Upload,
  CreditCard,
  Wallet,
  Bitcoin,
  Building,
  DollarSign
} from 'lucide-react';

type CheckoutType = 'deposit' | 'withdrawal' | 'fawry' | 'gcc' | 'crypto';

interface PaymentMethod {
  id: string;
  name: string;
  enabled: boolean;
}

export function SmartCheckoutDesigner() {
  const { t } = useLanguage();
  const [checkoutType, setCheckoutType] = useState<CheckoutType>('deposit');
  const [minAmount, setMinAmount] = useState('50');
  const [maxAmount, setMaxAmount] = useState('50000');
  const [feeMarkup, setFeeMarkup] = useState('12');
  const [autoExpire, setAutoExpire] = useState('15');
  
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    { id: 'vodafone', name: 'Vodafone Cash', enabled: true },
    { id: 'orange', name: 'Orange Cash', enabled: true },
    { id: 'instapay', name: 'InstaPay', enabled: true },
    { id: 'fawry', name: 'Fawry', enabled: true }
  ]);

  const checkoutTypes = [
    { id: 'deposit' as const, label: 'Deposit', icon: DollarSign, color: 'from-green-500 to-emerald-500' },
    { id: 'withdrawal' as const, label: 'Withdrawal', icon: Upload, color: 'from-blue-500 to-cyan-500' },
    { id: 'fawry' as const, label: 'Fawry', icon: Building, color: 'from-orange-500 to-amber-500' },
    { id: 'gcc' as const, label: 'GCC Corridor', icon: CreditCard, color: 'from-purple-500 to-violet-500' },
    { id: 'crypto' as const, label: 'Crypto', icon: Bitcoin, color: 'from-yellow-500 to-orange-500' }
  ];

  const togglePaymentMethod = (id: string) => {
    setPaymentMethods(methods =>
      methods.map(method =>
        method.id === id ? { ...method, enabled: !method.enabled } : method
      )
    );
  };

  const saveConfiguration = () => {
    console.log('Configuration saved:', {
      checkoutType,
      minAmount,
      maxAmount,
      feeMarkup,
      autoExpire,
      paymentMethods
    });
    // Show success message
  };

  return (
    <div className="p-4 sm:p-8 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
            <Smartphone className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-semibold text-white">Smart Checkout Designer</h1>
            <p className="text-gray-400">Preview and configure customer-facing checkout pages</p>
          </div>
        </div>
      </div>

      {/* Checkout Type Tabs */}
      <div className="mb-6 flex gap-3 overflow-x-auto pb-2">
        {checkoutTypes.map((type) => {
          const Icon = type.icon;
          return (
            <motion.button
              key={type.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setCheckoutType(type.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all flex-shrink-0 ${
                checkoutType === type.id
                  ? 'bg-gradient-to-r ' + type.color + ' text-white shadow-lg'
                  : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              <Icon className="w-5 h-5" />
              {type.label}
            </motion.button>
          );
        })}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Mobile Preview */}
        <div className="lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Live Preview</h2>
              <div className="flex gap-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  title="View Code"
                >
                  <Code className="w-5 h-5 text-gray-400" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  title="Preview"
                >
                  <Eye className="w-5 h-5 text-gray-400" />
                </motion.button>
              </div>
            </div>

            {/* iPhone Mockup */}
            <div className="flex justify-center">
              <div className="relative">
                {/* Phone Frame */}
                <div className="w-[360px] h-[720px] bg-gradient-to-b from-[#1e293b] to-[#0f172a] rounded-[3rem] p-3 shadow-2xl border-8 border-[#1e293b]">
                  {/* Notch */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-7 bg-[#0f172a] rounded-b-3xl z-10"></div>
                  
                  {/* Screen */}
                  <div className="w-full h-full bg-gradient-to-br from-[#1a1d23] to-[#0f172a] rounded-[2.5rem] overflow-hidden">
                    {/* Status Bar */}
                    <div className="flex items-center justify-between px-6 py-3 bg-[#1e293b]/50">
                      <span className="text-white text-sm font-medium">9:41</span>
                      <div className="flex items-center gap-1">
                        <div className="w-4 h-4 bg-white/20 rounded-sm"></div>
                        <div className="w-4 h-4 bg-white/20 rounded-sm"></div>
                        <div className="text-white text-sm">45%</div>
                        <div className="w-6 h-3 border-2 border-white/40 rounded-sm"></div>
                      </div>
                    </div>

                    {/* Checkout Content */}
                    <div className="p-4 space-y-4 overflow-y-auto h-[calc(100%-60px)]">
                      {/* Header */}
                      <div className="text-center mb-4">
                        <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                          <span className="text-2xl font-bold text-white">P</span>
                        </div>
                        <h3 className="text-white font-bold text-lg">Deposit Funds</h3>
                        <p className="text-gray-400 text-sm">Alpha Trading Merchant</p>
                      </div>

                      {/* Amount Display */}
                      <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-400 text-sm">YOU SEND</span>
                          <span className="text-white font-bold">USD 100.00</span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-400 text-sm">RATE</span>
                          <span className="text-white text-sm">49.85 × 1.012 markup</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">YOU RECEIVE</span>
                          <span className="text-green-400 font-bold text-lg">EGP 4,935.00</span>
                        </div>
                      </div>

                      {/* Payment Methods */}
                      <div>
                        <p className="text-gray-400 text-sm mb-3">SELECT METHOD</p>
                        <div className="flex gap-2 overflow-x-auto pb-2">
                          {paymentMethods.filter(m => m.enabled).map((method) => (
                            <button
                              key={method.id}
                              className={`px-4 py-2 rounded-lg font-medium text-sm flex-shrink-0 ${
                                method.id === 'vodafone'
                                  ? 'bg-gradient-to-r from-[#e60000] to-[#c00000] text-white'
                                  : 'bg-white/5 text-gray-400 border border-white/10'
                              }`}
                            >
                              {method.name.split(' ')[0]}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Send To */}
                      <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                        <p className="text-gray-400 text-sm mb-2">Send to:</p>
                        <div className="flex items-center justify-between">
                          <span className="text-white font-mono">01012345678</span>
                          <button className="p-1.5 rounded bg-white/10">
                            <Copy className="w-4 h-4 text-gray-400" />
                          </button>
                        </div>
                        <p className="text-blue-400 text-xs mt-1">Vodafone Cash - Personal account</p>
                      </div>

                      {/* Upload Proof */}
                      <div className="border-2 border-dashed border-white/20 rounded-xl p-6 text-center">
                        <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-400 text-sm">Upload payment proof</p>
                        <p className="text-gray-500 text-xs mt-1">JPG, PNG or PDF</p>
                      </div>

                      {/* Timer */}
                      <div className="flex items-center justify-center gap-2 text-red-400">
                        <Clock className="w-4 h-4" />
                        <span className="font-mono text-sm">14:23</span>
                        <span className="text-gray-400 text-xs">REF: TXN-2847163</span>
                      </div>

                      {/* Submit Button */}
                      <button className="w-full py-3 rounded-xl bg-gradient-to-r from-[#1e40af] to-[#1e3a8a] text-white font-bold shadow-lg">
                        Submit Payment Proof
                      </button>
                    </div>
                  </div>
                </div>

                {/* Label */}
                <div className="text-center mt-4">
                  <p className="text-gray-400 text-sm uppercase tracking-wider">
                    {checkoutType.toUpperCase()} CHECKOUT
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Configuration Panel */}
        <div className="lg:col-span-5">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 sticky top-4"
          >
            <div className="flex items-center gap-2 mb-6">
              <Settings className="w-5 h-5 text-[#8b5cf6]" />
              <h2 className="text-xl font-semibold text-white">Configuration</h2>
            </div>

            <div className="space-y-5">
              {/* Min Amount */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Min Amount
                </label>
                <input
                  type="number"
                  value={minAmount}
                  onChange={(e) => setMinAmount(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
                />
              </div>

              {/* Max Amount */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Max Amount
                </label>
                <input
                  type="number"
                  value={maxAmount}
                  onChange={(e) => setMaxAmount(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
                />
              </div>

              {/* Fee Markup % */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Fee Markup %
                </label>
                <input
                  type="number"
                  value={feeMarkup}
                  onChange={(e) => setFeeMarkup(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
                />
              </div>

              {/* Auto-expire */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Auto-expire (minutes)
                </label>
                <input
                  type="number"
                  value={autoExpire}
                  onChange={(e) => setAutoExpire(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
                />
              </div>

              {/* Payment Methods */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">
                  Payment Methods
                </label>
                <div className="space-y-3">
                  {paymentMethods.map((method) => (
                    <div
                      key={method.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10"
                    >
                      <span className="text-white">{method.name}</span>
                      <button
                        onClick={() => togglePaymentMethod(method.id)}
                        className={`relative w-12 h-6 rounded-full transition-colors ${
                          method.enabled ? 'bg-[#8b5cf6]' : 'bg-gray-600'
                        }`}
                      >
                        <motion.div
                          animate={{ x: method.enabled ? 24 : 0 }}
                          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                          className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-md"
                        />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Save Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={saveConfiguration}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium shadow-lg hover:shadow-violet-500/30 transition-shadow flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-5 h-5" />
                Save Configuration
              </motion.button>

              {/* Export Options */}
              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/10">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white text-sm font-medium flex items-center justify-center gap-2 transition-colors"
                >
                  <Code className="w-4 h-4" />
                  Export Code
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white text-sm font-medium flex items-center justify-center gap-2 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Usage Instructions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-8 p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Integration Guide</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#7c3aed] flex items-center justify-center mb-3">
              <span className="text-white font-bold">1</span>
            </div>
            <h4 className="text-white font-medium mb-2">Configure Settings</h4>
            <p className="text-sm text-gray-400">
              Set your amount limits, fees, and enable payment methods
            </p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#3b82f6] to-[#2563eb] flex items-center justify-center mb-3">
              <span className="text-white font-bold">2</span>
            </div>
            <h4 className="text-white font-medium mb-2">Preview & Test</h4>
            <p className="text-sm text-gray-400">
              View live preview and test the checkout flow
            </p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#10b981] to-[#059669] flex items-center justify-center mb-3">
              <span className="text-white font-bold">3</span>
            </div>
            <h4 className="text-white font-medium mb-2">Export & Deploy</h4>
            <p className="text-sm text-gray-400">
              Download code or use API integration
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
