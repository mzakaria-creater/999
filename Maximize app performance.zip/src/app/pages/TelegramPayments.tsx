import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { 
  Send, 
  MessageCircle, 
  Bot, 
  Zap,
  Shield,
  Globe,
  Copy,
  CheckCircle,
  Settings,
  Link,
  QrCode,
  Users
} from 'lucide-react';
import { useState } from 'react';

export function TelegramPayments() {
  const { t } = useLanguage();
  const [botToken, setBotToken] = useState('');
  const [webhookUrl, setWebhookUrl] = useState('https://api.ontarget-psp.com/telegram/webhook');
  const [copied, setCopied] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const stats = [
    { label: 'Active Bots', value: '3', icon: Bot, color: 'from-[#0088cc] to-[#006699]' },
    { label: 'Messages Today', value: '1.2K', icon: MessageCircle, color: 'from-[#8b5cf6] to-[#7c3aed]' },
    { label: 'Transactions', value: '458', icon: Zap, color: 'from-[#10b981] to-[#059669]' },
    { label: 'Total Users', value: '2.4K', icon: Users, color: 'from-[#f59e0b] to-[#d97706]' }
  ];

  const features = [
    {
      icon: Shield,
      title: 'Secure Payments',
      description: 'End-to-end encrypted payment processing',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Zap,
      title: 'Instant Notifications',
      description: 'Real-time payment confirmations via Telegram',
      color: 'from-yellow-500 to-amber-500'
    },
    {
      icon: Bot,
      title: 'Smart Bot Integration',
      description: 'Automated customer support and payment handling',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Globe,
      title: 'Multi-Currency',
      description: 'Support for 50+ currencies worldwide',
      color: 'from-purple-500 to-violet-500'
    }
  ];

  return (
    <div className="p-4 sm:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0088cc] to-[#006699] flex items-center justify-center">
            <Send className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-semibold text-white">Telegram Payments</h1>
            <p className="text-gray-400">Process payments directly through Telegram</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bot Configuration */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0088cc] to-[#006699] flex items-center justify-center">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-semibold text-white">Bot Configuration</h2>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Bot Token
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={botToken}
                  onChange={(e) => setBotToken(e.target.value)}
                  placeholder="Enter your Telegram Bot Token"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors"
                />
                <button
                  onClick={() => copyToClipboard(botToken)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-2">Get your bot token from @BotFather on Telegram</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Webhook URL
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors"
                />
                <button
                  onClick={() => copyToClipboard(webhookUrl)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <Link className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full px-6 py-4 rounded-xl bg-gradient-to-r from-[#0088cc] to-[#006699] text-white font-medium flex items-center justify-center gap-2 shadow-lg hover:shadow-blue-500/30 transition-shadow"
            >
              <CheckCircle className="w-5 h-5" />
              Save Configuration
            </motion.button>
          </div>
        </motion.div>

        {/* Payment Link Generator */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
              <QrCode className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-semibold text-white">Payment Link</h2>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Amount (EGP)
              </label>
              <input
                type="number"
                placeholder="0.00"
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Description
              </label>
              <textarea
                rows={3}
                placeholder="Payment description..."
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors resize-none"
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full px-6 py-4 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center justify-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
            >
              <Send className="w-5 h-5" />
              Generate Telegram Link
            </motion.button>

            <div className="p-4 rounded-xl bg-[#0088cc]/10 border border-[#0088cc]/30">
              <p className="text-sm text-gray-400 mb-2">Generated Link:</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs text-[#0088cc] bg-black/20 px-3 py-2 rounded-lg overflow-x-auto">
                  t.me/YourBot?start=pay_abc123xyz
                </code>
                <button className="p-2 rounded-lg bg-[#0088cc]/20 hover:bg-[#0088cc]/30 transition-colors">
                  <Copy className="w-4 h-4 text-[#0088cc]" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 hover:border-white/20 transition-all"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-400">{feature.description}</p>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
