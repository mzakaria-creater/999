import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { 
  LayoutDashboard,
  Receipt,
  Wallet,
  Store,
  CreditCard,
  FileText,
  Users,
  CheckSquare,
  DollarSign,
  Send,
  Shield,
  BarChart3,
  Code,
  Settings,
  Bitcoin,
  TrendingUp,
  Package,
  Clock,
  AlertCircle,
  FolderOpen,
  Database,
  Globe,
  Zap,
  Activity,
  UserPlus
} from 'lucide-react';
import { useMobileTheme } from '../context/MobileThemeContext';
import { useLanguage } from '../context/LanguageContext';

interface AppIcon {
  id: string;
  name: string;
  nameAr: string;
  icon: typeof LayoutDashboard;
  color: string;
  gradient: string;
  route: string;
  category: string;
  emoji?: string;
}

const apps: AppIcon[] = [
  {
    id: 'dashboard',
    name: 'Dashboard',
    nameAr: 'لوحة التحكم',
    icon: LayoutDashboard,
    color: '#8b5cf6',
    gradient: 'from-[#8b5cf6] to-[#7c3aed]',
    route: '/mobile/dashboard',
    category: 'main'
  },
  {
    id: 'transactions',
    name: 'Txs psp',
    nameAr: 'معاملات PSP',
    icon: Receipt,
    color: '#3b82f6',
    gradient: 'from-[#3b82f6] to-[#2563eb]',
    route: '/mobile/transactions',
    category: 'main'
  },
  {
    id: 'wallets',
    name: 'Wallets',
    nameAr: 'المحافظ',
    icon: Wallet,
    color: '#10b981',
    gradient: 'from-[#10b981] to-[#059669]',
    route: '/mobile/wallets',
    category: 'main'
  },
  {
    id: 'wallet-pools',
    name: 'Wallet Pools',
    nameAr: 'مجموعات المحافظ',
    icon: Database,
    color: '#14b8a6',
    gradient: 'from-[#14b8a6] to-[#0d9488]',
    route: '/wallet-pools',
    category: 'main'
  },
  {
    id: 'merchants',
    name: 'Merchants',
    nameAr: 'التجار',
    icon: Store,
    color: '#f59e0b',
    gradient: 'from-[#f59e0b] to-[#d97706]',
    route: '/mobile/merchants',
    category: 'main'
  },
  {
    id: 'merchant-onboarding',
    name: 'Add Merchant',
    nameAr: 'إضافة تاجر',
    icon: UserPlus,
    color: '#8b5cf6',
    gradient: 'from-[#8b5cf6] to-[#6d28d9]',
    route: '/merchant-onboarding',
    category: 'management'
  },
  {
    id: 'payment-methods',
    name: 'Payment Methods',
    nameAr: 'طرق الدفع',
    icon: CreditCard,
    color: '#ec4899',
    gradient: 'from-[#ec4899] to-[#db2777]',
    route: '/payment-methods',
    category: 'payment'
  },
  {
    id: 'payment-accounts',
    name: 'Payment Accounts',
    nameAr: 'حسابات الدفع',
    icon: Database,
    color: '#06b6d4',
    gradient: 'from-[#06b6d4] to-[#0891b2]',
    route: '/payment-accounts',
    category: 'payment'
  },
  {
    id: 'payment-pages',
    name: 'Payment Pages',
    nameAr: 'صفحات الدفع',
    icon: FileText,
    color: '#8b5cf6',
    gradient: 'from-[#8b5cf6] to-[#6d28d9]',
    route: '/payment-pages',
    category: 'payment'
  },
  {
    id: 'users',
    name: 'Users & Roles',
    nameAr: 'المستخدمين',
    icon: Users,
    color: '#14b8a6',
    gradient: 'from-[#14b8a6] to-[#0d9488]',
    route: '/user-management',
    category: 'management'
  },
  {
    id: 'approvals',
    name: 'Approvals',
    nameAr: 'الموافقات',
    icon: CheckSquare,
    color: '#f97316',
    gradient: 'from-[#f97316] to-[#ea580c]',
    route: '/approvals',
    category: 'management'
  },
  {
    id: 'settlement',
    name: 'Settlement',
    nameAr: 'التسوية',
    icon: DollarSign,
    color: '#22c55e',
    gradient: 'from-[#22c55e] to-[#16a34a]',
    route: '/settlement',
    category: 'finance'
  },
  {
    id: 'payouts',
    name: 'Payouts',
    nameAr: 'المدفوعات',
    icon: Send,
    color: '#3b82f6',
    gradient: 'from-[#3b82f6] to-[#1d4ed8]',
    route: '/payouts',
    category: 'finance'
  },
  {
    id: 'risk',
    name: 'Risk & Fraud',
    nameAr: 'المخاطر',
    icon: Shield,
    color: '#ef4444',
    gradient: 'from-[#ef4444] to-[#dc2626]',
    route: '/risk',
    category: 'security'
  },
  {
    id: 'reports',
    name: 'Reports',
    nameAr: 'التقارير',
    icon: BarChart3,
    color: '#8b5cf6',
    gradient: 'from-[#8b5cf6] to-[#7c3aed]',
    route: '/reports',
    category: 'analytics'
  },
  {
    id: 'api-docs',
    name: 'API Docs',
    nameAr: 'توثيق API',
    icon: Code,
    color: '#6366f1',
    gradient: 'from-[#6366f1] to-[#4f46e5]',
    route: '/api-documentation',
    category: 'developer'
  },
  {
    id: 'binance',
    name: 'Binance P2P',
    nameAr: 'بينانس P2P',
    icon: Bitcoin,
    color: '#f59e0b',
    gradient: 'from-[#f59e0b] to-[#d97706]',
    route: '/binance-p2p',
    category: 'integration'
  },
  {
    id: 'analytics',
    name: 'Analytics',
    nameAr: 'التحليلات',
    icon: TrendingUp,
    color: '#10b981',
    gradient: 'from-[#10b981] to-[#059669]',
    route: '/dashboard',
    category: 'analytics'
  },
  {
    id: 'inventory',
    name: 'Inventory',
    nameAr: 'المخزون',
    icon: Package,
    color: '#06b6d4',
    gradient: 'from-[#06b6d4] to-[#0891b2]',
    route: '/dashboard',
    category: 'management'
  },
  {
    id: 'activity',
    name: 'Activity Log',
    nameAr: 'سجل النشاط',
    icon: Clock,
    color: '#a855f7',
    gradient: 'from-[#a855f7] to-[#9333ea]',
    route: '/dashboard',
    category: 'monitoring'
  },
  {
    id: 'alerts',
    name: 'Alerts',
    nameAr: 'التنبيهات',
    icon: AlertCircle,
    color: '#ef4444',
    gradient: 'from-[#ef4444] to-[#dc2626]',
    route: '/dashboard',
    category: 'monitoring'
  },
  {
    id: 'files',
    name: 'Files',
    nameAr: 'الملفات',
    icon: FolderOpen,
    color: '#3b82f6',
    gradient: 'from-[#3b82f6] to-[#2563eb]',
    route: '/dashboard',
    category: 'storage'
  },
  {
    id: 'integrations',
    name: 'Integrations',
    nameAr: 'التكاملات',
    icon: Globe,
    color: '#14b8a6',
    gradient: 'from-[#14b8a6] to-[#0d9488]',
    route: '/embed',
    category: 'integration'
  },
  {
    id: 'automation',
    name: 'Automation',
    nameAr: 'الأتمتة',
    icon: Zap,
    color: '#f59e0b',
    gradient: 'from-[#f59e0b] to-[#d97706]',
    route: '/dashboard',
    category: 'tools'
  },
  {
    id: 'monitoring',
    name: 'Monitoring',
    nameAr: 'المراقبة',
    icon: Activity,
    color: '#22c55e',
    gradient: 'from-[#22c55e] to-[#16a34a]',
    route: '/dashboard',
    category: 'monitoring'
  },
  {
    id: 'settings',
    name: 'Settings',
    nameAr: 'الإعدادات',
    icon: Settings,
    color: '#64748b',
    gradient: 'from-[#64748b] to-[#475569]',
    route: '/mobile/settings',
    category: 'system'
  }
];

export default function MobileAppGrid() {
  const navigate = useNavigate();
  const { config, theme } = useMobileTheme();
  const { direction } = useLanguage();

  const handleAppClick = (route: string) => {
    navigate(route);
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-[#0a0b0d] via-[#121417] to-[#0a0b0d] overflow-hidden`}>
      {/* Status Bar */}
      <div className={`${config.statusBar} px-6 pt-3 pb-2`}>
        <div className="flex items-center justify-between text-xs">
          
          <div className="flex items-center gap-2">
            
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div className="px-6 pt-8 pb-6">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`text-4xl font-bold ${config.textPrimary}`}
        >
          OnTarget PSP
        </motion.h1>
      </div>

      {/* App Grid */}
      <div className="px-4 pb-32">
        <div className="grid grid-cols-4 gap-4">
          {apps.map((app, index) => {
            const Icon = app.icon;
            
            return (
              <motion.button
                key={app.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.02 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleAppClick(app.route)}
                className="flex flex-col items-center gap-2 touch-manipulation"
              >
                {/* App Icon */}
                <div 
                  className={`w-16 h-16 rounded-[22%] shadow-lg backdrop-blur-xl border flex items-center justify-center ${
                    theme === 'dark' 
                      ? 'bg-[#1a1a1a]/80 border-white/10' 
                      : 'bg-white/80 border-gray-200'
                  }`}
                  style={{
                    boxShadow: theme === 'dark' 
                      ? `0 4px 20px ${app.color}20` 
                      : '0 4px 12px rgba(0,0,0,0.1)'
                  }}
                >
                  <div className={`w-12 h-12 rounded-[18%] bg-gradient-to-br ${app.gradient} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                  </div>
                </div>
                
                {/* App Name */}
                <div className={`text-[11px] font-medium text-center leading-tight w-full px-1 ${config.textPrimary}`}>
                  {direction === 'rtl' ? app.nameAr : app.name}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
