import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { GlassCard } from '../components/GlassCard';
import {
  TrendingUp,
  TrendingDown,
  RefreshCw,
  DollarSign,
  ArrowRight,
  Bitcoin,
  CircleDollarSign,
  AlertCircle,
  CheckCircle2,
  Clock,
  Users,
  Shield,
  ExternalLink,
  Filter,
  Search
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface P2POffer {
  id: string;
  merchant: string;
  price: number;
  available: number;
  limit: {
    min: number;
    max: number;
  };
  paymentMethods: string[];
  completionRate: number;
  trades: number;
  verified: boolean;
  avgTime: string;
}

export function BinanceP2PPage() {
  const { t, direction, language } = useLanguage();
  const [buyOffers, setBuyOffers] = useState<P2POffer[]>([]);
  const [sellOffers, setSellOffers] = useState<P2POffer[]>([]);
  const [livePrice, setLivePrice] = useState({ buy: 0, sell: 0, change: 0 });
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [activeTab, setActiveTab] = useState<'buy' | 'sell'>('buy');
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPayment, setFilterPayment] = useState('all');

  // Simulate live price updates
  useEffect(() => {
    const simulateLivePrices = () => {
      const basePrice = 48.50;
      const variation = (Math.random() - 0.5) * 0.5;
      const newBuyPrice = basePrice + variation;
      const newSellPrice = basePrice + variation - 0.2;
      const change = ((newBuyPrice - basePrice) / basePrice) * 100;

      setLivePrice({
        buy: newBuyPrice,
        sell: newSellPrice,
        change: change
      });
      setLastUpdate(new Date());
    };

    simulateLivePrices();
    const interval = setInterval(simulateLivePrices, 5000);
    return () => clearInterval(interval);
  }, []);

  // Generate mock P2P offers
  useEffect(() => {
    const mockBuyOffers: P2POffer[] = [
      {
        id: '1',
        merchant: 'EgyptCryptoKing',
        price: 48.52,
        available: 15000,
        limit: { min: 500, max: 50000 },
        paymentMethods: ['Vodafone Cash', 'Instapay', 'Bank Transfer'],
        completionRate: 98.5,
        trades: 1247,
        verified: true,
        avgTime: '2 mins'
      },
      {
        id: '2',
        merchant: 'CairoTrader',
        price: 48.55,
        available: 8500,
        limit: { min: 1000, max: 25000 },
        paymentMethods: ['Vodafone Cash', 'Orange Cash'],
        completionRate: 97.2,
        trades: 856,
        verified: true,
        avgTime: '5 mins'
      },
      {
        id: '3',
        merchant: 'NileCrypto',
        price: 48.58,
        available: 12000,
        limit: { min: 500, max: 100000 },
        paymentMethods: ['Instapay', 'Bank Transfer', 'Vodafone Cash'],
        completionRate: 99.1,
        trades: 2134,
        verified: true,
        avgTime: '1 min'
      },
      {
        id: '4',
        merchant: 'AlexCryptoHub',
        price: 48.60,
        available: 5500,
        limit: { min: 1000, max: 15000 },
        paymentMethods: ['Vodafone Cash', 'Etisalat Cash'],
        completionRate: 96.8,
        trades: 543,
        verified: false,
        avgTime: '8 mins'
      },
      {
        id: '5',
        merchant: 'PharaohTrading',
        price: 48.65,
        available: 20000,
        limit: { min: 2000, max: 75000 },
        paymentMethods: ['Bank Transfer', 'Instapay'],
        completionRate: 98.9,
        trades: 1876,
        verified: true,
        avgTime: '3 mins'
      }
    ];

    const mockSellOffers: P2POffer[] = [
      {
        id: '6',
        merchant: 'EgyptCryptoKing',
        price: 48.35,
        available: 18000,
        limit: { min: 500, max: 60000 },
        paymentMethods: ['Vodafone Cash', 'Instapay', 'Bank Transfer'],
        completionRate: 98.5,
        trades: 1247,
        verified: true,
        avgTime: '2 mins'
      },
      {
        id: '7',
        merchant: 'CairoVault',
        price: 48.30,
        available: 9500,
        limit: { min: 1000, max: 30000 },
        paymentMethods: ['Vodafone Cash', 'Orange Cash', 'WE Pay'],
        completionRate: 97.5,
        trades: 921,
        verified: true,
        avgTime: '4 mins'
      },
      {
        id: '8',
        merchant: 'DeltaExchange',
        price: 48.28,
        available: 25000,
        limit: { min: 2000, max: 150000 },
        paymentMethods: ['Bank Transfer', 'Instapay'],
        completionRate: 99.3,
        trades: 3421,
        verified: true,
        avgTime: '1 min'
      },
      {
        id: '9',
        merchant: 'PyramidCrypto',
        price: 48.25,
        available: 11000,
        limit: { min: 1000, max: 40000 },
        paymentMethods: ['Vodafone Cash', 'WE Pay'],
        completionRate: 96.5,
        trades: 654,
        verified: false,
        avgTime: '6 mins'
      }
    ];

    setBuyOffers(mockBuyOffers);
    setSellOffers(mockSellOffers);
  }, []);

  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1000);
  };

  const currentOffers = activeTab === 'buy' ? buyOffers : sellOffers;

  const filteredOffers = currentOffers.filter(offer => {
    const matchesSearch = offer.merchant.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPayment = filterPayment === 'all' || offer.paymentMethods.includes(filterPayment);
    return matchesSearch && matchesPayment;
  });

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center">
              <Bitcoin className="w-7 h-7 text-white" />
            </div>
            {language === 'ar' ? 'Binance P2P - USDT/EGP' : 'Binance P2P - USDT/EGP'}
          </h1>
          <p className="text-gray-400">
            {language === 'ar' 
              ? 'الأسعار المباشرة من سوق Binance P2P'
              : 'Live prices from Binance P2P marketplace'
            }
          </p>
        </div>
        <div className="flex items-center gap-3">
          <motion.a
            href="https://p2p.binance.com/en/trade/all-payments/USDT?fiat=EGP"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all flex items-center gap-2 text-white text-sm"
          >
            <ExternalLink className="w-4 h-4" />
            {language === 'ar' ? 'افتح في Binance' : 'Open in Binance'}
          </motion.a>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleRefresh}
            className={`p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all ${isLoading ? 'animate-spin' : ''}`}
          >
            <RefreshCw className="w-5 h-5 text-gray-300" />
          </motion.button>
        </div>
      </div>

      {/* Live Price Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <GlassCard hover className="p-6 border-green-400/20">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-green-400/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <p className="text-xs text-gray-400">
                  {language === 'ar' ? 'سعر الشراء' : 'Buy Price'}
                </p>
                <p className="text-sm text-gray-500">
                  {language === 'ar' ? 'أفضل عرض' : 'Best Offer'}
                </p>
              </div>
            </div>
            <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
              livePrice.change >= 0 ? 'bg-green-400/20 text-green-400' : 'bg-red-400/20 text-red-400'
            }`}>
              {livePrice.change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              <span className="text-xs font-semibold">{Math.abs(livePrice.change).toFixed(2)}%</span>
            </div>
          </div>
          <p className="text-3xl font-bold text-white mb-1">
            {livePrice.buy.toFixed(2)} <span className="text-lg text-gray-400">EGP</span>
          </p>
          <p className="text-xs text-gray-500">
            {language === 'ar' ? 'لكل USDT' : 'per USDT'}
          </p>
        </GlassCard>

        <GlassCard hover className="p-6 border-red-400/20">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-red-400/20 flex items-center justify-center">
                <TrendingDown className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <p className="text-xs text-gray-400">
                  {language === 'ar' ? 'سعر البيع' : 'Sell Price'}
                </p>
                <p className="text-sm text-gray-500">
                  {language === 'ar' ? 'أفضل عرض' : 'Best Offer'}
                </p>
              </div>
            </div>
          </div>
          <p className="text-3xl font-bold text-white mb-1">
            {livePrice.sell.toFixed(2)} <span className="text-lg text-gray-400">EGP</span>
          </p>
          <p className="text-xs text-gray-500">
            {language === 'ar' ? 'لكل USDT' : 'per USDT'}
          </p>
        </GlassCard>

        <GlassCard hover className="p-6 border-blue-400/20">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 rounded-xl bg-blue-400/20 flex items-center justify-center">
              <CircleDollarSign className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-gray-400">
                {language === 'ar' ? 'الفارق' : 'Spread'}
              </p>
              <p className="text-sm text-gray-500">
                {language === 'ar' ? 'شراء/بيع' : 'Buy/Sell'}
              </p>
            </div>
          </div>
          <p className="text-3xl font-bold text-blue-400 mb-1">
            {(livePrice.buy - livePrice.sell).toFixed(2)} <span className="text-lg text-gray-400">EGP</span>
          </p>
          <p className="text-xs text-gray-500">
            {((livePrice.buy - livePrice.sell) / livePrice.sell * 100).toFixed(2)}% {language === 'ar' ? 'فارق' : 'spread'}
          </p>
        </GlassCard>

        <GlassCard hover className="p-6 border-purple-400/20">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-10 h-10 rounded-xl bg-purple-400/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-xs text-gray-400">
                {language === 'ar' ? 'عروض متاحة' : 'Available'}
              </p>
              <p className="text-sm text-gray-500">
                {language === 'ar' ? 'التجار النشطون' : 'Active Traders'}
              </p>
            </div>
          </div>
          <p className="text-3xl font-bold text-purple-400 mb-1">
            {currentOffers.length}
          </p>
          <p className="text-xs text-gray-500">
            {language === 'ar' ? 'عرض' : 'offers'}
          </p>
        </GlassCard>
      </div>

      {/* Tabs & Filters */}
      <div className="flex flex-col md:flex-row items-center gap-4">
        <div className="flex items-center gap-3 p-1.5 bg-white/5 border border-white/10 rounded-2xl">
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab('buy')}
            className={`px-8 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'buy'
                ? 'bg-gradient-to-r from-green-400 to-green-500 text-white shadow-lg'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            {language === 'ar' ? '🟢 شراء USDT' : '🟢 Buy USDT'}
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab('sell')}
            className={`px-8 py-3 rounded-xl font-semibold transition-all ${
              activeTab === 'sell'
                ? 'bg-gradient-to-r from-red-400 to-red-500 text-white shadow-lg'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            {language === 'ar' ? '🔴 بيع USDT' : '🔴 Sell USDT'}
          </motion.button>
        </div>

        <div className="flex-1 flex items-center gap-3 w-full">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder={language === 'ar' ? 'ابحث عن تاجر...' : 'Search merchant...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
            />
          </div>

          <select
            value={filterPayment}
            onChange={(e) => setFilterPayment(e.target.value)}
            className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
          >
            <option value="all">{language === 'ar' ? 'كل طرق الدفع' : 'All Payments'}</option>
            <option value="Vodafone Cash">Vodafone Cash</option>
            <option value="Instapay">Instapay</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Orange Cash">Orange Cash</option>
            <option value="WE Pay">WE Pay</option>
          </select>
        </div>
      </div>

      {/* P2P Offers */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">
            {language === 'ar' 
              ? `عروض ${activeTab === 'buy' ? 'الشراء' : 'البيع'} (${filteredOffers.length})`
              : `${activeTab === 'buy' ? 'Buy' : 'Sell'} Offers (${filteredOffers.length})`
            }
          </h2>
          <p className="text-sm text-gray-400">
            {language === 'ar' ? 'آخر تحديث: ' : 'Updated: '}
            {lastUpdate.toLocaleTimeString()}
          </p>
        </div>

        <AnimatePresence mode="wait">
          {filteredOffers.map((offer, index) => (
            <motion.div
              key={offer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.05 }}
            >
              <GlassCard hover className="p-6">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                  {/* Merchant Info */}
                  <div className="lg:col-span-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-white font-bold text-lg">
                        {offer.merchant.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-white font-semibold">{offer.merchant}</p>
                          {offer.verified && (
                            <CheckCircle2 className="w-4 h-4 text-blue-400" />
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                          <Users className="w-3 h-3" />
                          {offer.trades} {language === 'ar' ? 'صفقة' : 'trades'}
                          <span>•</span>
                          {offer.completionRate}%
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="lg:col-span-2">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'السعر' : 'Price'}</p>
                    <p className="text-2xl font-bold text-white">
                      {offer.price.toFixed(2)}
                      <span className="text-sm text-gray-400 ml-1">EGP</span>
                    </p>
                  </div>

                  {/* Available */}
                  <div className="lg:col-span-2">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'متاح' : 'Available'}</p>
                    <p className="text-lg font-semibold text-white">
                      {offer.available.toLocaleString()}
                      <span className="text-sm text-gray-400 ml-1">USDT</span>
                    </p>
                  </div>

                  {/* Limits */}
                  <div className="lg:col-span-2">
                    <p className="text-xs text-gray-400 mb-1">{language === 'ar' ? 'الحدود' : 'Limits'}</p>
                    <p className="text-sm text-white">
                      {offer.limit.min.toLocaleString()} - {offer.limit.max.toLocaleString()}
                      <span className="text-xs text-gray-400 ml-1">EGP</span>
                    </p>
                    <div className="flex items-center gap-1 text-xs text-gray-400 mt-1">
                      <Clock className="w-3 h-3" />
                      {offer.avgTime}
                    </div>
                  </div>

                  {/* Payment Methods */}
                  <div className="lg:col-span-2">
                    <p className="text-xs text-gray-400 mb-2">{language === 'ar' ? 'طرق الدفع' : 'Payment'}</p>
                    <div className="flex flex-wrap gap-1">
                      {offer.paymentMethods.slice(0, 2).map((method) => (
                        <span
                          key={method}
                          className="px-2 py-1 rounded-md bg-white/5 text-xs text-gray-300 border border-white/10"
                        >
                          {method}
                        </span>
                      ))}
                      {offer.paymentMethods.length > 2 && (
                        <span className="px-2 py-1 rounded-md bg-white/5 text-xs text-gray-400">
                          +{offer.paymentMethods.length - 2}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="lg:col-span-1">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`w-full px-6 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 ${
                        activeTab === 'buy'
                          ? 'bg-gradient-to-r from-green-400 to-green-500 text-white'
                          : 'bg-gradient-to-r from-red-400 to-red-500 text-white'
                      }`}
                    >
                      {language === 'ar' ? (activeTab === 'buy' ? 'شراء' : 'بيع') : (activeTab === 'buy' ? 'Buy' : 'Sell')}
                      <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </AnimatePresence>

        {filteredOffers.length === 0 && (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 mx-auto mb-4 text-gray-600" />
            <p className="text-gray-400">
              {language === 'ar' ? 'لا توجد عروض متاحة' : 'No offers available'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
