import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Smartphone,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  BarChart3,
  Calendar,
  DollarSign,
  Users
} from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { WalletTransactionDetails } from '../components/WalletTransactionDetails';

interface WalletTransaction {
  id: string;
  phone: string;
  amount: string;
  provider: {
    name: string;
    nameAr: string;
    logo: string;
    color: string;
  };
  status: 'pending' | 'completed' | 'failed' | 'reviewing';
  date: string;
  time: string;
  ussdCode: string;
  merchantName: string;
  customerName: string;
  reference?: string;
}

const walletProviders = {
  vodafone: { 
    name: 'Vodafone Cash', 
    nameAr: 'فودافون كاش',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/a/af/Vodafone_Logo.png', 
    color: '#e60000' 
  },
  etisalat: { 
    name: 'Etisalat Cash', 
    nameAr: 'اتصالات كاش',
    logo: 'https://i.ibb.co/L8P4rD3/etisalat-cash.png', 
    color: '#719917' 
  },
  orange: { 
    name: 'Orange Money', 
    nameAr: 'أورانج موني',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Orange_logo.svg/1024px-Orange_logo.svg.png', 
    color: '#ff7900' 
  },
  we: { 
    name: 'WE Pay', 
    nameAr: 'وي باي',
    logo: 'https://i.ibb.co/v4S8FwX/we-pay.png', 
    color: '#4c0099' 
  }
};

const mockTransactions: WalletTransaction[] = [
  {
    id: 'MW-2024-001',
    phone: '01012345678',
    amount: '250.00',
    provider: walletProviders.vodafone,
    status: 'completed',
    date: '2026-03-15',
    time: '14:32:15',
    ussdCode: '*9*7*01012345678*250#',
    merchantName: 'TechStore Electronics',
    customerName: 'Ahmed Mohamed',
    reference: 'REF-VF-8372'
  },
  {
    id: 'MW-2024-002',
    phone: '01156789012',
    amount: '500.00',
    provider: walletProviders.etisalat,
    status: 'pending',
    date: '2026-03-15',
    time: '14:28:43',
    ussdCode: '*777*1*01156789012*500#',
    merchantName: 'FashionHub',
    customerName: 'Sara Ali'
  },
  {
    id: 'MW-2024-003',
    phone: '01234567890',
    amount: '150.00',
    provider: walletProviders.orange,
    status: 'reviewing',
    date: '2026-03-15',
    time: '14:25:08',
    ussdCode: '*115*1*01234567890*150#',
    merchantName: 'GadgetWorld',
    customerName: 'Mohamed Hassan'
  },
  {
    id: 'MW-2024-004',
    phone: '01501234567',
    amount: '1000.00',
    provider: walletProviders.we,
    status: 'completed',
    date: '2026-03-15',
    time: '14:20:31',
    ussdCode: '*990*1*01501234567*1000#',
    merchantName: 'BookStore',
    customerName: 'Fatima Ibrahim',
    reference: 'REF-WE-7291'
  },
  {
    id: 'MW-2024-005',
    phone: '01098765432',
    amount: '75.50',
    provider: walletProviders.vodafone,
    status: 'failed',
    date: '2026-03-15',
    time: '14:15:22',
    ussdCode: '*9*7*01098765432*75.5#',
    merchantName: 'SportGear Pro',
    customerName: 'Khaled Adel'
  }
];

export function MobileWalletTransactions() {
  const { t, language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [providerFilter, setProviderFilter] = useState<string>('all');
  const [selectedTransaction, setSelectedTransaction] = useState<WalletTransaction | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  const filteredTransactions = mockTransactions.filter(tx => {
    const matchesSearch = 
      tx.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.phone.includes(searchTerm) ||
      tx.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || tx.status === statusFilter;
    const matchesProvider = providerFilter === 'all' || tx.provider.name === providerFilter;

    return matchesSearch && matchesStatus && matchesProvider;
  });

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'completed':
        return {
          icon: CheckCircle2,
          color: '#6ee7b7',
          bg: 'bg-[#6ee7b7]/10',
          border: 'border-[#6ee7b7]/30',
          text: t('walletTransaction.statusCompleted')
        };
      case 'failed':
        return {
          icon: XCircle,
          color: '#ef4444',
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          text: t('walletTransaction.statusFailed')
        };
      case 'reviewing':
        return {
          icon: AlertCircle,
          color: '#fbbf24',
          bg: 'bg-[#fbbf24]/10',
          border: 'border-[#fbbf24]/30',
          text: t('walletTransaction.statusReviewing')
        };
      default:
        return {
          icon: Clock,
          color: '#94a3b8',
          bg: 'bg-gray-500/10',
          border: 'border-gray-500/30',
          text: t('walletTransaction.statusPending')
        };
    }
  };

  const stats = {
    total: mockTransactions.reduce((sum, tx) => sum + parseFloat(tx.amount), 0),
    completed: mockTransactions.filter(tx => tx.status === 'completed').length,
    pending: mockTransactions.filter(tx => tx.status === 'pending').length,
    reviewing: mockTransactions.filter(tx => tx.status === 'reviewing').length
  };

  const handleViewDetails = (transaction: WalletTransaction) => {
    setSelectedTransaction(transaction);
    setShowDetails(true);
  };

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">{t('mobileWallet.title')}</h1>
        <p className="text-gray-400">{t('mobileWallet.subtitle')}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6]">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <TrendingUp className="w-5 h-5 text-[#6ee7b7]" />
          </div>
          <p className="text-sm text-gray-400 mb-1">{t('mobileWallet.totalVolume')}</p>
          <p className="text-2xl font-bold text-white">{stats.total.toFixed(2)} {t('walletTransaction.egp')}</p>
          <p className="text-xs text-[#6ee7b7] mt-2">{t('mobileWallet.last24Hours')}</p>
        </GlassCard>

        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-[#6ee7b7]/20">
              <CheckCircle2 className="w-6 h-6 text-[#6ee7b7]" />
            </div>
            <span className="text-xs font-medium text-[#6ee7b7]">+{stats.completed}</span>
          </div>
          <p className="text-sm text-gray-400 mb-1">{t('mobileWallet.completed')}</p>
          <p className="text-2xl font-bold text-white">{stats.completed}</p>
          <p className="text-xs text-gray-400 mt-2">{t('mobileWallet.transactions')}</p>
        </GlassCard>

        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-[#fbbf24]/20">
              <Clock className="w-6 h-6 text-[#fbbf24]" />
            </div>
            <span className="text-xs font-medium text-[#fbbf24]">{stats.pending}</span>
          </div>
          <p className="text-sm text-gray-400 mb-1">{t('mobileWallet.pending')}</p>
          <p className="text-2xl font-bold text-white">{stats.pending}</p>
          <p className="text-xs text-gray-400 mt-2">{t('mobileWallet.awaitingConfirmation')}</p>
        </GlassCard>

        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-[#8b5cf6]/20">
              <AlertCircle className="w-6 h-6 text-[#8b5cf6]" />
            </div>
            <span className="text-xs font-medium text-[#8b5cf6]">{stats.reviewing}</span>
          </div>
          <p className="text-sm text-gray-400 mb-1">{t('mobileWallet.reviewing')}</p>
          <p className="text-2xl font-bold text-white">{stats.reviewing}</p>
          <p className="text-xs text-gray-400 mt-2">{t('mobileWallet.needsReview')}</p>
        </GlassCard>
      </div>

      {/* Filters and Actions */}
      <GlassCard className="p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder={t('mobileWallet.searchPlaceholder')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
            />
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
          >
            <option value="all">{t('mobileWallet.allStatus')}</option>
            <option value="completed">{t('walletTransaction.statusCompleted')}</option>
            <option value="pending">{t('walletTransaction.statusPending')}</option>
            <option value="reviewing">{t('walletTransaction.statusReviewing')}</option>
            <option value="failed">{t('walletTransaction.statusFailed')}</option>
          </select>

          {/* Provider Filter */}
          <select
            value={providerFilter}
            onChange={(e) => setProviderFilter(e.target.value)}
            className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20"
          >
            <option value="all">{t('mobileWallet.allProviders')}</option>
            <option value="Vodafone Cash">Vodafone Cash</option>
            <option value="Etisalat Cash">Etisalat Cash</option>
            <option value="Orange Money">Orange Money</option>
            <option value="WE Pay">WE Pay</option>
          </select>

          {/* Export Button */}
          <motion.button
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#6ee7b7] to-[#06b6d4] text-[#121417] font-medium flex items-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Download className="w-4 h-4" />
            {t('common.export')}
          </motion.button>
        </div>
      </GlassCard>

      {/* Transactions Table */}
      <GlassCard className="p-6">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('mobileWallet.transactionId')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('mobileWallet.customer')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('mobileWallet.phone')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('walletTransaction.provider')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('walletTransaction.amount')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('transactions.status')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('walletTransaction.date')}</th>
                <th className="text-left py-4 px-4 text-sm font-medium text-gray-400">{t('transactions.actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((transaction) => {
                const statusConfig = getStatusConfig(transaction.status);
                const StatusIcon = statusConfig.icon;

                return (
                  <motion.tr
                    key={transaction.id}
                    className="border-b border-white/5 hover:bg-white/5 transition-colors"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-gray-400" />
                        <span className="text-sm font-medium text-white">{transaction.id}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div>
                        <p className="text-sm font-medium text-white">{transaction.customerName}</p>
                        <p className="text-xs text-gray-400">{transaction.merchantName}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm text-white font-mono" dir="ltr">{transaction.phone}</span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <img 
                          src={transaction.provider.logo} 
                          alt={transaction.provider.name}
                          className="w-6 h-6 object-contain"
                        />
                        <span className="text-sm text-white">
                          {language === 'ar' ? transaction.provider.nameAr : transaction.provider.name}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm font-semibold text-white">{transaction.amount} {t('walletTransaction.egp')}</span>
                    </td>
                    <td className="py-4 px-4">
                      <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border ${statusConfig.bg} ${statusConfig.border}`}>
                        <StatusIcon className="w-3 h-3" style={{ color: statusConfig.color }} />
                        <span className="text-xs font-medium text-white">{statusConfig.text}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div>
                        <p className="text-sm text-white">{transaction.date}</p>
                        <p className="text-xs text-gray-400">{transaction.time}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <motion.button
                        onClick={() => handleViewDetails(transaction)}
                        className="p-2 rounded-lg bg-[#3b82f6]/20 border border-[#3b82f6]/30 text-[#3b82f6] hover:bg-[#3b82f6]/30 transition-colors"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Eye className="w-4 h-4" />
                      </motion.button>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>

          {filteredTransactions.length === 0 && (
            <div className="text-center py-12">
              <Smartphone className="w-12 h-12 mx-auto mb-4 text-gray-600" />
              <p className="text-gray-400">{t('mobileWallet.noTransactions')}</p>
            </div>
          )}
        </div>
      </GlassCard>

      {/* Transaction Details Modal */}
      <WalletTransactionDetails
        isOpen={showDetails}
        transaction={selectedTransaction}
        onClose={() => {
          setShowDetails(false);
          setSelectedTransaction(null);
        }}
      />
    </div>
  );
}
