import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Plus,
  Search,
  MoreVertical,
  CheckCircle,
  XCircle,
  AlertCircle,
  TrendingUp,
  Users,
  DollarSign,
  Activity,
  X,
  Mail,
  Globe,
  Key,
  Smartphone
} from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router';
import { DesktopMerchantSidebar } from '../components/DesktopMerchantSidebar';

interface Merchant {
  id: string;
  name: string;
  email: string;
  website: string;
  apiStatus: 'active' | 'inactive' | 'suspended';
  paymentMethods: string[];
  monthlyVolume: number;
  transactions: number;
  createdDate: string;
  apiKey: string;
}

const merchantsData: Merchant[] = [
  {
    id: 'MCH-1001',
    name: 'TechStore Electronics',
    email: 'admin@techstore.com',
    website: 'techstore.com',
    apiStatus: 'active',
    paymentMethods: ['Credit Card', 'Bank Transfer', 'E-Wallet'],
    monthlyVolume: 145230,
    transactions: 1247,
    createdDate: '2025-08-15',
    apiKey: 'sk_live_51H8x...'
  },
  {
    id: 'MCH-1002',
    name: 'FashionHub',
    email: 'payments@fashionhub.com',
    website: 'fashionhub.com',
    apiStatus: 'active',
    paymentMethods: ['Credit Card', 'E-Wallet'],
    monthlyVolume: 89450,
    transactions: 892,
    createdDate: '2025-09-22',
    apiKey: 'sk_live_51J2k...'
  },
  {
    id: 'MCH-1003',
    name: 'GadgetWorld',
    email: 'contact@gadgetworld.com',
    website: 'gadgetworld.com',
    apiStatus: 'active',
    paymentMethods: ['Credit Card', 'Bank Transfer'],
    monthlyVolume: 234500,
    transactions: 1567,
    createdDate: '2025-07-10',
    apiKey: 'sk_live_51K3m...'
  },
  {
    id: 'MCH-1004',
    name: 'BookStore Online',
    email: 'support@bookstore.com',
    website: 'bookstore.com',
    apiStatus: 'inactive',
    paymentMethods: ['Credit Card'],
    monthlyVolume: 18920,
    transactions: 234,
    createdDate: '2025-11-05',
    apiKey: 'sk_test_51L4n...'
  },
  {
    id: 'MCH-1005',
    name: 'SportGear Pro',
    email: 'admin@sportgear.com',
    website: 'sportgear.com',
    apiStatus: 'suspended',
    paymentMethods: ['Credit Card', 'Bank Transfer', 'E-Wallet'],
    monthlyVolume: 0,
    transactions: 0,
    createdDate: '2025-10-18',
    apiKey: 'sk_live_51M5o...'
  },
  {
    id: 'MCH-1006',
    name: 'HomeDecor Plus',
    email: 'info@homedecor.com',
    website: 'homedecor.com',
    apiStatus: 'active',
    paymentMethods: ['Credit Card', 'E-Wallet'],
    monthlyVolume: 67890,
    transactions: 456,
    createdDate: '2025-12-01',
    apiKey: 'sk_live_51N6p...'
  }
];

const apiStatusConfig = {
  active: {
    bg: 'bg-[#6ee7b7]/10',
    text: 'text-[#6ee7b7]',
    border: 'border-[#6ee7b7]/30',
    icon: CheckCircle
  },
  inactive: {
    bg: 'bg-[#9ca3af]/10',
    text: 'text-[#9ca3af]',
    border: 'border-[#9ca3af]/30',
    icon: AlertCircle
  },
  suspended: {
    bg: 'bg-[#f87171]/10',
    text: 'text-[#f87171]',
    border: 'border-[#f87171]/30',
    icon: XCircle
  }
};

export function Merchants() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newMerchant, setNewMerchant] = useState({
    name: '',
    email: '',
    website: '',
    paymentMethods: [] as string[]
  });
  const [selectedMerchantId, setSelectedMerchantId] = useState<string | null>(null);

  const filteredMerchants = merchantsData.filter(merchant =>
    merchant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    merchant.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    merchant.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalMerchants = merchantsData.length;
  const activeMerchants = merchantsData.filter(m => m.apiStatus === 'active').length;
  const totalVolume = merchantsData.reduce((sum, m) => sum + m.monthlyVolume, 0);
  const totalTransactions = merchantsData.reduce((sum, m) => sum + m.transactions, 0);

  const togglePaymentMethod = (method: string) => {
    setNewMerchant(prev => ({
      ...prev,
      paymentMethods: prev.paymentMethods.includes(method)
        ? prev.paymentMethods.filter(m => m !== method)
        : [...prev.paymentMethods, method]
    }));
  };

  const navigate = useNavigate();

  // Transform merchant data for sidebar
  const getSelectedMerchantDetail = () => {
    if (!selectedMerchantId) return null;
    
    const merchant = merchantsData.find(m => m.id === selectedMerchantId);
    if (!merchant) return null;

    return {
      id: merchant.id,
      name: merchant.name,
      code: 'PL',
      country: 'Egypt',
      status: merchant.apiStatus === 'active' ? 'active' as const : merchant.apiStatus === 'suspended' ? 'inactive' as const : 'gold' as const,
      volumeToday: `EGP ${(merchant.monthlyVolume / 30).toFixed(1)}K`,
      joined: merchant.createdDate.split('-')[1] === '03' ? 'Mar 2021' : 'Mar 2026',
      group: 'Premium Partners',
      tabs: [
        { id: 'overview', label: 'Overview', icon: '📊' },
        { id: 'payment', label: 'Payment Methods', icon: '💳' },
        { id: 'corridors', label: 'Corridors', icon: '🌐' },
        { id: 'api', label: 'API & Webhooks', icon: '🔌' },
        { id: 'settings', label: 'Settings', icon: '⚙️' }
      ],
      volumeData: [
        { day: 'Mon', value: 85 },
        { day: 'Tue', value: 72 },
        { day: 'Wed', value: 90 },
        { day: 'Thu', value: 78 },
        { day: 'Fri', value: 95 },
        { day: 'Sat', value: 88 },
        { day: 'Sun', value: 100 }
      ],
      paymentMethods: [
        { name: 'Vodafone Cash', percentage: 42, amount: '5.26K' },
        { name: 'InstaPay', percentage: 28, amount: '3.49K' },
        { name: 'Fawry', percentage: 18, amount: '2.24K' },
        { name: 'QB Card', percentage: 12, amount: '1.49K' }
      ],
      stats: {
        successRate: '97.3%',
        avgTransaction: 'EGP 1,840',
        complaints: '3 open',
        chargebacks: '0.12%'
      }
    };
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-white mb-2">Merchant Manager</h1>
          <p className="text-gray-400">Manage merchant accounts and API access</p>
        </div>
        <motion.button
          onClick={() => setShowCreateModal(true)}
          className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2"
          whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
          whileTap={{ scale: 0.95 }}
        >
          <Plus className="w-5 h-5" />
          Create Merchant
        </motion.button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20">
              <Users className="w-6 h-6 text-[#8b5cf6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Merchants</p>
            <h3 className="text-3xl font-semibold text-white">{totalMerchants}</h3>
            <p className="text-xs text-gray-500">Registered accounts</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20">
              <CheckCircle className="w-6 h-6 text-[#6ee7b7]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Active Merchants</p>
            <h3 className="text-3xl font-semibold text-white">{activeMerchants}</h3>
            <p className="text-xs text-gray-500">Currently processing</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#fbbf24]/20 to-[#f59e0b]/20">
              <DollarSign className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Total Volume</p>
            <h3 className="text-3xl font-semibold text-white">${(totalVolume / 1000).toFixed(0)}k</h3>
            <p className="text-xs text-gray-500">This month</p>
          </div>
        </GlassCard>

        <GlassCard hover className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#2563eb]/20">
              <Activity className="w-6 h-6 text-[#3b82f6]" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-gray-400 text-sm">Transactions</p>
            <h3 className="text-3xl font-semibold text-white">{totalTransactions.toLocaleString()}</h3>
            <p className="text-xs text-gray-500">This month</p>
          </div>
        </GlassCard>
      </div>

      {/* Search Bar */}
      <GlassCard className="p-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search merchants by name, ID, or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
          />
        </div>
      </GlassCard>

      {/* Merchants Table */}
      <GlassCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10 bg-white/5">
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Merchant ID</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Name</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">API Status</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Payment Methods</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Volume</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Transactions</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMerchants.map((merchant, index) => {
                const config = apiStatusConfig[merchant.apiStatus];
                const StatusIcon = config.icon;

                return (
                  <motion.tr
                    key={merchant.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-white/5 hover:bg-white/5 transition-all"
                  >
                    <td className="px-6 py-4">
                      <span className="font-mono text-sm text-white">{merchant.id}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm font-medium text-white">{merchant.name}</p>
                        <p className="text-xs text-gray-400">{merchant.email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${config.bg} ${config.text} border ${config.border}`}>
                        <StatusIcon className="w-3 h-3" />
                        <span className="text-xs font-medium capitalize">{merchant.apiStatus}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1">
                        {merchant.paymentMethods.map((method) => (
                          <span
                            key={method}
                            className="px-2 py-1 rounded-md bg-white/5 text-xs text-gray-300"
                          >
                            {method}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-semibold text-white">
                        ${merchant.monthlyVolume.toLocaleString()}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-white">{merchant.transactions}</span>
                    </td>
                    <td className="px-6 py-4">
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-2 rounded-lg hover:bg-white/10 transition-all"
                        onClick={() => {
                          // On larger screens, show sidebar; on smaller, navigate
                          if (window.innerWidth >= 1024) {
                            setSelectedMerchantId(merchant.id);
                          } else {
                            navigate(`/merchants/${merchant.id}`);
                          }
                        }}
                      >
                        <MoreVertical className="w-5 h-5 text-gray-400" />
                      </motion.button>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Create Merchant Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
              onClick={() => setShowCreateModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
              <div className="w-full max-w-2xl bg-[#1a1d23] border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
                {/* Modal Header */}
                <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#8b5cf6]/10 to-[#3b82f6]/10">
                  <h2 className="text-2xl font-semibold text-white">Create New Merchant</h2>
                  <motion.button
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setShowCreateModal(false)}
                    className="p-2 rounded-lg hover:bg-white/10 transition-all"
                  >
                    <X className="w-5 h-5 text-gray-400" />
                  </motion.button>
                </div>

                {/* Modal Body */}
                <div className="p-6 space-y-6">
                  {/* Merchant Name */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      Merchant Name
                    </label>
                    <input
                      type="text"
                      value={newMerchant.name}
                      onChange={(e) => setNewMerchant({ ...newMerchant, name: e.target.value })}
                      placeholder="Enter merchant business name"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={newMerchant.email}
                      onChange={(e) => setNewMerchant({ ...newMerchant, email: e.target.value })}
                      placeholder="merchant@example.com"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                    />
                  </div>

                  {/* Website */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Website URL
                    </label>
                    <input
                      type="url"
                      value={newMerchant.website}
                      onChange={(e) => setNewMerchant({ ...newMerchant, website: e.target.value })}
                      placeholder="https://example.com"
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-[#8b5cf6] focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                    />
                  </div>

                  {/* Payment Methods */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                      <Key className="w-4 h-4" />
                      Payment Methods
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {['Credit Card', 'Bank Transfer', 'E-Wallet'].map((method) => (
                        <motion.button
                          key={method}
                          onClick={() => togglePaymentMethod(method)}
                          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                            newMerchant.paymentMethods.includes(method)
                              ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#3b82f6]/20 text-white border border-[#8b5cf6]/30'
                              : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                          }`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          {method}
                        </motion.button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="px-6 py-4 border-t border-white/10 flex items-center justify-end gap-3 bg-white/5">
                  <motion.button
                    onClick={() => setShowCreateModal(false)}
                    className="px-6 py-3 rounded-full bg-white/5 text-white font-medium hover:bg-white/10 transition-all"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Cancel
                  </motion.button>
                  <motion.button
                    className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium"
                    whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      // Handle merchant creation
                      setShowCreateModal(false);
                      setNewMerchant({ name: '', email: '', website: '', paymentMethods: [] });
                    }}
                  >
                    Create Merchant
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Desktop Merchant Sidebar */}
      {selectedMerchantId && (
        <DesktopMerchantSidebar 
          merchant={getSelectedMerchantDetail()} 
          onClose={() => setSelectedMerchantId(null)} 
        />
      )}
    </div>
  );
}