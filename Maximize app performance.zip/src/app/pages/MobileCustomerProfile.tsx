import { motion } from 'motion/react';
import { useParams, useNavigate } from 'react-router';
import { 
  Mail,
  Phone,
  DollarSign,
  Receipt,
  Calendar,
  Plus,
  Edit3,
  Building2,
  CreditCard,
  TrendingUp,
  ArrowUpRight,
  CheckCircle2,
  Clock,
  XCircle
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { MobileAppCard } from '../components/MobileAppCard';
import { useState } from 'react';

interface CustomerProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive' | 'suspended';
  totalSpent: number;
  transactionCount: number;
  lastActivity: string;
  joinDate: string;
  notes: string[];
  linkedMerchants: {
    name: string;
    status: 'active' | 'inactive';
  }[];
}

interface CustomerTransaction {
  id: string;
  merchant: string;
  amount: number;
  currency: string;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  paymentMethod: string;
}

const mockProfile: CustomerProfile = {
  id: 'CUST-001',
  name: 'Ahmed Hassan',
  email: 'ahmed@example.com',
  phone: '+971 50-111-2222',
  status: 'active',
  totalSpent: 8550.00,
  transactionCount: 12,
  lastActivity: '2025-03-14',
  joinDate: '2024-01-15',
  notes: [
    'VIP customer',
    'Prefers bank transfers'
  ],
  linkedMerchants: [
    { name: 'GlobalPay Ltd', status: 'active' },
    { name: 'PayStream Inc', status: 'active' }
  ]
};

const mockTransactions: CustomerTransaction[] = [
  {
    id: '1',
    merchant: 'GlobalPay Ltd',
    amount: 3780.00,
    currency: 'USD',
    status: 'completed',
    date: '2025-03-13',
    paymentMethod: 'Bank Transfer'
  },
  {
    id: '2',
    merchant: 'PayStream Inc',
    amount: 1250.00,
    currency: 'USD',
    status: 'completed',
    date: '2025-03-10',
    paymentMethod: 'Credit Card'
  },
  {
    id: '3',
    merchant: 'GlobalPay Ltd',
    amount: 890.00,
    currency: 'USD',
    status: 'pending',
    date: '2025-03-08',
    paymentMethod: 'Wallet'
  },
  {
    id: '4',
    merchant: 'PayStream Inc',
    amount: 2630.00,
    currency: 'USD',
    status: 'completed',
    date: '2025-03-05',
    paymentMethod: 'Bank Transfer'
  }
];

export default function MobileCustomerProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, direction } = useLanguage();
  const [activeTab, setActiveTab] = useState<'profile' | 'transactions'>('profile');

  const profile = mockProfile;

  const getStatusConfig = (status: string) => {
    const configs = {
      active: {
        color: 'text-green-400',
        bgColor: 'bg-green-400/20',
        borderColor: 'border-green-400/30',
        label: direction === 'rtl' ? 'نشط' : 'Active'
      },
      inactive: {
        color: 'text-gray-400',
        bgColor: 'bg-gray-400/20',
        borderColor: 'border-gray-400/30',
        label: direction === 'rtl' ? 'غير نشط' : 'Inactive'
      },
      suspended: {
        color: 'text-red-400',
        bgColor: 'bg-red-400/20',
        borderColor: 'border-red-400/30',
        label: direction === 'rtl' ? 'معلق' : 'Suspended'
      }
    };
    return configs[status as keyof typeof configs] || configs.active;
  };

  const getTransactionStatusIcon = (status: string) => {
    const icons = {
      completed: { icon: CheckCircle2, color: 'text-green-400' },
      pending: { icon: Clock, color: 'text-yellow-400' },
      failed: { icon: XCircle, color: 'text-red-400' }
    };
    return icons[status as keyof typeof icons] || icons.completed;
  };

  const statusConfig = getStatusConfig(profile.status);

  return (
    <div className="pb-4">
      {/* Profile Header */}
      <div className="px-4 pt-4 pb-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-6 rounded-3xl bg-gradient-to-br from-[#1a1d23] to-[#252932] border border-white/10"
        >
          {/* Avatar and Basic Info */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center text-2xl font-bold text-white">
                {profile.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white mb-1">
                  {profile.name}
                </h2>
                <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg ${statusConfig.bgColor} border ${statusConfig.borderColor}`}>
                  <div className={`w-2 h-2 rounded-full ${statusConfig.color.replace('text-', 'bg-')}`} />
                  <span className={`text-xs font-medium ${statusConfig.color}`}>
                    {statusConfig.label}
                  </span>
                </div>
              </div>
            </div>
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
            >
              <Edit3 className="w-5 h-5 text-gray-400" />
            </motion.button>
          </div>

          {/* Contact Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
              <Mail className="w-5 h-5 text-[#8b5cf6] flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-xs text-gray-500 mb-0.5">
                  {direction === 'rtl' ? 'البريد الإلكتروني' : 'Email'}
                </div>
                <div className="text-white text-sm truncate">
                  {profile.email}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
              <Phone className="w-5 h-5 text-[#8b5cf6] flex-shrink-0" />
              <div className="flex-1">
                <div className="text-xs text-gray-500 mb-0.5">
                  {direction === 'rtl' ? 'الهاتف' : 'Phone'}
                </div>
                <div className="text-white text-sm">
                  {profile.phone}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Stats Cards */}
      <div className="px-4 mb-6">
        <div className="grid grid-cols-2 gap-3">
          <motion.div
            whileTap={{ scale: 0.97 }}
            className="p-4 rounded-2xl bg-gradient-to-br from-[#8b5cf6]/20 to-[#3b82f6]/20 border border-[#8b5cf6]/30"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-[#8b5cf6]/30 flex items-center justify-center">
                <DollarSign className="w-4 h-4 text-[#8b5cf6]" />
              </div>
              <div className="text-xs text-gray-400">
                {direction === 'rtl' ? 'إجمالي الإنفاق' : 'Total Spent'}
              </div>
            </div>
            <div className="text-2xl font-bold text-white mb-1">
              ${profile.totalSpent.toFixed(2)}
            </div>
            <div className="flex items-center gap-1 text-xs text-green-400">
              <TrendingUp className="w-3 h-3" />
              <span>+12% this month</span>
            </div>
          </motion.div>

          <motion.div
            whileTap={{ scale: 0.97 }}
            className="p-4 rounded-2xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#34d399]/20 border border-[#6ee7b7]/30"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-[#6ee7b7]/30 flex items-center justify-center">
                <Receipt className="w-4 h-4 text-[#6ee7b7]" />
              </div>
              <div className="text-xs text-gray-400">
                {direction === 'rtl' ? 'المعاملات' : 'Transactions'}
              </div>
            </div>
            <div className="text-2xl font-bold text-white mb-1">
              {profile.transactionCount}
            </div>
            <div className="text-xs text-gray-500">
              All time
            </div>
          </motion.div>
        </div>

        <div className="mt-3 p-4 rounded-2xl bg-white/5 border border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-gray-400" />
              <div>
                <div className="text-xs text-gray-500">
                  {direction === 'rtl' ? 'آخر نشاط' : 'Last Activity'}
                </div>
                <div className="text-white text-sm font-medium">
                  {profile.lastActivity}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-gray-500">
                {direction === 'rtl' ? 'تاريخ الانضمام' : 'Join Date'}
              </div>
              <div className="text-white text-sm font-medium">
                {profile.joinDate}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 mb-4">
        <div className="flex items-center gap-2 p-1 rounded-2xl bg-white/5 border border-white/10">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'profile'
                ? 'bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {direction === 'rtl' ? 'الملف الشخصي' : 'Profile'}
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('transactions')}
            className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'transactions'
                ? 'bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {direction === 'rtl' ? 'سجل الدفع' : 'Payment History'}
          </motion.button>
        </div>
      </div>

      {/* Content */}
      {activeTab === 'profile' ? (
        <>
          {/* Notes Section */}
          <div className="px-4 mb-4">
            <MobileAppCard gradient>
              <div className="flex items-center justify-between mb-4">
                <div className="text-white font-semibold text-sm uppercase tracking-wide text-gray-400">
                  {direction === 'rtl' ? 'ملاحظات' : 'NOTES'}
                </div>
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  className="p-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                >
                  <Plus className="w-4 h-4 text-gray-400" />
                </motion.button>
              </div>
              <div className="space-y-2">
                {profile.notes.map((note, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-2 p-3 rounded-xl bg-white/5 border border-white/10"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-[#8b5cf6] mt-2 flex-shrink-0" />
                    <p className="text-gray-300 text-sm flex-1">
                      {note}
                    </p>
                  </div>
                ))}
              </div>
            </MobileAppCard>
          </div>

          {/* Linked Merchants */}
          <div className="px-4 mb-6">
            <MobileAppCard gradient>
              <div className="text-white font-semibold text-sm uppercase tracking-wide text-gray-400 mb-4">
                {direction === 'rtl' ? 'التجار المرتبطون' : 'LINKED MERCHANTS'}
              </div>
              <div className="space-y-2">
                {profile.linkedMerchants.map((merchant, index) => {
                  const merchantStatus = getStatusConfig(merchant.status);
                  return (
                    <motion.div
                      key={index}
                      whileTap={{ scale: 0.98 }}
                      className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                          <Building2 className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="text-white font-medium text-sm">
                            {merchant.name}
                          </div>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <div className={`w-1.5 h-1.5 rounded-full ${merchantStatus.color.replace('text-', 'bg-')}`} />
                            <span className={`text-xs ${merchantStatus.color}`}>
                              {merchantStatus.label}
                            </span>
                          </div>
                        </div>
                      </div>
                      <ArrowUpRight className="w-4 h-4 text-gray-400" />
                    </motion.div>
                  );
                })}
              </div>
            </MobileAppCard>
          </div>
        </>
      ) : (
        <>
          {/* Payment History */}
          <div className="px-4 mb-6">
            <div className="space-y-3">
              {mockTransactions.map((transaction, index) => {
                const statusIcon = getTransactionStatusIcon(transaction.status);
                const StatusIcon = statusIcon.icon;

                return (
                  <motion.div
                    key={transaction.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <MobileAppCard gradient>
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1a1d23] to-[#252932] border border-white/10 flex items-center justify-center">
                            <CreditCard className="w-5 h-5 text-[#8b5cf6]" />
                          </div>
                          <div>
                            <div className="text-white font-medium text-sm">
                              {transaction.merchant}
                            </div>
                            <div className="text-gray-400 text-xs mt-0.5">
                              {transaction.paymentMethod}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-white font-bold text-sm">
                            ${transaction.amount.toFixed(2)}
                          </div>
                          <div className="text-gray-500 text-xs mt-0.5">
                            {transaction.currency}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-white/10">
                        <div className="flex items-center gap-1.5">
                          <StatusIcon className={`w-3.5 h-3.5 ${statusIcon.color}`} />
                          <span className={`text-xs font-medium ${statusIcon.color}`}>
                            {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                          </span>
                        </div>
                        <div className="text-gray-500 text-xs">
                          {transaction.date}
                        </div>
                      </div>
                    </MobileAppCard>
                  </motion.div>
                );
              })}
            </div>

            {/* Load More */}
            <motion.button
              whileTap={{ scale: 0.98 }}
              className="w-full mt-4 py-3 rounded-2xl bg-white/5 border border-white/10 text-gray-300 font-medium hover:bg-white/10 hover:text-white transition-all"
            >
              {direction === 'rtl' ? 'تحميل المزيد' : 'Load More'}
            </motion.button>
          </div>
        </>
      )}

      {/* Action Button */}
      <div className="px-4 mb-8">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate(-1)}
          className="w-full py-4 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] text-white font-semibold hover:from-[#9d6fff] hover:to-[#4a8eff] transition-all"
        >
          {direction === 'rtl' ? 'العودة' : 'Back'}
        </motion.button>
      </div>
    </div>
  );
}
