import { motion } from 'motion/react';
import { useState } from 'react';
import { GlassCard } from '../components/GlassCard';
import {
  Building2,
  Mail,
  Phone,
  Globe,
  MapPin,
  CreditCard,
  FileText,
  CheckCircle2,
  ArrowRight,
  Upload,
  User,
  Briefcase
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export function MerchantOnboarding() {
  const { t, direction } = useLanguage();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Business Info
    businessName: '',
    businessNameAr: '',
    businessType: '',
    taxId: '',
    registrationNumber: '',
    
    // Contact Info
    contactName: '',
    email: '',
    phone: '',
    website: '',
    
    // Address
    country: '',
    city: '',
    address: '',
    postalCode: '',
    
    // Bank Info
    bankName: '',
    accountName: '',
    accountNumber: '',
    iban: '',
    
    // Documents
    commercialLicense: null,
    taxCertificate: null,
    idCopy: null
  });

  const steps = [
    { number: 1, title: direction === 'rtl' ? 'معلومات الشركة' : 'Business Information', icon: Building2 },
    { number: 2, title: direction === 'rtl' ? 'معلومات الاتصال' : 'Contact Information', icon: User },
    { number: 3, title: direction === 'rtl' ? 'العنوان' : 'Address', icon: MapPin },
    { number: 4, title: direction === 'rtl' ? 'المعلومات البنكية' : 'Bank Information', icon: CreditCard },
    { number: 5, title: direction === 'rtl' ? 'المستندات' : 'Documents', icon: FileText },
    { number: 6, title: direction === 'rtl' ? 'المراجعة' : 'Review', icon: CheckCircle2 }
  ];

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-4">
              {direction === 'rtl' ? 'معلومات الشركة' : 'Business Information'}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'اسم الشركة (English)' : 'Business Name (English)'}
                </label>
                <input
                  type="text"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل اسم الشركة' : 'Enter business name'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'اسم الشركة (العربية)' : 'Business Name (Arabic)'}
                </label>
                <input
                  type="text"
                  value={formData.businessNameAr}
                  onChange={(e) => setFormData({ ...formData, businessNameAr: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل اسم الشركة بالعربية' : 'Enter business name in Arabic'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'نوع النشاط' : 'Business Type'}
                </label>
                <select
                  value={formData.businessType}
                  onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                >
                  <option value="">{direction === 'rtl' ? 'اختر نوع النشاط' : 'Select business type'}</option>
                  <option value="retail">Retail / تجزئة</option>
                  <option value="ecommerce">E-Commerce / تجارة إلكترونية</option>
                  <option value="services">Services / خدمات</option>
                  <option value="restaurant">Restaurant / مطعم</option>
                  <option value="technology">Technology / تكنولوجيا</option>
                  <option value="other">Other / أخرى</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الرقم الضريبي' : 'Tax ID'}
                </label>
                <input
                  type="text"
                  value={formData.taxId}
                  onChange={(e) => setFormData({ ...formData, taxId: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder="000-000-000"
                />
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'رقم السجل التجاري' : 'Commercial Registration Number'}
                </label>
                <input
                  type="text"
                  value={formData.registrationNumber}
                  onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل رقم السجل التجاري' : 'Enter registration number'}
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-4">
              {direction === 'rtl' ? 'معلومات الاتصال' : 'Contact Information'}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'اسم الشخص المسؤول' : 'Contact Person Name'}
                </label>
                <input
                  type="text"
                  value={formData.contactName}
                  onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل اسم المسؤول' : 'Enter contact name'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'البريد الإلكتروني' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'right-3' : 'left-3'}`} />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`w-full ${direction === 'rtl' ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50`}
                    placeholder="email@example.com"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'رقم الهاتف' : 'Phone Number'}
                </label>
                <div className="relative">
                  <Phone className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'right-3' : 'left-3'}`} />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={`w-full ${direction === 'rtl' ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50`}
                    placeholder="+20 100 000 0000"
                  />
                </div>
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الموقع الإلكتروني' : 'Website (Optional)'}
                </label>
                <div className="relative">
                  <Globe className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 ${direction === 'rtl' ? 'right-3' : 'left-3'}`} />
                  <input
                    type="url"
                    value={formData.website}
                    onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                    className={`w-full ${direction === 'rtl' ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50`}
                    placeholder="https://www.example.com"
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-4">
              {direction === 'rtl' ? 'عنوان الشركة' : 'Business Address'}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الدولة' : 'Country'}
                </label>
                <select
                  value={formData.country}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                >
                  <option value="">{direction === 'rtl' ? 'اختر الدولة' : 'Select country'}</option>
                  <option value="EG">🇪🇬 Egypt</option>
                  <option value="SA">🇸🇦 Saudi Arabia</option>
                  <option value="AE">🇦🇪 UAE</option>
                  <option value="KW">🇰🇼 Kuwait</option>
                  <option value="QA">🇶🇦 Qatar</option>
                  <option value="BH">🇧🇭 Bahrain</option>
                  <option value="OM">🇴🇲 Oman</option>
                  <option value="JO">🇯🇴 Jordan</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'المدينة' : 'City'}
                </label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل المدينة' : 'Enter city'}
                />
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'العنوان' : 'Street Address'}
                </label>
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50 resize-none"
                  rows={3}
                  placeholder={direction === 'rtl' ? 'أدخل العنوان الكامل' : 'Enter full address'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'الرمز البريدي' : 'Postal Code'}
                </label>
                <input
                  type="text"
                  value={formData.postalCode}
                  onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder="00000"
                />
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-4">
              {direction === 'rtl' ? 'المعلومات البنكية' : 'Bank Information'}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'اسم البنك' : 'Bank Name'}
                </label>
                <input
                  type="text"
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل اسم البنك' : 'Enter bank name'}
                />
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'اسم صاحب الحساب' : 'Account Holder Name'}
                </label>
                <input
                  type="text"
                  value={formData.accountName}
                  onChange={(e) => setFormData({ ...formData, accountName: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder={direction === 'rtl' ? 'أدخل اسم صاحب الحساب' : 'Enter account holder name'}
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'رقم الحساب' : 'Account Number'}
                </label>
                <input
                  type="text"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder="0000000000"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  {direction === 'rtl' ? 'IBAN' : 'IBAN'}
                </label>
                <input
                  type="text"
                  value={formData.iban}
                  onChange={(e) => setFormData({ ...formData, iban: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6]/50"
                  placeholder="EG00 0000 0000 0000 0000 0000 000"
                />
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-4">
              {direction === 'rtl' ? 'رفع المستندات' : 'Upload Documents'}
            </h3>
            
            <div className="space-y-4">
              {[
                { name: 'commercialLicense', label: direction === 'rtl' ? 'السجل التجاري' : 'Commercial License', required: true },
                { name: 'taxCertificate', label: direction === 'rtl' ? 'الشهادة الضريبية' : 'Tax Certificate', required: true },
                { name: 'idCopy', label: direction === 'rtl' ? 'نسخة من الهوية' : 'ID Copy', required: true }
              ].map((doc) => (
                <div key={doc.name} className="p-6 rounded-xl bg-white/5 border-2 border-dashed border-white/10 hover:border-[#8b5cf6]/30 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <FileText className="w-6 h-6 text-[#8b5cf6]" />
                      <div>
                        <p className="text-white font-semibold">{doc.label}</p>
                        <p className="text-xs text-gray-400">
                          {doc.required && (direction === 'rtl' ? 'مطلوب' : 'Required')} • PDF, JPG, PNG (Max 5MB)
                        </p>
                      </div>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2"
                    >
                      <Upload className="w-4 h-4" />
                      {direction === 'rtl' ? 'رفع' : 'Upload'}
                    </motion.button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-4">
              {direction === 'rtl' ? 'مراجعة المعلومات' : 'Review Your Information'}
            </h3>
            
            <GlassCard>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">{direction === 'rtl' ? 'معلومات الشركة' : 'Business Information'}</p>
                  <p className="text-lg font-bold text-white">{formData.businessName || 'Not provided'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-400">{direction === 'rtl' ? 'نوع النشاط' : 'Business Type'}</p>
                  <p className="text-white">{formData.businessType || 'Not provided'}</p>
                </div>
                <div>
                  <p className="text-gray-400">{direction === 'rtl' ? 'الرقم الضريبي' : 'Tax ID'}</p>
                  <p className="text-white">{formData.taxId || 'Not provided'}</p>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">{direction === 'rtl' ? 'معلومات الاتصال' : 'Contact Information'}</p>
                  <p className="text-lg font-bold text-white">{formData.contactName || 'Not provided'}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-400">{direction === 'rtl' ? 'البريد' : 'Email'}</p>
                  <p className="text-white">{formData.email || 'Not provided'}</p>
                </div>
                <div>
                  <p className="text-gray-400">{direction === 'rtl' ? 'الهاتف' : 'Phone'}</p>
                  <p className="text-white">{formData.phone || 'Not provided'}</p>
                </div>
              </div>
            </GlassCard>

            <div className="p-6 rounded-xl bg-green-400/10 border border-green-400/30">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-semibold mb-1">
                    {direction === 'rtl' ? 'جاهز للإرسال!' : 'Ready to Submit!'}
                  </p>
                  <p className="text-sm text-gray-300">
                    {direction === 'rtl' 
                      ? 'برجاء مراجعة جميع المعلومات قبل الإرسال. سيتم مراجعة طلبك خلال 24-48 ساعة.'
                      : 'Please review all information before submitting. Your application will be reviewed within 24-48 hours.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f1117] via-[#1a1d23] to-[#0f1117] p-4 md:p-8" dir={direction}>
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            {direction === 'rtl' ? 'تسجيل تاجر جديد' : 'Merchant Onboarding'}
          </h1>
          <p className="text-gray-400">
            {direction === 'rtl' 
              ? 'انضم إلى منصة OnTarget PSP وابدأ في قبول المدفوعات'
              : 'Join OnTarget PSP and start accepting payments'
            }
          </p>
        </div>

        {/* Steps Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = currentStep === step.number;
              const isCompleted = currentStep > step.number;
              
              return (
                <div key={step.number} className="flex-1">
                  <div className="flex items-center">
                    <div className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all ${
                      isCompleted 
                        ? 'bg-green-400 border-green-400'
                        : isActive
                          ? 'bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] border-[#8b5cf6]'
                          : 'bg-white/5 border-white/10'
                    }`}>
                      {isCompleted ? (
                        <CheckCircle2 className="w-6 h-6 text-white" />
                      ) : (
                        <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-500'}`} />
                      )}
                    </div>
                    
                    {index < steps.length - 1 && (
                      <div className={`flex-1 h-0.5 mx-2 ${
                        isCompleted ? 'bg-green-400' : 'bg-white/10'
                      }`} />
                    )}
                  </div>
                  
                  <p className={`text-xs mt-2 text-center ${
                    isActive ? 'text-white font-semibold' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Form Content */}
        <GlassCard className="mb-8">
          {renderStepContent()}
        </GlassCard>

        {/* Navigation Buttons */}
        <div className="flex items-center gap-4">
          {currentStep > 1 && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handlePrevious}
              className="flex-1 py-4 rounded-2xl bg-white/5 border border-white/10 text-gray-300 font-semibold hover:bg-white/10 transition-all"
            >
              {direction === 'rtl' ? 'السابق' : 'Previous'}
            </motion.button>
          )}
          
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleNext}
            className="flex-1 py-4 rounded-2xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-semibold shadow-lg shadow-[#8b5cf6]/20 flex items-center justify-center gap-2"
          >
            {currentStep === steps.length 
              ? (direction === 'rtl' ? 'إرسال الطلب' : 'Submit Application')
              : (direction === 'rtl' ? 'التالي' : 'Next')
            }
            {currentStep < steps.length && <ArrowRight className={`w-5 h-5 ${direction === 'rtl' ? 'rotate-180' : ''}`} />}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
