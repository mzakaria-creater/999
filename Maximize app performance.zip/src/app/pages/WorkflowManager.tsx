import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { useState } from 'react';
import { 
  GitBranch,
  Play,
  Pause,
  Plus,
  Settings,
  Trash2,
  Copy,
  Clock,
  CheckCircle,
  AlertTriangle,
  Zap,
  Mail,
  Bell,
  Database,
  Filter,
  Send,
  FileText,
  DollarSign,
  Users,
  ArrowRight,
  Edit,
  Eye,
  MoreVertical,
  TrendingUp
} from 'lucide-react';

interface WorkflowNode {
  id: string;
  type: 'trigger' | 'condition' | 'action';
  name: string;
  icon: any;
  config?: any;
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'inactive' | 'draft';
  trigger: string;
  nodes: WorkflowNode[];
  executions: number;
  lastRun: string;
  successRate: number;
}

export function WorkflowManager() {
  const { t } = useLanguage();
  const [selectedWorkflow, setSelectedWorkflow] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const workflows: Workflow[] = [
    {
      id: 'wf-001',
      name: 'Auto-Approve Low Value Transactions',
      description: 'Automatically approve transactions under 1000 EGP',
      status: 'active',
      trigger: 'New Transaction',
      nodes: [
        { id: 'n1', type: 'trigger', name: 'New Transaction', icon: Zap },
        { id: 'n2', type: 'condition', name: 'Amount < 1000 EGP', icon: Filter },
        { id: 'n3', type: 'action', name: 'Auto Approve', icon: CheckCircle },
        { id: 'n4', type: 'action', name: 'Send Email', icon: Mail }
      ],
      executions: 1247,
      lastRun: '2m ago',
      successRate: 98.5
    },
    {
      id: 'wf-002',
      name: 'Fraud Detection Alert',
      description: 'Alert security team for suspicious transactions',
      status: 'active',
      trigger: 'Suspicious Activity',
      nodes: [
        { id: 'n1', type: 'trigger', name: 'Suspicious Pattern', icon: AlertTriangle },
        { id: 'n2', type: 'condition', name: 'Risk Score > 70', icon: Filter },
        { id: 'n3', type: 'action', name: 'Flag Transaction', icon: AlertTriangle },
        { id: 'n4', type: 'action', name: 'Notify Team', icon: Bell }
      ],
      executions: 89,
      lastRun: '15m ago',
      successRate: 100
    },
    {
      id: 'wf-003',
      name: 'Daily Settlement Report',
      description: 'Generate and send daily settlement reports',
      status: 'active',
      trigger: 'Scheduled Daily',
      nodes: [
        { id: 'n1', type: 'trigger', name: 'Daily at 11:59 PM', icon: Clock },
        { id: 'n2', type: 'action', name: 'Generate Report', icon: FileText },
        { id: 'n3', type: 'action', name: 'Email Finance Team', icon: Mail }
      ],
      executions: 365,
      lastRun: '18h ago',
      successRate: 99.7
    },
    {
      id: 'wf-004',
      name: 'High-Value Transaction Approval',
      description: 'Require manual approval for transactions over 50K',
      status: 'active',
      trigger: 'New Transaction',
      nodes: [
        { id: 'n1', type: 'trigger', name: 'New Transaction', icon: Zap },
        { id: 'n2', type: 'condition', name: 'Amount > 50,000 EGP', icon: Filter },
        { id: 'n3', type: 'action', name: 'Request Approval', icon: Users },
        { id: 'n4', type: 'action', name: 'Notify Admin', icon: Bell }
      ],
      executions: 234,
      lastRun: '45m ago',
      successRate: 95.2
    },
    {
      id: 'wf-005',
      name: 'Merchant Onboarding Welcome',
      description: 'Send welcome package to new merchants',
      status: 'inactive',
      trigger: 'New Merchant',
      nodes: [
        { id: 'n1', type: 'trigger', name: 'Merchant Registered', icon: Users },
        { id: 'n2', type: 'action', name: 'Send Welcome Email', icon: Mail },
        { id: 'n3', type: 'action', name: 'Create API Keys', icon: Database }
      ],
      executions: 156,
      lastRun: '3d ago',
      successRate: 100
    },
    {
      id: 'wf-006',
      name: 'Failed Transaction Retry',
      description: 'Automatically retry failed transactions',
      status: 'draft',
      trigger: 'Failed Transaction',
      nodes: [
        { id: 'n1', type: 'trigger', name: 'Transaction Failed', icon: AlertTriangle },
        { id: 'n2', type: 'condition', name: 'Retry Count < 3', icon: Filter },
        { id: 'n3', type: 'action', name: 'Wait 5 Minutes', icon: Clock },
        { id: 'n4', type: 'action', name: 'Retry Transaction', icon: Zap }
      ],
      executions: 0,
      lastRun: 'Never',
      successRate: 0
    }
  ];

  const stats = [
    { label: 'Active Workflows', value: workflows.filter(w => w.status === 'active').length, icon: GitBranch, color: 'from-[#10b981] to-[#059669]' },
    { label: 'Total Executions', value: workflows.reduce((acc, w) => acc + w.executions, 0).toLocaleString(), icon: Zap, color: 'from-[#8b5cf6] to-[#7c3aed]' },
    { label: 'Avg Success Rate', value: `${(workflows.reduce((acc, w) => acc + w.successRate, 0) / workflows.length).toFixed(1)}%`, icon: TrendingUp, color: 'from-[#3b82f6] to-[#2563eb]' },
    { label: 'Triggers Today', value: '342', icon: Zap, color: 'from-[#f59e0b] to-[#d97706]' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'inactive': return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      case 'draft': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'trigger': return 'from-[#8b5cf6] to-[#7c3aed]';
      case 'condition': return 'from-[#f59e0b] to-[#d97706]';
      case 'action': return 'from-[#3b82f6] to-[#2563eb]';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="p-4 sm:p-8 max-w-[1800px] mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center">
                <GitBranch className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-semibold text-white">Workflow Manager</h1>
                <p className="text-gray-400">Automate your payment operations</p>
              </div>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowCreateModal(true)}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2 shadow-lg hover:shadow-violet-500/30 transition-shadow"
          >
            <Plus className="w-5 h-5" />
            Create Workflow
          </motion.button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                   style={{ backgroundImage: `linear-gradient(135deg, ${stat.color})` }} />
              <div className="relative">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <p className="text-2xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-sm text-gray-400">{stat.label}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Workflows List */}
      <div className="grid grid-cols-1 gap-4">
        {workflows.map((workflow, index) => (
          <motion.div
            key={workflow.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="p-6 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50 hover:border-white/20 transition-all"
          >
            <div className="flex flex-col lg:flex-row lg:items-center gap-6">
              {/* Workflow Info */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-semibold text-white">{workflow.name}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(workflow.status)}`}>
                        {workflow.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-400 mb-3">{workflow.description}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <div className="flex items-center gap-1">
                        <Zap className="w-4 h-4" />
                        <span>{workflow.trigger}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Play className="w-4 h-4" />
                        <span>{workflow.executions} runs</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{workflow.lastRun}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-green-400">{workflow.successRate}% success</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Workflow Nodes Visual */}
                <div className="flex items-center gap-2 overflow-x-auto pb-2">
                  {workflow.nodes.map((node, idx) => {
                    const Icon = node.icon;
                    return (
                      <div key={node.id} className="flex items-center gap-2 flex-shrink-0">
                        <div className={`px-3 py-2 rounded-lg bg-gradient-to-br ${getNodeColor(node.type)} flex items-center gap-2 shadow-lg`}>
                          <Icon className="w-4 h-4 text-white" />
                          <span className="text-xs font-medium text-white whitespace-nowrap">{node.name}</span>
                        </div>
                        {idx < workflow.nodes.length - 1 && (
                          <ArrowRight className="w-4 h-4 text-gray-500 flex-shrink-0" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-row lg:flex-col gap-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  title="Edit Workflow"
                >
                  <Edit className="w-5 h-5 text-gray-400" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  title="View Details"
                >
                  <Eye className="w-5 h-5 text-gray-400" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  title="Duplicate"
                >
                  <Copy className="w-5 h-5 text-gray-400" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  title={workflow.status === 'active' ? 'Pause' : 'Activate'}
                >
                  {workflow.status === 'active' ? (
                    <Pause className="w-5 h-5 text-yellow-400" />
                  ) : (
                    <Play className="w-5 h-5 text-green-400" />
                  )}
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-white/5 hover:bg-red-500/20 transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-5 h-5 text-red-400" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Workflow Templates */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-8 p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/90 to-[#1a1d23]/50"
      >
        <h2 className="text-2xl font-semibold text-white mb-6">Popular Workflow Templates</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              name: 'Payment Reconciliation',
              description: 'Auto-match payments with invoices',
              icon: DollarSign,
              color: 'from-green-500 to-emerald-500'
            },
            {
              name: 'Refund Processing',
              description: 'Automated refund approval workflow',
              icon: Send,
              color: 'from-blue-500 to-cyan-500'
            },
            {
              name: 'Compliance Checker',
              description: 'Verify KYC and AML requirements',
              icon: CheckCircle,
              color: 'from-purple-500 to-violet-500'
            },
            {
              name: 'Invoice Generator',
              description: 'Create and send invoices automatically',
              icon: FileText,
              color: 'from-orange-500 to-red-500'
            },
            {
              name: 'Chargeback Handler',
              description: 'Manage chargeback disputes',
              icon: AlertTriangle,
              color: 'from-red-500 to-pink-500'
            },
            {
              name: 'Customer Notification',
              description: 'Send payment status updates',
              icon: Bell,
              color: 'from-yellow-500 to-amber-500'
            }
          ].map((template, index) => {
            const Icon = template.icon;
            return (
              <motion.button
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="p-6 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all text-left"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{template.name}</h3>
                <p className="text-sm text-gray-400 mb-4">{template.description}</p>
                <div className="flex items-center gap-2 text-sm text-[#8b5cf6]">
                  <Plus className="w-4 h-4" />
                  <span>Use Template</span>
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* Create Workflow Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCreateModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="p-8 rounded-2xl backdrop-blur-xl border border-white/10 bg-gradient-to-br from-[#1a1d23]/95 to-[#1a1d23]/90 max-w-2xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-semibold text-white">Create New Workflow</h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <Trash2 className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Workflow Name
                  </label>
                  <input
                    type="text"
                    placeholder="Enter workflow name..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Describe what this workflow does..."
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#8b5cf6] transition-colors resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Trigger
                  </label>
                  <select className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors">
                    <option value="">Select a trigger...</option>
                    <option value="new_transaction">New Transaction</option>
                    <option value="failed_transaction">Failed Transaction</option>
                    <option value="new_merchant">New Merchant</option>
                    <option value="schedule">Scheduled</option>
                    <option value="webhook">Webhook</option>
                  </select>
                </div>

                <div className="flex gap-3 pt-4">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium"
                  >
                    Create Workflow
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setShowCreateModal(false)}
                    className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium border border-white/10 transition-all"
                  >
                    Cancel
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
