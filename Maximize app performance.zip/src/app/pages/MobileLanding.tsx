import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Smartphone } from 'lucide-react';

export default function MobileLanding() {
  const navigate = useNavigate();

  useEffect(() => {
    // Auto-redirect to mobile transactions after 1 second
    const timer = setTimeout(() => {
      navigate('/mobile/transactions');
    }, 1500);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0b0d] via-[#121417] to-[#0a0b0d] flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center"
      >
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="w-24 h-24 mx-auto mb-6 rounded-3xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center shadow-2xl"
        >
          <Smartphone className="w-12 h-12 text-white" />
        </motion.div>
        
        <h1 className="text-3xl font-bold text-white mb-3">
          OnTarget PSP
        </h1>
        
        <p className="text-gray-400 text-lg mb-8">
          Mobile Transactions Center
        </p>

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: '100%' }}
          transition={{ duration: 1.5 }}
          className="h-1 bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] rounded-full max-w-xs mx-auto"
        />
      </motion.div>
    </div>
  );
}
