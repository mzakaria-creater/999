import { motion } from 'motion/react';
import { GlassCard } from '../components/GlassCard';
import {
  Shield,
  Check,
  X,
  Info,
  Users,
  Settings
} from 'lucide-react';
import { UserRole, rolePermissions } from '../context/RoleContext';

interface Permission {
  page: string;
  label: string;
  description: string;
}

const permissions: Permission[] = [
  {
    page: 'dashboard',
    label: 'Dashboard',
    description: 'View revenue analytics, wallet balances, and live transactions'
  },
  {
    page: 'transactions',
    label: 'Transactions',
    description: 'Access transaction history with advanced filtering'
  },
  {
    page: 'wallets',
    label: 'Wallets',
    description: 'Manage wallet allocation and monitor capacity'
  },
  {
    page: 'merchants',
    label: 'Merchants',
    description: 'Create and manage merchant accounts'
  },
  {
    page: 'payment-methods',
    label: 'Payment Methods',
    description: 'Configure and manage payment methods and providers'
  },
  {
    page: 'payment-accounts',
    label: 'Payment Accounts',
    description: 'Manage receiving accounts, wallets, and bank accounts'
  },
  {
    page: 'payment-pages',
    label: 'Payment Pages',
    description: 'Configure hosted payment pages and links'
  },
  {
    page: 'embed-integration',
    label: 'Embed Integration',
    description: 'Integrate payment widgets into websites'
  },
  {
    page: 'api-docs',
    label: 'API Documentation',
    description: 'Access API documentation and keys'
  },
  {
    page: 'permissions',
    label: 'Permissions',
    description: 'View and manage role-based permissions'
  }
];

const roles: { role: UserRole; description: string; color: string }[] = [
  {
    role: 'Owner',
    description: 'Full access to all features and settings',
    color: 'from-[#8b5cf6] to-[#3b82f6]'
  },
  {
    role: 'Admin',
    description: 'Manage operations and configurations',
    color: 'from-[#6ee7b7] to-[#06b6d4]'
  },
  {
    role: 'Finance',
    description: 'Access financial data and reports',
    color: 'from-[#fbbf24] to-[#f59e0b]'
  },
  {
    role: 'Operations',
    description: 'Handle daily operations and merchants',
    color: 'from-[#3b82f6] to-[#2563eb]'
  },
  {
    role: 'Merchant',
    description: 'Access payment tools and documentation',
    color: 'from-[#f87171] to-[#ef4444]'
  },
  {
    role: 'Viewer',
    description: 'Read-only dashboard access',
    color: 'from-[#9ca3af] to-[#6b7280]'
  }
];

export function Permissions() {
  const hasAccess = (role: UserRole, page: string) => {
    return rolePermissions[role]?.[page] || false;
  };

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-semibold text-white mb-2">Permissions Matrix</h1>
        <p className="text-gray-400">Role-based access control for platform features</p>
      </div>

      {/* Role Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {roles.map((roleInfo, index) => {
          const rolePerms = rolePermissions[roleInfo.role];
          const accessCount = Object.keys(rolePerms).filter(key => rolePerms[key]).length;
          const totalPermissions = permissions.length;
          const accessPercentage = (accessCount / totalPermissions) * 100;

          return (
            <motion.div
              key={roleInfo.role}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard hover className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${roleInfo.color}`}>
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-white">{accessCount}</p>
                    <p className="text-xs text-gray-400">of {totalPermissions}</p>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{roleInfo.role}</h3>
                <p className="text-sm text-gray-400 mb-4">{roleInfo.description}</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">Access Level</span>
                    <span className="text-white font-semibold">{Math.round(accessPercentage)}%</span>
                  </div>
                  <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full bg-gradient-to-r ${roleInfo.color}`}
                      initial={{ width: 0 }}
                      animate={{ width: `${accessPercentage}%` }}
                      transition={{ delay: index * 0.1 + 0.2, duration: 0.8 }}
                      style={{ boxShadow: '0 0 12px rgba(139, 92, 246, 0.5)' }}
                    />
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* Permissions Matrix Table */}
      <GlassCard className="overflow-hidden">
        <div className="p-6 border-b border-white/10 bg-gradient-to-r from-[#8b5cf6]/10 to-[#3b82f6]/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6]">
                <Users className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-white">Access Control Matrix</h2>
                <p className="text-sm text-gray-400">Detailed permission breakdown by role</p>
              </div>
            </div>
            <motion.button
              className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white font-medium flex items-center gap-2"
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(139, 92, 246, 0.5)' }}
              whileTap={{ scale: 0.95 }}
            >
              <Settings className="w-5 h-5" />
              Manage Roles
            </motion.button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10 bg-white/5">
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400 w-1/4">
                  Feature
                </th>
                {roles.map((roleInfo) => (
                  <th
                    key={roleInfo.role}
                    className="text-center px-6 py-4 text-sm font-medium text-gray-400"
                  >
                    {roleInfo.role}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {permissions.map((permission, index) => (
                <motion.tr
                  key={permission.page}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-all"
                >
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium text-white">{permission.label}</p>
                      <p className="text-xs text-gray-400 mt-1">{permission.description}</p>
                    </div>
                  </td>
                  {roles.map((roleInfo) => {
                    const allowed = hasAccess(roleInfo.role, permission.page);
                    
                    return (
                      <td key={roleInfo.role} className="px-6 py-4 text-center">
                        {allowed ? (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ delay: index * 0.05 + 0.2 }}
                            className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-[#6ee7b7]/10 border border-[#6ee7b7]/30"
                          >
                            <Check className="w-5 h-5 text-[#6ee7b7]" />
                          </motion.div>
                        ) : (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ delay: index * 0.05 + 0.2 }}
                            className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-white/5"
                          >
                            <X className="w-5 h-5 text-gray-600" />
                          </motion.div>
                        )}
                      </td>
                    );
                  })}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <GlassCard className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#3b82f6]/20 to-[#2563eb]/20 flex-shrink-0">
              <Info className="w-6 h-6 text-[#3b82f6]" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Permission Inheritance</h3>
              <p className="text-sm text-gray-400 mb-3">
                Roles are hierarchical. Higher-level roles inherit all permissions from lower-level roles, plus additional capabilities.
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 rounded-full bg-[#8b5cf6]" style={{ boxShadow: '0 0 8px #8b5cf6' }} />
                  <span className="text-gray-300">Owner → Admin → Operations/Finance → Merchant → Viewer</span>
                </div>
              </div>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#6ee7b7]/20 to-[#06b6d4]/20 flex-shrink-0">
              <Shield className="w-6 h-6 text-[#6ee7b7]" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Security Best Practices</h3>
              <p className="text-sm text-gray-400 mb-3">
                Follow the principle of least privilege. Grant users only the permissions they need to perform their job functions.
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-[#6ee7b7]" />
                  <span className="text-gray-300">Regularly audit user permissions</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-[#6ee7b7]" />
                  <span className="text-gray-300">Remove access for inactive users</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-[#6ee7b7]" />
                  <span className="text-gray-300">Monitor permission changes</span>
                </div>
              </div>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Role Recommendations */}
      <GlassCard className="p-8">
        <h2 className="text-xl font-semibold text-white mb-6">Role Recommendations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { role: 'Owner', useCase: 'Company founders and executives', team: 'C-Suite' },
            { role: 'Admin', useCase: 'System administrators and technical leads', team: 'IT/Engineering' },
            { role: 'Finance', useCase: 'Finance team and accountants', team: 'Finance Dept.' },
            { role: 'Operations', useCase: 'Operations team and support staff', team: 'Operations Dept.' },
            { role: 'Merchant', useCase: 'External merchants using the platform', team: 'Third-party' },
            { role: 'Viewer', useCase: 'Stakeholders needing read-only access', team: 'Executives/Analysts' }
          ].map((rec, index) => (
            <motion.div
              key={rec.role}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
            >
              <h4 className="text-sm font-semibold text-white mb-2">{rec.role}</h4>
              <p className="text-xs text-gray-400 mb-2">{rec.useCase}</p>
              <div className="flex items-center gap-2">
                <Users className="w-3 h-3 text-[#8b5cf6]" />
                <span className="text-xs text-[#8b5cf6]">{rec.team}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}