import { useState, useEffect } from 'react';

export function useIsMobile(breakpoint: number = 768): boolean {
  const [isMobile, setIsMobile] = useState<boolean>(false);

  useEffect(() => {
    // Check on mount
    const checkIsMobile = () => {
      const mobile = window.innerWidth < breakpoint;
      setIsMobile(mobile);
    };

    // Initial check
    checkIsMobile();

    // Listen for resize
    window.addEventListener('resize', checkIsMobile);

    return () => window.removeEventListener('resize', checkIsMobile);
  }, [breakpoint]);

  return isMobile;
}

// Alternative: Check for touch device
export function useIsTouchDevice(): boolean {
  const [isTouch, setIsTouch] = useState<boolean>(false);

  useEffect(() => {
    const checkIsTouch = () => {
      const touch = 
        'ontouchstart' in window ||
        navigator.maxTouchPoints > 0 ||
        // @ts-ignore
        navigator.msMaxTouchPoints > 0;
      setIsTouch(touch);
    };

    checkIsTouch();
  }, []);

  return isTouch;
}
