// Shared data for both desktop and mobile views
// All pages should import from this file to ensure consistency

export const dashboardStats = {
  totalRevenue: 73000,
  transactions: 1247,
  walletBalance: 284500,
  activeMerchants: 147,
};

export const revenueData = [
  { date: 'Mar 7', amount: 45000 },
  { date: 'Mar 8', amount: 52000 },
  { date: 'Mar 9', amount: 48000 },
  { date: 'Mar 10', amount: 61000 },
  { date: 'Mar 11', amount: 55000 },
  { date: 'Mar 12', amount: 67000 },
  { date: 'Mar 13', amount: 73000 },
];

export const paymentMethods = [
  { name: 'Credit Card', value: 45, color: '#8b5cf6' },
  { name: 'Bank Transfer', value: 30, color: '#3b82f6' },
  { name: 'E-Wallet', value: 25, color: '#6ee7b7' },
];

export const liveTransactions = [
  { id: 'TX-8372', merchant: 'TechStore', amount: 1250.00, status: 'success' as const, time: '2 min ago' },
  { id: 'TX-8371', merchant: 'FashionHub', amount: 890.50, status: 'success' as const, time: '5 min ago' },
  { id: 'TX-8370', merchant: 'GadgetWorld', amount: 2340.00, status: 'pending' as const, time: '7 min ago' },
  { id: 'TX-8369', merchant: 'BookStore', amount: 145.00, status: 'success' as const, time: '9 min ago' },
  { id: 'TX-8368', merchant: 'SportGear', amount: 567.80, status: 'failed' as const, time: '12 min ago' },
];

export const merchantsData = [
  {
    id: 'MCH-1001',
    name: 'TechStore Electronics',
    email: 'admin@techstore.com',
    website: 'techstore.com',
    apiStatus: 'active' as const,
    paymentMethods: ['Credit Card', 'Bank Transfer', 'E-Wallet'],
    monthlyVolume: 145230,
    transactions: 1247,
    createdDate: '2025-08-15',
    apiKey: 'sk_live_51H8x...'
  },
  {
    id: 'MCH-1002',
    name: 'FashionHub',
    email: 'payments@fashionhub.com',
    website: 'fashionhub.com',
    apiStatus: 'active' as const,
    paymentMethods: ['Credit Card', 'E-Wallet'],
    monthlyVolume: 89450,
    transactions: 892,
    createdDate: '2025-09-22',
    apiKey: 'sk_live_51J2k...'
  },
  {
    id: 'MCH-1003',
    name: 'GadgetWorld',
    email: 'contact@gadgetworld.com',
    website: 'gadgetworld.com',
    apiStatus: 'active' as const,
    paymentMethods: ['Credit Card', 'Bank Transfer'],
    monthlyVolume: 234500,
    transactions: 1567,
    createdDate: '2025-07-10',
    apiKey: 'sk_live_51K3m...'
  },
  {
    id: 'MCH-1004',
    name: 'BookStore Online',
    email: 'support@bookstore.com',
    website: 'bookstore.com',
    apiStatus: 'inactive' as const,
    paymentMethods: ['Credit Card'],
    monthlyVolume: 18920,
    transactions: 234,
    createdDate: '2025-11-05',
    apiKey: 'sk_test_51L4n...'
  },
  {
    id: 'MCH-1005',
    name: 'SportGear Pro',
    email: 'admin@sportgear.com',
    website: 'sportgear.com',
    apiStatus: 'suspended' as const,
    paymentMethods: ['Credit Card', 'Bank Transfer', 'E-Wallet'],
    monthlyVolume: 0,
    transactions: 0,
    createdDate: '2025-10-18',
    apiKey: 'sk_live_51M5o...'
  },
  {
    id: 'MCH-1006',
    name: 'HomeDecor Plus',
    email: 'info@homedecor.com',
    website: 'homedecor.com',
    apiStatus: 'active' as const,
    paymentMethods: ['Credit Card', 'E-Wallet'],
    monthlyVolume: 67890,
    transactions: 456,
    createdDate: '2025-12-01',
    apiKey: 'sk_live_51N6p...'
  }
];

export const walletsData = [
  {
    id: 'WAL-4523',
    name: 'Main Operations Wallet',
    currency: 'USD',
    balance: 125450.75,
    status: 'active' as const,
    dailyLimit: 50000,
    used: 42500,
    icon: '💼',
  },
  {
    id: 'WAL-4524',
    name: 'Reserve Wallet',
    currency: 'USD',
    balance: 89230.50,
    status: 'active' as const,
    dailyLimit: 30000,
    used: 12000,
    icon: '🏦',
  },
  {
    id: 'WAL-4525',
    name: 'Merchant Payouts',
    currency: 'USD',
    balance: 43780.25,
    status: 'active' as const,
    dailyLimit: 100000,
    used: 56700,
    icon: '💳',
  },
  {
    id: 'WAL-4526',
    name: 'Refunds Pool',
    currency: 'USD',
    balance: 26040.00,
    status: 'active' as const,
    dailyLimit: 20000,
    used: 8900,
    icon: '↩️',
  },
];

export const transactionsData = [
  {
    id: 'TX-8372',
    merchant: 'TechStore',
    customer: 'John Doe',
    amount: 1250.00,
    status: 'success' as const,
    method: 'Credit Card',
    time: '2 min ago',
    date: '2026-03-16',
    wallet: 'WAL-4523',
  },
  {
    id: 'TX-8371',
    merchant: 'FashionHub',
    customer: 'Jane Smith',
    amount: 890.50,
    status: 'success' as const,
    method: 'Bank Transfer',
    time: '5 min ago',
    date: '2026-03-16',
    wallet: 'WAL-4524',
  },
  {
    id: 'TX-8370',
    merchant: 'GadgetWorld',
    customer: 'Mike Johnson',
    amount: 2340.00,
    status: 'pending' as const,
    method: 'E-Wallet',
    time: '7 min ago',
    date: '2026-03-16',
    wallet: 'WAL-4523',
  },
  {
    id: 'TX-8369',
    merchant: 'BookStore',
    customer: 'Sarah Williams',
    amount: 145.00,
    status: 'success' as const,
    method: 'Credit Card',
    time: '9 min ago',
    date: '2026-03-16',
    wallet: 'WAL-4525',
  },
  {
    id: 'TX-8368',
    merchant: 'SportGear',
    customer: 'Tom Brown',
    amount: 567.80,
    status: 'failed' as const,
    method: 'Credit Card',
    time: '12 min ago',
    date: '2026-03-16',
    wallet: 'WAL-4523',
  },
];
