import { createBrowserRouter, Navigate } from 'react-router';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Transactions } from './pages/Transactions';
import { Wallets } from './pages/Wallets';
import { Merchants } from './pages/Merchants';
import { MerchantDetail } from './pages/MerchantDetail';
import { PaymentPages } from './pages/PaymentPages';
import { EmbedIntegration } from './pages/EmbedIntegration';
import { ApiDocs } from './pages/ApiDocs';
import { Permissions } from './pages/Permissions';
import { PaymentMethods } from './pages/PaymentMethods';
import { PaymentAccounts } from './pages/PaymentAccounts';
import { MobileWalletTransactions } from './pages/MobileWalletTransactions';
import MerchantMobileView from './pages/MerchantMobileView';
import { ApiDocumentation } from './pages/ApiDocumentation';
import { BinancePage } from './pages/BinancePage';
import { MobileAppLayout } from './components/MobileAppLayout';
import MobileDashboard from './pages/MobileDashboard';
import MobileTransactionsCenter from './pages/MobileTransactionsCenter';
import MobileTransactionDetails from './pages/MobileTransactionDetails';
import MobileCustomerProfile from './pages/MobileCustomerProfile';
import MobileLanding from './pages/MobileLanding';
import MobileSettings from './pages/MobileSettings';
import MobileAppGrid from './pages/MobileAppGrid';
import { AnimationShowcase } from './pages/AnimationShowcase';
import { WalletPools } from './pages/WalletPools';
import { BinanceP2PPage } from './pages/BinanceP2PPage';
import { UserManagement } from './pages/UserManagement';
import { MerchantOnboarding } from './pages/MerchantOnboarding';
import { ZohoForms } from './pages/ZohoForms';
import { AutomationCenter } from './pages/AutomationCenter';
import { WorkflowManager } from './pages/WorkflowManager';
import { PaymentCheckout } from './pages/PaymentCheckout';
import { Approvals } from './pages/Approvals';
import { Settlement } from './pages/Settlement';
import { Payouts } from './pages/Payouts';
import { Risk } from './pages/Risk';
import { Reports } from './pages/Reports';
import { ImportTransactions } from './pages/ImportTransactions';
import { TelegramPayments } from './pages/TelegramPayments';
import { LiveRates } from './pages/LiveRates';
import { EditRole } from './pages/EditRole';
import { EditPaymentMethod } from './pages/EditPaymentMethod';
import { TableTransactions } from './pages/TableTransactions';
import { LiveMonitor } from './pages/LiveMonitor';
import { SmartCheckoutDesigner } from './pages/SmartCheckoutDesigner';
import NGPayDashboard from './pages/NGPayDashboard';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: LiveMonitor },
      { path: 'dashboard', Component: Dashboard },
      { path: 'live-monitor', Component: LiveMonitor },
      { path: 'ngpay-dashboard', Component: NGPayDashboard },
      { path: 'animations', Component: AnimationShowcase },
      { path: 'transactions', Component: Transactions },
      { path: 'mobile-wallet-transactions', Component: MobileWalletTransactions },
      { path: 'wallets', Component: Wallets },
      { path: 'wallet-pools', Component: WalletPools },
      { path: 'merchants', Component: Merchants },
      { path: 'merchants/:id', Component: MerchantDetail },
      { path: 'merchant-mobile/:id', Component: MerchantMobileView },
      { path: 'merchant-onboarding', Component: MerchantOnboarding },
      { path: 'payment-methods', Component: PaymentMethods },
      { path: 'payment-accounts', Component: PaymentAccounts },
      { path: 'payment-pages', Component: PaymentPages },
      { path: 'embed', Component: EmbedIntegration },
      { path: 'api-docs', Component: ApiDocs },
      { path: 'api-documentation', Component: ApiDocumentation },
      { path: 'binance', Component: BinancePage },
      { path: 'binance-p2p', Component: BinanceP2PPage },
      { path: 'user-management', Component: UserManagement },
      { path: 'permissions', Component: Permissions },
      { path: 'mobile-view', Component: MobileLanding },
      { path: 'mobile-app-grid', Component: MobileAppGrid },
      { path: 'zoho-forms', Component: ZohoForms },
      { path: 'automation-center', Component: AutomationCenter },
      { path: 'workflow-manager', Component: WorkflowManager },
      { path: 'payment-checkout', Component: PaymentCheckout },
      { path: 'approvals', Component: Approvals },
      { path: 'settlement', Component: Settlement },
      { path: 'payouts', Component: Payouts },
      { path: 'risk', Component: Risk },
      { path: 'reports', Component: Reports },
      { path: 'import-transactions', Component: ImportTransactions },
      { path: 'telegram-payments', Component: TelegramPayments },
      { path: 'live-rates', Component: LiveRates },
      { path: 'edit-role', Component: EditRole },
      { path: 'edit-payment-method', Component: EditPaymentMethod },
      { path: 'table-transactions', Component: TableTransactions },
      { path: 'smart-checkout', Component: SmartCheckoutDesigner },
    ],
  },
  // Mobile App Routes
  {
    path: '/mobile',
    Component: MobileAppLayout,
    children: [
      { index: true, element: <Navigate to="/mobile/apps" replace /> },
      { path: 'apps', Component: MobileAppGrid },
      { path: 'dashboard', Component: MobileDashboard },
      { path: 'transactions', Component: MobileTransactionsCenter },
      { path: 'transactions/:id', Component: MobileTransactionDetails },
      { path: 'customers/:id', Component: MobileCustomerProfile },
      { path: 'wallets', Component: MobileWalletTransactions },
      { path: 'merchants', Component: MerchantMobileView },
      { path: 'settings', Component: MobileSettings },
    ],
  },
]);
