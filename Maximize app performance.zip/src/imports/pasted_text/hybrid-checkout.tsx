import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Phone, CheckCircle, Copy, Upload, Image, Loader2 } from 'lucide-react';
import { createTransaction } from '@/lib/transactions';
import { allocateWallets, WalletAllocationResult } from '@/lib/walletAllocator';
import { supabase } from '@/integrations/supabase/client';
import { useCheckoutToken } from '@/hooks/useCheckoutToken';
import { CheckoutLoading, CheckoutError } from '@/components/CheckoutGuard';

export default function HybridCheckout() {
  const { loading: tokenLoading, error: tokenError, data: tokenData } = useCheckoutToken();

  const [reference, setReference] = useState('');
  const [amount, setAmount] = useState(0);
  const [allocations, setAllocations] = useState<WalletAllocationResult[]>([]);
  const [txnCreated, setTxnCreated] = useState(false);
  const [txnId, setTxnId] = useState('');
  const [showProof, setShowProof] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);

  const provider = tokenData?.provider || 'vodafone';

  useEffect(() => {
    if (tokenLoading || tokenError || !tokenData) return;

    const initCheckout = async () => {
      const finalAmount = tokenData.amount || 0;
      setAmount(finalAmount);
      if (finalAmount <= 0) { setLoading(false); return; }

      if (!txnCreated) {
        try {
          const txn = await createTransaction({
            amount: finalAmount,
            type: 'PAY_IN',
            method: `${provider} (Hybrid)`,
            customerPhone: tokenData.customer_phone || undefined,
            customerName: tokenData.customer_name || undefined,
            merchantName: tokenData.merchant_name,
            description: `Hybrid checkout via ${provider}`,
          });
          setReference(txn.transaction_id);
          setTxnId(txn.id);
          setTxnCreated(true);
        } catch {
          setReference('TXN' + Math.floor(Math.random() * 900000 + 100000));
        }

        try {
          const allocs = await allocateWallets(finalAmount, provider);
          setAllocations(allocs);
        } catch (err: any) {
          toast.error('Wallet allocation: ' + err.message);
          setAllocations([]);
        }
      }
      setLoading(false);
    };
    initCheckout();
  }, [tokenLoading, tokenError, tokenData]);

  if (tokenLoading) return <CheckoutLoading />;
  if (tokenError) return <CheckoutError message={tokenError} />;

  const openUSSD = () => {
    const urls: Record<string, string> = { vodafone: 'tel:*9%23', etisalat: 'tel:*777%23', orange: 'tel:%23115%23' };
    if (urls[provider]) window.location.href = urls[provider];
    else toast.error('Provider USSD not configured');
  };

  const confirmSent = () => setShowProof(true);

  const handleProofUpload = async (file: File) => {
    if (!txnId) return;
    setUploading(true);
    try {
      const ext = file.name.split('.').pop();
      const filePath = `${txnId}.${ext}`;
      const { error } = await supabase.storage.from('proof').upload(filePath, file, { upsert: true });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from('proof').getPublicUrl(filePath);
      await supabase.from('transactions').update({ status: 'WAITING_VERIFICATION', proof_image_url: urlData.publicUrl }).eq('id', txnId);
      setShowProof(false);
      toast.success('Proof uploaded. Waiting verification...');
    } catch (e: any) {
      toast.error('Upload failed: ' + e.message);
    }
    setUploading(false);
  };

  const skipProof = async () => {
    if (txnId) await supabase.from('transactions').update({ status: 'WAITING_VERIFICATION' }).eq('id', txnId);
    setShowProof(false);
    toast.success('Payment submitted. Waiting verification...');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground p-6 flex flex-col items-center">
      <h2 className="text-xl font-bold mb-2">Press2Pay Wallet Checkout</h2>
      <p className="text-sm text-muted-foreground mb-6">{tokenData?.merchant_name}</p>

      <div className="w-full max-w-md space-y-4">
        {allocations.length === 0 && (
          <div className="glass-card p-5 text-center text-muted-foreground text-sm">
            No wallets available for allocation. Please contact support.
          </div>
        )}

        {allocations.map((w, i) => (
          <div key={i} className="glass-card p-5 relative">
            <div className="flex justify-between items-start mb-2">
              <div>
                <b className="text-lg block mb-1 text-primary">Send {Number(w.amount).toLocaleString()} EGP</b>
                <div className="text-sm text-muted-foreground">
                  To Wallet: <span className="text-foreground font-mono font-bold">{w.wallet_number}</span>
                </div>
                {w.account_name && (
                  <div className="text-xs text-muted-foreground mt-0.5">Account: {w.account_name}</div>
                )}
                <div className="text-xs text-muted-foreground mt-1">Reference: {reference}</div>
              </div>
              <button onClick={() => copyToClipboard(w.wallet_number)} className="p-2 hover:bg-secondary rounded-lg text-primary transition-colors">
                <Copy className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}

        {allocations.length > 0 && (
          <div className="flex gap-3 mt-6">
            <button onClick={openUSSD} className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2">
              <Phone className="w-4 h-4" /> Open USSD
            </button>
            <button onClick={confirmSent} className="flex-1 bg-secondary hover:bg-secondary/80 text-foreground py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 border border-border">
              <CheckCircle className="w-4 h-4" /> I Sent Payment
            </button>
          </div>
        )}

        {showProof && (
          <div className="glass-card p-4 space-y-3">
            <div className="flex items-center gap-2"><Image className="w-5 h-5 text-primary" /><h3 className="font-bold text-sm">Upload Proof of Payment</h3></div>
            <label className="flex flex-col items-center gap-2 py-6 border-2 border-dashed border-primary/30 rounded-xl cursor-pointer hover:bg-primary/5">
              <Upload className="w-8 h-8 text-primary/50" />
              <span className="text-sm text-primary font-medium">{uploading ? 'Uploading...' : 'Click to upload'}</span>
              <input type="file" accept="image/*" className="hidden" disabled={uploading} onChange={e => { if (e.target.files?.[0]) handleProofUpload(e.target.files[0]); }} />
            </label>
            <button onClick={skipProof} className="w-full py-2 text-sm text-muted-foreground hover:text-foreground">Skip — Mark without proof</button>
          </div>
        )}
      </div>
    </div>
  );
}
