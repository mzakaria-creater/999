import { useState, useRef } from 'react';
import {
  BookOpen, Database, Globe, Shield, Code2, ChevronDown, ChevronRight,
  Copy, CheckCircle2, Send, ArrowRightLeft, Zap, CreditCard, Wallet,
  Building2, Bell, BarChart3, Lock, Clock, AlertTriangle, Ban, Hash, Download
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

type HttpMethod = 'GET' | 'POST' | 'PATCH' | 'DELETE';

interface Endpoint {
  method: HttpMethod;
  path: string;
  title: string;
  description: string;
  category: string;
  requestBody?: string;
  responseBody: string;
  queryParams?: string;
}

const endpoints: Endpoint[] = [
  {
    method: 'POST', path: '/transactions', title: 'Create Transaction (Hosted Checkout)',
    category: 'Payments',
    description: 'Create a new payment request and receive a hosted checkout URL.',
    requestBody: JSON.stringify({
      amount: 1000, currency: 'EGP', order_id: 'ORD_12345',
      customer_email: 'customer@example.com', customer_name: 'Ahmed Hassan',
      callback_url: 'https://merchant.com/webhook',
      success_url: 'https://merchant.com/success',
      cancel_url: 'https://merchant.com/cancel',
      metadata: { cart_id: 'CART_123' }
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'TRX_1234567890',
        checkout_url: 'https://checkout.ontarget-egy.com/TRX_1234567890',
        status: 'pending', amount: 1000., currency: 'EGP',
        expires_at: '2026-02-20T14:30:00Z'
      }
    }, null, 2),
  },
  {
    method: 'GET', path: '/transactions', title: 'List Transactions',
    category: 'Payments',
    description: 'Retrieve a paginated list of all transactions with optional filters.',
    queryParams: 'limit=20&offset=0&status=completed&from_date=2026-01-01&to_date=2026-03-01',
    responseBody: JSON.stringify({
      success: true, data: [
        { id: 'TRX_001', amount: 1000, currency: 'EGP', status: 'completed', payment_method: 'vodafone_cash' },
        { id: 'TRX_002', amount: 500, currency: 'EGP', status: 'pending', payment_method: 'instapay' },
      ], pagination: { limit: 20, offset: 0, total: 156 }
    }, null, 2),
  },
  {
    method: 'GET', path: '/transactions/{id}', title: 'Get Transaction Details',
    category: 'Payments',
    description: 'Retrieve detailed information about a specific transaction.',
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'TRX_1234567890', amount: 1000, currency: 'EGP', status: 'completed',
        payment_method: 'vodafone_cash', order_id: 'ORD_12345',
        created_at: '2026-02-20T12:00:00Z', completed_at: '2026-02-20T12:05:00Z',
      }
    }, null, 2),
  },
  {
    method: 'POST', path: '/deposit', title: 'Direct Deposit (S2S)',
    category: 'Payments',
    description: 'Returns wallet instructions for direct wallet number allocation.',
    requestBody: JSON.stringify({
      amount: 1000, currency: 'EGP', payment_method: 'vodafone_cash', order_id: 'ORD_12345'
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'DEP_1234567890', wallet_number: '01012345678', wallet_name: 'OnTarget Payment',
        reference: 'REF_ABC123', amount: 1000, currency: 'EGP',
        expires_at: '2026-02-20T14:00:00Z',
      }
    }, null, 2),
  },
  {
    method: 'POST', path: '/withdrawals', title: 'Create Withdrawal',
    category: 'Withdrawals',
    description: 'Create a payout/withdrawal request to a bank account or mobile wallet.',
    requestBody: JSON.stringify({
      amount: 5000, currency: 'EGP',
      destination: { type: 'bank_account', account_number: '1234567890', bank_code: 'NBEG', account_holder: 'Ahmed Hassan' }
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'WTH_1234567890', status: 'processing', amount: 5000, currency: 'EGP',
        estimated_arrival: '1-2 business days'
      }
    }, null, 2),
  },
  {
    method: 'GET', path: '/withdrawals', title: 'List Withdrawals',
    category: 'Withdrawals',
    description: 'Retrieve a list of all withdrawal requests.',
    responseBody: JSON.stringify({
      success: true, data: [
        { id: 'WTH_001', status: 'completed', amount: 5000 },
        { id: 'WTH_002', status: 'processing', amount: 2000 },
      ], pagination: { limit: 20, offset: 0, total: 42 }
    }, null, 2),
  },
  {
    method: 'POST', path: '/merchants', title: 'Create Merchant',
    category: 'Merchants',
    description: 'Create a new merchant account. Supports hierarchy: master_l1, merchant_l2, sub_l3.',
    requestBody: JSON.stringify({
      level: 'merchant_l2', parent_merchant_id: 'M_001',
      business_name: 'Tech Solutions Ltd', email: 'merchant@techsolutions.com',
      country: 'EG', currency: 'EGP'
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'M_002', mid: 'MER-A3B7K9', level: 'merchant_l2',
        business_name: 'Tech Solutions Ltd', status: 'active', api_key: 'sk_live_...'
      }
    }, null, 2),
  },
  {
    method: 'GET', path: '/merchants', title: 'List Merchants',
    category: 'Merchants',
    description: 'List all merchants. Filter by level.',
    queryParams: 'level=merchant_l2&limit=20&offset=0',
    responseBody: JSON.stringify({
      success: true, data: [
        { id: 'M_001', mid: 'MER-X1Y2Z3', level: 'master_l1', business_name: 'OnTarget Master' },
        { id: 'M_002', mid: 'MER-A3B7K9', level: 'merchant_l2', business_name: 'Tech Solutions' },
      ]
    }, null, 2),
  },
  {
    method: 'POST', path: '/webhooks', title: 'Register Webhook',
    category: 'Webhooks',
    description: 'Register a URL to receive webhook notifications.',
    requestBody: JSON.stringify({
      url: 'https://merchant.com/webhooks/ontarget',
      events: ['transaction.completed', 'withdrawal.completed']
    }, null, 2),
    responseBody: JSON.stringify({
      success: true, data: {
        id: 'WH_001', url: 'https://merchant.com/webhooks/ontarget',
        secret: 'whsec_...', events: ['transaction.completed', 'withdrawal.completed']
      }
    }, null, 2),
  },
  {
    method: 'GET', path: '/reports/balance', title: 'Get Balance',
    category: 'Reports',
    description: 'Get current account balance.',
    responseBody: JSON.stringify({
      success: true, data: { available: 50000, pending: 5000, currency: 'EGP' }
    }, null, 2),
  },
  {
    method: 'GET', path: '/reports/analytics', title: 'Get Analytics',
    category: 'Reports',
    description: 'Get transaction analytics and metrics.',
    queryParams: 'from_date=2026-01-01&to_date=2026-03-01',
    responseBody: JSON.stringify({
      success: true, data: {
        total_transactions: 1500, total_volume: 2500000,
        success_rate: 90.0,
        by_payment_method: { vodafone_cash: 800, instapay: 350, fawry: 200, card: 150 }
      }
    }, null, 2),
  },
];

const methodColors: Record<HttpMethod, string> = {
  GET: 'bg-chart-2/15 text-chart-2 border-chart-2/30',
  POST: 'bg-primary/15 text-primary border-primary/30',
  PATCH: 'bg-chart-4/15 text-chart-4 border-chart-4/30',
  DELETE: 'bg-destructive/15 text-destructive border-destructive/30',
};

const statusList = [
  { status: 'PENDING', icon: Clock, color: 'text-chart-4', desc: 'Waiting for payment' },
  { status: 'PROCESSING', icon: Zap, color: 'text-chart-2', desc: 'Being processed' },
  { status: 'PAID', icon: CheckCircle2, color: 'text-primary', desc: 'Payment confirmed' },
  { status: 'COMPLETED', icon: CheckCircle2, color: 'text-primary', desc: 'Fully completed' },
  { status: 'REFUNDED', icon: ArrowRightLeft, color: 'text-chart-2', desc: 'Refunded' },
  { status: 'CANCELLED', icon: Ban, color: 'text-muted-foreground', desc: 'Cancelled' },
  { status: 'EXPIRED', icon: Clock, color: 'text-muted-foreground', desc: 'Expired' },
  { status: 'FAILED', icon: AlertTriangle, color: 'text-destructive', desc: 'Failed' },
  { status: 'DECLINED', icon: AlertTriangle, color: 'text-destructive', desc: 'Declined' },
];

const dbTables = [
  { name: 'merchants', cols: ['id (uuid PK)', 'mid (text, auto MER-XXXXXX)', 'name', 'type', 'status', 'country', 'parent_id (FK merchants)', 'volume', 'merchant_count'] },
  { name: 'app_users', cols: ['id (uuid PK)', 'username', 'full_name', 'email', 'role', 'status', 'organization', 'merchant_id (FK merchants)', 'assigned_wallet_pool (text[])'] },
  { name: 'app_roles', cols: ['id (uuid PK)', 'name', 'description', 'is_system', 'permissions (jsonb)'] },
  { name: 'transactions', cols: ['id (uuid PK)', 'transaction_id', 'amount', 'currency', 'status', 'type', 'method', 'merchant_id (FK merchants)', 'merchant_name', 'customer_name', 'customer_phone', 'proof_image_url', 'fee', 'net_amount'] },
  { name: 'wallets', cols: ['id (uuid PK)', 'name', 'code', 'number', 'provider', 'status', 'balance', 'daily_limit', 'monthly_limit', 'used_today'] },
  { name: 'payment_gateways', cols: ['id (uuid PK)', 'name', 'display_name', 'provider', 'type', 'environment', 'status', 'currency', 'endpoint_url', 'webhook_url'] },
  { name: 'payment_links', cols: ['id (uuid PK)', 'reference', 'amount', 'status', 'merchant', 'description'] },
  { name: 'merchant_form_assignments', cols: ['id (uuid PK)', 'merchant_id (FK merchants)', 'form_type', 'payment_method', 'enabled', 'proof_required', 'config (jsonb)'] },
];

const categories = [...new Set(endpoints.map(e => e.category))];

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast.success('Copied');
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="relative group">
      <pre className="bg-background border border-border rounded-lg p-4 text-xs font-mono overflow-x-auto text-foreground/80">
        <code>{code}</code>
      </pre>
      <button onClick={handleCopy} className="absolute top-2 right-2 p-1.5 rounded-md bg-secondary/80 text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-all">
        {copied ? <CheckCircle2 size={14} /> : <Copy size={14} />}
      </button>
    </div>
  );
}

function EndpointCard({ endpoint }: { endpoint: Endpoint }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="glass-card overflow-hidden">
      <button onClick={() => setExpanded(!expanded)} className="w-full flex items-center gap-3 p-4 hover:bg-secondary/20 transition-colors text-left">
        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${methodColors[endpoint.method]}`}>
          {endpoint.method}
        </span>
        <code className="text-xs font-mono text-muted-foreground flex-1">{endpoint.path}</code>
        <span className="text-sm font-medium hidden sm:block">{endpoint.title}</span>
        {expanded ? <ChevronDown size={16} className="text-muted-foreground" /> : <ChevronRight size={16} className="text-muted-foreground" />}
      </button>
      {expanded && (
        <div className="px-4 pb-4 space-y-4 border-t border-border pt-4">
          <p className="text-sm text-muted-foreground">{endpoint.description}</p>
          <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Headers</div>
          <CodeBlock code={`Authorization: Bearer sk_test_your_api_key_here\nContent-Type: application/json`} />
          {endpoint.queryParams && (
            <>
              <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Query Parameters</div>
              <CodeBlock code={endpoint.queryParams} />
            </>
          )}
          {endpoint.requestBody && (
            <>
              <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Send size={12} /> Request Body
              </div>
              <CodeBlock code={endpoint.requestBody} />
            </>
          )}
          <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <ArrowRightLeft size={12} /> Response
          </div>
          <CodeBlock code={endpoint.responseBody} />
        </div>
      )}
    </div>
  );
}

export default function ApiDocsPage() {
  const [activeTab, setActiveTab] = useState<'endpoints' | 'statuses' | 'schema' | 'auth' | 'database'>('endpoints');
  const contentRef = useRef<HTMLDivElement>(null);
  const [exporting, setExporting] = useState(false);

  const handleExportPDF = async () => {
    if (!contentRef.current) return;
    setExporting(true);
    try {
      const html2canvas = (await import('html2canvas')).default;
      const { jsPDF } = await import('jspdf');
      const canvas = await html2canvas(contentRef.current, { scale: 1.5, backgroundColor: '#0f0f14', useCORS: true });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      let position = 0;
      const pageHeight = pdf.internal.pageSize.getHeight();
      while (position < pdfHeight) {
        if (position > 0) pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, -position, pdfWidth, pdfHeight);
        position += pageHeight;
      }
      pdf.save('OnTarget-API-Documentation.pdf');
      toast.success('PDF downloaded');
    } catch (err) {
      toast.error('Failed to export PDF');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-8" ref={contentRef}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-xl gradient-primary">
            <BookOpen className="w-7 h-7 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">API Documentation</h1>
            <p className="text-sm text-muted-foreground mt-1">
              OnTarget REST API — payments, withdrawals, merchants, webhooks & reports.
            </p>
          </div>
        </div>
        <Button onClick={handleExportPDF} disabled={exporting} variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          {exporting ? 'Exporting...' : 'Download PDF'}
        </Button>
      </div>

      {/* Base URL */}
      <div className="glass-card p-4 flex items-center gap-3">
        <Globe size={16} className="text-primary shrink-0" />
        <div>
          <span className="text-xs text-muted-foreground">Base URL</span>
          <code className="block text-sm font-mono text-foreground">https://api.ontarget-egy.com/v1</code>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary/50 p-1 rounded-xl w-fit flex-wrap">
        {[
          { key: 'endpoints' as const, label: 'Endpoints', icon: Globe },
          { key: 'auth' as const, label: 'Auth', icon: Lock },
          { key: 'statuses' as const, label: 'Statuses', icon: Zap },
          { key: 'schema' as const, label: 'Schemas', icon: Code2 },
          { key: 'database' as const, label: 'Database', icon: Database },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.key ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon size={15} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Auth Tab */}
      {activeTab === 'auth' && (
        <div className="space-y-4">
          <div className="glass-card p-5 space-y-4">
            <h3 className="flex items-center gap-2 text-sm font-bold">
              <Shield size={16} className="text-primary" /> Bearer Token Authentication
            </h3>
            <p className="text-sm text-muted-foreground">
              All API requests require a Bearer token in the <code className="px-1.5 py-0.5 bg-secondary rounded text-xs font-mono">Authorization</code> header.
            </p>
            <div className="grid gap-3">
              <div className="flex items-center gap-3 p-3 bg-secondary/30 border border-border rounded-xl">
                <div className="w-2 h-2 rounded-full bg-chart-4" />
                <div><div className="text-sm font-bold font-mono">sk_test_...</div><div className="text-xs text-muted-foreground">Sandbox</div></div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-secondary/30 border border-border rounded-xl">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <div><div className="text-sm font-bold font-mono">sk_live_...</div><div className="text-xs text-muted-foreground">Production</div></div>
              </div>
            </div>
            <CodeBlock code={`curl -X POST https://api.ontarget-egy.com/v1/transactions \\
  -H "Authorization: Bearer sk_test_your_api_key" \\
  -H "Content-Type: application/json" \\
  -d '{"amount": 1000, "currency": "EGP", "order_id": "ORD_123"}'`} />
          </div>
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">Rate Limits</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 bg-secondary/30 border border-border rounded-xl">
                <div className="text-2xl font-black text-primary">1000</div>
                <div className="text-xs text-muted-foreground">Requests per minute</div>
              </div>
              <div className="p-3 bg-secondary/30 border border-border rounded-xl">
                <div className="text-2xl font-black text-chart-2">100</div>
                <div className="text-xs text-muted-foreground">Burst per second</div>
              </div>
            </div>
          </div>
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">Payment Methods</h3>
            <div className="flex flex-wrap gap-2">
              {['vodafone_cash', 'orange_money', 'instapay', 'fawry', 'card', 'bank_transfer'].map(m => (
                <span key={m} className="px-3 py-1.5 bg-secondary/50 border border-border rounded-lg text-xs font-mono">{m}</span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Endpoints Tab */}
      {activeTab === 'endpoints' && (
        <div className="space-y-8">
          {categories.map(cat => (
            <div key={cat} className="space-y-3">
              <h2 className="text-lg font-bold flex items-center gap-2">
                {cat === 'Payments' && <CreditCard size={18} className="text-primary" />}
                {cat === 'Withdrawals' && <Wallet size={18} className="text-chart-4" />}
                {cat === 'Merchants' && <Building2 size={18} className="text-chart-3" />}
                {cat === 'Webhooks' && <Bell size={18} className="text-chart-2" />}
                {cat === 'Reports' && <BarChart3 size={18} className="text-chart-5" />}
                {cat}
              </h2>
              {endpoints.filter(e => e.category === cat).map(ep => (
                <EndpointCard key={ep.path + ep.method} endpoint={ep} />
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Statuses Tab */}
      {activeTab === 'statuses' && (
        <div className="space-y-4">
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold mb-4">Transaction Status Codes</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {statusList.map(s => (
                <div key={s.status} className="flex items-center gap-3 p-3 bg-secondary/30 border border-border rounded-xl">
                  <s.icon size={18} className={s.color} />
                  <div>
                    <div className="text-sm font-bold font-mono">{s.status}</div>
                    <div className="text-xs text-muted-foreground">{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">Status Flow</h3>
            <CodeBlock code={`PENDING → PROCESSING → PAID/COMPLETED
PENDING → CANCELLED / EXPIRED
PROCESSING → DECLINED / FAILED
PAID → REFUNDED`} />
          </div>
        </div>
      )}

      {/* Schema Tab */}
      {activeTab === 'schema' && (
        <div className="space-y-4">
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">CreateTransactionRequest</h3>
            <CodeBlock code={`{
  amount: number         // Required. Min: 10
  currency: string       // "EGP" | "SAR" | "AED" | "USD" | "EUR"
  order_id: string       // Your unique order ID
  customer_email?: string
  customer_name?: string
  customer_phone?: string
  callback_url?: string
  success_url?: string
  cancel_url?: string
  metadata?: object
}`} />
          </div>
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">CreateWithdrawalRequest</h3>
            <CodeBlock code={`{
  amount: number
  currency: string
  destination: {
    type: "bank_account" | "mobile_wallet"
    account_holder: string
    account_number?: string
    bank_code?: string
    wallet_provider?: "vodafone_cash" | "orange_money"
    wallet_number?: string
  }
}`} />
          </div>
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">Error Response</h3>
            <CodeBlock code={JSON.stringify({
              success: false,
              error: { code: 'validation_error', message: 'Amount must be at least 10', details: { field: 'amount', min: 10 } }
            }, null, 2)} />
          </div>
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">HTTP Status Codes</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-border">
                  <tr>
                    <th className="py-2 px-3 text-xs font-bold text-muted-foreground uppercase">Code</th>
                    <th className="py-2 px-3 text-xs font-bold text-muted-foreground uppercase">Meaning</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[
                    ['200', 'Success', 'text-primary'],
                    ['400', 'Bad Request', 'text-chart-4'],
                    ['401', 'Unauthorized', 'text-destructive'],
                    ['403', 'Forbidden', 'text-destructive'],
                    ['404', 'Not Found', 'text-chart-4'],
                    ['429', 'Rate Limited', 'text-chart-4'],
                    ['500', 'Server Error', 'text-destructive'],
                  ].map(([code, meaning, color]) => (
                    <tr key={code}><td className={`py-2 px-3 font-mono text-xs ${color}`}>{code}</td><td className="py-2 px-3 text-muted-foreground">{meaning}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Database Tab */}
      {activeTab === 'database' && (
        <div className="space-y-4">
          <div className="glass-card p-5 space-y-2">
            <h3 className="text-sm font-bold flex items-center gap-2 mb-4">
              <Database size={16} className="text-primary" /> Database Schema — 8 Tables
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              All tables have Row-Level Security (RLS) enabled. MID is auto-generated as MER-XXXXXX.
            </p>
          </div>
          {dbTables.map(table => (
            <div key={table.name} className="glass-card overflow-hidden">
              <div className="p-4 border-b border-border flex items-center gap-3">
                <Hash size={14} className="text-primary" />
                <span className="font-mono font-bold text-sm">{table.name}</span>
                <span className="text-xs text-muted-foreground ml-auto">{table.cols.length} columns</span>
              </div>
              <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {table.cols.map(col => {
                  const isPk = col.includes('PK');
                  const isFk = col.includes('FK');
                  return (
                    <div key={col} className={`text-xs font-mono p-2 rounded-lg border ${isPk ? 'bg-primary/10 border-primary/30 text-primary' : isFk ? 'bg-chart-2/10 border-chart-2/30 text-chart-2' : 'bg-secondary/30 border-border text-foreground/70'}`}>
                      {col}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold">Relationships</h3>
            <CodeBlock code={`merchants.parent_id → merchants.id (self-referencing hierarchy)
app_users.merchant_id → merchants.id
transactions.merchant_id → merchants.id
merchant_form_assignments.merchant_id → merchants.id
app_users.role ↔ app_roles.name (logical reference)`} />
          </div>
        </div>
      )}
    </div>
  );
}