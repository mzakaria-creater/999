import { useState, useEffect, useMemo } from "react";
import { useParams, Link } from "react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, ArrowDownCircle, ArrowUpCircle, DollarSign, TrendingUp, Percent, Users, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import DashboardLayout from "@/components/DashboardLayout";

interface Transaction {
  id: string;
  transaction_id: string;
  amount: number;
  fee: number | null;
  net_amount: number | null;
  status: string;
  type: string;
  method: string | null;
  customer_name: string | null;
  created_at: string;
}

interface Merchant {
  id: string;
  name: string;
  mid: string | null;
  type: string;
  status: string;
  hold_percentage: number | null;
  referral_fee_percentage: number | null;
  parent_id: string | null;
}

interface Referral {
  id: string;
  name: string;
  type: string;
  volume: number;
  txnCount: number;
  referralFee: number;
}

export default function MerchantAnalyticsPage() {
  const { merchantId } = useParams();
  const [merchant, setMerchant] = useState<Merchant | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    if (!merchantId) return;
    setLoading(true);

    const [mRes, tRes, childRes] = await Promise.all([
      supabase.from("merchants").select("*").eq("id", merchantId).single(),
      supabase.from("transactions").select("*").eq("merchant_id", merchantId).order("created_at", { ascending: false }).limit(100),
      supabase.from("merchants").select("id, name, type, referral_fee_percentage").eq("parent_id", merchantId),
    ]);

    if (mRes.data) setMerchant(mRes.data as any);
    if (tRes.data) setTransactions(tRes.data as any);

    // For each child merchant, get their transaction volume
    if (childRes.data && childRes.data.length > 0) {
      const refs: Referral[] = [];
      for (const child of childRes.data) {
        const { data: childTxns } = await supabase
          .from("transactions")
          .select("amount, fee")
          .eq("merchant_id", child.id)
          .in("status", ["COMPLETED", "PAID"]);

        const vol = (childTxns || []).reduce((a, t) => a + t.amount, 0);
        const feePct = (child as any).referral_fee_percentage || 0;
        refs.push({
          id: child.id,
          name: child.name,
          type: child.type,
          volume: vol,
          txnCount: (childTxns || []).length,
          referralFee: vol * (feePct / 100),
        });
      }
      setReferrals(refs);
    }

    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [merchantId]);

  const stats = useMemo(() => {
    const payIn = transactions.filter(t => t.type === "PAY_IN");
    const payOut = transactions.filter(t => t.type === "PAY_OUT");
    const totalIn = payIn.reduce((a, t) => a + t.amount, 0);
    const totalOut = payOut.reduce((a, t) => a + t.amount, 0);
    const totalFees = transactions.reduce((a, t) => a + (t.fee || 0), 0);
    const net = totalIn - totalOut - totalFees;
    const totalReferralFees = referrals.reduce((a, r) => a + r.referralFee, 0);

    return { totalIn, totalOut, totalFees, net, txnCount: transactions.length, totalReferralFees };
  }, [transactions, referrals]);

  if (!merchant && !loading) return <DashboardLayout title="Merchant Analytics"><p className="text-muted-foreground">Merchant not found</p></DashboardLayout>;

  return (
    <DashboardLayout title="Merchant Analytics">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/merchants"><Button variant="ghost" size="sm"><ArrowLeft className="w-4 h-4" /></Button></Link>
            <div>
              <h2 className="text-2xl font-bold">{merchant?.name || "Loading..."}</h2>
              <p className="text-sm text-muted-foreground font-mono">{merchant?.mid} • {merchant?.type}</p>
            </div>
            <Badge variant="outline" className={merchant?.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"}>{merchant?.status}</Badge>
          </div>
          <Button size="sm" variant="outline" onClick={fetchData}><RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} /></Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <Card><CardContent className="pt-4 pb-3"><div className="flex items-center gap-2 mb-1"><ArrowDownCircle className="h-4 w-4 text-blue-500" /><span className="text-xs text-muted-foreground">PAY_IN</span></div><div className="text-lg font-bold text-blue-600">{stats.totalIn.toLocaleString()}</div></CardContent></Card>
          <Card><CardContent className="pt-4 pb-3"><div className="flex items-center gap-2 mb-1"><ArrowUpCircle className="h-4 w-4 text-purple-500" /><span className="text-xs text-muted-foreground">PAY_OUT</span></div><div className="text-lg font-bold text-purple-600">{stats.totalOut.toLocaleString()}</div></CardContent></Card>
          <Card><CardContent className="pt-4 pb-3"><div className="flex items-center gap-2 mb-1"><DollarSign className="h-4 w-4 text-orange-500" /><span className="text-xs text-muted-foreground">Fees</span></div><div className="text-lg font-bold text-orange-600">{stats.totalFees.toLocaleString()}</div></CardContent></Card>
          <Card><CardContent className="pt-4 pb-3"><div className="flex items-center gap-2 mb-1"><TrendingUp className="h-4 w-4 text-emerald-500" /><span className="text-xs text-muted-foreground">Net</span></div><div className="text-lg font-bold text-emerald-600">{stats.net.toLocaleString()}</div></CardContent></Card>
          <Card><CardContent className="pt-4 pb-3"><div className="flex items-center gap-2 mb-1"><Percent className="h-4 w-4 text-primary" /><span className="text-xs text-muted-foreground">Hold</span></div><div className="text-lg font-bold">{merchant?.hold_percentage || 0}%</div></CardContent></Card>
          <Card><CardContent className="pt-4 pb-3"><div className="flex items-center gap-2 mb-1"><Users className="h-4 w-4 text-primary" /><span className="text-xs text-muted-foreground">Referral $</span></div><div className="text-lg font-bold text-primary">{stats.totalReferralFees.toLocaleString()}</div></CardContent></Card>
        </div>

        {/* Referrals */}
        {referrals.length > 0 && (
          <Card>
            <CardContent className="pt-4">
              <h3 className="text-sm font-bold text-muted-foreground mb-3 flex items-center gap-2"><Users className="w-4 h-4" /> Referral Merchants (Earning {merchant?.referral_fee_percentage || 0}% per txn)</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Merchant</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead className="text-right">Volume</TableHead>
                    <TableHead className="text-right">Txns</TableHead>
                    <TableHead className="text-right">Referral Fee</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {referrals.map(r => (
                    <TableRow key={r.id}>
                      <TableCell>
                        <Link to={`/merchant-analytics/${r.id}`} className="text-primary hover:underline font-medium">{r.name}</Link>
                      </TableCell>
                      <TableCell><Badge variant="outline">{r.type}</Badge></TableCell>
                      <TableCell className="text-right">{r.volume.toLocaleString()} EGP</TableCell>
                      <TableCell className="text-right">{r.txnCount}</TableCell>
                      <TableCell className="text-right font-bold text-primary">{r.referralFee.toLocaleString()} EGP</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Transaction List */}
        <Card>
          <CardContent className="pt-4">
            <h3 className="text-sm font-bold text-muted-foreground mb-3">Recent Transactions ({stats.txnCount})</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Fee</TableHead>
                  <TableHead className="text-right">Net</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.slice(0, 20).map(t => (
                  <TableRow key={t.id}>
                    <TableCell className="font-mono text-xs">{t.transaction_id}</TableCell>
                    <TableCell>{t.customer_name || "—"}</TableCell>
                    <TableCell><Badge variant="outline" className={t.type === "PAY_IN" ? "bg-blue-50 text-blue-700" : "bg-purple-50 text-purple-700"}>{t.type}</Badge></TableCell>
                    <TableCell>{t.method || "—"}</TableCell>
                    <TableCell className="text-right font-medium">{t.amount.toLocaleString()}</TableCell>
                    <TableCell className="text-right text-muted-foreground">{(t.fee || 0).toFixed(2)}</TableCell>
                    <TableCell className="text-right font-medium">{(t.net_amount || 0).toLocaleString()}</TableCell>
                    <TableCell><Badge variant="outline">{t.status}</Badge></TableCell>
                    <TableCell className="text-xs text-muted-foreground">{new Date(t.created_at).toLocaleDateString("en-GB")}</TableCell>
                  </TableRow>
                ))}
                {transactions.length === 0 && <TableRow><TableCell colSpan={9} className="text-center py-8 text-muted-foreground">No transactions</TableCell></TableRow>}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}