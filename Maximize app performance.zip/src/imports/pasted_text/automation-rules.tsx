import { useState, useEffect } from 'react';
import {
  Workflow, Plus, MoreVertical, Edit, Trash2, RefreshCw,
  Play, Pause, Zap, AlertCircle, CheckCircle2, ChevronDown
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import DashboardLayout from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';

interface AutomationRule {
  id: string;
  name: string;
  rule_type: string;
  company_id: string | null;
  group_id: string | null;
  is_active: boolean;
  conditions_json: Record<string, any>;
  actions_json: Record<string, any>;
  priority: number;
  created_at: string;
}

const RULE_TYPES = [
  { value: 'transaction_created', label: 'Transaction Created', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  { value: 'proof_uploaded', label: 'Proof Uploaded', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  { value: 'webhook_received', label: 'Webhook Received', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  { value: 'risk_scored', label: 'Risk Scored', color: 'bg-red-50 text-red-700 border-red-200' },
  { value: 'wallet_allocated', label: 'Wallet Allocated', color: 'bg-teal-50 text-teal-700 border-teal-200' },
  { value: 'transaction_failed', label: 'Transaction Failed', color: 'bg-orange-50 text-orange-700 border-orange-200' },
  { value: 'transaction_approved', label: 'Transaction Approved', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
];

const EXAMPLE_CONDITIONS = `{
  "payment_method": "vodafone_cash",
  "amount_lte": 5000,
  "risk_score_lt": 20
}`;

const EXAMPLE_ACTIONS = `{
  "auto_approve": true,
  "notify_ops": true,
  "create_audit_log": true
}`;

const emptyForm = {
  name: '',
  rule_type: 'transaction_created',
  is_active: true,
  conditions_json: EXAMPLE_CONDITIONS,
  actions_json: EXAMPLE_ACTIONS,
  priority: '1',
  company_id: '',
  group_id: '',
};

export default function AutomationRulesPage() {
  const [rules, setRules] = useState<AutomationRule[]>([]);
  const [companies, setCompanies] = useState<{ id: string; name: string }[]>([]);
  const [groups, setGroups] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingRule, setEditingRule] = useState<AutomationRule | null>(null);
  const [formData, setFormData] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [jsonError, setJsonError] = useState<string | null>(null);

  const fetchRules = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('automation_rules')
      .select('*')
      .order('priority', { ascending: true });
    if (error) toast.error('Failed to load rules');
    else setRules(data || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchRules();
    supabase.from('companies').select('id, name').then(({ data }) => setCompanies(data || []));
    supabase.from('company_groups').select('id, name').then(({ data }) => setGroups(data || []));
  }, []);

  const validateJson = (text: string) => {
    try { JSON.parse(text); return true; } catch { return false; }
  };

  const openCreate = () => {
    setEditingRule(null);
    setFormData(emptyForm);
    setJsonError(null);
    setShowFormModal(true);
  };

  const openEdit = (rule: AutomationRule) => {
    setEditingRule(rule);
    setFormData({
      name: rule.name,
      rule_type: rule.rule_type,
      is_active: rule.is_active,
      conditions_json: JSON.stringify(rule.conditions_json, null, 2),
      actions_json: JSON.stringify(rule.actions_json, null, 2),
      priority: String(rule.priority),
      company_id: rule.company_id || '',
      group_id: rule.group_id || '',
    });
    setJsonError(null);
    setShowFormModal(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) { toast.error('Rule name is required'); return; }
    if (!validateJson(formData.conditions_json)) { setJsonError('Invalid JSON in conditions'); return; }
    if (!validateJson(formData.actions_json)) { setJsonError('Invalid JSON in actions'); return; }
    setSaving(true);
    const payload = {
      name: formData.name,
      rule_type: formData.rule_type,
      is_active: formData.is_active,
      conditions_json: JSON.parse(formData.conditions_json),
      actions_json: JSON.parse(formData.actions_json),
      priority: Number(formData.priority) || 1,
      company_id: formData.company_id || null,
      group_id: formData.group_id || null,
    };
    if (editingRule) {
      const { error } = await supabase.from('automation_rules').update(payload).eq('id', editingRule.id);
      if (error) toast.error('Failed to update rule');
      else { toast.success('Rule updated'); setShowFormModal(false); fetchRules(); }
    } else {
      const { error } = await supabase.from('automation_rules').insert(payload);
      if (error) toast.error('Failed to create rule');
      else { toast.success('Rule created'); setShowFormModal(false); fetchRules(); }
    }
    setSaving(false);
  };

  const toggleActive = async (rule: AutomationRule) => {
    const { error } = await supabase
      .from('automation_rules')
      .update({ is_active: !rule.is_active })
      .eq('id', rule.id);
    if (error) toast.error('Failed to toggle rule');
    else fetchRules();
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    await supabase.from('automation_rules').delete().eq('id', deletingId);
    toast.success('Rule deleted');
    setShowDeleteDialog(false);
    setDeletingId(null);
    fetchRules();
  };

  const getRuleTypeConfig = (type: string) =>
    RULE_TYPES.find(r => r.value === type) || RULE_TYPES[0];

  const stats = {
    total: rules.length,
    active: rules.filter(r => r.is_active).length,
    inactive: rules.filter(r => !r.is_active).length,
  };

  return (
    <DashboardLayout title="Automation Rules">
      <div className="space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: 'Total Rules', count: stats.total, color: 'text-foreground' },
            { label: 'Active', count: stats.active, color: 'text-emerald-600' },
            { label: 'Inactive', count: stats.inactive, color: 'text-muted-foreground' },
          ].map(s => (
            <div key={s.label} className="bg-card border rounded-lg p-4">
              <p className="text-sm text-muted-foreground">{s.label}</p>
              <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.count}</p>
            </div>
          ))}
        </div>

        {/* Controls */}
        <div className="flex justify-between items-center">
          <h2 className="text-sm font-medium text-muted-foreground">
            {rules.length} rule{rules.length !== 1 ? 's' : ''} configured
          </h2>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={fetchRules} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
            <Button onClick={openCreate}>
              <Plus className="h-4 w-4 mr-2" />New Rule
            </Button>
          </div>
        </div>

        {/* Rules List */}
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : rules.length === 0 ? (
          <div className="text-center py-12 bg-card border rounded-lg">
            <Workflow className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <p className="font-medium">No automation rules yet</p>
            <p className="text-sm text-muted-foreground mt-1">Rules automate transaction decisions and notifications</p>
            <Button className="mt-4" onClick={openCreate}>
              <Plus className="h-4 w-4 mr-2" />Create First Rule
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {rules.map(rule => {
              const typeConfig = getRuleTypeConfig(rule.rule_type);
              const actions = Object.keys(rule.actions_json || {});
              return (
                <div key={rule.id} className={`bg-card border rounded-lg p-4 transition-opacity ${!rule.is_active ? 'opacity-60' : ''}`}>
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${rule.is_active ? 'bg-primary/10' : 'bg-muted'}`}>
                        <Zap className={`h-4 w-4 ${rule.is_active ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{rule.name}</span>
                          <span className="text-xs text-muted-foreground">P{rule.priority}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${typeConfig.color}`}>
                            {typeConfig.label}
                          </span>
                          {actions.slice(0, 3).map(a => (
                            <span key={a} className="text-xs bg-muted px-2 py-0.5 rounded font-mono">{a}</span>
                          ))}
                          {actions.length > 3 && (
                            <span className="text-xs text-muted-foreground">+{actions.length - 3} more</span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <Switch
                        checked={rule.is_active}
                        onCheckedChange={() => toggleActive(rule)}
                      />
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEdit(rule)}>
                            <Edit className="h-4 w-4 mr-2" />Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => { setDeletingId(rule.id); setShowDeleteDialog(true); }}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Form Modal */}
      <Dialog open={showFormModal} onOpenChange={setShowFormModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingRule ? 'Edit Rule' : 'New Automation Rule'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>Rule Name *</Label>
                <Input
                  value={formData.name}
                  onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                  placeholder="e.g. Auto-approve low risk VF Cash"
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Trigger Event</Label>
                <Select value={formData.rule_type} onValueChange={v => setFormData(p => ({ ...p, rule_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {RULE_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Priority</Label>
                <Input
                  value={formData.priority}
                  onChange={e => setFormData(p => ({ ...p, priority: e.target.value }))}
                  type="number"
                  min="1"
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Company (optional)</Label>
                <Select value={formData.company_id} onValueChange={v => setFormData(p => ({ ...p, company_id: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="All companies" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All companies</SelectItem>
                    {companies.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Group (optional)</Label>
                <Select value={formData.group_id} onValueChange={v => setFormData(p => ({ ...p, group_id: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="All groups" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All groups</SelectItem>
                    {groups.map(g => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Conditions (JSON)</Label>
              <p className="text-xs text-muted-foreground mt-0.5 mb-1">
                Define when this rule triggers. Keys: payment_method, amount_lte, amount_gte, risk_score_lt, currency
              </p>
              <Textarea
                value={formData.conditions_json}
                onChange={e => { setFormData(p => ({ ...p, conditions_json: e.target.value })); setJsonError(null); }}
                className="mt-1 font-mono text-sm"
                rows={5}
              />
            </div>

            <div>
              <Label>Actions (JSON)</Label>
              <p className="text-xs text-muted-foreground mt-0.5 mb-1">
                Actions: auto_approve, send_to_review, decline, assign_wallet, notify_ops, call_webhook, create_audit_log
              </p>
              <Textarea
                value={formData.actions_json}
                onChange={e => { setFormData(p => ({ ...p, actions_json: e.target.value })); setJsonError(null); }}
                className="mt-1 font-mono text-sm"
                rows={5}
              />
            </div>

            {jsonError && (
              <div className="flex items-center gap-2 text-destructive text-sm p-3 bg-destructive/10 rounded-lg">
                <AlertCircle className="h-4 w-4 shrink-0" />
                {jsonError}
              </div>
            )}

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="text-sm font-medium">Active</p>
                <p className="text-xs text-muted-foreground">Enable this rule to run automatically</p>
              </div>
              <Switch
                checked={formData.is_active}
                onCheckedChange={v => setFormData(p => ({ ...p, is_active: v }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFormModal(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : editingRule ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Delete Rule</DialogTitle></DialogHeader>
          <p className="text-muted-foreground py-2">Are you sure you want to delete this automation rule?</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
