أكيد، وده أصلًا هو الشكل الصحيح للمنصة.
الـ Portal مش يكون مجرد docs فقط، بل Merchant + Admin + Ops Platform كاملة.

الشكل الكامل لمنصة OnTarget

1. إدارة وسائل الدفع

تقدر تضيف وتعدل وتوقف أي وسيلة دفع من لوحة التحكم، مثل:
	•	Vodafone Cash
	•	Orange Cash
	•	Etisalat Cash
	•	WE Pay
	•	InstaPay
	•	Bank Transfer
	•	أي وسيلة GCC/MENA لاحقًا

لكل وسيلة:
	•	الاسم
	•	اللوجو
	•	النوع
	•	الدولة
	•	العملة
	•	الحالة
	•	الرسوم
	•	الحد الأدنى والأقصى
	•	نوع التكامل: wallet / bank / gateway / manual

⸻

2. إدارة حسابات الدفع

قسم كامل لإضافة وتعديل حسابات الاستقبال:
	•	محافظ
	•	حسابات بنكية
	•	InstaPay handles
	•	أي حسابات تسوية

لكل حساب:
	•	provider
	•	account number / wallet number
	•	account name
	•	daily limit
	•	monthly limit
	•	current usage
	•	status
	•	assigned merchants
	•	priority
	•	routing rules

⸻

3. ربط كل تاجر بالوسائل والحسابات المناسبة

لكل Merchant:
	•	وسائل الدفع المسموح بها
	•	العملات المسموح بها
	•	الرسوم الخاصة به
	•	callback URL
	•	logo_url
	•	MID
	•	API key
	•	secret key
	•	settlement settings
	•	payout settings

يعني تاجر A يشوف Vodafone + InstaPay فقط
وتاجر B يشوف Bank + Payment Link + iFrame
وتاجر C له إعدادات مختلفة تمامًا.

⸻

4. قائمة التجار

صفحة كاملة فيها:
	•	اسم التاجر
	•	MID
	•	الحالة
	•	عدد العمليات
	•	إجمالي الإيداعات
	•	آخر نشاط
	•	نوع الربط
	•	مسؤول الحساب

وممكن منها:
	•	إضافة تاجر
	•	تعديل بياناته
	•	إيقافه
	•	إصدار API keys
	•	ربطه بوسائل الدفع
	•	ربطه بحسابات الدفع

⸻

5. المستخدمين والصلاحيات

لازم يكون عندك Users + Roles + Permissions.

الأدوار الأساسية:
	•	Owner
	•	Super Admin
	•	Finance
	•	Operations
	•	Risk
	•	Support
	•	Merchant Admin
	•	Merchant Viewer

كل مستخدم له:
	•	اسم
	•	إيميل
	•	role
	•	merchant_id إن وجد
	•	status
	•	2FA
	•	session logs

⸻

6. المعاملات

قسم المعاملات يكون قوي جدًا، وفيه:
	•	transaction id
	•	merchant
	•	amount
	•	currency
	•	payment method
	•	assigned account
	•	status
	•	created at
	•	verified at
	•	proof
	•	callback status
	•	risk score

وفلاتر:
	•	بالتاريخ
	•	بالتاجر
	•	بوسيلة الدفع
	•	بالحالة
	•	بالمبلغ
	•	برقم الحساب

⸻

7. صفحات أساسية داخل المنصة

Dashboard
Merchants
Merchant Profiles
Users & Roles
Payment Methods
Payment Accounts
Transactions
Approvals Queue
Wallet Allocation
Settlement
Payouts
Payment Links
Checkout Sessions
API Keys
Webhooks
Automation
Reports
Risk & Fraud
Logs & Audit
Settings


⸻

إمكانيات متطورة لازم تكون موجودة

Wallet Allocation Engine

النظام يختار تلقائيًا أفضل حساب استقبال حسب:
	•	السعة المتبقية
	•	نوع الوسيلة
	•	التاجر
	•	الدولة
	•	العملة
	•	الأولوية
	•	الضغط الحالي

⸻

Dynamic Routing

لو Vodafone ممتلئة:
	•	يتحول لمحفظة أخرى
	•	أو يتحول لـ InstaPay
	•	أو يوقف الوسيلة لهذا التاجر مؤقتًا

⸻

Smart Fees Engine

لكل Merchant / Method / Region:
	•	deposit fee
	•	payout fee
	•	fixed fee
	•	percentage fee
	•	tax
	•	partner split

⸻

Settlement Engine

إدارة التسويات:
	•	يومي
	•	أسبوعي
	•	شهري
	•	T+0 / T+1 / T+3
	•	حسب العملة
	•	حسب التاجر

⸻

Payout Module

إضافة قسم سحب/صرف:
	•	payout request
	•	approval flow
	•	beneficiary account
	•	payout method
	•	payout status

⸻

Risk & Fraud

لازم يكون عندك:
	•	duplicate detection
	•	suspicious behavior alerts
	•	high amount alert
	•	repeated failed proofs
	•	repeated same sender
	•	IP/device checks
	•	blacklist / whitelist

⸻

الأتمتة التي يجب إضافتها

1. Auto Verification

عند رفع إثبات:
	•	OCR
	•	قراءة المبلغ
	•	قراءة الرقم
	•	قراءة الوقت
	•	مطابقة مع المعاملة

2. Auto Callback Retry

إذا فشل webhook:
	•	retry 1 min
	•	retry 5 min
	•	retry 15 min
	•	retry 1 hour

3. Auto Expire

أي session لم تُدفع خلال 15 دقيقة:
	•	expired
	•	release account
	•	notify merchant

4. Auto Account Rotation

إذا حساب وصل limit:
	•	disable temporarily
	•	route to next account

5. Auto Alerts

إشعارات:
	•	Telegram
	•	Email
	•	داخل النظام

6. Auto Reconciliation

مطابقة:
	•	incoming payments
	•	approved transactions
	•	unsettled amounts
	•	merchant balances

⸻

شكل الـ Portal الصح

Admin Portal

لإدارة كل شيء

Merchant Portal

لكل تاجر حسابه الخاص

Ops Portal

للتحقق والمراجعة

Finance Portal

للتسويات والتقارير

⸻

قاعدة البيانات الأساسية

merchants
merchant_users
roles
permissions
payment_methods
payment_accounts
merchant_payment_methods
merchant_accounts
transactions
transaction_proofs
checkout_sessions
payment_links
wallet_allocations
settlements
payouts
webhooks
automation_rules
audit_logs
risk_alerts
api_keys


⸻

أهم شاشة Dashboard

لازم تعرض:
	•	إجمالي اليوم
	•	عدد المعاملات
	•	نجاح / فشل / pending
	•	top merchants
	•	top methods
	•	wallet capacity
	•	callback failures
	•	alerts

⸻

أفضل طريقة نبني بها المنصة

الترتيب الصح:

المرحلة 1

Core Admin Platform
	•	merchants
	•	users
	•	methods
	•	accounts
	•	transactions

المرحلة 2

Checkout + Payment Links + iFrame

المرحلة 3

Automation + allocation + risk

المرحلة 4

Settlement + payouts + reports

المرحلة 5

Docs portal + merchant self-service

⸻

الخلاصة

نعم، المنصة يجب أن تدعم بالكامل:
	•	إضافة وتعديل وسائل الدفع
	•	إضافة وتعديل حسابات الدفع
	•	ربط كل تاجر بما يناسبه
	•	إدارة المستخدمين
	•	قائمة التجار
	•	قائمة المعاملات
	•	صلاحيات متقدمة
	•	أتمتة ذكية
	•	Routing
	•	Wallet allocation
	•	Risk controls
	•	Settlement
	•	Payouts

والشكل النهائي سيكون أقرب إلى:
	•	Stripe Dashboard
	•	Checkout.com Admin
	•	Paymob Merchant Portal
	•	PSP operations platform

الخطوة التالية التي أفضّلها الآن: أبدأ لك Portal Information Architecture كاملة + sidebar + modules + permissions matrix بشكل جاهز للبناء.