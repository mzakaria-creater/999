import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import {
  Building2, Plus, Search, Filter, MoreVertical, Eye, Edit, Trash2,
  CheckCircle, XCircle, Clock, Globe, Phone, Mail, MapPin, RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import DashboardLayout from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface Company {
  id: string;
  name: string;
  legal_name: string | null;
  company_code: string | null;
  status: string;
  industry: string | null;
  tax_number: string | null;
  registration_number: string | null;
  country: string | null;
  city: string | null;
  address: string | null;
  website: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  created_at: string;
}

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  active: { label: 'Active', color: 'bg-emerald-500/10 text-emerald-600 border-emerald-200', icon: CheckCircle },
  inactive: { label: 'Inactive', color: 'bg-gray-100 text-gray-600 border-gray-200', icon: XCircle },
  suspended: { label: 'Suspended', color: 'bg-red-500/10 text-red-600 border-red-200', icon: XCircle },
  pending: { label: 'Pending', color: 'bg-amber-500/10 text-amber-600 border-amber-200', icon: Clock },
};

const emptyForm = {
  name: '',
  legal_name: '',
  company_code: '',
  status: 'active',
  industry: '',
  tax_number: '',
  registration_number: '',
  country: 'Egypt',
  city: '',
  address: '',
  website: '',
  contact_email: '',
  contact_phone: '',
};

export default function CompaniesPage() {
  const navigate = useNavigate();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [formData, setFormData] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const fetchCompanies = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) toast.error('Failed to load companies');
    else setCompanies(data || []);
    setLoading(false);
  };

  useEffect(() => { fetchCompanies(); }, []);

  const filtered = companies.filter(c => {
    const matchSearch = !searchQuery ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.company_code || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.contact_email || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const openCreate = () => {
    setEditingCompany(null);
    setFormData(emptyForm);
    setShowFormModal(true);
  };

  const openEdit = (company: Company) => {
    setEditingCompany(company);
    setFormData({
      name: company.name,
      legal_name: company.legal_name || '',
      company_code: company.company_code || '',
      status: company.status,
      industry: company.industry || '',
      tax_number: company.tax_number || '',
      registration_number: company.registration_number || '',
      country: company.country || 'Egypt',
      city: company.city || '',
      address: company.address || '',
      website: company.website || '',
      contact_email: company.contact_email || '',
      contact_phone: company.contact_phone || '',
    });
    setShowFormModal(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) { toast.error('Company name is required'); return; }
    setSaving(true);
    const payload = {
      name: formData.name,
      legal_name: formData.legal_name || null,
      company_code: formData.company_code || null,
      status: formData.status,
      industry: formData.industry || null,
      tax_number: formData.tax_number || null,
      registration_number: formData.registration_number || null,
      country: formData.country || null,
      city: formData.city || null,
      address: formData.address || null,
      website: formData.website || null,
      contact_email: formData.contact_email || null,
      contact_phone: formData.contact_phone || null,
    };
    if (editingCompany) {
      const { error } = await supabase.from('companies').update(payload).eq('id', editingCompany.id);
      if (error) toast.error('Failed to update company');
      else { toast.success('Company updated'); setShowFormModal(false); fetchCompanies(); }
    } else {
      const { error } = await supabase.from('companies').insert(payload);
      if (error) toast.error('Failed to create company');
      else { toast.success('Company created'); setShowFormModal(false); fetchCompanies(); }
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deletingId) return;
    const { error } = await supabase.from('companies').delete().eq('id', deletingId);
    if (error) toast.error('Failed to delete company');
    else { toast.success('Company deleted'); fetchCompanies(); }
    setShowDeleteDialog(false);
    setDeletingId(null);
  };

  const statCounts = {
    all: companies.length,
    active: companies.filter(c => c.status === 'active').length,
    inactive: companies.filter(c => c.status === 'inactive').length,
    pending: companies.filter(c => c.status === 'pending').length,
  };

  return (
    <DashboardLayout title="Companies">
      <div className="space-y-6">
        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total', count: statCounts.all, color: 'text-foreground' },
            { label: 'Active', count: statCounts.active, color: 'text-emerald-600' },
            { label: 'Inactive', count: statCounts.inactive, color: 'text-gray-500' },
            { label: 'Pending', count: statCounts.pending, color: 'text-amber-600' },
          ].map(s => (
            <div key={s.label} className="bg-card border rounded-lg p-4">
              <p className="text-sm text-muted-foreground">{s.label}</p>
              <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.count}</p>
            </div>
          ))}
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-3 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search companies..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={fetchCompanies} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
            <Button onClick={openCreate}>
              <Plus className="h-4 w-4 mr-2" />
              New Company
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-card border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 border-b">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Company</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Code</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Industry</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Contact</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Status</th>
                  <th className="text-left px-4 py-3 font-medium text-muted-foreground">Created</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">Loading...</td></tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-12">
                      <Building2 className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                      <p className="text-muted-foreground">No companies found</p>
                      <Button variant="outline" className="mt-3" onClick={openCreate}>
                        <Plus className="h-4 w-4 mr-2" />Add Company
                      </Button>
                    </td>
                  </tr>
                ) : filtered.map(company => {
                  const status = statusConfig[company.status] || statusConfig.active;
                  const StatusIcon = status.icon;
                  return (
                    <tr key={company.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                            <Building2 className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{company.name}</p>
                            {company.legal_name && <p className="text-xs text-muted-foreground">{company.legal_name}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs bg-muted px-2 py-1 rounded">
                          {company.company_code || '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{company.industry || '—'}</td>
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          {company.contact_email && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Mail className="h-3 w-3" />{company.contact_email}
                            </div>
                          )}
                          {company.contact_phone && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Phone className="h-3 w-3" />{company.contact_phone}
                            </div>
                          )}
                          {company.city && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <MapPin className="h-3 w-3" />{company.city}, {company.country}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${status.color}`}>
                          <StatusIcon className="h-3 w-3" />{status.label}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {new Date(company.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => navigate(`/companies/${company.id}`)}>
                              <Eye className="h-4 w-4 mr-2" />View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEdit(company)}>
                              <Edit className="h-4 w-4 mr-2" />Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => { setDeletingId(company.id); setShowDeleteDialog(true); }}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filtered.length > 0 && (
            <div className="px-4 py-3 border-t text-sm text-muted-foreground">
              Showing {filtered.length} of {companies.length} companies
            </div>
          )}
        </div>
      </div>

      {/* Create / Edit Modal */}
      <Dialog open={showFormModal} onOpenChange={setShowFormModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingCompany ? 'Edit Company' : 'New Company'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
            {/* Basic Info */}
            <div className="sm:col-span-2">
              <Label>Company Name *</Label>
              <Input
                value={formData.name}
                onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                placeholder="e.g. Acme Corp"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Legal Name</Label>
              <Input
                value={formData.legal_name}
                onChange={e => setFormData(p => ({ ...p, legal_name: e.target.value }))}
                placeholder="Legal entity name"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Company Code</Label>
              <Input
                value={formData.company_code}
                onChange={e => setFormData(p => ({ ...p, company_code: e.target.value }))}
                placeholder="e.g. ACME-001"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Industry</Label>
              <Input
                value={formData.industry}
                onChange={e => setFormData(p => ({ ...p, industry: e.target.value }))}
                placeholder="e.g. E-commerce"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={v => setFormData(p => ({ ...p, status: v }))}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Tax Number</Label>
              <Input
                value={formData.tax_number}
                onChange={e => setFormData(p => ({ ...p, tax_number: e.target.value }))}
                placeholder="Tax registration number"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Registration Number</Label>
              <Input
                value={formData.registration_number}
                onChange={e => setFormData(p => ({ ...p, registration_number: e.target.value }))}
                placeholder="Commercial registration"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Country</Label>
              <Input
                value={formData.country}
                onChange={e => setFormData(p => ({ ...p, country: e.target.value }))}
                placeholder="Country"
                className="mt-1"
              />
            </div>
            <div>
              <Label>City</Label>
              <Input
                value={formData.city}
                onChange={e => setFormData(p => ({ ...p, city: e.target.value }))}
                placeholder="City"
                className="mt-1"
              />
            </div>
            <div className="sm:col-span-2">
              <Label>Address</Label>
              <Input
                value={formData.address}
                onChange={e => setFormData(p => ({ ...p, address: e.target.value }))}
                placeholder="Full address"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Website</Label>
              <Input
                value={formData.website}
                onChange={e => setFormData(p => ({ ...p, website: e.target.value }))}
                placeholder="https://example.com"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Contact Email</Label>
              <Input
                value={formData.contact_email}
                onChange={e => setFormData(p => ({ ...p, contact_email: e.target.value }))}
                placeholder="contact@company.com"
                type="email"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Contact Phone</Label>
              <Input
                value={formData.contact_phone}
                onChange={e => setFormData(p => ({ ...p, contact_phone: e.target.value }))}
                placeholder="+20 10x xxx xxxx"
                className="mt-1"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFormModal(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? 'Saving...' : editingCompany ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Company</DialogTitle>
          </DialogHeader>
          <p className="text-muted-foreground py-2">
            Are you sure you want to delete this company? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}