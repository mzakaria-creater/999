ممتاز. إضافة Import Transactions + Mass Selection مهمة جدًا لمنصة مثل OnTarget PSP لأنها تسمح لك بإدخال معاملات كثيرة مرة واحدة ومراجعتها بسرعة. سأعطيك التصميم الصحيح للميزة داخل المنصة.

⸻

1️⃣ Import Transactions (رفع ملف معاملات)

أين تكون في المنصة

داخل:

Transactions → Import Transactions

زر واضح:

Import File


⸻

2️⃣ أنواع الملفات المدعومة

يفضل دعم:

CSV
Excel (.xlsx)
Numbers export
Google Sheets CSV


⸻

3️⃣ نموذج ملف المعاملات

التاجر أو فريق العمليات يرفع ملف بهذا الشكل:

order_id	merchant	amount	method	account	reference	time
ORD001	ForexPro	1500	Vodafone	01012345678	928172	12:30
ORD002	BrokerX	900	InstaPay	IBAN123	827171	12:45


⸻

4️⃣ رفع الملف

واجهة بسيطة:

Drag & Drop File
or
Upload CSV / Excel

ثم:

Preview Transactions


⸻

5️⃣ Preview قبل الإدخال

قبل إدخال المعاملات تظهر مراجعة:

Select	Order ID	Merchant	Amount	Method	Account
☐	ORD001	ForexPro	1500	Vodafone	01012345678
☐	ORD002	BrokerX	900	InstaPay	IBAN


⸻

6️⃣ Mass Selection

يكون لديك اختيار جماعي.

في الأعلى

☑ Select All

ثم خيارات:

Approve Selected
Reject Selected
Assign Account
Delete
Export


⸻

7️⃣ مثال واجهة Mass Action

[ Select All ]   128 selected

Approve
Reject
Assign Wallet
Export
Delete


⸻

8️⃣ تخصيص الحسابات تلقائيًا

عند الاستيراد يمكن للنظام:

Auto Wallet Allocation

يعني:

amount → choose wallet
method → choose account
merchant → choose routing


⸻

9️⃣ مثال Mass Assign

اختر معاملات كثيرة:

Select 50 transactions

ثم:

Assign Payment Account

ثم:

Vodafone Wallet 3


⸻

🔟 Import Withdrawals

يمكن أيضًا رفع ملف سحوبات:

merchant	amount	destination	account
ForexPro	5000	Vodafone	010
BrokerX	2000	Bank	IBAN


⸻

11️⃣ معالجة أخطاء الملف

إذا الملف فيه أخطاء:

Row	Error
3	Missing amount
5	Invalid method

النظام يوضحها قبل الإدخال.

⸻

12️⃣ زر التنفيذ

بعد المراجعة:

Import 128 Transactions


⸻

13️⃣ بعد الإدخال

النظام ينشئ:

checkout session
transaction
wallet assignment
status pending


⸻

14️⃣ Import Proof Images

يمكن رفع صور دفعة واحدة:

Upload Proof Folder

ويتم ربطها بالـ:

order_id
reference
trx_id


⸻

15️⃣ Import Settlement Files

يمكن أيضًا رفع:

bank statement
wallet statement
provider report

لمطابقة المعاملات.

⸻

16️⃣ مثال كود Import API

POST /api/v1/transactions/import

{
 "file":"transactions.csv",
 "merchant":"ForexPro"
}


⸻

17️⃣ مثال Mass Approve API

POST /api/v1/transactions/bulk-approve

{
 "trx_ids":[
 "TRX001",
 "TRX002",
 "TRX003"
 ]
}


⸻

18️⃣ تصميم الواجهة Mobile Friendly

على الموبايل:

كل معاملة Card:

☑ TRX 88213
Merchant: ForexPro
Amount: 1500
Method: Vodafone

ثم زر:

Bulk Actions


⸻

19️⃣ مزايا متقدمة

يمكنك إضافة:

Auto Mapping

النظام يقرأ:

column name

ويطابقها تلقائيًا.

⸻

Duplicate Detection

إذا نفس:

reference
amount
time

يظهر تحذير.

⸻

Smart Validation

يتأكد من:

amount
method
account
merchant


⸻

20️⃣ النتيجة

المنصة ستسمح لك:

✔ رفع آلاف المعاملات مرة واحدة
✔ مراجعة قبل الإدخال
✔ اختيار جماعي
✔ تنفيذ جماعي
✔ تخصيص الحسابات تلقائيًا
✔ اكتشاف الأخطاء

⸻

لو أردت، أستطيع أيضًا أن أصمم لك واجهة Import Transactions الكاملة UI (مثل Stripe Ops Console) مع:
	•	drag & drop
	•	preview grid
	•	mass selection
	•	validation
	•	automation

بشكل جاهز للمنصة.