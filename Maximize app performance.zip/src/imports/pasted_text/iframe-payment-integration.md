نعم — iFrame مهم جدًا في منصات الدفع، وهو فعلاً الطريقة التي تستخدمها منصات مثل Stripe وCheckout.com لدمج صفحة الدفع داخل موقع التاجر بدون تحويل المستخدم لصفحة خارجية.

سأشرح لك كيف يعمل iFrame في منصتك (OnTarget / Goldex PSP) وكيف تبنيه بشكل صحيح.

⸻

ما هو iFrame Checkout

بدلاً من تحويل العميل إلى موقع الدفع:

merchant-site.com → redirect → checkout.ontarget.com

يمكن للتاجر تضمين صفحة الدفع مباشرة داخل موقعه:

<iframe
  src="https://checkout.ontarget-egy.com/start?mid=MERCH001"
  width="100%"
  height="700"
  frameborder="0">
</iframe>

فتظهر صفحة الدفع داخل الموقع نفسه.

⸻

لماذا iFrame مهم

التاجر يحصل على:
	•	تجربة دفع داخل الموقع
	•	لا يفقد العميل
	•	لا يظهر redirect
	•	يمكن تصميم الصفحة حسب التاجر

⸻

أنواع Checkout التي يمكن تحميلها داخل iFrame

مثلاً:

Wallet checkout

/checkout/wallet

InstaPay checkout

/checkout/instapay

Bank transfer checkout

/checkout/bank

QR checkout

/checkout/qr


⸻

مثال عملي

موقع التاجر:

broker.com/deposit

يضع:

<iframe
 src="https://checkout.ontarget-egy.com/wallet?mid=MERCH001&amount=1500"
 width="100%"
 height="650">
</iframe>

فتظهر:

Vodafone Cash
Orange Cash
Etisalat Cash
WE Pay


⸻

طريقة تمرير البيانات

يمكن إرسال البيانات عبر URL:

https://checkout.ontarget-egy.com/start
?mid=MERCH001
&order_id=ORD9281
&amount=1500
&currency=EGP
&hash=f84a1d0


⸻

Hash Security

يجب التحقق من التوقيع.

مثال:

hash = SHA256(
  mid + order_id + amount + currency + secret
)

إذا كان hash غير صحيح → رفض الطلب.

⸻

كيف يتواصل iFrame مع موقع التاجر

يتم باستخدام:

window.postMessage

مثال عند نجاح الدفع:

window.parent.postMessage(
 {
   status: "success",
   transaction_id: "TRX93812"
 },
 "*"
)

موقع التاجر يستقبل الرسالة:

window.addEventListener("message", function(event) {
  if(event.data.status === "success"){
     console.log("Payment success")
  }
})


⸻

أنواع iFrame التي يجب أن تدعمها منصتك

1️⃣ Embedded Checkout

<iframe src="/checkout/start">

2️⃣ Specific checkout

/checkout/wallet
/checkout/bank

3️⃣ Payment Link

https://pay.ontarget-egy.com/abc123

4️⃣ Redirect checkout

redirect_url


⸻

بنية صفحات checkout في المنصة

/checkout/start
/checkout/wallet
/checkout/instapay
/checkout/bank
/checkout/qr
/checkout/gcc-wallet
/checkout/voucher


⸻

ربط checkout بالتاجر

في قاعدة البيانات:

merchant_checkouts

الحقول:

merchant_id
checkout_type
enabled
priority

مثال:

ForexPro → wallet
ForexPro → instapay
BrokerX → bank


⸻

Admin Panel

يجب أن يحتوي على:

Checkout Builder

يمكنك:
	•	إنشاء checkout جديد
	•	تخصيص UI
	•	ربطه بالتجار

⸻

مثال النتيجة النهائية

تاجر:

ForexPro

checkout المتاح:

Wallet
InstaPay

صفحة الدفع تظهر:

Select Payment Method

📱 Mobile Wallet
⚡ InstaPay


⸻

شيء مهم جدًا

إذا بنيت النظام بهذه الطريقة، ستصبح منصتك:

OnTarget PSP

مع:

Multi Checkout Engine

مثل:
	•	Stripe
	•	Checkout.com
	•	Paymob

⸻

إذا أردت، يمكنني في الرسالة القادمة أن أريك:

كيف تبني Checkout Engine كامل (مثل Stripe)
يشمل:
	•	iFrame
	•	Redirect
	•	Payment Links
	•	Wallet routing
	•	Multi-region checkout

وهذا هو قلب أي PSP احترافي.