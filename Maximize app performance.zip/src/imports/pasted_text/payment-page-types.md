
IMPORTANT:
Generate FULL INTERNAL PAGE CONTENT, not only page shells.
Every page must include real sections, cards, tables, filters, buttons, states, empty states, status badges, search areas, tabs, charts, side panels, and action buttons.
Do not create generic placeholders only.

PLATFORM NAME:
OnTarget PSP

SYSTEM TYPE:
Payment Service Provider platform for merchants, sub-merchants, finance teams, operations teams, and administrators.

MAIN REQUIREMENT:
This platform must include MULTIPLE PAYMENT PAGE TYPES, dynamic merchant integration options, role-based views, hidden pages by role, and smart user role recognition after login.

PAGES TO DESIGN:

1) LOGIN PAGE
Create a secure login page for platform users.
Include:
- username/email field
- password field
- remember me
- forgot password
- login button
- support contact
- role-aware system note
After login, system should understand user role from account data and redirect to the correct dashboard automatically.

2) SMART ROLE-BASED REDIRECTION LOGIC UI FLOW
Design a visual access logic section showing that after login the system reads:
- username
- merchant_id
- role
- permissions
- status
Then opens the correct dashboard automatically.

Example roles:
- Owner
- Super Admin
- Finance Manager
- Operations
- Merchant Admin
- Merchant User
- Viewer / Read Only

Add a clean permissions matrix component showing page visibility by role.

3) ADMIN MASTER DASHBOARD
Full detailed dashboard with:
- total transactions
- deposits today
- withdrawals today
- pending approvals
- failed transactions
- merchant count
- active wallets
- total processed volume
- revenue today
- commission summary
- live transactions feed
- payment method distribution chart
- wallet utilization chart
- risk alerts panel
- recent merchant activity
- quick action buttons

4) FINANCE DASHBOARD
Show only finance-related sections:
- settlement summary
- commission totals
- payout requests
- wallet balances
- broker balances
- reconciliation status
- daily / weekly / monthly summaries
- export reports
- approve settlement
- pending financial actions

5) OPERATIONS DASHBOARD
Show only operations-related sections:
- pending transaction approvals
- uploaded receipts queue
- callback failures
- flagged transactions
- duplicate detection panel
- transaction review queue
- manual verification buttons
- wallet assignment issues
- action center

6) MERCHANT DASHBOARD
Merchant should only see their own data.
Include:
- today’s transactions
- successful payments
- failed payments
- pending transactions
- payment links created
- invoices created
- checkout integrations
- API usage summary
- callback status
- settlement history
- recent customer payments
- create new payment button
- create payment link
- create invoice
- generate embed code

7) VIEWER DASHBOARD
Read-only dashboard with no destructive actions.
Show:
- reports
- basic transaction lists
- summary cards
- no edit buttons
- no settings
- no user management

8) TRANSACTIONS PAGE
Create a full transaction management page with:
- table columns:
  Transaction ID
  Merchant
  Customer Name
  Customer Phone
  Amount
  Currency
  Payment Method
  Assigned Wallet
  Provider
  Status
  Created Date
  Updated Date
  Actions
- filters:
  date range
  merchant
  status
  provider
  wallet
  amount range
  search by transaction id / phone
- row actions:
  view
  approve
  reject
  mark pending
  resend callback
  open receipt
- detailed transaction side drawer

9) PAYMENT PAGE TYPES SECTION
Create MULTIPLE smart payment interfaces, not one checkout only.

A. Hosted Payment Page
- branded payment page
- amount
- transaction reference
- merchant name
- payment method selector
- submit payment
- status banner

B. Embedded iFrame Payment Widget
- compact widget for merchant websites
- merchant logo area
- amount field or prefilled amount
- wallet/payment method display
- pay now button
- secure widget footer
- integration note
- generated iframe embed code block

C. Payment Link Page
- page opened by link
- merchant branding
- invoice reference
- amount due
- expiry timer
- payment options
- customer details
- pay now button

D. Invoice Payment Page
- invoice summary
- customer name
- due amount
- due date
- line items
- payment methods
- status badge
- pay invoice action

E. QR Payment Page
- QR code block
- copy amount
- copy reference
- wallet/account details
- upload receipt
- confirm transfer
- countdown timer
- pending review state

F. Mobile Wallet Transfer Page
Designed for Egypt local payment methods.
Include:
- Vodafone Cash
- Orange Money
- Etisalat Cash
- InstaPay
- Meeza / bank transfer style option
Display:
- allocated wallet/account
- amount
- transaction reference
- QR area
- USSD button
- copy wallet number
- upload screenshot
- I sent payment button
- awaiting confirmation state

10) EMBED / IFRAME INTEGRATION PAGE
Create a merchant-facing integration page showing:
- embedded payment preview
- iframe code snippet
- script integration option
- domain allowlist setting
- callback URL field
- success URL
- failed URL
- test mode / live mode toggle
- copy code button

11) API DOCUMENTATION PAGE
Design a full API docs page for merchants.
Include:
- sidebar endpoints menu
- authentication section
- API key explanation
- base URL
- example endpoints:
  POST /create-transaction
  GET /transaction-status
  POST /create-payment-link
  POST /create-invoice
  POST /payout
  POST /callback
- request example
- response example
- status codes
- decline reasons
- webhook events
- test credentials section
- support section

12) COMMISSION & PRICING PAGE
Create a page showing:
- deposit commission
- withdrawal commission
- settlement fees
- provider cost
- net revenue
- custom merchant pricing
- tier pricing
- monthly volume bracket pricing
- commission calculator
- summary cards
- comparison table
- contract / agreement style summary panel

13) USERS & ROLES PAGE
Create a professional RBAC page with:
- users table
- role column
- merchant mapping
- status
- last login
- allowed pages
- actions
- create user button
- assign role modal
- permissions modal
- disable user button

14) PERMISSIONS MATRIX PAGE
This page is critical.
Create a full matrix with rows as pages/modules and columns as roles.
Roles:
- Owner
- Super Admin
- Finance
- Operations
- Merchant Admin
- Merchant User
- Viewer
Modules:
- dashboard
- transactions
- wallets
- merchants
- users
- pricing
- API docs
- payment links
- invoices
- settlements
- reports
- settings
Show permissions:
- view