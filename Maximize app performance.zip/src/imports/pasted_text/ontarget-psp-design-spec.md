Design a next-generation fintech payment gateway platform UI for “OnTarget PSP”.

YEAR STYLE:
2026 modern fintech interface.
Avoid old dashboard styles. Do not repeat classic dark dashboards.

VISUAL STYLE:
- soft glass surfaces
- layered translucent panels
- subtle depth shadows
- smooth gradients
- glowing interactive elements
- premium fintech minimalism

COLOR SYSTEM:
Use a modern fintech palette that is NOT typical black + gold.

Primary base:
Deep graphite (#121417)

Accent gradients:
Electric violet → cobalt blue
Mint → aqua glow
Soft amber highlights for actions

Status colors:
Success: neon mint
Pending: soft amber
Failed: coral red

Use glowing hover states.

TYPOGRAPHY:
Inter variable font
Large clean headings
High readability tables

COMPONENT STYLE:
All components must feel modern and interactive.

Buttons:
- rounded pill buttons
- subtle glow on hover
- animated press state
- icon + label buttons

Form Inputs:
- floating labels
- smart validation
- inline hints
- focus glow border
- success / error inline feedback

Switches / Toggles:
- modern sliding switches
- animated color change
- soft glow when active

Dropdowns:
- searchable dropdown
- icon support
- keyboard navigation

Filters:
Do NOT use simple dropdown filters.
Use modern filter chips and dynamic filter panels.

Example filter system:
- date range picker
- merchant selector
- wallet selector
- status chips
- amount slider filter
- live search input

Tables:
- sticky headers
- sortable columns
- hover row highlight
- inline action buttons
- expandable row details
- status badges
- live updating rows

Charts:
- smooth animated charts
- gradient area charts
- donut charts for payment methods
- wallet capacity gauges

MAIN PAGES:

1) Smart Dashboard
Include:
- revenue cards
- wallet balances
- live transactions
- volume charts
- payment method distribution
- merchant activity
- alerts panel

2) Transactions Manager
Advanced transaction table with filters, search, row actions, and expandable details.

3) Wallet Allocation System
Show wallets as cards with:
- provider logo
- wallet number
- daily limit
- monthly limit
- usage bar
- available capacity gauge

4) Merchant Manager
Merchant table with:
- merchant id
- API status
- payment methods
- volume
- status

Include create merchant modal.

5) Multi Payment Pages
Design multiple payment interfaces:

Hosted Payment Page
Payment Link Page
QR Payment Page
Invoice Payment Page
Embedded Widget Page

Each page must look modern and mobile friendly.

6) Embed Integration Page
Show iframe integration preview and code block.

7) API Documentation Page
Modern developer docs layout with endpoint cards and request/response examples.

ROLE BASED ACCESS SYSTEM:

Design UI logic where pages are visible depending on user role.

Roles:
Owner
Admin
Finance
Operations
Merchant
Viewer

Each role should see different sidebar menus.

Sidebar must dynamically hide pages not allowed for that role.

Add permissions matrix UI showing which roles can access each page.

MICRO INTERACTIONS:

Add modern animations:
hover glow
button ripple
loading skeletons
animated counters
smooth dropdown open
soft transitions

OUTPUT:
Generate full internal page designs with real content, tables, filters, forms, and buttons.
Avoid empty placeholder blocks.