import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import {
  RefreshCw, ArrowUpDown,
  Send, Wallet, DollarSign, Clock, ShieldCheck, AlertTriangle,
} from 'lucide-react';

interface RateData {
  lastPrice: string;
  highPrice: string;
  lowPrice: string;
  buyPrice: string;
  sellPrice: string;
  spread: string;
  priceChange: string;
  priceChangePercent: string;
  weightedAvgPrice: string;
  source: string;
}

interface P2PAd {
  id: string;
  price: string;
  minAmount: string;
  maxAmount: string;
  available: string;
  tradeType: string;
  payMethods: string[];
  merchant: {
    name: string;
    completedOrders: number;
    completionRate: number;
    isVerified: boolean;
  };
}

export default function BinancePage() {
  const [rate, setRate] = useState<RateData | null>(null);
  const [buyAds, setBuyAds] = useState<P2PAd[]>([]);
  const [sellAds, setSellAds] = useState<P2PAd[]>([]);
  const [loading, setLoading] = useState({ rate: true, p2p: true });
  const [p2pTab, setP2pTab] = useState<'BUY' | 'SELL'>('BUY');
  const [payoutForm, setPayoutForm] = useState({ address: '', amount: '', coin: 'USDT', network: 'TRX' });
  const [payoutLoading, setPayoutLoading] = useState(false);

  const fetchRate = useCallback(async () => {
    setLoading(l => ({ ...l, rate: true }));
    try {
      const { data, error } = await supabase.functions.invoke('binance-api', {
        body: { action: 'rate' },
      });
      if (error) throw error;
      setRate(data.rate);
    } catch (err: any) {
      console.error('Rate fetch error:', err);
    } finally {
      setLoading(l => ({ ...l, rate: false }));
    }
  }, []);

  const fetchP2P = useCallback(async (tradeType: 'BUY' | 'SELL') => {
    setLoading(l => ({ ...l, p2p: true }));
    try {
      const { data, error } = await supabase.functions.invoke('binance-api', {
        body: { action: 'p2p', tradeType, asset: 'USDT', fiat: 'EGP', rows: 10 },
      });
      if (error) throw error;
      if (tradeType === 'BUY') setBuyAds(data.ads);
      else setSellAds(data.ads);
    } catch (err: any) {
      console.error('P2P fetch error:', err);
    } finally {
      setLoading(l => ({ ...l, p2p: false }));
    }
  }, []);

  useEffect(() => {
    fetchRate();
    fetchP2P('BUY');
    fetchP2P('SELL');
    const interval = setInterval(fetchRate, 30000);
    return () => clearInterval(interval);
  }, [fetchRate, fetchP2P]);

  const handlePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payoutForm.address || !payoutForm.amount) return;
    setPayoutLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('binance-api', {
        body: { action: 'payout', ...payoutForm },
      });
      if (error) throw error;
      if (data.error) {
        toast.error(data.error);
      } else {
        toast.success(`Payout submitted! ID: ${data.withdrawId}`);
        setPayoutForm(f => ({ ...f, address: '', amount: '' }));
      }
    } catch (err: any) {
      toast.error(err.message || 'Payout failed');
    } finally {
      setPayoutLoading(false);
    }
  };

  const currentAds = p2pTab === 'BUY' ? buyAds : sellAds;

  return (
    <div className="space-y-6">
      {/* Rate Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="col-span-1 md:col-span-2 p-6 bg-gradient-to-br from-[hsl(var(--primary)/0.05)] to-transparent border-primary/20">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#F0B90B]/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-[#F0B90B]">₿</span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">USDT / EGP</p>
                <h2 className="text-3xl font-bold text-foreground tracking-tight">
                  {loading.rate ? '...' : rate ? `${parseFloat(rate.lastPrice).toFixed(2)} EGP` : 'N/A'}
                </h2>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={fetchRate} disabled={loading.rate}>
              <RefreshCw className={`h-4 w-4 ${loading.rate ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {rate && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Buy Price</p>
                <p className="text-sm font-semibold text-emerald-500">{parseFloat(rate.buyPrice).toFixed(2)} EGP</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Sell Price</p>
                <p className="text-sm font-semibold text-red-500">{parseFloat(rate.sellPrice).toFixed(2)} EGP</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Spread</p>
                <p className="text-sm font-semibold text-foreground">{rate.spread}%</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Range</p>
                <p className="text-sm font-semibold text-foreground">{parseFloat(rate.lowPrice).toFixed(2)} - {parseFloat(rate.highPrice).toFixed(2)}</p>
              </div>
            </div>
          )}
        </Card>

        <Card className="p-6 space-y-3">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-foreground">Quick Convert</h3>
          </div>
          {rate && (
            <div className="space-y-3">
              <div className="bg-secondary rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">1 USDT =</p>
                <p className="text-xl font-bold text-foreground">{parseFloat(rate.lastPrice).toFixed(2)} EGP</p>
              </div>
              <div className="bg-secondary rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">100 USDT =</p>
                <p className="text-xl font-bold text-foreground">{(parseFloat(rate.lastPrice) * 100).toFixed(2)} EGP</p>
              </div>
              <div className="bg-secondary rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">1000 EGP =</p>
                <p className="text-xl font-bold text-foreground">{(1000 / parseFloat(rate.lastPrice)).toFixed(2)} USDT</p>
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* P2P + Payout Tabs */}
      <Tabs defaultValue="p2p" className="space-y-4">
        <TabsList className="bg-secondary">
          <TabsTrigger value="p2p"><ArrowUpDown className="h-4 w-4 mr-2" />P2P Market</TabsTrigger>
          <TabsTrigger value="payout"><Send className="h-4 w-4 mr-2" />Payout</TabsTrigger>
          <TabsTrigger value="receive"><Wallet className="h-4 w-4 mr-2" />Receive</TabsTrigger>
        </TabsList>

        {/* P2P Tab */}
        <TabsContent value="p2p" className="space-y-4">
          <Card className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant={p2pTab === 'BUY' ? 'default' : 'outline'}
                  className={p2pTab === 'BUY' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
                  onClick={() => { setP2pTab('BUY'); if (buyAds.length === 0) fetchP2P('BUY'); }}
                >
                  Buy USDT
                </Button>
                <Button
                  size="sm"
                  variant={p2pTab === 'SELL' ? 'default' : 'outline'}
                  className={p2pTab === 'SELL' ? 'bg-red-600 hover:bg-red-700' : ''}
                  onClick={() => { setP2pTab('SELL'); if (sellAds.length === 0) fetchP2P('SELL'); }}
                >
                  Sell USDT
                </Button>
              </div>
              <Button variant="ghost" size="sm" onClick={() => fetchP2P(p2pTab)} disabled={loading.p2p}>
                <RefreshCw className={`h-3 w-3 mr-1 ${loading.p2p ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>

            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Merchant</TableHead>
                    <TableHead>Price (EGP)</TableHead>
                    <TableHead className="hidden md:table-cell">Available</TableHead>
                    <TableHead className="hidden md:table-cell">Limit</TableHead>
                    <TableHead>Payment</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading.p2p ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading P2P offers...</TableCell></TableRow>
                  ) : currentAds.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No offers available</TableCell></TableRow>
                  ) : (
                    currentAds.map((ad) => (
                      <TableRow key={ad.id} className="hover:bg-muted/30">
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                              {ad.merchant.name?.charAt(0)?.toUpperCase() || '?'}
                            </div>
                            <div>
                              <div className="flex items-center gap-1">
                                <span className="text-sm font-medium text-foreground">{ad.merchant.name}</span>
                                {ad.merchant.isVerified && <ShieldCheck className="h-3 w-3 text-[#F0B90B]" />}
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {ad.merchant.completedOrders} orders • {(ad.merchant.completionRate * 100).toFixed(0)}%
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={`text-base font-bold ${p2pTab === 'BUY' ? 'text-emerald-500' : 'text-red-500'}`}>
                            {parseFloat(ad.price).toFixed(2)}
                          </span>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <span className="text-sm text-foreground">{parseFloat(ad.available).toFixed(2)} USDT</span>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <span className="text-xs text-muted-foreground">
                            {parseFloat(ad.minAmount).toFixed(0)} - {parseFloat(ad.maxAmount).toFixed(0)} EGP
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {ad.payMethods.slice(0, 2).map(m => (
                              <Badge key={m} variant="secondary" className="text-[10px] px-1.5 py-0">
                                {m}
                              </Badge>
                            ))}
                            {ad.payMethods.length > 2 && (
                              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">+{ad.payMethods.length - 2}</Badge>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        {/* Payout Tab */}
        <TabsContent value="payout">
          <Card className="p-6 max-w-lg">
            <div className="flex items-center gap-2 mb-4">
              <Send className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-foreground">Send USDT Payout</h3>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 mb-4 flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-yellow-500 shrink-0 mt-0.5" />
              <p className="text-xs text-yellow-600 dark:text-yellow-400">
                Requires Binance API key with withdrawal permissions. Configure in Integration Secrets.
              </p>
            </div>

            <form onSubmit={handlePayout} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Recipient Address</label>
                <input
                  type="text"
                  placeholder="TRC20 / ERC20 address..."
                  value={payoutForm.address}
                  onChange={e => setPayoutForm(f => ({ ...f, address: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/30"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Amount (USDT)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    placeholder="100.00"
                    value={payoutForm.amount}
                    onChange={e => setPayoutForm(f => ({ ...f, amount: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Network</label>
                  <select
                    value={payoutForm.network}
                    onChange={e => setPayoutForm(f => ({ ...f, network: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                  >
                    <option value="TRX">TRC20 (Low Fee)</option>
                    <option value="ETH">ERC20</option>
                    <option value="BSC">BEP20</option>
                    <option value="SOL">Solana</option>
                    <option value="MATIC">Polygon</option>
                  </select>
                </div>
              </div>

              {rate && payoutForm.amount && (
                <div className="bg-secondary rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Estimated EGP value</p>
                  <p className="text-lg font-bold text-foreground">
                    {(parseFloat(payoutForm.amount) * parseFloat(rate.lastPrice)).toFixed(2)} EGP
                  </p>
                </div>
              )}

              <Button type="submit" className="w-full" disabled={payoutLoading}>
                {payoutLoading ? 'Processing...' : 'Send Payout'}
              </Button>
            </form>
          </Card>
        </TabsContent>

        {/* Receive Tab */}
        <TabsContent value="receive">
          <Card className="p-6 max-w-lg">
            <div className="flex items-center gap-2 mb-4">
              <Wallet className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-foreground">Accept Payment in USDT</h3>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-4">
              <h4 className="text-sm font-medium text-foreground mb-2">How to accept USDT payments:</h4>
              <ol className="text-xs text-muted-foreground space-y-2 list-decimal ml-4">
                <li>Generate a deposit address from your Binance account</li>
                <li>Share the address/QR code with the payer</li>
                <li>Monitor incoming deposits via Binance API</li>
                <li>Auto-convert to EGP using the current rate</li>
              </ol>
            </div>

            <div className="bg-secondary rounded-lg p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Current Rate</span>
              </div>
              {rate && (
                <div className="text-center py-3">
                  <p className="text-2xl font-bold text-foreground">1 USDT = {parseFloat(rate.lastPrice).toFixed(2)} EGP</p>
                  <p className="text-xs text-muted-foreground mt-1">Updated every 30 seconds</p>
                </div>
              )}
            </div>

            <div className="mt-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-yellow-500 shrink-0 mt-0.5" />
              <p className="text-xs text-yellow-600 dark:text-yellow-400">
                Full payment acceptance requires Binance API integration. Add your API credentials to enable deposit monitoring.
              </p>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
