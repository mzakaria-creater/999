import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  FileText, Download, RefreshCw, Eye, Send, CheckCircle2,
  Clock, AlertTriangle, XCircle, Search, Plus, DollarSign,
  Building2, Calendar, BarChart3
} from "lucide-react";
import { toast } from "sonner";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Contract {
  id: string;
  merchant: string;
  type: string;
  startDate: string;
  endDate: string;
  value: number;
  status: "Active" | "Expiring" | "Expired";
  contactPerson: string;
  email: string;
  commissionRate: number;
  billingCycle: string;
  paymentTerms: string;
  notes: string;
}

interface Invoice {
  id: string;
  merchant: string;
  amount: number;
  period: string;
  issued: string;
  due: string;
  status: "Paid" | "Outstanding" | "Overdue";
  breakdown: { label: string; amount: number }[];
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const contracts: Contract[] = [
  { id: "CTR-2024-001", merchant: "Cairo Digital Merchants", type: "Full Service", startDate: "2024-01-01", endDate: "2024-12-31", value: 480000, status: "Active", contactPerson: "Ahmed Hassan", email: "ahmed@cairodm.com", commissionRate: 2.5, billingCycle: "Monthly", paymentTerms: "Net 30", notes: "Preferred tier with custom SLAs." },
  { id: "CTR-2024-002", merchant: "Nile Commerce Ltd", type: "Gateway Only", startDate: "2024-03-15", endDate: "2025-03-14", value: 120000, status: "Active", contactPerson: "Sara Nasser", email: "sara@nilecommerce.com", commissionRate: 1.8, billingCycle: "Monthly", paymentTerms: "Net 15", notes: "Gateway-only package." },
  { id: "CTR-2024-003", merchant: "Delta Retail Group", type: "Enterprise", startDate: "2023-06-01", endDate: "2026-05-31", value: 1800000, status: "Active", contactPerson: "Omar Farouk", email: "omar@deltaretail.com", commissionRate: 1.5, billingCycle: "Quarterly", paymentTerms: "Net 45", notes: "3-year enterprise agreement." },
  { id: "CTR-2024-004", merchant: "AlexPay Solutions", type: "Standard", startDate: "2024-02-01", endDate: "2025-01-31", value: 240000, status: "Active", contactPerson: "Mona Adel", email: "mona@alexpay.com", commissionRate: 2.0, billingCycle: "Monthly", paymentTerms: "Net 30", notes: "" },
  { id: "CTR-2024-005", merchant: "Pyramid E-Commerce", type: "Full Service", startDate: "2023-12-01", endDate: "2024-11-30", value: 360000, status: "Expiring", contactPerson: "Khaled Ibrahim", email: "khaled@pyramidec.com", commissionRate: 2.2, billingCycle: "Monthly", paymentTerms: "Net 30", notes: "Up for renewal — rate renegotiation expected." },
  { id: "CTR-2024-006", merchant: "Sphinx Fintech", type: "Standard", startDate: "2024-04-01", endDate: "2024-09-30", value: 80000, status: "Expiring", contactPerson: "Dina Kamal", email: "dina@sphinxft.com", commissionRate: 2.5, billingCycle: "Monthly", paymentTerms: "Net 30", notes: "" },
  { id: "CTR-2024-007", merchant: "MedCity Payments", type: "Gateway Only", startDate: "2023-09-15", endDate: "2024-09-14", value: 60000, status: "Expiring", contactPerson: "Ramy Saad", email: "ramy@medcity.com", commissionRate: 1.9, billingCycle: "Monthly", paymentTerms: "Net 15", notes: "Expiring in 2 weeks." },
  { id: "CTR-2023-008", merchant: "Luxor Traders", type: "Standard", startDate: "2023-01-01", endDate: "2023-12-31", value: 96000, status: "Expired", contactPerson: "Heba Mostafa", email: "heba@luxortraders.com", commissionRate: 2.5, billingCycle: "Monthly", paymentTerms: "Net 30", notes: "Not renewed." },
  { id: "CTR-2023-009", merchant: "Aswan Market Co.", type: "Basic", startDate: "2023-03-01", endDate: "2024-02-29", value: 48000, status: "Expired", contactPerson: "Tarek Samir", email: "tarek@aswanmarket.com", commissionRate: 2.8, billingCycle: "Monthly", paymentTerms: "Net 30", notes: "" },
  { id: "CTR-2023-010", merchant: "Suez Canal Trade", type: "Standard", startDate: "2022-07-01", endDate: "2024-06-30", value: 192000, status: "Expired", contactPerson: "Yasmin Farid", email: "yasmin@suezcanaltrade.com", commissionRate: 2.0, billingCycle: "Quarterly", paymentTerms: "Net 45", notes: "Contract lapsed." },
];

const invoices: Invoice[] = [
  { id: "INV-2024-0156", merchant: "Cairo Digital Merchants", amount: 42800, period: "Sep 2024", issued: "2024-10-01", due: "2024-10-31", status: "Outstanding", breakdown: [{ label: "Transaction Commission (2.5%)", amount: 38500 }, { label: "Gateway Fee", amount: 3000 }, { label: "Setup/Maintenance", amount: 1300 }] },
  { id: "INV-2024-0155", merchant: "Nile Commerce Ltd", amount: 11200, period: "Sep 2024", issued: "2024-10-01", due: "2024-10-15", status: "Outstanding", breakdown: [{ label: "Transaction Commission (1.8%)", amount: 9800 }, { label: "Gateway Fee", amount: 1400 }] },
  { id: "INV-2024-0154", merchant: "Delta Retail Group", amount: 156400, period: "Q3 2024", issued: "2024-10-01", due: "2024-11-15", status: "Outstanding", breakdown: [{ label: "Transaction Commission (1.5%)", amount: 142000 }, { label: "Enterprise Support", amount: 8400 }, { label: "Custom Integration", amount: 6000 }] },
  { id: "INV-2024-0153", merchant: "Sphinx Fintech", amount: 7600, period: "Aug 2024", issued: "2024-09-01", due: "2024-09-30", status: "Overdue", breakdown: [{ label: "Transaction Commission (2.5%)", amount: 6800 }, { label: "Gateway Fee", amount: 800 }] },
  { id: "INV-2024-0152", merchant: "MedCity Payments", amount: 5200, period: "Aug 2024", issued: "2024-09-01", due: "2024-09-15", status: "Overdue", breakdown: [{ label: "Transaction Commission (1.9%)", amount: 4600 }, { label: "Gateway Fee", amount: 600 }] },
  { id: "INV-2024-0151", merchant: "Pyramid E-Commerce", amount: 34200, period: "Aug 2024", issued: "2024-09-01", due: "2024-09-30", status: "Overdue", breakdown: [{ label: "Transaction Commission (2.2%)", amount: 30500 }, { label: "Gateway Fee", amount: 2700 }, { label: "Maintenance", amount: 1000 }] },
  { id: "INV-2024-0150", merchant: "Luxor Traders", amount: 8400, period: "Jul 2024", issued: "2024-08-01", due: "2024-08-30", status: "Overdue", breakdown: [{ label: "Transaction Commission (2.5%)", amount: 7800 }, { label: "Gateway Fee", amount: 600 }] },
  { id: "INV-2024-0149", merchant: "Cairo Digital Merchants", amount: 39600, period: "Aug 2024", issued: "2024-09-01", due: "2024-09-30", status: "Paid", breakdown: [{ label: "Transaction Commission (2.5%)", amount: 35800 }, { label: "Gateway Fee", amount: 2800 }, { label: "Setup/Maintenance", amount: 1000 }] },
  { id: "INV-2024-0148", merchant: "Nile Commerce Ltd", amount: 10400, period: "Aug 2024", issued: "2024-09-01", due: "2024-09-15", status: "Paid", breakdown: [{ label: "Transaction Commission (1.8%)", amount: 9200 }, { label: "Gateway Fee", amount: 1200 }] },
  { id: "INV-2024-0147", merchant: "AlexPay Solutions", amount: 22800, period: "Aug 2024", issued: "2024-09-01", due: "2024-09-30", status: "Paid", breakdown: [{ label: "Transaction Commission (2.0%)", amount: 20400 }, { label: "Gateway Fee", amount: 2400 }] },
  { id: "INV-2024-0146", merchant: "Delta Retail Group", amount: 148200, period: "Q2 2024", issued: "2024-07-01", due: "2024-08-15", status: "Paid", breakdown: [{ label: "Transaction Commission (1.5%)", amount: 135000 }, { label: "Enterprise Support", amount: 8200 }, { label: "Custom Integration", amount: 5000 }] },
  { id: "INV-2024-0145", merchant: "Cairo Digital Merchants", amount: 41200, period: "Jul 2024", issued: "2024-08-01", due: "2024-08-31", status: "Paid", breakdown: [{ label: "Transaction Commission (2.5%)", amount: 37000 }, { label: "Gateway Fee", amount: 3200 }, { label: "Setup/Maintenance", amount: 1000 }] },
];

const currentMonthBreakdown = [
  { feeType: "Transaction Commission", invoices: 12, totalEGP: 284600 },
  { feeType: "Gateway Fees", invoices: 12, totalEGP: 18400 },
  { feeType: "Enterprise Support", invoices: 2, totalEGP: 16800 },
  { feeType: "Custom Integration", invoices: 1, totalEGP: 6000 },
  { feeType: "Setup / Maintenance", invoices: 3, totalEGP: 3600 },
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  if (status === "Active" || status === "Paid") return <span className="badge-success">{status}</span>;
  if (status === "Expiring" || status === "Outstanding") return <span className="badge-warning">{status}</span>;
  if (status === "Expired" || status === "Overdue") return <span className="badge-danger">{status}</span>;
  return <span className="badge-muted">{status}</span>;
}

function ContractDetailModal({ contract, open, onClose }: { contract: Contract | null; open: boolean; onClose: () => void }) {
  if (!contract) return null;
  const billingItems = [
    { label: "Commission Rate", value: `${contract.commissionRate}%` },
    { label: "Billing Cycle", value: contract.billingCycle },
    { label: "Payment Terms", value: contract.paymentTerms },
    { label: "Contract Value", value: `EGP ${contract.value.toLocaleString()}` },
    { label: "Monthly Avg", value: `EGP ${Math.round(contract.value / 12).toLocaleString()}` },
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4 text-primary" />
            Contract Detail — {contract.id}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-5 mt-1">
          {/* Header info */}
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-lg font-semibold text-foreground">{contract.merchant}</p>
              <p className="text-sm text-muted-foreground">{contract.type} Agreement</p>
            </div>
            <StatusBadge status={contract.status} />
          </div>

          {/* Key dates */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p2p-card p-3">
              <p className="text-xs text-muted-foreground mb-0.5">Start Date</p>
              <p className="text-sm font-medium">{contract.startDate}</p>
            </div>
            <div className="p2p-card p-3">
              <p className="text-xs text-muted-foreground mb-0.5">End Date</p>
              <p className="text-sm font-medium">{contract.endDate}</p>
            </div>
          </div>

          {/* Contact */}
          <div className="p2p-card p-3 space-y-1">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Primary Contact</p>
            <p className="text-sm font-medium">{contract.contactPerson}</p>
            <p className="text-xs text-muted-foreground">{contract.email}</p>
          </div>

          {/* Billing Summary */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Billing Summary</p>
            <div className="rounded-lg border border-border overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  {billingItems.map((item) => (
                    <tr key={item.label} className="border-b border-border last:border-0">
                      <td className="px-3 py-2 text-muted-foreground">{item.label}</td>
                      <td className="px-3 py-2 text-right font-medium">{item.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {contract.notes && (
            <div className="p2p-card p-3 bg-amber-50/60 border-amber-200">
              <p className="text-xs font-medium text-amber-700 mb-1">Notes</p>
              <p className="text-sm text-amber-800">{contract.notes}</p>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Download PDF
            </Button>
            {contract.status !== "Active" && (
              <Button size="sm" className="gap-1.5">
                <RefreshCw className="h-3.5 w-3.5" /> Renew Contract
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InvoiceDetailModal({ invoice, open, onClose }: { invoice: Invoice | null; open: boolean; onClose: () => void }) {
  if (!invoice) return null;
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4 text-primary" />
            Invoice {invoice.id}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="font-semibold">{invoice.merchant}</p>
              <p className="text-xs text-muted-foreground">Period: {invoice.period}</p>
            </div>
            <StatusBadge status={invoice.status} />
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="p2p-card p-3">
              <p className="text-xs text-muted-foreground mb-0.5">Issued</p>
              <p className="font-medium">{invoice.issued}</p>
            </div>
            <div className="p2p-card p-3">
              <p className="text-xs text-muted-foreground mb-0.5">Due</p>
              <p className="font-medium">{invoice.due}</p>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Breakdown</p>
            <div className="rounded-lg border border-border overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  {invoice.breakdown.map((item, idx) => (
                    <tr key={idx} className="border-b border-border last:border-0">
                      <td className="px-3 py-2 text-muted-foreground">{item.label}</td>
                      <td className="px-3 py-2 text-right font-medium">EGP {item.amount.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-muted/50 font-semibold">
                    <td className="px-3 py-2">Total</td>
                    <td className="px-3 py-2 text-right">EGP {invoice.amount.toLocaleString()}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Download PDF
            </Button>
            {invoice.status !== "Paid" && (
              <>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Send className="h-3.5 w-3.5" /> Send Reminder
                </Button>
                <Button size="sm" className="gap-1.5" onClick={() => toast.success("Invoice marked as paid")}>
                  <CheckCircle2 className="h-3.5 w-3.5" /> Mark Paid
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Contracts Tab ────────────────────────────────────────────────────────────

function ContractsTab() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const filtered = contracts.filter((c) => {
    const matchesSearch = c.merchant.toLowerCase().includes(search.toLowerCase()) || c.id.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || c.status.toLowerCase() === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = [
    { label: "Total", value: 34, icon: FileText, color: "text-primary" },
    { label: "Active", value: 28, icon: CheckCircle2, color: "text-emerald-600" },
    { label: "Expiring Soon", value: 3, icon: AlertTriangle, color: "text-amber-500" },
    { label: "Expired", value: 3, icon: XCircle, color: "text-red-500" },
  ];

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="stat-card">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground">{s.label}</span>
              <s.icon className={`h-4 w-4 ${s.color}`} />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-1">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input placeholder="Search contracts..." className="pl-8 h-8 text-sm" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 w-36 text-xs">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="expiring">Expiring</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button size="sm" className="gap-1.5 h-8">
          <Plus className="h-3.5 w-3.5" /> New Contract
        </Button>
      </div>

      {/* Table */}
      <div className="p2p-card overflow-hidden p-0">
        <Table className="p2p-table">
          <TableHeader>
            <TableRow>
              <TableHead>Contract ID</TableHead>
              <TableHead>Merchant</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Start Date</TableHead>
              <TableHead>End Date</TableHead>
              <TableHead className="text-right">Value (EGP)</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-mono text-xs font-medium text-primary">{c.id}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="text-sm font-medium">{c.merchant}</span>
                  </div>
                </TableCell>
                <TableCell><span className="badge-info">{c.type}</span></TableCell>
                <TableCell className="text-sm text-muted-foreground">{c.startDate}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{c.endDate}</TableCell>
                <TableCell className="text-right text-sm font-medium">{c.value.toLocaleString()}</TableCell>
                <TableCell><StatusBadge status={c.status} /></TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={() => { setSelectedContract(c); setDetailOpen(true); }}>
                      <Eye className="h-3 w-3" /> View
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={() => toast.success("Downloading PDF…")}>
                      <Download className="h-3 w-3" />
                    </Button>
                    {c.status !== "Active" && (
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1 text-amber-600 hover:text-amber-700" onClick={() => toast.info("Opening renewal wizard…")}>
                        <RefreshCw className="h-3 w-3" /> Renew
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <ContractDetailModal contract={selectedContract} open={detailOpen} onClose={() => setDetailOpen(false)} />
    </div>
  );
}

// ─── Invoices Tab ─────────────────────────────────────────────────────────────

function InvoicesTab() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const filtered = invoices.filter((inv) => {
    const matchesSearch = inv.merchant.toLowerCase().includes(search.toLowerCase()) || inv.id.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || inv.status.toLowerCase() === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = [
    { label: "Total", value: 156, icon: FileText, color: "text-primary" },
    { label: "Paid", value: 142, icon: CheckCircle2, color: "text-emerald-600" },
    { label: "Outstanding", value: 10, icon: Clock, color: "text-blue-500" },
    { label: "Overdue", value: 4, icon: AlertTriangle, color: "text-red-500" },
  ];

  const totalCurrentMonth = currentMonthBreakdown.reduce((acc, r) => acc + r.totalEGP, 0);

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="stat-card">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground">{s.label}</span>
              <s.icon className={`h-4 w-4 ${s.color}`} />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-2 flex-1">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input placeholder="Search invoices..." className="pl-8 h-8 text-sm" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 w-36 text-xs">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="outstanding">Outstanding</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="gap-1.5 h-8">
            <Download className="h-3.5 w-3.5" /> Export
          </Button>
          <Button size="sm" className="gap-1.5 h-8">
            <Plus className="h-3.5 w-3.5" /> New Invoice
          </Button>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="p2p-card overflow-hidden p-0">
        <Table className="p2p-table">
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Merchant</TableHead>
              <TableHead className="text-right">Amount (EGP)</TableHead>
              <TableHead>Period</TableHead>
              <TableHead>Issued</TableHead>
              <TableHead>Due</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((inv) => (
              <TableRow key={inv.id}>
                <TableCell className="font-mono text-xs font-medium text-primary">{inv.id}</TableCell>
                <TableCell className="text-sm font-medium">{inv.merchant}</TableCell>
                <TableCell className="text-right text-sm font-semibold">{inv.amount.toLocaleString()}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{inv.period}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{inv.issued}</TableCell>
                <TableCell className={`text-sm font-medium ${inv.status === "Overdue" ? "text-red-600" : "text-muted-foreground"}`}>{inv.due}</TableCell>
                <TableCell><StatusBadge status={inv.status} /></TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={() => { setSelectedInvoice(inv); setDetailOpen(true); }}>
                      <Eye className="h-3 w-3" /> View
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => toast.success("Downloading PDF…")}>
                      <Download className="h-3 w-3" />
                    </Button>
                    {inv.status !== "Paid" && (
                      <>
                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1 text-emerald-600 hover:text-emerald-700" onClick={() => toast.success("Invoice marked as paid")}>
                          <CheckCircle2 className="h-3 w-3" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1 text-blue-600 hover:text-blue-700" onClick={() => toast.info("Reminder sent")}>
                          <Send className="h-3 w-3" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Current Month Billing Summary */}
      <div className="p2p-card p-5">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold">Current Month Billing Summary — October 2024</h3>
        </div>
        <div className="space-y-3">
          {currentMonthBreakdown.map((row) => {
            const pct = Math.round((row.totalEGP / totalCurrentMonth) * 100);
            return (
              <div key={row.feeType} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{row.feeType}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-muted-foreground">{row.invoices} invoices</span>
                    <span className="font-semibold text-foreground w-28 text-right">EGP {row.totalEGP.toLocaleString()}</span>
                  </div>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full bg-primary/70" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
          <div className="pt-2 border-t border-border flex items-center justify-between text-sm font-semibold">
            <span>Total</span>
            <span>EGP {totalCurrentMonth.toLocaleString()}</span>
          </div>
        </div>
      </div>

      <InvoiceDetailModal invoice={selectedInvoice} open={detailOpen} onClose={() => setDetailOpen(false)} />
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function ContractsInvoicesPage() {
  return (
    <DashboardLayout title="Contracts & Invoices">
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="section-title">Contracts & Invoices</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Manage merchant agreements and billing documentation</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1.5 h-8">
              <Download className="h-3.5 w-3.5" /> Export All
            </Button>
          </div>
        </div>

        <Tabs defaultValue="contracts">
          <TabsList className="h-9">
            <TabsTrigger value="contracts" className="text-xs gap-1.5">
              <FileText className="h-3.5 w-3.5" /> Contracts
            </TabsTrigger>
            <TabsTrigger value="invoices" className="text-xs gap-1.5">
              <DollarSign className="h-3.5 w-3.5" /> Invoices
            </TabsTrigger>
          </TabsList>

          <TabsContent value="contracts" className="mt-5">
            <ContractsTab />
          </TabsContent>

          <TabsContent value="invoices" className="mt-5">
            <InvoicesTab />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
