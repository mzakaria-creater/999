Add a new advanced module to the existing p2p platform called:

Interactive Decision Flow Visualizer

Purpose:
Create a visual, interactive transaction approval flow viewer for admins and operations teams. It should display how each transaction moves through decision logic from webhook reception to final approval, manual review, routing, or rejection.

Core features:

1) Visual Flow Diagram
Build a node-based decision flow interface showing the transaction path in real time.

Main nodes:
- Webhook Input: receives transaction payload
- Issuer Check: determines payment issuer / payment method
- Wallet Flow: routes to Vodafone Cash / Etisalat Cash / Orange Cash / Bank Transfer / USDT / other configured methods
- Merchant / Group Rules Check
- Limits Check
- Duplicate Check
- Risk Scoring
- Auto Approval Decision
- Manual Review Queue
- Approved
- Declined
- Expired
- Settlement Queue

2) Interactive Behavior
- Each node must be clickable
- Clicking a node opens a side panel or modal showing:
  - node name
  - rule description
  - input values
  - output values
  - matched condition
  - timestamp
  - triggered action
  - related transaction ID
- Show animated transaction path through the flow
- Highlight successful path in green
- Highlight warning/manual review path in orange
- Highlight blocked/declined path in red
- Allow replay of transaction decision path

3) Webhook Input Node
- Display incoming webhook data structure
- Show merchant ID, group ID, amount, currency, phone/account, payment method, reference, callback URLs, risk metadata, and raw webhook payload
- Include payload validation status
- Show whether webhook signature/hash was valid

4) Issuer Check Node
- Route based on selected or detected payment method
- Show which issuer was chosen:
  - Vodafone Cash
  - Etisalat Cash
  - Orange Cash
  - InstaPay
  - Bank Transfer
  - USDT
  - Other custom methods
- Show routing reason and fallback logic if issuer unavailable

5) Wallet Flow Logic
- Visual branches for each wallet/payment path
- Show selected wallet/account and why it was chosen
- Include:
  - available capacity
  - daily/monthly usage
  - group assignment
  - merchant compatibility
  - priority score
  - failover route
- If no wallet available, route to exception/manual review

6) Rule Engine Nodes
Add logic nodes for:
- Merchant active/inactive check
- Group permissions check
- Amount min/max check
- Daily/monthly wallet limits
- Duplicate transaction detection
- Velocity check
- Blacklist / blocklist check
- Device/IP mismatch check
- Geo mismatch
- Customer behavior anomaly
- Fee / pricing rule match
- Settlement eligibility
Each rule node should show pass/fail result and rule explanation.

7) AI Risk Layer
- Add AI risk score node
- Score from 0 to 100
- Show explainable factors:
  - unusual amount
  - repeated attempts
  - suspicious device
  - issuer mismatch
  - merchant history
  - customer history
  - blacklist hit
- Based on score:
  - low risk => auto approve
  - medium risk => manual review
  - high risk => auto decline or block

8) Simulation Mode
Allow users to simulate transaction scenarios:
- choose merchant
- choose company group
- choose payment method
- enter amount
- choose wallet availability mode
- set risk conditions
- run simulation
Then visually display the full decision path and final outcome.

9) Live Mode + Historical Mode
- Live mode: new incoming transactions animate through the flow
- Historical mode: open any existing transaction and inspect the exact decision path it followed
- Provide filtering by:
  - merchant
  - group
  - payment method
  - amount range
  - status
  - risk level
  - date/time

10) Reports & Auditability
- Save decision traces for every transaction
- Show audit log entries for every node transition
- Export decision trace as:
  - PDF
  - CSV
  - JSON
- Include flow summary:
  - transaction ID
  - final decision
  - total processing time
  - node count
  - decision reason
  - reviewer if manual intervention happened

11) Admin Configuration
Add a Decision Rules Manager where admins can:
- enable/disable rules
- reorder some checks
- configure thresholds
- define wallet priority
- define fallback routes
- define auto-approval thresholds
- define group-specific logic
- define issuer-specific logic

12) UI/UX Requirements
- Must match the existing premium dark purple futuristic fintech style
- Use glassmorphism cards, glowing connectors, elegant node graph UI
- Arabic/English bilingual support
- Full RTL/LTR support
- Responsive on desktop/tablet
- Node graph should look polished and enterprise-grade
- Right panel for node details
- Top filters and transaction selector
- Mini-map for large flow diagrams
- Zoom in / zoom out / fit to screen controls

13) Suggested pages inside this module
- Flow Overview
- Live Decision Monitor
- Transaction Replay
- Rule Manager
- Simulation Lab
- Decision Audit Logs

14) Data model additions
Create backend structures for:
- decision_flows
- decision_nodes
- decision_edges
- transaction_decision_traces
- rule_evaluations
- simulation_runs
- flow_templates
- flow_versions
- audit_events

15) Demo data
Seed realistic demo data with transactions flowing through:
- approved paths
- manual review paths
- declined paths
- wallet unavailable paths
- risk-triggered paths
- issuer fallback paths

This module should feel like a real operational control center for intelligent payment approvals and wallet routing, not just a static diagram.