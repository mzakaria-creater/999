import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Fawry endpoints
const FAWRY_BASE_URL = "https://atfawry.fawrystaging.com"; // staging
// const FAWRY_BASE_URL = "https://www.atfawry.com"; // production

const CHARGE_ENDPOINT = "/ECommerceWeb/Fawry/payments/charge";
const STATUS_ENDPOINT = "/ECommerceWeb/Fawry/payments/status/v2";

async function sha256(message: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const MERCHANT_CODE = Deno.env.get("FAWRY_MERCHANT_ID");
  const SECRET_KEY = Deno.env.get("FAWRY_SECRET_KEY");

  if (!MERCHANT_CODE || !SECRET_KEY) {
    return new Response(
      JSON.stringify({ error: "Fawry credentials not configured" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const { action, ...body } = await req.json();

    // ── ACTION: create ──────────────────────────────────────────
    // Creates a Fawry pay-at-Fawry reference number
    if (action === "create") {
      const {
        merchant_ref_num,
        amount,
        customer_name,
        customer_phone,
        customer_email,
        description,
        merchant_id,        // internal merchant UUID
        merchant_name,      // internal merchant name
      } = body;

      if (!amount) {
        return new Response(
          JSON.stringify({ error: "amount is required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // If merchant_id provided, look up their fawry_merchant_ref from DB
      let effectiveMerchantRef = merchant_ref_num;
      if (!effectiveMerchantRef && merchant_id) {
        const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
        const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        const sb = createClient(supabaseUrl, supabaseKey);
        const { data: merchant } = await sb
          .from("merchants")
          .select("fawry_merchant_ref")
          .eq("id", merchant_id)
          .single();
        if (merchant?.fawry_merchant_ref) {
          effectiveMerchantRef = merchant.fawry_merchant_ref;
        }
      }

      // Auto-generate if still missing
      if (!effectiveMerchantRef) {
        effectiveMerchantRef = `FWR-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      }

      const amountFormatted = Number(amount).toFixed(2);
      const customerProfileId = customer_phone || "";

      // Signature = SHA256(merchantCode + merchantRefNum + customerProfileId + paymentMethod + amount + secureKey)
      const signatureRaw = `${MERCHANT_CODE}${effectiveMerchantRef}${customerProfileId}PAYATFAWRY${amountFormatted}${SECRET_KEY}`;
      const signature = await sha256(signatureRaw);

      const chargeRequest = {
        merchantCode: MERCHANT_CODE,
        merchantRefNum: effectiveMerchantRef,
        customerName: customer_name || "Customer",
        customerMobile: customer_phone || "",
        customerEmail: customer_email || "",
        customerProfileId: customerProfileId,
        amount: Number(amountFormatted),
        currencyCode: "EGP",
        language: "en-gb",
        chargeItems: [
          {
            itemId: effectiveMerchantRef,
            description: description || "Payment",
            price: Number(amountFormatted),
            quantity: 1,
          },
        ],
        paymentMethod: "PAYATFAWRY",
        description: description || "Payment",
        signature,
      };

      console.log("Fawry charge request:", JSON.stringify(chargeRequest));

      const fawryRes = await fetch(`${FAWRY_BASE_URL}${CHARGE_ENDPOINT}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(chargeRequest),
      });

      const fawryData = await fawryRes.json();
      console.log("Fawry charge response:", JSON.stringify(fawryData));

      if (fawryData.statusCode !== 200) {
        return new Response(
          JSON.stringify({
            error: fawryData.statusDescription || "Fawry charge failed",
            fawry_status: fawryData.statusCode,
            details: fawryData,
          }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Save transaction in DB
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      const { data: txn, error: txnErr } = await supabase
        .from("transactions")
        .insert({
          transaction_id: effectiveMerchantRef,
          amount: Number(amountFormatted),
          type: "PAY_IN",
          method: "FAWRY",
          status: "PENDING",
          currency: "EGP",
          fee: 0,
          net_amount: Number(amountFormatted),
          customer_phone: customer_phone || null,
          customer_name: customer_name || null,
          customer_email: customer_email || null,
          merchant_id: merchant_id || null,
          merchant_name: merchant_name || "Fawry Pay-In",
          description: description || `Fawry reference: ${fawryData.referenceNumber}`,
        })
        .select()
        .single();

      if (txnErr) {
        console.error("DB insert error:", txnErr.message);
      }

      return new Response(
        JSON.stringify({
          success: true,
          reference_number: fawryData.referenceNumber,
          merchant_ref_num: effectiveMerchantRef,
          expiry_date: fawryData.expirationDate,
          amount: Number(amountFormatted),
          status: fawryData.statusDescription,
          transaction_id: txn?.id || null,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ── ACTION: status ──────────────────────────────────────────
    // Checks the payment status of a Fawry reference
    if (action === "status") {
      const { merchant_ref_num } = body;

      if (!merchant_ref_num) {
        return new Response(
          JSON.stringify({ error: "merchant_ref_num is required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Signature = SHA256(merchantCode + merchantRefNum + secureKey)
      const signatureRaw = `${MERCHANT_CODE}${merchant_ref_num}${SECRET_KEY}`;
      const signature = await sha256(signatureRaw);

      const statusUrl = `${FAWRY_BASE_URL}${STATUS_ENDPOINT}?merchantCode=${encodeURIComponent(MERCHANT_CODE)}&merchantRefNumber=${encodeURIComponent(merchant_ref_num)}&signature=${signature}`;

      const fawryRes = await fetch(statusUrl);
      const fawryData = await fawryRes.json();
      console.log("Fawry status response:", JSON.stringify(fawryData));

      // Update transaction status in DB if paid
      if (fawryData.paymentStatus === "PAID") {
        const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
        const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        const supabase = createClient(supabaseUrl, supabaseKey);

        await supabase
          .from("transactions")
          .update({ status: "COMPLETED" })
          .eq("transaction_id", merchant_ref_num);
      }

      return new Response(
        JSON.stringify({
          success: true,
          payment_status: fawryData.paymentStatus,
          reference_number: fawryData.referenceNumber,
          payment_amount: fawryData.paymentAmount,
          payment_method: fawryData.paymentMethod,
          fawry_fees: fawryData.fawryFees,
          status_code: fawryData.statusCode,
          status_description: fawryData.statusDescription,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action. Use "create" or "status".' }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: unknown) {
    console.error("Fawry edge function error:", err);
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
