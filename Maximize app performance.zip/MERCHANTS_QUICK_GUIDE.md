# 🏪 Merchants Page - Quick Reference

## 🚀 **In 3 Minutes**

Your OnTarget PSP now has a **full-featured Merchants management system**!

---

## 📍 **Navigation**

```
/merchants          → Merchant list
/merchants/:id      → Merchant detail page
```

---

## 🎯 **Main Features**

### **1. Merchant List** (`/merchants`)
```
┌─────────────────────────────────────────┐
│  Search Bar                             │
├─────────────────────────────────────────┤
│  MCH-1001 │ TechStore  │ Active │ $145k │
│  MCH-1002 │ FashionHub │ Active │ $89k  │
│  MCH-1003 │ GadgetWorld│ Active │ $234k │
└─────────────────────────────────────────┘
```

**Features:**
- ✅ Search by name, ID, email
- ✅ Status badges (Active/Inactive/Suspended)
- ✅ Volume & transaction counts
- ✅ Create new merchant button

---

### **2. Merchant Detail** (`/merchants/MCH-1001`)

#### **4 Tabs:**

**📋 Overview**
- Business information
- Contact details
- Tier information
- Edit mode

**🔑 API Keys**
- Generate new keys
- Show/hide keys
- Copy to clipboard
- Revoke keys
- Permission management

**💳 Payment Methods**
- Credit/Debit Cards
- Bank Transfer
- Digital Wallets
- Cryptocurrency
- Enable/disable toggle

**⚙️ Checkout Config**
- URLs (redirect, webhook, success, cancel)
- Theme (Light/Dark/Auto)
- Language (EN/AR/ES/FR)
- Currencies (USD/EUR/GBP)

---

## 👑 **Tier System**

| Tier | Monthly Volume | Fee | Monthly Cost |
|------|---------------|-----|--------------|
| ⚡ Starter | $10k | 2.9% | Free |
| 📈 Growth | $50k | 2.5% | $49 |
| ⭐ Professional | $200k | 2.2% | $199 |
| 👑 Enterprise | Unlimited | 1.9% | $499 |

**Change Tier:**
1. Click tier badge in header
2. Select new tier
3. Confirm change

---

## 🔑 **API Key Workflow**

### **Generate New Key**
```
1. Go to "API Keys" tab
2. Click "Generate New Key"
3. Enter key name
4. Select permissions (read/write/delete)
5. Click "Generate Key"
6. Copy key immediately (won't show again!)
```

### **Key Actions**
- 👁️ Show/Hide - Toggle visibility
- 📋 Copy - Copy to clipboard
- 🔒 Revoke - Permanently disable

---

## 💳 **Payment Methods**

### **4 Types Available:**

#### **1. Credit/Debit Cards**
- Visa, Mastercard, Amex
- Status: Toggle to enable/disable

#### **2. Bank Transfer**
- Processing: 2 days
- Banks: Chase, BofA, Wells Fargo

#### **3. Digital Wallets**
- Apple Pay, Google Pay, PayPal

#### **4. Cryptocurrency**
- BTC, ETH, USDT
- Status: Disabled by default

---

## ⚙️ **Checkout Configuration**

### **Required URLs:**
```
Redirect URL:  Where to send after payment
Webhook URL:   Where to receive payment events
Success URL:   Where to redirect on success
Cancel URL:    Where to redirect on cancel
```

### **Appearance:**
- **Theme:** Light, Dark, or Auto
- **Language:** EN, AR, ES, FR
- **Currency:** USD, EUR, GBP

---

## 🎨 **Status Badges**

### **Merchant Status**
- 🟢 **Active** - Processing payments
- 🟡 **Inactive** - Temporarily disabled
- 🔴 **Suspended** - Account suspended

### **API Key Status**
- 🟢 **Active** - Can be used
- 🟡 **Inactive** - Temporarily disabled
- 🔴 **Revoked** - Permanently disabled

---

## ⚡ **Quick Actions**

### **From Merchant List:**
```
[⋮ Actions] → View Details
           → Edit Merchant
           → Suspend Account
           → Delete Merchant
```

### **From Merchant Detail:**
```
[Edit] → Edit business info
[Tier] → Change tier
[Save] → Save changes
[Back] → Return to list
```

---

## 📊 **Summary Cards**

### **Merchant List Page:**
```
┌─────────────────────────────────────────┐
│  [6] Total    [5] Active                │
│  [$555k] Volume   [4,390] Transactions  │
└─────────────────────────────────────────┘
```

### **Merchant Detail Page:**
```
┌─────────────────────────────────────────┐
│  [$145k] Monthly   [1,247] Trans        │
│  [2.2%] Fee        [3/4] Methods        │
└─────────────────────────────────────────┘
```

---

## 🎯 **Common Tasks**

### **Create New Merchant**
1. Click "Create Merchant" button
2. Enter business details
3. Select payment methods
4. Click "Create Merchant"

### **Edit Merchant Profile**
1. Open merchant detail
2. Click "Edit" button
3. Modify information
4. Click "Save"

### **Generate API Key**
1. Go to "API Keys" tab
2. Click "Generate New Key"
3. Set name and permissions
4. Copy generated key

### **Enable Payment Method**
1. Go to "Payment Methods" tab
2. Find the method
3. Click unlock icon
4. Method instantly enabled

### **Configure Checkout**
1. Go to "Checkout Config" tab
2. Enter all URLs
3. Select theme and language
4. Click "Save Configuration"

---

## 💫 **Visual Features**

### **Glassmorphic Design**
- Translucent cards
- Backdrop blur effects
- Subtle borders
- Smooth shadows

### **Animations**
- Page transitions
- Tab switching
- Button hover effects
- Modal slide-ins
- Toast notifications

### **Color Coding**
- 🟣 Violet - Primary actions
- 🟢 Green - Success/Active
- 🔴 Red - Danger/Suspended
- 🟡 Yellow/Gold - Enterprise tier
- ⚪ Gray - Inactive

---

## 🔍 **Search & Filter**

### **Search Bar**
```
Type to search by:
  - Merchant name
  - Merchant ID
  - Email address
```

**Real-time results** - Updates as you type!

---

## ✅ **All Features At a Glance**

| Feature | Location | Action |
|---------|----------|--------|
| View merchants | `/merchants` | Browse table |
| Create merchant | List page | Click button |
| View details | Click merchant | See all info |
| Edit profile | Detail page | Click Edit |
| Change tier | Detail header | Click tier badge |
| Generate API key | API Keys tab | Click button |
| Enable payment | Payment tab | Toggle lock icon |
| Configure checkout | Checkout tab | Enter URLs |
| Search merchants | List page | Type in search |
| View stats | Both pages | See summary cards |

---

## 🎉 **You're Ready!**

The Merchants page is **fully functional** with:

✅ Complete merchant management  
✅ 4-tier system  
✅ API key generation  
✅ Payment method config  
✅ Checkout setup  
✅ Professional design  
✅ Smooth animations  

**Start managing merchants now!** 🚀

---

**Built for OnTarget PSP**  
*Professional Merchant Management · 2026*
