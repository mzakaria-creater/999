# 📱 OnTarget PSP - Mobile Themes System

## ✅ What's Implemented

### 🎨 8 Premium Mobile Themes

1. **Dark Mode** (Default)
   - Classic dark theme with violet-blue gradients
   - Perfect for night use

2. **Light Mode**
   - Clean white interface
   - Optimized for daytime viewing

3. **Violet Dark**
   - Deep purple aesthetic
   - Mystical and elegant

4. **Blue Dark**
   - Ocean-inspired blues
   - Professional and calm

5. **Mint Dark**
   - Fresh emerald tones
   - Nature-inspired design

6. **Amber Dark**
   - Warm golden hues
   - Cozy and inviting

7. **Cyber Dark**
   - Futuristic cyan accents
   - Tech-forward appearance

8. **Neon Dark**
   - Vibrant pink highlights
   - Bold and energetic

## 🚀 Features

### ✨ Responsive Layout
- Automatically switches to mobile view on screens < 768px
- Desktop layout for larger screens
- Seamless navigation between modes

### 🎯 Auto-Routing
- When detected as mobile, auto-redirects to mobile routes:
  - `/` → `/mobile/dashboard`
  - `/transactions` → `/mobile/transactions`
  - `/wallets` → `/mobile/wallets`
  - `/merchants` → `/mobile/merchants`

### 📄 Mobile Pages
1. **Dashboard** (`/mobile/dashboard`)
2. **Transactions Center** (`/mobile/transactions`)
   - Stats cards (Total, Completed, Pending, Failed, Review, Volume)
   - Country flags integration
   - Search & filter capabilities
   - Transaction selection with checkboxes
3. **Transaction Details** (`/mobile/transactions/:id`)
   - Full transaction information
   - Proof of payment viewer
   - Audit trail
   - Customer profile link
4. **Customer Profile** (`/mobile/customers/:id`)
   - Customer information
   - Payment history
   - Linked merchants
5. **Wallets** (`/mobile/wallets`)
6. **Merchants** (`/mobile/merchants`)
7. **Settings** (`/mobile/settings`) 🆕
   - Theme selector with preview
   - Language switcher (EN/AR)
   - Account & security options
   - Notification preferences

### 🌍 Full RTL Support
- Arabic language with proper RTL layout
- Mirrored icons and navigation
- Culturally appropriate design

### 💾 Theme Persistence
- Selected theme saved to localStorage
- Persists across sessions
- Instant theme switching

## 🎯 How to Use

### Accessing Mobile View

1. **Automatic (Recommended)**
   - Open app on mobile device or resize browser < 768px
   - Will auto-redirect to `/mobile/dashboard`

2. **Manual**
   - Navigate to `/mobile/transactions` directly
   - Or use `/mobile-view` for landing page

### Changing Theme

1. Go to Settings (`/mobile/settings`)
2. Tap on "App Theme" section
3. Browse 8 available themes
4. Tap to select - changes instantly!
5. Theme is saved automatically

### Changing Language

1. Go to Settings (`/mobile/settings`)
2. Tap English or العربية
3. Entire app switches language with RTL support

## 🏗️ Technical Architecture

### Context Providers
```
App
├── LanguageProvider (EN/AR + RTL)
├── MobileThemeProvider (8 themes)
└── RoleProvider (User roles)
```

### Theme System
- `MobileThemeContext` - Central theme management
- `useMobileTheme()` hook - Access theme anywhere
- Dynamic class generation
- CSS-in-JS for gradient backgrounds

### Routing
- `ResponsiveLayout` - Detects screen size
- Auto-switches between `Layout` (desktop) and `MobileAppLayout` (mobile)
- Nested routes for mobile pages

## 📊 Mobile Pages Structure

```
/mobile
├── /dashboard - Home dashboard
├── /transactions - Transactions center
│   └── /:id - Transaction details
├── /customers/:id - Customer profile
├── /wallets - Wallet management
├── /merchants - Merchant list
└── /settings - App settings & themes
```

## 🎨 Theme Configuration

Each theme includes:
- Background gradients
- Card backgrounds
- Border colors
- Primary gradient colors
- Accent colors
- Text colors (primary/secondary)
- Status bar color
- Navigation background

## 🔧 Development

### Adding New Theme

1. Edit `/src/app/context/MobileThemeContext.tsx`
2. Add new theme to `MobileTheme` type
3. Add configuration to `themeConfigs`
4. Theme will automatically appear in Settings

### Customizing Existing Theme

1. Locate theme in `themeConfigs`
2. Modify colors/gradients
3. Changes reflect immediately

## 📱 UI Components

- `MobileAppLayout` - Main mobile shell
- `MobileStatusBar` - iOS-style status bar
- `FxRateBar` - Currency exchange rates
- `MobileAppCard` - Themed card component
- `MobileBottomNav` - Bottom navigation

## 🌟 Design Features

- Glassmorphic UI with backdrop blur
- Smooth animations with Motion
- Pull-to-refresh ready
- Touch-optimized interactions
- Safe area insets for notched devices
- Bottom navigation with active indicators

## 📝 Notes

- All themes are dark-based except "Light Mode"
- Themes work seamlessly with RTL
- Theme preference syncs across tabs
- Responsive design works on all mobile devices
- Optimized for iOS and Android

---

**Ready to use!** Just resize your browser or open on mobile device! 🎉
