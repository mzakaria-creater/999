# ⚡ دليل البدء السريع - OnTarget PSP

<div dir="rtl">

## 🚀 البدء في 3 دقائق

### 1. التثبيت

```bash
# استنساخ المشروع (أو download ZIP)
git clone https://github.com/username/ontarget-psp.git
cd ontarget-psp

# تثبيت المكتبات (اختر واحدة)
pnpm install    # موصى به ✅
# أو
npm install
# أو
yarn install
```

### 2. إعداد Environment Variables

```bash
# نسخ ملف المثال
cp .env.local.example .env.local

# تحرير الملف وإضافة المفاتيح
nano .env.local
# أو
code .env.local
```

**الحد الأدنى المطلوب:**
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3. تشغيل المشروع

```bash
pnpm dev
```

افتح [http://localhost:3000](http://localhost:3000) 🎉

---

## 📱 الوصول للصفحات

### Desktop View:
- **الرئيسية:** [http://localhost:3000](http://localhost:3000)
- **Dashboard:** [http://localhost:3000/dashboard](http://localhost:3000/dashboard)
- **Transactions:** [http://localhost:3000/transactions](http://localhost:3000/transactions)
- **Merchants:** [http://localhost:3000/merchants](http://localhost:3000/merchants)

### Mobile View:
- **Mobile Dashboard:** [http://localhost:3000/mobile/dashboard](http://localhost:3000/mobile/dashboard)
- **Mobile Transactions:** [http://localhost:3000/mobile/transactions](http://localhost:3000/mobile/transactions)

---

## 🎯 ميزات سريعة

### تبديل اللغة:
- زر اللغة في الـ Sidebar (عربي/English)

### تبديل الدور:
- زر Role Switcher في الـ Header
- 6 أدوار: Super Admin, Admin, Manager, Operator, Support, Viewer

### تبديل الثيم (Mobile):
- الإعدادات → Mobile Theme
- iOS Classic / iOS Dark / Android Material

---

## 🔧 أوامر مفيدة

```bash
# Development
pnpm dev              # تشغيل Development server
pnpm dev --turbo      # تشغيل مع Turbopack (أسرع)

# Production
pnpm build            # بناء للـ Production
pnpm start            # تشغيل Production server

# Quality
pnpm lint             # فحص الكود
pnpm check-env        # فحص Environment variables

# Clean
rm -rf .next          # حذف build cache
rm -rf node_modules   # حذف dependencies
pnpm install          # إعادة التثبيت
```

---

## 🐛 حل المشاكل السريع

### المشكلة: Port 3000 مشغول

```bash
# تشغيل على port آخر
pnpm dev -p 3001

# أو إيقاف العملية المشغلة
lsof -ti:3000 | xargs kill -9  # Mac/Linux
netstat -ano | findstr :3000   # Windows
```

### المشكلة: Environment Variables لا تعمل

```bash
# تأكد من:
1. الملف اسمه .env.local (وليس .env)
2. المتغيرات تبدأ بـ NEXT_PUBLIC_ للـ client
3. أعد تشغيل dev server بعد التغيير

# أعد التشغيل
Ctrl+C
pnpm dev
```

### المشكلة: Build Errors

```bash
# نظف وأعد البناء
rm -rf .next
rm -rf node_modules
pnpm install
pnpm build
```

### المشكلة: CSS لا يعمل

```bash
# تحقق من Tailwind config
# الملفات يجب أن تكون موجودة:
- tailwind.config.js
- postcss.config.js
- app/layout.tsx يستورد CSS
```

---

## 📂 الملفات المهمة

```
ontarget-psp/
├── app/                    # Next.js App Router
│   ├── layout.tsx         # Root layout (ابدأ هنا)
│   ├── page.tsx           # الصفحة الرئيسية
│   ├── (main)/            # صفحات الـ Desktop
│   └── mobile/            # صفحات الـ Mobile
├── src/
│   ├── app/
│   │   ├── components/    # مكونات React
│   │   ├── pages/         # Page components
│   │   └── context/       # Context providers
│   └── styles/            # ملفات CSS
├── .env.local             # Environment variables (أنشئها)
├── next.config.js         # إعدادات Next.js
└── package.json           # Dependencies
```

---

## 🎨 تخصيص سريع

### تغيير اللون الرئيسي:

```css
/* src/styles/theme.css */
:root {
  --primary: 238.7 83.5 66.7%;  /* الحالي: Indigo */
  
  /* جرب:
  --primary: 221.2 83.2 53.3%;  Blue
  --primary: 262.1 83.3 57.8%;  Purple
  --primary: 142.1 76.2 36.3%;  Green
  */
}
```

### تغيير الخط:

```tsx
// app/layout.tsx
import { Cairo } from 'next/font/google';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  display: 'swap',
});
```

### تغيير اللغة الافتراضية:

```js
// next.config.js
i18n: {
  defaultLocale: 'en',  // غيّر من 'ar' إلى 'en'
}
```

---

## 📦 إضافة صفحة جديدة

### 1. إنشاء Page Component:

```tsx
// src/app/pages/MyNewPage.tsx
export function MyNewPage() {
  return (
    <div>
      <h1>صفحتي الجديدة</h1>
    </div>
  );
}
```

### 2. إنشاء Next.js Route:

```tsx
// app/(main)/my-new-page/page.tsx
'use client';

import { MyNewPage } from '@/app/pages/MyNewPage';

export default function MyNewPageRoute() {
  return <MyNewPage />;
}
```

### 3. إضافة Link في Sidebar:

```tsx
// src/app/components/Sidebar.tsx
{
  icon: Plus,
  label_ar: 'صفحتي الجديدة',
  label_en: 'My New Page',
  path: '/my-new-page',
}
```

---

## 🌐 النشر السريع على Vercel

### الطريقة 1: عبر الموقع (الأسهل)

1. Push المشروع على GitHub
2. اذهب إلى [vercel.com](https://vercel.com)
3. "New Project" → اختر Repository
4. أضف Environment Variables
5. Deploy! ✅

### الطريقة 2: عبر CLI

```bash
# تثبيت Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Production Deploy
vercel --prod
```

---

## 🎓 تعلم المزيد

### الوثائق:
- [Next.js Docs](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Supabase Docs](https://supabase.com/docs)

### الأدلة في المشروع:
- `README.md` - نظرة شاملة
- `DEPLOYMENT_GUIDE.md` - دليل النشر الكامل
- `NEXTJS_MIGRATION_GUIDE.md` - تفاصيل التحويل

---

## 💡 نصائح سريعة

### 🔥 Hot Tips:

1. **استخدم Turbopack للسرعة:**
   ```bash
   pnpm dev --turbo
   ```

2. **افتح DevTools:**
   - `F12` أو `Cmd/Ctrl + Shift + I`
   - شاهد Console للأخطاء

3. **راقب التغييرات:**
   - Fast Refresh تلقائي
   - لا حاجة لإعادة التشغيل

4. **استخدم TypeScript:**
   - Autocomplete ممتاز
   - اكتب `.ts` بدل `.js`

5. **استخدم ESLint:**
   ```bash
   pnpm lint
   ```

---

## ✅ Checklist البداية

- [ ] تثبيت Dependencies
- [ ] نسخ .env.local.example
- [ ] إضافة Supabase keys
- [ ] تشغيل `pnpm dev`
- [ ] فتح http://localhost:3000
- [ ] استكشاف الصفحات
- [ ] تجربة Mobile view
- [ ] تبديل اللغة والدور
- [ ] قراءة README.md

---

## 🆘 المساعدة

### إذا واجهت مشكلة:

1. ✅ تحقق من Console في المتصفح
2. ✅ تحقق من Terminal للأخطاء
3. ✅ اقرأ error message بعناية
4. ✅ ابحث في Documentation
5. ✅ راجع DEPLOYMENT_GUIDE.md

### Logs مفيدة:

```bash
# شاهد Build logs
pnpm build 2>&1 | tee build.log

# شاهد Dev logs
pnpm dev 2>&1 | tee dev.log
```

---

## 🎉 جاهز للانطلاق!

الآن أنت جاهز لاستخدام OnTarget PSP! 🚀

**Next Steps:**
1. استكشف الصفحات المختلفة
2. جرب Mobile view
3. اقرأ الوثائق
4. ابدأ التطوير!

---

**بُني بـ ❤️ باستخدام Next.js و Tailwind CSS**

**Version:** 2.6.0  
**Last Updated:** March 22, 2026

</div>
