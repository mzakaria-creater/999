'use client';

import { BinancePage } from '@/app/pages/BinancePage';

export default function BinancePageRoute() {
  return <BinancePage />;
}
