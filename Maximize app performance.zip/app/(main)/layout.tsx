'use client';

import { Providers } from '../providers';
import { Layout } from '@/app/components/Layout';

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Providers>
      <Layout>
        {children}
      </Layout>
    </Providers>
  );
}
