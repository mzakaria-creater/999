'use client';

import { PaymentPages } from '@/app/pages/PaymentPages';

export default function PaymentPagesPage() {
  return <PaymentPages />;
}
