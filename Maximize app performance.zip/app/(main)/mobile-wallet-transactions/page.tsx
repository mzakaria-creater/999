'use client';

import { MobileWalletTransactions } from '@/app/pages/MobileWalletTransactions';

export default function MobileWalletTransactionsPage() {
  return <MobileWalletTransactions />;
}
