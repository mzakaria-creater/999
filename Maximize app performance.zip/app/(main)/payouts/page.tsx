'use client';

import { Payouts } from '@/app/pages/Payouts';

export default function PayoutsPage() {
  return <Payouts />;
}
