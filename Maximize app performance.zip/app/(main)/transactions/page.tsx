'use client';

import { Transactions } from '@/app/pages/Transactions';

export default function TransactionsPage() {
  return <Transactions />;
}
