'use client';

import { EmbedIntegration } from '@/app/pages/EmbedIntegration';

export default function EmbedPage() {
  return <EmbedIntegration />;
}
