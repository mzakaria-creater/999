'use client';

import { Settlement } from '@/app/pages/Settlement';

export default function SettlementPage() {
  return <Settlement />;
}
