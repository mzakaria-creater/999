'use client';

import { TableTransactions } from '@/app/pages/TableTransactions';

export default function TableTransactionsPage() {
  return <TableTransactions />;
}
