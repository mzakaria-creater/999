'use client';

import { SmartCheckoutDesigner } from '@/app/pages/SmartCheckoutDesigner';

export default function SmartCheckoutPage() {
  return <SmartCheckoutDesigner />;
}
