'use client';

import { LiveRates } from '@/app/pages/LiveRates';

export default function LiveRatesPage() {
  return <LiveRates />;
}
