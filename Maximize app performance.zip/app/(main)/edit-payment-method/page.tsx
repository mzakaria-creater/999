'use client';

import { EditPaymentMethod } from '@/app/pages/EditPaymentMethod';

export default function EditPaymentMethodPage() {
  return <EditPaymentMethod />;
}
