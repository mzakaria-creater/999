'use client';

import { LiveMonitor } from '@/app/pages/LiveMonitor';

export default function LiveMonitorPage() {
  return <LiveMonitor />;
}
