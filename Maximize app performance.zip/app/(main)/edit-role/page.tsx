'use client';

import { EditRole } from '@/app/pages/EditRole';

export default function EditRolePage() {
  return <EditRole />;
}
