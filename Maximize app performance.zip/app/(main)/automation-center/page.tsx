'use client';

import { AutomationCenter } from '@/app/pages/AutomationCenter';

export default function AutomationCenterPage() {
  return <AutomationCenter />;
}
