'use client';

import MobileAppGrid from '@/app/pages/MobileAppGrid';

export default function MobileAppGridPage() {
  return <MobileAppGrid />;
}
