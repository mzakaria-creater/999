'use client';

import { MerchantOnboarding } from '@/app/pages/MerchantOnboarding';

export default function MerchantOnboardingPage() {
  return <MerchantOnboarding />;
}
