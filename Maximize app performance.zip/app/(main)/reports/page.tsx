'use client';

import { Reports } from '@/app/pages/Reports';

export default function ReportsPage() {
  return <Reports />;
}
