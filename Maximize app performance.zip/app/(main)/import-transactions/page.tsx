'use client';

import { ImportTransactions } from '@/app/pages/ImportTransactions';

export default function ImportTransactionsPage() {
  return <ImportTransactions />;
}
