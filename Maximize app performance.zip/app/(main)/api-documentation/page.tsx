'use client';

import { ApiDocumentation } from '@/app/pages/ApiDocumentation';

export default function ApiDocumentationPage() {
  return <ApiDocumentation />;
}
