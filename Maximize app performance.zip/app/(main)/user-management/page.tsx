'use client';

import { UserManagement } from '@/app/pages/UserManagement';

export default function UserManagementPage() {
  return <UserManagement />;
}
