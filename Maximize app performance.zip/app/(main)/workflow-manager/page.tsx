'use client';

import { WorkflowManager } from '@/app/pages/WorkflowManager';

export default function WorkflowManagerPage() {
  return <WorkflowManager />;
}
