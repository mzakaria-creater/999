'use client';

import { ReactNode } from 'react';
import { Sidebar } from '@/app/components/Sidebar';
import { RoleSwitcher } from '@/app/components/RoleSwitcher';
import { LanguageSwitcher } from '@/app/components/LanguageSwitcher';
import { FxRateBar } from '@/app/components/FxRateBar';
import { useLanguage } from '@/app/context/LanguageContext';

export function LayoutClient({ children }: { children: ReactNode }) {
  const { t } = useLanguage();

  return (
    <div className="flex h-screen w-screen bg-[#121417] overflow-hidden fixed inset-0">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* FX Rate Bar */}
        <FxRateBar />
        
        <header className="border-b border-white/10 bg-[#1a1d23]/50 backdrop-blur-sm px-4 sm:px-8 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-4">
            <div className="text-xs sm:text-sm text-gray-400">
              {t('header.date')}
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <LanguageSwitcher />
            <RoleSwitcher />
          </div>
        </header>
        <main className="flex-1 overflow-y-auto overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
