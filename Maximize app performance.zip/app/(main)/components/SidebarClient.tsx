'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  ArrowLeftRight,
  Wallet,
  Users,
  CreditCard,
  Code,
  FileText,
  Shield,
  ChevronLeft,
  ChevronRight,
  Settings,
  Building2,
  ChevronDown,
  Smartphone,
  Bitcoin
} from 'lucide-react';
import { useRole, hasPermission } from '@/app/context/RoleContext';
import { useLanguage } from '@/app/context/LanguageContext';
import { useState } from 'react';
import { Tooltip } from '@/app/components/Tooltip';

interface SubNavItem {
  name: string;
  path: string;
  permission: string;
  translationKey: string;
}

interface NavItem {
  name: string;
  path?: string;
  icon: React.ComponentType<{ className?: string }>;
  permission: string;
  translationKey: string;
  subItems?: SubNavItem[];
}

const navItems: NavItem[] = [
  { 
    name: 'Dashboard', 
    path: '/dashboard', 
    icon: LayoutDashboard, 
    permission: 'dashboard', 
    translationKey: 'nav.dashboard' 
  },
  { 
    name: 'Transactions', 
    path: '/transactions', 
    icon: ArrowLeftRight, 
    permission: 'transactions', 
    translationKey: 'nav.transactions' 
  },
  { 
    name: 'Wallets', 
    path: '/wallets', 
    icon: Wallet, 
    permission: 'wallets', 
    translationKey: 'nav.wallets' 
  },
  { 
    name: 'Merchants', 
    path: '/merchants', 
    icon: Users, 
    permission: 'merchants', 
    translationKey: 'nav.merchants' 
  },
  { 
    name: 'Payment Methods', 
    path: '/payment-methods', 
    icon: CreditCard, 
    permission: 'payment-methods', 
    translationKey: 'nav.paymentMethods' 
  },
  { 
    name: 'Payment Accounts', 
    path: '/payment-accounts', 
    icon: Building2, 
    permission: 'payment-accounts', 
    translationKey: 'nav.paymentAccounts' 
  },
  { 
    name: 'Payment Pages', 
    path: '/payment-pages', 
    icon: FileText, 
    permission: 'payment-pages', 
    translationKey: 'nav.paymentPages' 
  },
  { 
    name: 'API Documentation', 
    path: '/api-documentation', 
    icon: Code, 
    permission: 'api-docs', 
    translationKey: 'nav.apiDocumentation' 
  },
  { 
    name: 'Permissions', 
    path: '/permissions', 
    icon: Shield, 
    permission: 'permissions', 
    translationKey: 'nav.permissions' 
  },
  {
    name: 'Mobile',
    icon: Smartphone,
    permission: 'dashboard',
    translationKey: 'nav.mobile',
    subItems: [
      {
        name: 'Dashboard',
        path: '/mobile/dashboard',
        permission: 'dashboard',
        translationKey: 'nav.mobileDashboard',
      },
      {
        name: 'Transactions',
        path: '/mobile/transactions',
        permission: 'transactions',
        translationKey: 'nav.mobileTransactions',
      },
      {
        name: 'Settings',
        path: '/mobile/settings',
        permission: 'dashboard',
        translationKey: 'nav.mobileSettings',
      },
    ],
  },
];

export function SidebarClient() {
  const pathname = usePathname();
  const { currentRole } = useRole();
  const { t, language } = useLanguage();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const isRTL = language === 'ar';

  const toggleExpand = (itemName: string) => {
    setExpandedItems(prev => 
      prev.includes(itemName) 
        ? prev.filter(name => name !== itemName)
        : [...prev, itemName]
    );
  };

  const isActive = (path?: string) => {
    if (!path) return false;
    return pathname === path;
  };

  return (
    <motion.aside
      initial={false}
      animate={{ width: isCollapsed ? '80px' : '280px' }}
      className={`relative bg-[#1a1d23]/80 backdrop-blur-xl border-r border-white/10 flex flex-col transition-all duration-300 flex-shrink-0 ${
        isRTL ? 'border-l border-r-0' : ''
      }`}
      style={{ direction: isRTL ? 'rtl' : 'ltr' }}
    >
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <AnimatePresence mode="wait">
          {!isCollapsed ? (
            <motion.div
              key="full-logo"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center shadow-lg shadow-[#8b5cf6]/50">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="white" opacity="0.9"/>
                  <path d="M2 17L12 22L22 17V12L12 17L2 12V17Z" fill="white" opacity="0.6"/>
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">OnTarget</h1>
                <p className="text-xs text-gray-400">PSP Platform</p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="collapsed-logo"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#3b82f6] flex items-center justify-center mx-auto shadow-lg shadow-[#8b5cf6]/50"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="white" opacity="0.9"/>
                <path d="M2 17L12 22L22 17V12L12 17L2 12V17Z" fill="white" opacity="0.6"/>
              </svg>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {navItems.map((item) => {
          if (!hasPermission(currentRole.id, item.permission)) {
            return null;
          }

          const Icon = item.icon;
          const isExpanded = expandedItems.includes(item.name);
          const hasSubItems = item.subItems && item.subItems.length > 0;

          if (hasSubItems) {
            return (
              <div key={item.name}>
                {isCollapsed ? (
                  <Tooltip content={t(item.translationKey)} position={isRTL ? 'left' : 'right'}>
                    <button
                      onClick={() => toggleExpand(item.name)}
                      className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-white/10 hover:text-white transition-all group relative"
                    >
                      <Icon className="w-5 h-5" />
                    </button>
                  </Tooltip>
                ) : (
                  <button
                    onClick={() => toggleExpand(item.name)}
                    className="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-white/10 hover:text-white transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5" />
                      <span className="text-sm font-medium">{t(item.translationKey)}</span>
                    </div>
                    <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </button>
                )}
                
                <AnimatePresence>
                  {isExpanded && !isCollapsed && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className={`py-1 space-y-1 ${isRTL ? 'pr-8' : 'pl-8'}`}>
                        {item.subItems?.map((subItem) => {
                          if (!hasPermission(currentRole.id, subItem.permission)) {
                            return null;
                          }
                          return (
                            <Link
                              key={subItem.path}
                              href={subItem.path}
                              className={`flex items-center gap-3 px-4 py-2 rounded-xl transition-all ${
                                isActive(subItem.path)
                                  ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-[#8b5cf6]/30'
                                  : 'text-gray-400 hover:bg-white/5 hover:text-white'
                              }`}
                            >
                              <span className="text-xs font-medium">{t(subItem.translationKey)}</span>
                            </Link>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          }

          if (isCollapsed) {
            return (
              <Tooltip key={item.name} content={t(item.translationKey)} position={isRTL ? 'left' : 'right'}>
                <Link
                  href={item.path || '#'}
                  className={`flex items-center justify-center gap-3 px-4 py-3 rounded-xl transition-all group relative ${
                    isActive(item.path)
                      ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-[#8b5cf6]/30'
                      : 'text-gray-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {isActive(item.path) && (
                    <motion.div
                      layoutId="active-pill"
                      className={`absolute ${isRTL ? 'right-0' : 'left-0'} top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-full`}
                    />
                  )}
                </Link>
              </Tooltip>
            );
          }

          return (
            <Link
              key={item.name}
              href={item.path || '#'}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all group relative ${
                isActive(item.path)
                  ? 'bg-gradient-to-r from-[#8b5cf6] to-[#3b82f6] text-white shadow-lg shadow-[#8b5cf6]/30'
                  : 'text-gray-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{t(item.translationKey)}</span>
              {isActive(item.path) && (
                <motion.div
                  layoutId="active-pill"
                  className={`absolute ${isRTL ? 'right-0' : 'left-0'} top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-full`}
                />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Collapse Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className={`absolute ${isRTL ? 'left-0 -translate-x-1/2' : 'right-0 translate-x-1/2'} top-20 w-6 h-6 rounded-full bg-[#1a1d23] border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all`}
      >
        {isCollapsed ? (
          isRTL ? <ChevronLeft className="w-3 h-3 text-gray-400" /> : <ChevronRight className="w-3 h-3 text-gray-400" />
        ) : (
          isRTL ? <ChevronRight className="w-3 h-3 text-gray-400" /> : <ChevronLeft className="w-3 h-3 text-gray-400" />
        )}
      </button>

      {/* Footer */}
      <div className="p-4 border-t border-white/10">
        {!isCollapsed ? (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#6ee7b7] to-[#06b6d4] flex items-center justify-center text-sm font-bold">
              {currentRole.name.substring(0, 2).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{currentRole.name}</p>
              <p className="text-xs text-gray-400 truncate">{t('sidebar.role')}</p>
            </div>
          </div>
        ) : (
          <Tooltip content={currentRole.name} position={isRTL ? 'left' : 'right'}>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#6ee7b7] to-[#06b6d4] flex items-center justify-center text-sm font-bold mx-auto">
              {currentRole.name.substring(0, 2).toUpperCase()}
            </div>
          </Tooltip>
        )}
      </div>
    </motion.aside>
  );
}
