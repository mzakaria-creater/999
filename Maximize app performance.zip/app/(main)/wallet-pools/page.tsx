'use client';

import { WalletPools } from '@/app/pages/WalletPools';

export default function WalletPoolsPage() {
  return <WalletPools />;
}
