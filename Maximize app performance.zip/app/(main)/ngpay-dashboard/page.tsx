'use client';

import NGPayDashboard from '@/app/pages/NGPayDashboard';

export default function NGPayDashboardPage() {
  return <NGPayDashboard />;
}
