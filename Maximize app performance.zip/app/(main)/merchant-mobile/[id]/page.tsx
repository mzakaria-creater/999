'use client';

import MerchantMobileView from '@/app/pages/MerchantMobileView';
import { useParams } from 'next/navigation';

export default function MerchantMobilePage() {
  const params = useParams();
  const id = params.id as string;

  return <MerchantMobileView />;
}
