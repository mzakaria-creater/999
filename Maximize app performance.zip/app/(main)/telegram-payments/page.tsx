'use client';

import { TelegramPayments } from '@/app/pages/TelegramPayments';

export default function TelegramPaymentsPage() {
  return <TelegramPayments />;
}
