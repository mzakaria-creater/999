'use client';

import { PaymentCheckout } from '@/app/pages/PaymentCheckout';

export default function PaymentCheckoutPage() {
  return <PaymentCheckout />;
}
