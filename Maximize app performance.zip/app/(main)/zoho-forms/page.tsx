'use client';

import { ZohoForms } from '@/app/pages/ZohoForms';

export default function ZohoFormsPage() {
  return <ZohoForms />;
}
