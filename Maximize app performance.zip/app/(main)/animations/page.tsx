'use client';

import { AnimationShowcase } from '@/app/pages/AnimationShowcase';

export default function AnimationsPage() {
  return <AnimationShowcase />;
}
