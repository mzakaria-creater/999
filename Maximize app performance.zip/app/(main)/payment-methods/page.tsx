'use client';

import { PaymentMethods } from '@/app/pages/PaymentMethods';

export default function PaymentMethodsPage() {
  return <PaymentMethods />;
}
