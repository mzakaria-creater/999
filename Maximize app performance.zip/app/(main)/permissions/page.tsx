'use client';

import { Permissions } from '@/app/pages/Permissions';

export default function PermissionsPage() {
  return <Permissions />;
}
