'use client';

import { Risk } from '@/app/pages/Risk';

export default function RiskPage() {
  return <Risk />;
}
