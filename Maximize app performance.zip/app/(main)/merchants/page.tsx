'use client';

import { Merchants } from '@/app/pages/Merchants';

export default function MerchantsPage() {
  return <Merchants />;
}
