'use client';

import { MerchantDetail } from '@/app/pages/MerchantDetail';
import { useParams } from 'next/navigation';

export default function MerchantDetailPage() {
  const params = useParams();
  const id = params.id as string;

  return <MerchantDetail />;
}
