'use client';

import { BinanceP2PPage } from '@/app/pages/BinanceP2PPage';

export default function BinanceP2PPageRoute() {
  return <BinanceP2PPage />;
}
