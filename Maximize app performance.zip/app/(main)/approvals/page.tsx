'use client';

import { Approvals } from '@/app/pages/Approvals';

export default function ApprovalsPage() {
  return <Approvals />;
}
