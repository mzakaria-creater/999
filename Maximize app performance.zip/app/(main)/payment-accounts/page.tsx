'use client';

import { PaymentAccounts } from '@/app/pages/PaymentAccounts';

export default function PaymentAccountsPage() {
  return <PaymentAccounts />;
}
