'use client';

import MobileLanding from '@/app/pages/MobileLanding';

export default function MobileViewPage() {
  return <MobileLanding />;
}
