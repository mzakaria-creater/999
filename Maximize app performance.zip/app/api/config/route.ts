import { NextResponse } from 'next/server';

export async function GET() {
  // Return public config (without sensitive data)
  return NextResponse.json({
    supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL,
    environment: process.env.NODE_ENV,
    features: {
      supabase: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
      analytics: false,
      pwa: true,
    },
  });
}
