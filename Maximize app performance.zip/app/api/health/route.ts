import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'OnTarget PSP API is running',
    version: '2.6.0',
    timestamp: new Date().toISOString(),
  });
}
