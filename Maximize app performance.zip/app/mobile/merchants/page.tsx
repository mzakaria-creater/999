'use client';

import MerchantMobileView from '@/app/pages/MerchantMobileView';

export default function MobileMerchantsPage() {
  return <MerchantMobileView />;
}
