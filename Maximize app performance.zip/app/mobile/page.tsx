'use client';

import MobileDashboard from '@/app/pages/MobileDashboard';

export default function MobilePage() {
  return <MobileDashboard />;
}
