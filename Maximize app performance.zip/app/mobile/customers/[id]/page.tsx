'use client';

import MobileCustomerProfile from '@/app/pages/MobileCustomerProfile';
import { useParams } from 'next/navigation';

export default function MobileCustomerPage() {
  const params = useParams();
  const id = params.id as string;

  return <MobileCustomerProfile />;
}
