'use client';

import MobileTransactionDetails from '@/app/pages/MobileTransactionDetails';

export default function MobileTransactionDetailsPage() {
  return <MobileTransactionDetails />;
}
