'use client';

import MobileTransactionsCenter from '@/app/pages/MobileTransactionsCenter';

export default function MobileTransactionsPage() {
  return <MobileTransactionsCenter />;
}
