'use client';

import MobileDashboard from '@/app/pages/MobileDashboard';

export default function MobileDashboardPage() {
  return <MobileDashboard />;
}
