'use client';

import MobileAppGrid from '@/app/pages/MobileAppGrid';

export default function MobileAppsPage() {
  return <MobileAppGrid />;
}
