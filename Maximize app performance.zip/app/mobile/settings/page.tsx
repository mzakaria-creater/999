'use client';

import MobileSettings from '@/app/pages/MobileSettings';

export default function MobileSettingsPage() {
  return <MobileSettings />;
}
