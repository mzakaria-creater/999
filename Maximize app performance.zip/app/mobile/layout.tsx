'use client';

import { Providers } from '../providers';
import { MobileAppLayout } from '@/app/components/MobileAppLayout';

export default function MobileLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Providers>
      <MobileAppLayout>
        {children}
      </MobileAppLayout>
    </Providers>
  );
}
