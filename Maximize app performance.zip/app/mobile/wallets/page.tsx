'use client';

import { MobileWalletTransactions } from '@/app/pages/MobileWalletTransactions';

export default function MobileWalletsPage() {
  return <MobileWalletTransactions />;
}
