import type { Metadata } from 'next';
import { Tajawal } from 'next/font/google';
import '../src/styles/index.css';
import '../src/styles/tailwind.css';
import '../src/styles/theme.css';
import '../src/styles/fonts.css';
import { LanguageProvider } from '@/app/context/LanguageContext';
import { RoleProvider } from '@/app/context/RoleContext';
import { MobileThemeProvider } from '@/app/context/MobileThemeContext';
import { Toaster } from 'sonner';

const tajawal = Tajawal({
  weight: ['200', '300', '400', '500', '700', '800', '900'],
  subsets: ['arabic', 'latin'],
  display: 'swap',
  variable: '--font-tajawal',
});

export const metadata: Metadata = {
  title: 'OnTarget PSP - Payment Service Platform',
  description: 'منصة دفع مالية متكاملة مع دعم كامل للعربية (RTL) وطرق دفع الشرق الأوسط والخليج',
  manifest: '/manifest.json',
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
  },
  themeColor: '#6366f1',
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className={tajawal.variable}>
      <body className="antialiased">
        <LanguageProvider>
          <RoleProvider>
            <MobileThemeProvider>
              {children}
              <Toaster position="top-center" richColors />
            </MobileThemeProvider>
          </RoleProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
