import { MetadataRoute } from 'next';

/**
 * Sitemap for OnTarget PSP
 * This will be generated at /sitemap.xml
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://your-domain.com';

  // Main pages
  const routes = [
    '',
    '/dashboard',
    '/transactions',
    '/merchants',
    '/wallets',
    '/payment-methods',
    '/payment-pages',
    '/payment-accounts',
    '/smart-checkout',
    '/live-monitor',
    '/live-rates',
    '/reports',
    '/mobile',
    '/mobile/dashboard',
    '/mobile/transactions',
    '/mobile/wallets',
    '/mobile/merchants',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'daily' as const,
    priority: route === '' ? 1 : 0.8,
  }));

  return routes;
}
