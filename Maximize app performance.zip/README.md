# OnTarget PSP - Payment Service Platform

منصة دفع مالية متكاملة بتصميم glassmorphic حديث مع دعم كامل للغة العربية (RTL) وتجربة مستخدم بنمط iOS للهواتف المحمولة.

## 🚀 المميزات الرئيسية

### 📱 تصميم متجاوب ومتعدد المنصات
- واجهة سطح مكتب مع sidebar منظم في 11 فئة رئيسية
- تطبيق mobile مع bottom navigation bar
- تجربة مستخدم بنمط iOS للهواتف المحمولة
- دعم كامل للعربية (RTL)

### 🔐 نظام التحكم بالصلاحيات (RBAC)
- 6 أدوار مختلفة للمستخدمين
- صلاحيات مخصصة لكل دور
- نظام أمان متقدم

### 💳 طرق الدفع
- دعم PayPal, Binance, OKX
- محافظ الهاتف المحمول المصرية (Fawry, Vodafone Cash, إلخ)
- صفحات checkout متخصصة
- أسعار صرف حية

### 📊 أكثر من 40 صفحة تشمل:
- إدارة المعاملات والمحافظ
- إدارة التجار والعملاء
- نظام أتمتة متقدم
- تقارير وتحليلات
- مراقبة مباشرة

## 🛠️ التقنيات المستخدمة

- **Framework:** Next.js 15 (App Router)
- **Styling:** Tailwind CSS v4
- **UI Components:** Radix UI, shadcn/ui
- **Charts:** Recharts
- **Animations:** Motion (Framer Motion)
- **Backend:** Supabase (Database, Auth, Storage)
- **Icons:** Lucide React, Material UI Icons
- **Forms:** React Hook Form
- **Deployment:** Vercel

## 📦 التثبيت والإعداد

### المتطلبات الأساسية
- Node.js 18.17 أو أحدث
- pnpm (مفضل) أو npm

### 1. استنساخ المشروع
```bash
git clone <repository-url>
cd ontarget-psp
```

### 2. تثبيت الحزم
```bash
pnpm install
# أو
npm install
```

### 3. إعداد المتغيرات البيئية
انسخ ملف `.env.example` إلى `.env.local`:

```bash
cp .env.example .env.local
```

املأ المتغيرات البيئية في `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
```

### 4. تشغيل المشروع محلياً
```bash
pnpm dev
# أو
npm run dev
```

افتح [http://localhost:3000](http://localhost:3000) في المتصفح.

## 🌐 النشر على Vercel

### الطريقة الأولى: من خلال واجهة Vercel (الأسهل)

1. قم بإنشاء حساب على [Vercel](https://vercel.com)
2. اضغط على "Add New Project"
3. استورد مشروعك من GitHub/GitLab/Bitbucket
4. Vercel سيكتشف Next.js تلقائياً
5. أضف المتغيرات البيئية في قسم "Environment Variables":
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
6. اضغط "Deploy"

### الطريقة الثانية: من خلال Vercel CLI

```bash
# تثبيت Vercel CLI
npm i -g vercel

# تسجيل الدخول
vercel login

# نشر المشروع
vercel

# أو للنشر المباشر إلى production
vercel --prod
```

### إعداد المتغيرات البيئية في Vercel

```bash
# إضافة متغيرات البيئة
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY
```

## 📁 هيكل المشروع

```
ontarget-psp/
├── app/                          # Next.js App Router
│   ├── (main)/                   # Desktop routes
│   │   ├── dashboard/
│   │   ├── transactions/
│   │   ├── merchants/
│   │   ├── wallets/
│   │   └── ...
│   ├── mobile/                   # Mobile routes
│   │   ├── dashboard/
│   │   ├── transactions/
│   │   └── ...
│   ├── api/                      # API routes
│   │   ├── config/
│   │   └── health/
│   ├── layout.tsx                # Root layout
│   └── page.tsx                  # Home page
├── src/
│   ├── app/
│   │   ├── components/           # React components
│   │   ├── context/              # Context providers
│   │   ├── hooks/                # Custom hooks
│   │   ├── pages/                # Page components (legacy)
│   │   └── services/             # Business logic
│   ├── styles/                   # Global styles
│   └── utils/                    # Utility functions
├── public/                       # Static assets
├── supabase/                     # Supabase functions
├── middleware.ts                 # Next.js middleware
├── next.config.js                # Next.js config
├── tailwind.config.js            # Tailwind config
├── tsconfig.json                 # TypeScript config
└── vercel.json                   # Vercel config
```

## 🔧 الأوامر المتاحة

```bash
# التطوير المحلي
pnpm dev

# بناء المشروع للإنتاج
pnpm build

# تشغيل النسخة المبنية
pnpm start

# فحص الكود
pnpm lint
```

## 🎨 التخصيص

### تغيير الألوان والثيم
قم بتعديل متغيرات CSS في `/src/styles/theme.css`

### إضافة صفحات جديدة
1. للصفحات Desktop: أضف في `/app/(main)/your-page/page.tsx`
2. للصفحات Mobile: أضف في `/app/mobile/your-page/page.tsx`

### تخصيص Sidebar
قم بتعديل `/src/app/components/Sidebar.tsx`

## 🔐 الأمان

- جميع المتغيرات الحساسة يجب أن تكون في `.env.local` ولا ترفع إلى Git
- `SUPABASE_SERVICE_ROLE_KEY` يجب استخدامه فقط في server-side code
- Middleware يضيف security headers تلقائياً
- CORS مُعد بشكل صحيح للـ API routes

## 📚 الموارد

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [Supabase Documentation](https://supabase.com/docs)
- [Vercel Documentation](https://vercel.com/docs)

## 🤝 المساهمة

نرحب بالمساهمات! الرجاء:
1. Fork المشروع
2. إنشاء branch جديد (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push إلى البranch (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## 📝 الترخيص

هذا المشروع خاص ومحمي بحقوق الملكية.

## 📧 الدعم

للحصول على الدعم، يرجى فتح issue في GitHub أو التواصل مع فريق التطوير.

---

**تم التطوير بـ ❤️ باستخدام Next.js و Tailwind CSS**
