# 🚀 Quick Start - Animations in OnTarget PSP

## 🎯 **In 5 Minutes**

Your OnTarget PSP now has **professional 2026-style animations**. Here's how to use them:

---

## 1️⃣ **Page Transitions** (Already Active!)

Your routes already have smooth transitions. Navigate between pages to see them!

**Current Setup:**
```tsx
// In /src/app/components/Layout.tsx
<PageTransition type="slide">
  <Outlet />
</PageTransition>
```

**Try it:** Click any sidebar link → See smooth slide animation ✨

---

## 2️⃣ **Animated Buttons** (Replace Any Button)

**Before:**
```tsx
<button onClick={handleExport} className="btn-primary">
  Export Report
</button>
```

**After:**
```tsx
import { AnimatedButton } from './components/AnimatedButton';

<AnimatedButton onClick={handleExport} ripple lift>
  <Download /> Export Report
</AnimatedButton>
```

**Result:** Click ripple effect + hover lift animation 💫

---

## 3️⃣ **Success Confetti** (Any Success Action)

```tsx
import { useConfetti } from './components/ConfettiEffect';

function MyComponent() {
  const { fireConfetti } = useConfetti();
  
  const handleSuccess = () => {
    fireConfetti('success'); // 🎉
    // Your success logic
  };
  
  return <button onClick={handleSuccess}>Complete Payment</button>;
}
```

**Confetti Types:**
- `'success'` - Quick burst
- `'celebration'` - Big party! 
- `'burst'` - Massive explosion
- `'rain'` - Continuous rain

---

## 4️⃣ **Loading Skeletons** (Show During Loading)

```tsx
import { DashboardCardSkeleton } from './components/SkeletonLoader';

function Dashboard() {
  const [loading, setLoading] = useState(true);
  
  if (loading) {
    return (
      <div className="grid grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <DashboardCardSkeleton key={i} />
        ))}
      </div>
    );
  }
  
  return <DashboardCards />;
}
```

**Available Skeletons:**
- `<DashboardCardSkeleton />` - Stats cards
- `<TransactionSkeleton />` - Transaction items
- `<ChartSkeleton />` - Charts
- `<TableRowSkeleton columns={5} />` - Table rows

---

## 5️⃣ **3D Hover Cards** (Make Cards Interactive)

```tsx
import { HoverCard3D } from './components/HoverCard3D';

<HoverCard3D intensity={15} shine={true}>
  <div className="p-6 rounded-2xl bg-white/5">
    <h3>Total Revenue</h3>
    <p className="text-3xl">$73,000</p>
  </div>
</HoverCard3D>
```

**Move your mouse over it** → See 3D tilt effect! 🎯

---

## 6️⃣ **Swipeable Cards** (Mobile Only)

```tsx
import { SwipeableCard } from './components/SwipeableCard';

<SwipeableCard
  leftAction="delete"
  rightAction="approve"
  onSwipeLeft={() => handleDelete(tx.id)}
  onSwipeRight={() => handleApprove(tx.id)}
>
  <TransactionCard data={tx} />
</SwipeableCard>
```

**On mobile:** Swipe left/right to reveal actions 📱

---

## 7️⃣ **Stagger Animations** (Lists & Grids)

```tsx
import { StaggerContainer, StaggerItem } from './components/AnimatedChart';

<StaggerContainer staggerDelay={0.1}>
  {items.map(item => (
    <StaggerItem key={item.id}>
      <ItemCard data={item} />
    </StaggerItem>
  ))}
</StaggerContainer>
```

**Result:** Items appear one by one 🌊

---

## 🎨 **Real Examples in Your App**

### Dashboard Export Button
**File:** `/src/app/pages/Dashboard.tsx`

```tsx
const { fireConfetti } = useConfetti();

const handleExport = () => {
  fireConfetti('success');
  // Export logic
};

<AnimatedButton onClick={handleExport} ripple lift>
  <Download /> Export Report
</AnimatedButton>
```

### Transaction Cards (Mobile)
**File:** `/src/app/pages/MobileTransactionsCenter.tsx` (if needed)

```tsx
<SwipeableCard
  onSwipeRight={() => {
    fireConfetti('success');
    handleApprove(tx.id);
  }}
>
  <TransactionCard />
</SwipeableCard>
```

---

## 🎯 **Most Common Use Cases**

### 1. Success Feedback
```tsx
const handlePayment = async () => {
  await processPayment();
  fireConfetti('celebration');
  toast.success('Payment completed!');
};
```

### 2. Loading State
```tsx
{isLoading ? (
  <>
    <DashboardCardSkeleton />
    <DashboardCardSkeleton />
    <DashboardCardSkeleton />
  </>
) : (
  <DashboardCards data={stats} />
)}
```

### 3. Interactive Cards
```tsx
<div className="grid grid-cols-3 gap-6">
  {cards.map(card => (
    <HoverCard3D key={card.id} intensity={12}>
      <FeatureCard data={card} />
    </HoverCard3D>
  ))}
</div>
```

---

## ⚙️ **Customization**

### Change Animation Speed
```tsx
<PageTransition type="slide" duration={0.2}> {/* Faster */}
```

### Disable Ripple
```tsx
<AnimatedButton ripple={false} lift={true}>
  No Ripple
</AnimatedButton>
```

### Custom Confetti Colors
```tsx
const { fireConfetti } = useConfetti();

fireConfetti('burst'); // Uses your brand colors automatically
```

### Adjust 3D Intensity
```tsx
<HoverCard3D intensity={5}>  {/* Subtle */}
<HoverCard3D intensity={20}> {/* Dramatic */}
```

---

## 🎬 **See It in Action**

### Test Page Transitions
1. Open your app
2. Click **Dashboard** → **Transactions** → **Merchants**
3. Watch smooth slide transitions ✨

### Test Button Ripple
1. Go to Dashboard
2. Click "Export Report" button
3. See ripple effect + confetti 🎉

### Test 3D Cards (Desktop)
1. Go to Dashboard
2. Hover over stat cards
3. Move mouse around → See 3D tilt 🎯

### Test Swipe (Mobile)
1. Open on mobile device
2. Go to Transactions
3. Swipe left/right on transaction card
4. See action indicators 📱

---

## 🚨 **Troubleshooting**

### "Motion is not defined"
**Already Fixed!** ✅ All imports are correct.

### Animations not showing?
Check if user has `prefers-reduced-motion` enabled in OS settings.

### Confetti not working?
Make sure you imported the hook:
```tsx
import { useConfetti } from './components/ConfettiEffect';
const { fireConfetti } = useConfetti();
```

### Page transitions not smooth?
Verify PageTransition wraps Outlet in Layout.tsx (already done ✅)

---

## 📱 **Mobile-Specific Features**

### Swipe Threshold
```tsx
<SwipeableCard threshold={150}> {/* More swipe needed */}
```

### Disable on Desktop
```tsx
import { useIsMobile } from '../hooks/useIsMobile';

const isMobile = useIsMobile();

{isMobile && (
  <SwipeableCard>
    <Content />
  </SwipeableCard>
)}
```

---

## 🎨 **Animation Cheat Sheet**

| Component | Use Case | Example |
|-----------|----------|---------|
| `PageTransition` | Route changes | Already active ✅ |
| `AnimatedButton` | Important CTAs | Export, Submit, Approve |
| `useConfetti` | Success moments | Payment success, approval |
| `DashboardCardSkeleton` | Loading data | Dashboard, reports |
| `HoverCard3D` | Feature highlights | Stats, features |
| `SwipeableCard` | Mobile actions | Delete, approve, archive |
| `StaggerContainer` | Lists/grids | Transaction lists, cards |

---

## 💡 **Pro Tips**

1. **Don't overuse** - Reserve animations for important interactions
2. **Match the mood** - Subtle for data, bold for celebrations
3. **Test on real devices** - Always check mobile performance
4. **Respect accessibility** - Animations auto-disable for users who need it
5. **Use skeletons** - Show loading states, not blank screens

---

## 🎉 **You're Ready!**

All animations are **production-ready** and working in your app. Just import and use!

**Next Steps:**
1. Try the examples above
2. Read `/ANIMATIONS_GUIDE.md` for advanced usage
3. Customize to match your needs

---

**Built for OnTarget PSP with ❤️**
*Modern · Fast · Accessible · Mobile-First*
