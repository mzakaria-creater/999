# OnTarget PSP Changelog

## Version 2.3.0 (2026-03-16)

### ✨ New Features
- **Desktop Merchant Sidebar**: Added comprehensive merchant detail sidebar for screens larger than iPad (>= 1024px)
  - Auto-slides from right (LTR) or left (RTL) with spring animation
  - Displays merchant profile, volume charts, payment methods breakdown, and statistics
  - Features glassmorphic design with gradient borders and backdrop blur
  - Includes 7-day volume chart with animated bars and SVG line overlay
  - Shows top payment methods with animated progress bars
  - Displays key metrics: Success Rate, Avg Transaction, Complaints, Chargebacks
  - Interactive tabs: Overview, Payment Methods, Corridors, API & Webhooks, Settings
  
- **Reusable Desktop Sidebar Component**: Created `DesktopDetailsSidebar` for general use
  - Customizable width, title, icon, and subtitle
  - RTL support with automatic positioning
  - Smooth spring animations and glassmorphic effects
  - Scrollable content area with gradient glow effects

### 🔧 Improvements
- **Smart Screen Detection**: Merchant table now detects screen size
  - Screens >= 1024px: Opens detail sidebar on the same page
  - Screens < 1024px: Navigates to dedicated merchant detail page
  
- **Enhanced User Experience**: 
  - Click any merchant row to view details
  - Close sidebar with animated X button or by selecting another merchant
  - Smooth transitions with Motion/React spring animations

### 📦 Components Added
- `/src/app/components/DesktopMerchantSidebar.tsx` - Specialized merchant detail sidebar
- `/src/app/components/DesktopDetailsSidebar.tsx` - Generic reusable sidebar component

### 🎨 Design System
- Consistent glassmorphic design with gradient overlays
- Purple-to-blue gradient accents (#8b5cf6 → #3b82f6)
- Animated charts with staggered entrance animations
- Hover effects and interactive states throughout

### 🐛 Bug Fixes
- None in this release

---

## Version 2.2.7 (2026-03-16)

### 🐛 Bug Fixes
- Fixed export default errors in `MobileTransactionsCenter.tsx`
- Removed duplicate code and routes in `routes.tsx`
- Fixed version.ts formatting
- Cleaned up console errors

### 🧹 Code Quality
- Removed duplicate mobile route definitions
- Standardized export patterns across mobile components
- Improved route organization

---

## Version 2.2.0 - 2.2.6

Previous versions with mobile app grid, bottom navigation, and core payment features.

---

## Version 2.0.0 - 2.1.x

Initial Next.js migration and core feature implementation.
