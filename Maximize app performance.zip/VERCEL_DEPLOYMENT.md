# 🚀 دليل النشر على Vercel - OnTarget PSP

دليل شامل لنشر منصة OnTarget PSP على Vercel بشكل صحيح.

## 📋 المتطلبات الأساسية

- [x] حساب على [Vercel](https://vercel.com)
- [x] حساب على [GitHub](https://github.com) / GitLab / Bitbucket
- [x] مشروع Supabase مُعد ومُفعّل
- [x] المشروع مرفوع على Git repository

## 🎯 خطوات النشر

### 1️⃣ ربط Repository مع Vercel

#### الطريقة الأولى: من خلال واجهة Vercel (موصى بها للمبتدئين)

1. **تسجيل الدخول إلى Vercel**
   - اذهب إلى [vercel.com](https://vercel.com)
   - سجل دخول أو أنشئ حساب جديد

2. **إضافة مشروع جديد**
   ```
   Dashboard → Add New... → Project
   ```

3. **استيراد Git Repository**
   - اختر GitHub / GitLab / Bitbucket
   - امنح Vercel صلاحيات الوصول
   - اختر repository الخاص بـ OnTarget PSP

4. **تكوين المشروع**
   ```
   Framework Preset: Next.js
   Root Directory: ./
   Build Command: pnpm build (أو npm run build)
   Output Directory: .next
   Install Command: pnpm install (أو npm install)
   ```

5. **إضافة Environment Variables**
   
   اضغط على "Environment Variables" وأضف:
   
   ```env
   NEXT_PUBLIC_SUPABASE_URL = your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY = your_supabase_anon_key
   SUPABASE_SERVICE_ROLE_KEY = your_supabase_service_role_key
   ```
   
   **مهم جداً:** 
   - اختر "Production, Preview, and Development" لكل متغير
   - تأكد من عدم وجود مسافات زائدة في القيم

6. **النشر**
   - اضغط "Deploy"
   - انتظر حتى ينتهي البناء (عادة 2-5 دقائق)
   - ستحصل على رابط مثل: `https://your-project.vercel.app`

#### الطريقة الثانية: من خلال Vercel CLI (للمتقدمين)

1. **تثبيت Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **تسجيل الدخول**
   ```bash
   vercel login
   ```

3. **النشر الأول**
   ```bash
   vercel
   ```
   
   سيطلب منك:
   - اختيار scope (account/team)
   - تأكيد اسم المشروع
   - اختيار directory
   - تأكيد الإعدادات

4. **إضافة Environment Variables**
   ```bash
   vercel env add NEXT_PUBLIC_SUPABASE_URL production
   vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY production
   vercel env add SUPABASE_SERVICE_ROLE_KEY production
   ```

5. **النشر إلى Production**
   ```bash
   vercel --prod
   ```

### 2️⃣ إعداد Supabase

1. **الحصول على بيانات Supabase**
   - اذهب إلى [Supabase Dashboard](https://app.supabase.com)
   - اختر مشروعك
   - اذهب إلى `Settings → API`
   - انسخ:
     - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
     - `anon/public key` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
     - `service_role key` → `SUPABASE_SERVICE_ROLE_KEY`

2. **إعداد Authentication**
   - في Supabase: `Authentication → URL Configuration`
   - أضف Vercel domain:
     ```
     Site URL: https://your-project.vercel.app
     Redirect URLs: 
     - https://your-project.vercel.app/**
     - http://localhost:3000/**
     ```

3. **إعداد CORS**
   - في Supabase: `Settings → API → CORS`
   - أضف:
     ```
     https://your-project.vercel.app
     http://localhost:3000
     ```

### 3️⃣ التحقق من النشر الناجح

بعد النشر، تحقق من:

1. **الصفحة الرئيسية تعمل**
   ```
   https://your-project.vercel.app
   ```

2. **API Health Check**
   ```
   https://your-project.vercel.app/api/health
   ```
   يجب أن تعيد: `{ "status": "ok" }`

3. **تحميل الموارد**
   - افتح Developer Tools (F12)
   - تحقق من عدم وجود أخطاء في Console
   - تحقق من تحميل الصور والأيقونات

4. **اتصال Supabase**
   - جرب تسجيل الدخول
   - تحقق من عمل المعاملات

## 🔧 حل المشاكل الشائعة

### مشكلة: Build يفشل بسبب TypeScript errors

**الحل:**
```bash
# في vercel.json أو في Build Settings
{
  "build": {
    "env": {
      "SKIP_TYPE_CHECK": "true"
    }
  }
}
```

أو في `next.config.js`:
```js
module.exports = {
  typescript: {
    ignoreBuildErrors: true, // استخدم فقط للضرورة
  },
}
```

### مشكلة: Environment variables غير معرفة

**الحل:**
1. تأكد من البادئة `NEXT_PUBLIC_` للمتغيرات المستخدمة في Client
2. أعد deploy بعد إضافة المتغيرات
3. تحقق من الإملاء والحروف الكبيرة/الصغيرة

### مشكلة: Fonts لا تظهر بشكل صحيح

**الحل:**
تأكد من أن `/src/styles/fonts.css` محمل في `app/layout.tsx`

### مشكلة: Images من Supabase لا تظهر

**الحل:**
تحقق من `next.config.js`:
```js
images: {
  remotePatterns: [
    {
      protocol: 'https',
      hostname: '*.supabase.co',
    },
  ],
}
```

### مشكلة: 404 على الصفحات

**الحل:**
- تأكد من structure الصفحات في `/app/`
- تأكد من وجود `page.tsx` في كل route

## 📊 مراقبة الأداء

### في Vercel Dashboard

1. **Analytics**
   - اذهب إلى `Project → Analytics`
   - راقب:
     - Page views
     - Unique visitors
     - Top pages
     - Geographic distribution

2. **Speed Insights**
   - `Project → Speed Insights`
   - راقب Core Web Vitals:
     - LCP (Largest Contentful Paint)
     - FID (First Input Delay)
     - CLS (Cumulative Layout Shift)

3. **Real-time Logs**
   - `Project → Logs`
   - راقب الأخطاء في real-time

## 🔄 التحديثات التلقائية

Vercel يدعم CI/CD تلقائياً:

1. **Production Deployments**
   - كل push إلى `main` branch = deployment تلقائي

2. **Preview Deployments**
   - كل Pull Request = preview deployment مستقل
   - رابط مؤقت للمراجعة

3. **إيقاف Auto-deployments**
   ```
   Project Settings → Git → Ignored Build Step
   ```

## 🌐 Custom Domain

### ربط Domain مخصص

1. **في Vercel**
   ```
   Project → Settings → Domains
   ```

2. **إضافة Domain**
   - أدخل domain الخاص بك (مثل: `ontarget-psp.com`)
   - Vercel سيعطيك DNS records

3. **في موفر Domain**
   - أضف DNS records:
     ```
     Type: A
     Name: @
     Value: 76.76.21.21
     
     Type: CNAME
     Name: www
     Value: cname.vercel-dns.com
     ```

4. **انتظر DNS Propagation**
   - عادة 5-30 دقيقة
   - تحقق من: [whatsmydns.net](https://whatsmydns.net)

5. **SSL/HTTPS**
   - Vercel يوفر SSL certificate تلقائياً
   - لا حاجة لإعداد إضافي

## 🔐 أفضل الممارسات الأمنية

1. **Environment Variables**
   - ✅ استخدم Vercel Environment Variables
   - ❌ لا تضع secrets في الكود
   - ❌ لا تضع `.env` في Git

2. **Service Role Key**
   - ✅ استخدمه فقط في Server Components / API Routes
   - ❌ لا تستخدمه في Client Components

3. **Headers الأمنية**
   - موجودة في `middleware.ts`
   - يمكن إضافة المزيد في `vercel.json`

4. **Rate Limiting**
   - فكّر في إضافة rate limiting للـ API
   - استخدم Vercel Edge Middleware

## 📈 تحسين الأداء

### 1. تفعيل Image Optimization

Already configured في `next.config.js`

### 2. استخدام ISR (Incremental Static Regeneration)

في الصفحات التي لا تتغير كثيراً:
```tsx
export const revalidate = 3600; // كل ساعة
```

### 3. تقليل حجم Bundle

```bash
# تحليل bundle size
npm run build

# راجع .next/analyze/
```

### 4. استخدام Edge Functions

للـ API routes السريعة:
```tsx
export const runtime = 'edge';
```

## 🔍 المراقبة والتنبيهات

### تفعيل Notifications

```
Project Settings → Notifications
```

اختر:
- [ ] Deployment Started
- [x] Deployment Failed
- [x] Deployment Ready
- [x] Domain Configuration Changed

### Integration مع Slack/Discord

```
Project Settings → Integrations → Add Integration
```

## 📞 الدعم

- **Vercel Docs:** [vercel.com/docs](https://vercel.com/docs)
- **Next.js Docs:** [nextjs.org/docs](https://nextjs.org/docs)
- **Supabase Docs:** [supabase.com/docs](https://supabase.com/docs)
- **Community:** [vercel.com/discord](https://vercel.com/discord)

---

**🎉 مبروك! مشروعك الآن على Vercel!**

الرابط: `https://your-project.vercel.app`
