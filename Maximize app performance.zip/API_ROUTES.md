# 🔌 API Routes Documentation - OnTarget PSP

دليل شامل لجميع API routes المتاحة في المنصة.

## 📍 Base URL

```
Local: http://localhost:3000/api
Production: https://your-domain.com/api
```

## 🏥 Health & Status

### GET /api/health

فحص حالة التطبيق والاتصال بـ Supabase.

**Request:**
```bash
curl http://localhost:3000/api/health
```

**Response (200 OK):**
```json
{
  "status": "ok",
  "timestamp": "2026-03-22T10:00:00.000Z",
  "services": {
    "database": "connected",
    "auth": "operational"
  }
}
```

**Response (503 Service Unavailable):**
```json
{
  "status": "error",
  "message": "Service unavailable",
  "services": {
    "database": "disconnected",
    "auth": "operational"
  }
}
```

---

### GET /api/config

الحصول على تكوينات التطبيق العامة (غير الحساسة).

**Request:**
```bash
curl http://localhost:3000/api/config
```

**Response (200 OK):**
```json
{
  "app": {
    "name": "OnTarget PSP",
    "version": "3.0.0",
    "environment": "production"
  },
  "features": {
    "supabase": true,
    "analytics": true,
    "rtl": true
  },
  "supabase": {
    "url": "https://xxxxx.supabase.co",
    "anonKey": "eyJhbGciOiJIUzI1..."
  }
}
```

**Note:** لا تُرجع أي مفاتيح حساسة (service role key).

---

## 💰 Transactions API

### GET /api/transactions

الحصول على قائمة المعاملات مع pagination و filtering.

**Query Parameters:**
- `page` (number, default: 1) - رقم الصفحة
- `limit` (number, default: 50) - عدد النتائج
- `status` (string, optional) - فلترة حسب الحالة
- `merchant_id` (string, optional) - فلترة حسب التاجر
- `from_date` (ISO string, optional) - من تاريخ
- `to_date` (ISO string, optional) - إلى تاريخ

**Request:**
```bash
curl "http://localhost:3000/api/transactions?page=1&limit=20&status=completed"
```

**Response (200 OK):**
```json
{
  "data": [
    {
      "id": "txn_123",
      "amount": 1500.00,
      "currency": "EGP",
      "status": "completed",
      "merchant_id": "mer_456",
      "created_at": "2026-03-22T10:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8
  }
}
```

---

### GET /api/transactions/[id]

الحصول على تفاصيل معاملة محددة.

**Request:**
```bash
curl http://localhost:3000/api/transactions/txn_123
```

**Response (200 OK):**
```json
{
  "id": "txn_123",
  "amount": 1500.00,
  "currency": "EGP",
  "status": "completed",
  "merchant": {
    "id": "mer_456",
    "name": "Example Store"
  },
  "customer": {
    "email": "customer@example.com",
    "phone": "+20123456789"
  },
  "payment_method": "vodafone_cash",
  "created_at": "2026-03-22T10:00:00Z",
  "updated_at": "2026-03-22T10:05:00Z"
}
```

---

### POST /api/transactions

إنشاء معاملة جديدة.

**Headers:**
```
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Request Body:**
```json
{
  "amount": 1500.00,
  "currency": "EGP",
  "merchant_id": "mer_456",
  "customer_email": "customer@example.com",
  "payment_method": "vodafone_cash",
  "callback_url": "https://merchant.com/callback"
}
```

**Response (201 Created):**
```json
{
  "id": "txn_123",
  "status": "pending",
  "payment_url": "https://checkout.ontarget-psp.com/pay/txn_123"
}
```

---

## 🏪 Merchants API

### GET /api/merchants

الحصول على قائمة التجار.

**Request:**
```bash
curl -H "Authorization: Bearer {token}" \
  http://localhost:3000/api/merchants
```

**Response (200 OK):**
```json
{
  "data": [
    {
      "id": "mer_123",
      "name": "Example Store",
      "email": "merchant@example.com",
      "status": "active",
      "created_at": "2026-01-01T00:00:00Z"
    }
  ]
}
```

---

### POST /api/merchants

إنشاء تاجر جديد (Admin only).

**Headers:**
```
Content-Type: application/json
Authorization: Bearer {admin_token}
```

**Request Body:**
```json
{
  "name": "New Store",
  "email": "newstore@example.com",
  "phone": "+20123456789",
  "business_type": "retail",
  "country": "EG"
}
```

**Response (201 Created):**
```json
{
  "id": "mer_124",
  "name": "New Store",
  "api_key": "sk_live_xxxxxx",
  "webhook_secret": "whsec_xxxxxx"
}
```

---

## 💼 Wallets API

### GET /api/wallets

الحصول على المحافظ وأرصدتها.

**Request:**
```bash
curl -H "Authorization: Bearer {token}" \
  http://localhost:3000/api/wallets
```

**Response (200 OK):**
```json
{
  "data": [
    {
      "id": "wal_123",
      "name": "Main Wallet",
      "currency": "EGP",
      "balance": 50000.00,
      "available_balance": 48500.00,
      "status": "active"
    }
  ]
}
```

---

### GET /api/wallets/[id]/transactions

معاملات محفظة محددة.

**Request:**
```bash
curl http://localhost:3000/api/wallets/wal_123/transactions
```

**Response (200 OK):**
```json
{
  "wallet_id": "wal_123",
  "transactions": [
    {
      "id": "wt_123",
      "type": "credit",
      "amount": 1500.00,
      "balance_after": 50000.00,
      "description": "Payment received",
      "created_at": "2026-03-22T10:00:00Z"
    }
  ]
}
```

---

## 📊 Reports API

### GET /api/reports/summary

تقرير ملخص للمعاملات والإيرادات.

**Query Parameters:**
- `from_date` (ISO string) - من تاريخ
- `to_date` (ISO string) - إلى تاريخ
- `merchant_id` (string, optional) - تاجر محدد

**Request:**
```bash
curl "http://localhost:3000/api/reports/summary?from_date=2026-03-01&to_date=2026-03-31"
```

**Response (200 OK):**
```json
{
  "period": {
    "from": "2026-03-01",
    "to": "2026-03-31"
  },
  "summary": {
    "total_transactions": 1500,
    "total_volume": 750000.00,
    "successful_transactions": 1425,
    "failed_transactions": 75,
    "success_rate": 95.0
  },
  "by_status": {
    "completed": 1425,
    "pending": 50,
    "failed": 25
  }
}
```

---

## 💱 Exchange Rates API

### GET /api/rates/live

الحصول على أسعار الصرف الحية.

**Request:**
```bash
curl http://localhost:3000/api/rates/live
```

**Response (200 OK):**
```json
{
  "timestamp": "2026-03-22T10:00:00Z",
  "base": "USD",
  "rates": {
    "EGP": 48.50,
    "SAR": 3.75,
    "AED": 3.67,
    "KWD": 0.31,
    "BHD": 0.38
  }
}
```

---

### POST /api/rates/convert

تحويل مبلغ من عملة لأخرى.

**Request Body:**
```json
{
  "amount": 100,
  "from": "USD",
  "to": "EGP"
}
```

**Response (200 OK):**
```json
{
  "amount": 100,
  "from": "USD",
  "to": "EGP",
  "rate": 48.50,
  "result": 4850.00,
  "timestamp": "2026-03-22T10:00:00Z"
}
```

---

## 🔐 Authentication

### POST /api/auth/signup

تسجيل مستخدم جديد.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "name": "John Doe",
  "role": "merchant"
}
```

**Response (201 Created):**
```json
{
  "user": {
    "id": "usr_123",
    "email": "user@example.com",
    "role": "merchant"
  },
  "session": {
    "access_token": "eyJhbGciOiJI...",
    "refresh_token": "v1.Mr2V...",
    "expires_at": 1711105200
  }
}
```

---

### POST /api/auth/login

تسجيل الدخول.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

**Response (200 OK):**
```json
{
  "session": {
    "access_token": "eyJhbGciOiJI...",
    "refresh_token": "v1.Mr2V...",
    "expires_at": 1711105200
  },
  "user": {
    "id": "usr_123",
    "email": "user@example.com",
    "role": "merchant"
  }
}
```

---

### POST /api/auth/logout

تسجيل الخروج.

**Headers:**
```
Authorization: Bearer {access_token}
```

**Response (200 OK):**
```json
{
  "message": "Logged out successfully"
}
```

---

## 🔔 Webhooks

### POST /api/webhooks/transaction

استقبال تحديثات المعاملات من payment providers.

**Headers:**
```
X-Webhook-Signature: sha256=xxxxx
Content-Type: application/json
```

**Request Body:**
```json
{
  "event": "transaction.completed",
  "transaction_id": "txn_123",
  "status": "completed",
  "amount": 1500.00,
  "timestamp": "2026-03-22T10:00:00Z"
}
```

**Response (200 OK):**
```json
{
  "received": true,
  "processed": true
}
```

---

## ⚠️ Error Responses

جميع API endpoints تُرجع أخطاء بتنسيق موحد:

### 400 Bad Request
```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Invalid request parameters",
    "details": {
      "field": "amount",
      "issue": "Amount must be positive"
    }
  }
}
```

### 401 Unauthorized
```json
{
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Authentication required"
  }
}
```

### 403 Forbidden
```json
{
  "error": {
    "code": "FORBIDDEN",
    "message": "Insufficient permissions"
  }
}
```

### 404 Not Found
```json
{
  "error": {
    "code": "NOT_FOUND",
    "message": "Resource not found"
  }
}
```

### 500 Internal Server Error
```json
{
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "An unexpected error occurred",
    "request_id": "req_123456"
  }
}
```

---

## 🔒 Authentication & Authorization

### Bearer Token

معظم endpoints تتطلب authentication:

```bash
curl -H "Authorization: Bearer {access_token}" \
  http://localhost:3000/api/endpoint
```

### API Keys (للتجار)

```bash
curl -H "X-API-Key: sk_live_xxxxx" \
  http://localhost:3000/api/endpoint
```

---

## 📝 Rate Limiting

- **Anonymous requests:** 100 requests/hour
- **Authenticated requests:** 1000 requests/hour
- **Merchant API keys:** 10000 requests/hour

Headers في الـ response:
```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1711105200
```

---

## 🧪 Testing

### Local Development
```bash
# Start server
pnpm dev

# Test endpoint
curl http://localhost:3000/api/health
```

### Production
```bash
curl https://your-domain.com/api/health
```

---

## 📚 المزيد من الموارد

- [Supabase API Docs](https://supabase.com/docs/reference/javascript)
- [Next.js API Routes](https://nextjs.org/docs/app/building-your-application/routing/route-handlers)
- [OpenAPI Spec](./openapi.yaml) - قريباً

---

**Last Updated:** March 22, 2026  
**Version:** 3.0.0
