# OnTarget PSP - Mobile App Grid (iPad Style)

## 📱 Overview

A modern iPad-style mobile interface with an app grid launcher, replacing traditional sidebar navigation with colorful app icons in a responsive grid layout.

## 🎨 Features

### 1. **iPad-Style App Grid** (`/mobile-apps`)
- 24 beautifully designed app icons with gradient backgrounds
- 4-column responsive grid layout
- Smooth animations and touch interactions
- iOS-style icon design with rounded corners
- Custom color gradients for each app

### 2. **Themes**
- **Dark Mode** - Pure black background with translucent icons
- **Light Mode** - Clean white background with subtle shadows

### 3. **Dock Navigation**
Fixed bottom dock with 4 essential apps:
- Dashboard
- Transactions
- Wallets
- Settings

### 4. **Bilingual Support**
- Full English and Arabic (RTL) support
- Automatic text direction switching
- Localized app names

## 📂 File Structure

```
/src/app/
├── pages/
│   ├── MobileAppGrid.tsx          # Main iPad-style app grid
│   ├── MobileLanding.tsx          # Splash screen with auto-redirect
│   ├── MobileSettings.tsx         # Theme & language settings
│   ├── MobileTransactionsCenter.tsx
│   ├── MobileTransactionDetails.tsx
│   └── MobileCustomerProfile.tsx
├── context/
│   └── MobileThemeContext.tsx     # Theme management (light/dark only)
├── components/
│   ├── MobileAppLayout.tsx        # Mobile app wrapper with nav
│   ├── MobileAppCard.tsx          # Reusable card component
│   └── MobileStatusBar.tsx        # iOS-style status bar
└── hooks/
    └── useIsMobile.tsx            # Mobile detection hook
```

## 🚀 Usage

### Access Points

1. **Splash Screen**: `/mobile-view`
   - Auto-redirects to app grid after 1.5 seconds

2. **App Grid**: `/mobile-apps`
   - Main iPad-style launcher with all apps

3. **Mobile Routes**: `/mobile/*`
   - Dashboard: `/mobile/dashboard`
   - Transactions: `/mobile/transactions`
   - Wallets: `/mobile/wallets`
   - Settings: `/mobile/settings`

### Adding New Apps

Edit `/src/app/pages/MobileAppGrid.tsx`:

```typescript
const apps: AppIcon[] = [
  {
    id: 'your-app',
    name: 'Your App',
    nameAr: 'تطبيقك',
    icon: YourIcon,           // Lucide icon
    color: '#8b5cf6',         // Primary color
    gradient: 'from-[#8b5cf6] to-[#7c3aed]',
    route: '/your-route',
    category: 'main'
  },
  // ... other apps
];
```

### Customizing Themes

Edit `/src/app/context/MobileThemeContext.tsx`:

```typescript
const themeConfigs: Record<MobileTheme, ThemeConfig> = {
  'dark': {
    name: 'Dark Mode',
    background: 'from-[#000000] via-[#0a0a0a] to-[#000000]',
    appGridBg: 'bg-[#000000]',
    iconBg: 'bg-[#1a1a1a]/80',
    // ... other properties
  },
  'light': {
    // ... light theme config
  }
};
```

## 🎯 App Categories

Apps are organized into logical categories:

- **main** - Core functionality (Dashboard, Transactions, Wallets, Merchants)
- **payment** - Payment processing (Methods, Accounts, Pages)
- **management** - User & business management
- **finance** - Financial operations (Settlement, Payouts)
- **security** - Risk & fraud management
- **analytics** - Reporting & analytics
- **developer** - API documentation
- **integration** - Third-party integrations (Binance)
- **monitoring** - Activity logs & alerts
- **storage** - File management
- **tools** - Automation & utilities
- **system** - Settings & configuration

## 📱 Responsive Design

- **Grid Layout**: 4 columns on mobile/tablet
- **Icon Size**: 70px × 70px with gradient inner circle
- **Spacing**: 24px gap between icons
- **Touch Targets**: Optimized for finger-friendly interaction

## 🎨 Design Tokens

### Dark Theme
- Background: `#000000`
- Icon Background: `#1a1a1a` @ 80% opacity
- Border: White @ 10% opacity
- Shadow: Colored glow matching icon gradient

### Light Theme
- Background: `#f5f5f7`
- Icon Background: White @ 80% opacity
- Border: Gray-200
- Shadow: Subtle black shadow

## ⚡ Performance

- **Lazy Loading**: All routes are code-split
- **Staggered Animations**: Icons animate in sequence (20ms delay)
- **Touch Optimization**: `touch-manipulation` for better mobile performance
- **Backdrop Blur**: Hardware-accelerated blur effects

## 🌐 Internationalization

The app grid supports full bilingual operation:

```typescript
{
  en: 'Dashboard',
  ar: 'لوحة التحكم'
}
```

All app names automatically switch based on selected language.

## 🔗 Navigation Flow

```
/mobile-view (Splash)
    ↓ (1.5s auto-redirect)
/mobile-apps (App Grid)
    ↓ (Click any icon)
/mobile/* or /* (App Pages)
```

## 💡 Best Practices

1. **Icons**: Use Lucide React icons for consistency
2. **Colors**: Choose vibrant, contrasting gradient colors
3. **Names**: Keep app names short (max 2 words)
4. **Routes**: Prefix mobile-specific routes with `/mobile/`
5. **Gradients**: Use 2-color gradients from same color family

## 🛠️ Development

### Theme Toggle
Users can toggle between light/dark themes in Settings:
- Navigate to `/mobile/settings`
- Tap "App Theme"
- Select desired theme

### Language Toggle
Users can switch languages in Settings:
- Navigate to `/mobile/settings`
- Tap language card (English/العربية)

## 📋 TODO / Future Enhancements

- [ ] Add haptic feedback on icon tap
- [ ] Implement folder support for organizing apps
- [ ] Add home screen customization (rearrange icons)
- [ ] Support for app badges (notification counts)
- [ ] Search functionality for finding apps
- [ ] Recently used apps section
- [ ] Swipe gestures for navigation
- [ ] Dark mode auto-switch based on system preference

## 🎉 Conclusion

The iPad-style app grid provides a modern, intuitive mobile experience that's familiar to users while maintaining the professional PSP platform functionality. The design emphasizes visual appeal, ease of use, and seamless navigation between different platform features.
