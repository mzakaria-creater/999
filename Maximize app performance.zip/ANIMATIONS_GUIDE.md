# 🎨 OnTarget PSP - Advanced Animations Guide

## Overview

This guide covers all the advanced animation features implemented in the OnTarget PSP platform using Motion (formerly Framer Motion) and various interaction patterns.

---

## 📦 **Animation Components Library**

### 1. **Page Transitions** (`/src/app/components/PageTransition.tsx`)

Smooth transitions between routes with multiple animation types.

**Usage:**
```tsx
import { PageTransition } from './components/PageTransition';

<PageTransition type="slide">
  <YourPageContent />
</PageTransition>
```

**Animation Types:**
- `fade` - Simple opacity transition
- `slide` - Horizontal slide with fade
- `scale` - Scale with fade
- `blur` - Blur effect transition

**Features:**
- ✅ Automatic route change detection
- ✅ Custom easing curves
- ✅ Wait mode for sequential animations

---

### 2. **AnimatedButton** (`/src/app/components/AnimatedButton.tsx`)

Enhanced button with ripple effects and lift animations.

**Usage:**
```tsx
import { AnimatedButton } from './components/AnimatedButton';

<AnimatedButton 
  variant="primary" 
  ripple={true} 
  lift={true}
  onClick={() => console.log('Clicked!')}
>
  <Download /> Export Report
</AnimatedButton>
```

**Props:**
- `variant` - 'primary' | 'secondary' | 'ghost'
- `ripple` - Enable click ripple effect (default: true)
- `lift` - Enable hover lift animation (default: true)
- `disabled` - Disable button interactions

**Features:**
- ✅ Dynamic ripple effects on click
- ✅ Spring-based hover animations
- ✅ Multiple visual variants
- ✅ Automatic cleanup of ripple animations

---

### 3. **Skeleton Loaders** (`/src/app/components/SkeletonLoader.tsx`)

Modern loading placeholders with shimmer animation.

**Components:**
- `Skeleton` - Base skeleton component
- `DashboardCardSkeleton` - Pre-built dashboard card skeleton
- `TableRowSkeleton` - Table row skeleton
- `ChartSkeleton` - Chart loading state
- `TransactionSkeleton` - Transaction item skeleton

**Usage:**
```tsx
import { DashboardCardSkeleton, TransactionSkeleton } from './components/SkeletonLoader';

{loading ? (
  <DashboardCardSkeleton />
) : (
  <DashboardCard data={data} />
)}
```

**Features:**
- ✅ Animated gradient shimmer
- ✅ Multiple pre-built layouts
- ✅ Customizable shapes and sizes
- ✅ Matches glassmorphic design

---

### 4. **Advanced Chart Animations** (`/src/app/components/AnimatedChart.tsx`)

Enhanced chart components with stagger and spring animations.

**Components:**
- `AnimatedChartWrapper` - Wraps charts with entrance animation
- `AnimatedCounter` - Animated number counter with effects
- `StaggerContainer` & `StaggerItem` - Stagger child animations
- `AnimatedLabel` - Custom animated labels for Recharts

**Usage:**
```tsx
import { AnimatedChartWrapper, StaggerContainer, StaggerItem } from './components/AnimatedChart';

<AnimatedChartWrapper delay={0.2}>
  <ResponsiveContainer>
    <AreaChart data={data}>
      {/* Chart components */}
    </AreaChart>
  </ResponsiveContainer>
</AnimatedChartWrapper>

<StaggerContainer staggerDelay={0.1}>
  {items.map(item => (
    <StaggerItem key={item.id}>
      <ItemCard data={item} />
    </StaggerItem>
  ))}
</StaggerContainer>
```

**Features:**
- ✅ Smooth entrance animations
- ✅ Staggered child reveals
- ✅ Spring-based number counters
- ✅ Custom easing functions

---

### 5. **Swipeable Cards** (`/src/app/components/SwipeableCard.tsx`)

Mobile-optimized swipe-to-action cards.

**Components:**
- `SwipeableCard` - Swipeable card with action indicators
- `SwipeNavigation` - Page-level swipe navigation

**Usage:**
```tsx
import { SwipeableCard } from './components/SwipeableCard';

<SwipeableCard
  leftAction="delete"
  rightAction="approve"
  onSwipeLeft={() => handleDelete(item.id)}
  onSwipeRight={() => handleApprove(item.id)}
  threshold={100}
>
  <TransactionCard data={item} />
</SwipeableCard>
```

**Action Types:**
- `delete` - Red delete action
- `archive` - Yellow archive action
- `approve` - Green approve action

**Features:**
- ✅ Visual action indicators
- ✅ Configurable swipe threshold
- ✅ Spring-based drag physics
- ✅ Auto-reset on incomplete swipe
- ✅ Touch-optimized for mobile

---

### 6. **Confetti Effects** (`/src/app/components/ConfettiEffect.tsx`)

Celebration effects using canvas-confetti.

**Usage:**
```tsx
import { useConfetti } from './components/ConfettiEffect';

function MyComponent() {
  const { fireConfetti } = useConfetti();
  
  const handleSuccess = () => {
    fireConfetti('celebration');
    // Success logic
  };
  
  return <button onClick={handleSuccess}>Complete</button>;
}
```

**Effect Types:**
- `success` - Quick burst celebration
- `celebration` - Extended multi-point fireworks
- `burst` - Large multi-layered explosion
- `rain` - Continuous confetti rain

**Features:**
- ✅ Multiple particle patterns
- ✅ Customizable colors
- ✅ Auto-cleanup
- ✅ Performance optimized

---

### 7. **3D Hover Cards** (`/src/app/components/HoverCard3D.tsx`)

Advanced 3D transform effects on hover.

**Components:**
- `HoverCard3D` - 3D tilt card effect
- `MagneticButton` - Magnetic attraction button
- `FloatingCard` - Continuous floating animation

**Usage:**
```tsx
import { HoverCard3D, MagneticButton } from './components/HoverCard3D';

<HoverCard3D intensity={15} shine={true} scale={true}>
  <DashboardCard data={stats} />
</HoverCard3D>

<MagneticButton strength={0.3} className="btn-primary">
  Submit
</MagneticButton>
```

**Features:**
- ✅ Real 3D perspective transforms
- ✅ Dynamic shine/glare effects
- ✅ Magnetic mouse attraction
- ✅ Spring-based physics
- ✅ Smooth reset on mouse leave

---

## 🎯 **Implementation Examples**

### Dashboard with All Features

```tsx
import { PageTransition } from './components/PageTransition';
import { AnimatedButton } from './components/AnimatedButton';
import { HoverCard3D } from './components/HoverCard3D';
import { useConfetti } from './components/ConfettiEffect';

export function Dashboard() {
  const { fireConfetti } = useConfetti();
  
  const handleExport = () => {
    fireConfetti('success');
    // Export logic
  };
  
  return (
    <PageTransition type="slide">
      <div className="p-8 space-y-6">
        <div className="flex justify-between">
          <h1>Dashboard</h1>
          <AnimatedButton onClick={handleExport} ripple lift>
            Export Report
          </AnimatedButton>
        </div>
        
        <div className="grid grid-cols-4 gap-6">
          {stats.map(stat => (
            <HoverCard3D key={stat.id} intensity={10}>
              <StatCard data={stat} />
            </HoverCard3D>
          ))}
        </div>
      </div>
    </PageTransition>
  );
}
```

### Mobile Transactions with Swipe

```tsx
import { SwipeableCard } from './components/SwipeableCard';
import { useConfetti } from './components/ConfettiEffect';

export function MobileTransactions() {
  const { fireConfetti } = useConfetti();
  
  const handleApprove = (id: string) => {
    fireConfetti('success');
    // Approve transaction
  };
  
  return (
    <div className="space-y-3">
      {transactions.map(tx => (
        <SwipeableCard
          key={tx.id}
          leftAction="delete"
          rightAction="approve"
          onSwipeRight={() => handleApprove(tx.id)}
          onDelete={() => handleDelete(tx.id)}
        >
          <TransactionCard data={tx} />
        </SwipeableCard>
      ))}
    </div>
  );
}
```

### Loading States

```tsx
import { DashboardCardSkeleton } from './components/SkeletonLoader';
import { StaggerContainer, StaggerItem } from './components/AnimatedChart';

export function DashboardCards() {
  if (loading) {
    return (
      <div className="grid grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <DashboardCardSkeleton key={i} />
        ))}
      </div>
    );
  }
  
  return (
    <StaggerContainer staggerDelay={0.1}>
      {stats.map(stat => (
        <StaggerItem key={stat.id}>
          <StatCard data={stat} />
        </StaggerItem>
      ))}
    </StaggerContainer>
  );
}
```

---

## 🎨 **Animation Best Practices**

### Performance Optimization

1. **Use `transform` and `opacity` for animations** (GPU-accelerated)
2. **Avoid animating `width`, `height`, or `position`**
3. **Use `will-change` sparingly** - Motion handles this automatically
4. **Disable animations on low-power mode** - Motion respects `prefers-reduced-motion`

### Timing & Easing

```tsx
// Recommended durations
const DURATIONS = {
  fast: 0.15,    // Button presses
  normal: 0.3,   // Page transitions
  slow: 0.5,     // Complex animations
};

// Recommended easing curves
const EASING = {
  smooth: [0.22, 1, 0.36, 1],      // Custom smooth
  elastic: 'spring',                // Spring physics
  quick: [0.4, 0, 0.2, 1],         // Material Design
};
```

### Accessibility

All animations respect `prefers-reduced-motion`:
```tsx
<motion.div
  animate={{ opacity: 1 }}
  transition={{ 
    duration: 0.3,
    // Automatically disabled if user prefers reduced motion
  }}
>
  Content
</motion.div>
```

---

## 📱 **Mobile Optimizations**

### Touch Gestures

```tsx
// Optimized drag for mobile
<motion.div
  drag="x"
  dragElastic={0.7}
  dragConstraints={{ left: -200, right: 0 }}
  className="touch-pan-y" // Allow vertical scroll
>
  Content
</motion.div>
```

### Reduced Animations

On mobile devices, consider:
- Shorter animation durations (0.2s instead of 0.3s)
- Simpler effects (fade instead of complex 3D)
- Disable heavy effects on low-end devices

---

## 🎭 **Animation Variants**

### Common Patterns

```tsx
// Fade in from bottom
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
};

// Scale bounce
const scaleBounce = {
  initial: { scale: 0.8 },
  animate: { scale: 1 },
  transition: { type: 'spring', stiffness: 500, damping: 30 },
};

// Slide from side
const slideIn = {
  initial: { x: -100, opacity: 0 },
  animate: { x: 0, opacity: 1 },
  exit: { x: 100, opacity: 0 },
};
```

---

## 🚀 **Next Steps**

### Potential Enhancements

1. **Gesture Controls** - Add pinch-to-zoom for charts
2. **Scroll Animations** - Parallax and scroll-triggered animations
3. **Loading Sequences** - Multi-stage loading animations
4. **Micro-interactions** - Success checkmarks, error shakes
5. **Theme Transitions** - Smooth dark/light mode transitions

---

## 📚 **Additional Resources**

- [Motion Documentation](https://motion.dev)
- [Canvas Confetti](https://github.com/catdad/canvas-confetti)
- [Animation Principles](https://www.designbetter.co/animation-handbook)

---

## ✅ **Checklist**

- [x] Page transitions implemented
- [x] Button ripple effects
- [x] Loading skeletons
- [x] Chart animations
- [x] Swipe gestures
- [x] Confetti effects
- [x] 3D hover effects
- [x] Accessibility support
- [x] Mobile optimization

---

**Built with ❤️ for OnTarget PSP**
