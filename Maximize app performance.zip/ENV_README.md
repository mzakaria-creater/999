# 🔐 Environment Configuration - Complete Guide

Welcome to the OnTarget PSP environment configuration system. This guide will help you set up all required environment variables for the payment gateway platform.

---

## 📚 Documentation Index

We've created comprehensive documentation to help you configure the platform:

| Document | Purpose | When to Use |
|----------|---------|-------------|
| **[ENV_SETUP.md](./ENV_SETUP.md)** | Detailed setup guide with step-by-step instructions | First-time setup, troubleshooting |
| **[ENV_QUICK_REFERENCE.md](./ENV_QUICK_REFERENCE.md)** | Quick commands and common configurations | Daily reference, quick lookups |
| **[ENVIRONMENT_VARIABLES.md](./ENVIRONMENT_VARIABLES.md)** | Complete variable reference | Understanding all options |
| **This file** | Overview and getting started | Start here |

---

## 🚀 Quick Start (5 Minutes)

### 1. Copy the Template

```bash
cp .env.example .env
```

### 2. Generate Secure Keys

```bash
# Generate JWT secret
openssl rand -hex 32

# Generate encryption key
openssl rand -hex 32
```

### 3. Edit Your Configuration

```bash
# Open in your editor
nano .env
# or
code .env
```

### 4. Minimum Required Variables

At minimum, set these variables:

```env
NODE_ENV=development
APP_URL=http://localhost:3000
API_URL=http://localhost:8000/api/v1
DATABASE_URL=postgresql://postgres:yourpassword@localhost:5432/ontarget_psp
JWT_SECRET=your_generated_jwt_secret_here
ENCRYPTION_KEY=your_generated_encryption_key_here
STRIPE_SECRET_KEY=sk_test_your_stripe_key_here
```

### 5. Validate

```bash
npm run env:check
```

✅ If all checks pass, you're ready to go!

---

## 📁 What's Included

### Configuration Files

```
.
├── .env.example          # Template with all variables
├── .env                  # Your actual config (gitignored)
├── .gitignore           # Prevents committing secrets
└── scripts/
    └── check-env.js     # Validation script
```

### Documentation Files

```
.
├── ENV_README.md                 # This file - overview
├── ENV_SETUP.md                  # Detailed setup guide (15 min read)
├── ENV_QUICK_REFERENCE.md        # Quick commands (2 min read)
└── ENVIRONMENT_VARIABLES.md      # Complete reference (20 min read)
```

---

## 🎯 Choose Your Path

### Path 1: Just Want to Get Started?
👉 Follow the **Quick Start** above, then read **[ENV_QUICK_REFERENCE.md](./ENV_QUICK_REFERENCE.md)**

### Path 2: Setting Up for Development?
👉 Read **[ENV_SETUP.md](./ENV_SETUP.md)** sections:
- Application Settings
- Database Configuration
- Payment Gateways (pick one to start)
- Testing Configuration

### Path 3: Deploying to Production?
👉 Read **[ENV_SETUP.md](./ENV_SETUP.md)** sections:
- Security Best Practices
- Production Deployment
- All Payment Gateways
- Monitoring & Logging
- Compliance & Regulatory

### Path 4: Need a Specific Feature?
👉 Use **[ENVIRONMENT_VARIABLES.md](./ENVIRONMENT_VARIABLES.md)** to find:
- Email setup → Section 5
- SMS setup → Section 6
- File storage → Section 7
- Fraud detection → Section 9
- Feature flags → Section 12

---

## 🔑 Essential Variables Explained

### Application Settings
```env
NODE_ENV=development        # development | staging | production
APP_URL=http://localhost:3000
API_URL=http://localhost:8000/api/v1
```
Controls the runtime environment and URLs.

### Database
```env
DATABASE_URL=postgresql://user:pass@host:5432/dbname
```
PostgreSQL connection string. All database config in one variable.

### Security
```env
JWT_SECRET=your_32_character_secret_here
ENCRYPTION_KEY=your_32_character_key_here
```
🚨 **CRITICAL:** Must be at least 32 characters. Different for each environment.

### Payment Provider (Choose at least one)
```env
# Option 1: Stripe (International)
STRIPE_SECRET_KEY=sk_test_xxxxx

# Option 2: Paymob (Egypt)
PAYMOB_API_KEY=your_key_here

# Option 3: Fawry (Egypt)
FAWRY_SECRET_KEY=your_key_here
```

---

## 🌍 Environment Types

### Development (Local)
- Test mode enabled
- Mock services allowed
- Verbose logging
- Sample data
- Relaxed security

**File:** `.env` (local, gitignored)

### Staging
- Real integrations
- Test/sandbox API keys
- Production-like data
- Moderate logging
- Enhanced security

**File:** `.env.staging` (never committed)

### Production
- Live API keys
- Real transactions
- Minimal logging
- Maximum security
- Compliance enabled

**File:** Use secrets manager (AWS Secrets Manager, Vault, etc.)

---

## 🔒 Security Checklist

Before deploying to production:

- [ ] All secrets are at least 32 characters
- [ ] No "test", "dev", or "example" in keys
- [ ] JWT_SECRET is unique per environment
- [ ] .env file is in .gitignore
- [ ] Production secrets stored in vault
- [ ] File permissions set to 600: `chmod 600 .env`
- [ ] Different database password for production
- [ ] Using live (not test) API keys
- [ ] SSL/TLS enabled for all connections
- [ ] Backup credentials configured

---

## 🧪 Testing Your Configuration

### Method 1: Use the Validator
```bash
npm run env:check
```

### Method 2: Test Database Connection
```bash
psql $DATABASE_URL -c "SELECT 1"
```

### Method 3: Test Redis Connection
```bash
redis-cli -h $REDIS_HOST -p $REDIS_PORT ping
```

### Method 4: Test API Key
```bash
# Example for Stripe
curl https://api.stripe.com/v1/balance \
  -u $STRIPE_SECRET_KEY:
```

---

## 🆘 Common Issues

### ❌ "DATABASE_URL not set"
**Solution:** Copy `.env.example` to `.env` and configure

### ❌ "Connection refused"
**Solution:** Check if database/Redis is running
```bash
# PostgreSQL
systemctl status postgresql

# Redis
redis-cli ping
```

### ❌ "Invalid JWT token"
**Solution:** Ensure JWT_SECRET is at least 32 characters

### ❌ "Payment provider authentication failed"
**Solution:** Verify API keys are correct and active

### ❌ ".env file not found"
**Solution:** Copy the example file
```bash
cp .env.example .env
```

---

## 📊 Configuration Templates

### Minimal (Development)
```env
NODE_ENV=development
APP_URL=http://localhost:3000
API_URL=http://localhost:8000/api/v1
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/ontarget_psp
JWT_SECRET=dev_jwt_secret_min_32_characters_long
ENCRYPTION_KEY=dev_encryption_key_32_chars_min
STRIPE_SECRET_KEY=sk_test_xxxxx
```

### Standard (Staging)
All minimal variables plus:
```env
REDIS_HOST=staging-redis.example.com
SMTP_HOST=smtp.sendgrid.net
SENDGRID_API_KEY=SG.xxxxx
SENTRY_DSN=https://xxxxx@sentry.io/xxxxx
PAYMOB_API_KEY=test_key_xxxxx
FAWRY_SECRET_KEY=test_key_xxxxx
```

### Full (Production)
All standard variables plus:
```env
# Use live API keys
STRIPE_SECRET_KEY=sk_live_xxxxx
PAYMOB_API_KEY=live_key_xxxxx

# Enhanced security
PCI_COMPLIANT_MODE=true
AML_SCREENING_ENABLED=true
CBE_REPORTING_ENABLED=true

# Monitoring
SENTRY_ENVIRONMENT=production
LOG_LEVEL=warn

# Compliance
DATA_RETENTION_DAYS=2555
```

---

## 🎓 Learning Path

### Beginner (Just Getting Started)
1. Read this file
2. Follow Quick Start
3. Skim ENV_QUICK_REFERENCE.md
4. Start developing!

### Intermediate (Setting Up Services)
1. Read ENV_SETUP.md sections as needed
2. Configure payment providers
3. Set up email/SMS
4. Enable monitoring

### Advanced (Production Deployment)
1. Read entire ENV_SETUP.md
2. Study ENVIRONMENT_VARIABLES.md
3. Set up secrets management
4. Configure compliance features
5. Enable all monitoring

---

## 🔗 External Resources

### Payment Providers
- **Stripe:** https://stripe.com/docs
- **Paymob:** https://docs.paymob.com
- **Fawry:** https://developer.fawry.com

### Services
- **SendGrid (Email):** https://docs.sendgrid.com
- **Twilio (SMS):** https://www.twilio.com/docs
- **Sentry (Monitoring):** https://docs.sentry.io
- **AWS S3 (Storage):** https://docs.aws.amazon.com/s3

### Security
- **Generate Keys:** https://randomkeygen.com
- **Secrets Management:** https://www.vaultproject.io

---

## 📞 Getting Help

### Documentation Issues
Found an error or need clarification?
- Open an issue on GitHub
- Email: docs@ontargetpsp.com

### Configuration Support
Need help setting up?
- Email: devops@ontargetpsp.com
- Slack: #ontarget-devops
- Documentation: https://docs.ontargetpsp.com

### Security Concerns
Found a security issue?
- Email: security@ontargetpsp.com
- **DO NOT** open public issues for security problems

---

## 🗺️ What's Next?

After configuring your environment:

1. **Start the Application**
   ```bash
   npm install
   npm run dev
   ```

2. **Run Migrations**
   ```bash
   npm run db:migrate
   ```

3. **Seed Sample Data**
   ```bash
   npm run db:seed
   ```

4. **Test API Endpoints**
   ```bash
   curl http://localhost:8000/api/v1/health
   ```

5. **Access Dashboard**
   ```
   http://localhost:3000
   ```

---

## 📝 Changelog

### Version 1.0.0 (March 14, 2026)
- Initial environment configuration system
- Complete documentation suite
- Validation script
- Support for 10+ payment providers
- Security best practices guide

---

## 📄 License

© 2026 OnTarget PSP. All rights reserved.

---

## ✨ Tips & Tricks

### Tip 1: Use Environment-Specific Files
```bash
# Development
cp .env.example .env

# Staging
cp .env.example .env.staging

# Production - use secrets manager instead
```

### Tip 2: Version Control Your .env.example
```bash
# Always commit the example
git add .env.example
git commit -m "Update environment template"

# Never commit actual .env
git status  # Should NOT show .env
```

### Tip 3: Automate Validation in CI/CD
```yaml
# .github/workflows/deploy.yml
- name: Validate Environment
  run: npm run env:check
```

### Tip 4: Document Custom Variables
If you add custom variables, document them:
```env
# Custom: Your specific use case
MY_CUSTOM_VAR=value  # Description of what this does
```

---

**🎉 You're all set! Choose your documentation path above and get started.**

---

**Version:** 1.0.0  
**Last Updated:** March 14, 2026  
**Maintained by:** OnTarget PSP DevOps Team
