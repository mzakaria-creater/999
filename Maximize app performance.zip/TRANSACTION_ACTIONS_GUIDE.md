# Transaction Actions Guide

## Overview
This guide explains how to use the transaction action functions in the OnTarget PSP platform. The system provides both specific action functions and a generic `executeTransactionAction` function for maximum flexibility.

## Table of Contents
- [Quick Start](#quick-start)
- [Available Actions](#available-actions)
- [API Functions](#api-functions)
- [Usage Examples](#usage-examples)
- [UI Component](#ui-component)
- [Error Handling](#error-handling)
- [Best Practices](#best-practices)

---

## Quick Start

### Basic Import
```typescript
import {
  executeTransactionAction,
  approveTransaction,
  rejectTransaction,
  markTransactionPaid,
  verifyPayment,
  refundTransaction,
  cancelTransaction,
  type TransactionActionRequest
} from '../utils/transactionApi';
```

### Simple Example
```typescript
// Approve a transaction
const response = await approveTransaction('TRX_123456', 'Approved by admin');

if (response.success) {
  console.log('Transaction approved:', response.data);
} else {
  console.error('Error:', response.error?.message);
}
```

---

## Available Actions

### 1. **Approve** (`approve`)
- **Description**: Approve a pending or processing transaction
- **Status Flow**: `pending` → `paid` or `processing` → `completed`
- **Use Cases**: Manual approval after verification

### 2. **Reject** (`reject`)
- **Description**: Reject a transaction
- **Status Flow**: `pending/processing` → `declined`
- **Required**: `reason` parameter
- **Use Cases**: Fraud detection, failed verification

### 3. **Mark Paid** (`mark_paid`)
- **Description**: Manually mark a transaction as paid
- **Status Flow**: `processing` → `paid`
- **Optional**: `proof_image_url`
- **Use Cases**: Manual payment confirmation

### 4. **Verify Payment** (`verify_payment`)
- **Description**: Verify uploaded payment proof
- **Required**: `verified` boolean
- **Use Cases**: Review and verify payment screenshots

### 5. **Refund** (`refund`)
- **Description**: Process a refund for a completed transaction
- **Status Flow**: `paid/completed` → `refunded`
- **Optional**: `refund_amount` (defaults to full amount)
- **Use Cases**: Customer refund requests

### 6. **Cancel** (`cancel`)
- **Description**: Cancel a pending transaction
- **Status Flow**: `pending` → `cancelled`
- **Optional**: `reason`
- **Use Cases**: Customer cancellation, expired sessions

---

## API Functions

### Generic Function: `executeTransactionAction`

The most flexible function that can execute any action:

```typescript
async function executeTransactionAction(
  transactionId: string,
  actionRequest: TransactionActionRequest
): Promise<ApiResponse<Transaction>>
```

**Parameters:**
```typescript
interface TransactionActionRequest {
  action: 'approve' | 'reject' | 'refund' | 'cancel' | 'mark_paid' | 'verify_payment';
  reason?: string;
  refund_amount?: number;
  notes?: string;
}
```

**Example:**
```typescript
const response = await executeTransactionAction('TRX_123456', {
  action: 'approve',
  notes: 'Verified via bank statement'
});
```

---

### Specific Action Functions

#### 1. Approve Transaction
```typescript
async function approveTransaction(
  transactionId: string,
  notes?: string
): Promise<ApiResponse<Transaction>>
```

**Example:**
```typescript
const response = await approveTransaction(
  'TRX_123456',
  'Payment proof verified manually'
);
```

---

#### 2. Reject Transaction
```typescript
async function rejectTransaction(
  transactionId: string,
  reason: string,
  notes?: string
): Promise<ApiResponse<Transaction>>
```

**Example:**
```typescript
const response = await rejectTransaction(
  'TRX_123456',
  'Invalid payment proof',
  'Screenshot appears to be edited'
);
```

---

#### 3. Mark Transaction as Paid
```typescript
async function markTransactionPaid(
  transactionId: string,
  proofImageUrl?: string,
  notes?: string
): Promise<ApiResponse<Transaction>>
```

**Example:**
```typescript
const response = await markTransactionPaid(
  'TRX_123456',
  'https://cdn.example.com/proof.jpg',
  'Confirmed via bank transfer receipt'
);
```

---

#### 4. Verify Payment
```typescript
async function verifyPayment(
  transactionId: string,
  verified: boolean,
  notes?: string
): Promise<ApiResponse<Transaction>>
```

**Example:**
```typescript
// Verify payment
const response = await verifyPayment(
  'TRX_123456',
  true,
  'Payment proof matches transaction details'
);

// Reject verification
const response = await verifyPayment(
  'TRX_123456',
  false,
  'Payment proof is unclear'
);
```

---

#### 5. Refund Transaction
```typescript
async function refundTransaction(
  transactionId: string,
  refundAmount?: number,
  reason?: string,
  notes?: string
): Promise<ApiResponse<Transaction>>
```

**Example:**
```typescript
// Full refund
const response = await refundTransaction(
  'TRX_123456',
  undefined, // Full amount
  'Product not delivered',
  'Customer requested refund'
);

// Partial refund
const response = await refundTransaction(
  'TRX_123456',
  50.00, // Partial amount
  'Partial service cancellation',
  'Refunded 50% as per policy'
);
```

---

#### 6. Cancel Transaction
```typescript
async function cancelTransaction(
  transactionId: string,
  reason?: string,
  notes?: string
): Promise<ApiResponse<Transaction>>
```

**Example:**
```typescript
const response = await cancelTransaction(
  'TRX_123456',
  'Customer changed mind',
  'Cancelled within 15-minute window'
);
```

---

## Usage Examples

### Example 1: React Component with State Management

```typescript
import { useState } from 'react';
import { approveTransaction, rejectTransaction } from '../utils/transactionApi';
import { toast } from 'sonner';

function TransactionReview({ transaction }) {
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    setLoading(true);
    
    const response = await approveTransaction(
      transaction.id,
      'Approved after manual review'
    );

    if (response.success) {
      toast.success('Transaction approved!');
      // Update local state or refetch data
    } else {
      toast.error(response.error?.message || 'Failed to approve');
    }
    
    setLoading(false);
  };

  const handleReject = async () => {
    setLoading(true);
    
    const response = await rejectTransaction(
      transaction.id,
      'Suspicious activity detected',
      'Flagged by fraud detection system'
    );

    if (response.success) {
      toast.success('Transaction rejected');
    } else {
      toast.error(response.error?.message || 'Failed to reject');
    }
    
    setLoading(false);
  };

  return (
    <div className="flex gap-2">
      <button 
        onClick={handleApprove} 
        disabled={loading}
        className="px-4 py-2 bg-green-500 text-white rounded"
      >
        Approve
      </button>
      <button 
        onClick={handleReject} 
        disabled={loading}
        className="px-4 py-2 bg-red-500 text-white rounded"
      >
        Reject
      </button>
    </div>
  );
}
```

---

### Example 2: Bulk Actions

```typescript
import { bulkApproveTransactions, bulkRejectTransactions } from '../utils/transactionApi';

async function handleBulkApprove(transactionIds: string[]) {
  const response = await bulkApproveTransactions(
    transactionIds,
    'Bulk approved by admin'
  );

  if (response.success) {
    console.log(`Processed: ${response.data.processed}`);
    console.log(`Failed: ${response.data.failed}`);
  }
}

// Usage
handleBulkApprove(['TRX_001', 'TRX_002', 'TRX_003']);
```

---

### Example 3: Using Generic Action Function

```typescript
import { executeTransactionAction } from '../utils/transactionApi';

async function handleCustomAction(transactionId: string) {
  // Flexible - can execute any action
  const response = await executeTransactionAction(transactionId, {
    action: 'refund',
    refund_amount: 100.00,
    reason: 'Customer complaint',
    notes: 'Processed via customer service ticket #12345'
  });

  return response;
}
```

---

### Example 4: With Error Handling and Retry Logic

```typescript
async function robustTransactionAction(
  transactionId: string, 
  maxRetries = 3
) {
  let attempts = 0;

  while (attempts < maxRetries) {
    try {
      const response = await approveTransaction(transactionId);
      
      if (response.success) {
        return response.data;
      }
      
      // Handle specific error codes
      if (response.error?.code === 'network_error') {
        attempts++;
        await new Promise(resolve => setTimeout(resolve, 1000 * attempts));
        continue;
      }
      
      // Non-retryable error
      throw new Error(response.error?.message);
      
    } catch (error) {
      if (attempts === maxRetries - 1) throw error;
      attempts++;
    }
  }
}
```

---

## UI Component

### Using the TransactionActions Component

The platform includes a pre-built `TransactionActions` component:

```typescript
import { TransactionActions } from '../components/TransactionActions';

function TransactionDetail({ transaction }) {
  const handleActionComplete = (updatedTransaction) => {
    console.log('Transaction updated:', updatedTransaction);
    // Refresh data or update state
  };

  return (
    <div>
      <h2>Transaction: {transaction.transaction_id}</h2>
      
      {/* Full view with all actions */}
      <TransactionActions 
        transaction={transaction}
        onActionComplete={handleActionComplete}
      />
      
      {/* Compact view (icon buttons only) */}
      <TransactionActions 
        transaction={transaction}
        onActionComplete={handleActionComplete}
        compact={true}
      />
    </div>
  );
}
```

---

## Error Handling

### Response Structure

All action functions return a consistent response:

```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}
```

### Common Error Codes

| Code | Description | Action |
|------|-------------|--------|
| `validation_error` | Invalid parameters | Check input data |
| `unauthorized` | Invalid API key | Verify authentication |
| `not_found` | Transaction not found | Check transaction ID |
| `invalid_status` | Cannot perform action in current status | Check transaction status |
| `network_error` | Network failure | Retry request |
| `rate_limited` | Too many requests | Wait and retry |

### Error Handling Example

```typescript
const response = await approveTransaction(transactionId);

if (!response.success) {
  switch (response.error?.code) {
    case 'validation_error':
      toast.error('Invalid transaction data');
      break;
    case 'invalid_status':
      toast.error('Transaction cannot be approved in current status');
      break;
    case 'network_error':
      toast.error('Network error. Please try again.');
      break;
    default:
      toast.error(response.error?.message || 'Unknown error occurred');
  }
}
```

---

## Best Practices

### 1. Always Check Response Status
```typescript
const response = await approveTransaction(transactionId);

if (response.success && response.data) {
  // Success - use response.data
} else {
  // Error - handle response.error
}
```

### 2. Provide Meaningful Notes
```typescript
// ❌ Bad
await approveTransaction(txId, 'ok');

// ✅ Good
await approveTransaction(
  txId, 
  'Approved after verifying bank statement and customer ID'
);
```

### 3. Use Specific Functions When Possible
```typescript
// ❌ Less readable
await executeTransactionAction(txId, { action: 'approve' });

// ✅ More explicit
await approveTransaction(txId);
```

### 4. Handle Loading States
```typescript
const [loading, setLoading] = useState(false);

const handleAction = async () => {
  setLoading(true);
  try {
    await approveTransaction(txId);
  } finally {
    setLoading(false); // Always reset loading state
  }
};
```

### 5. Validate Before Action
```typescript
async function handleRefund(amount: number) {
  // Validate first
  if (amount <= 0 || amount > transaction.amount) {
    toast.error('Invalid refund amount');
    return;
  }

  // Then execute
  const response = await refundTransaction(
    transaction.id,
    amount,
    'Customer refund request'
  );
}
```

### 6. Use TypeScript Types
```typescript
import type { 
  Transaction, 
  TransactionActionRequest,
  ApiResponse 
} from '../utils/transactionApi';

// Full type safety
const handleAction = async (
  txId: string
): Promise<Transaction | null> => {
  const response: ApiResponse<Transaction> = await approveTransaction(txId);
  return response.success ? response.data || null : null;
};
```

---

## API Endpoint Reference

All transaction actions use this endpoint:

```
POST /transactions/{transaction_id}/actions
```

**Headers:**
```
Authorization: Bearer {api_key}
Content-Type: application/json
```

**Request Body:**
```json
{
  "action": "approve",
  "reason": "Optional reason",
  "refund_amount": 100.00,
  "notes": "Optional notes"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "TRX_123456",
    "status": "completed",
    "amount": 1000,
    "currency": "EGP",
    ...
  }
}
```

---

## Testing

### Mock API for Testing

```typescript
// Mock function for testing
const mockApproveTransaction = async (txId: string) => {
  return {
    success: true,
    data: {
      id: txId,
      transaction_id: txId,
      status: 'completed',
      amount: 1000,
      currency: 'EGP'
    } as Transaction
  };
};

// Use in tests
test('approves transaction', async () => {
  const response = await mockApproveTransaction('TRX_TEST');
  expect(response.success).toBe(true);
  expect(response.data?.status).toBe('completed');
});
```

---

## Support

For issues or questions:
- Check the [API Documentation](/api-docs)
- Review error codes in the response
- Contact support with transaction ID and error details

---

**Last Updated:** March 2026  
**Version:** 1.0.0  
**Platform:** OnTarget PSP
