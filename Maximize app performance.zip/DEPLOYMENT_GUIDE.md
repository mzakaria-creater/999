# 🚀 دليل النشر على Vercel - OnTarget PSP

## 📋 المتطلبات الأساسية

- حساب على [Vercel](https://vercel.com)
- حساب على [Supabase](https://supabase.com) (اختياري)
- Git repository على GitHub/GitLab/Bitbucket

---

## 🎯 خطوات النشر السريع

### 1️⃣ رفع المشروع على Git

```bash
# تهيئة Git repository
git init
git add .
git commit -m "Initial commit: OnTarget PSP v2.6.0"

# ربط المشروع بـ GitHub
git remote add origin https://github.com/username/ontarget-psp.git
git branch -M main
git push -u origin main
```

### 2️⃣ الربط مع Vercel

#### الطريقة الأولى: من خلال واجهة Vercel

1. اذهب إلى [Vercel Dashboard](https://vercel.com/dashboard)
2. انقر على **"Add New Project"**
3. اختر Git repository الخاص بك
4. اختر **"Next.js"** كـ Framework Preset
5. انقر على **"Deploy"**

#### الطريقة الثانية: باستخدام Vercel CLI

```bash
# تثبيت Vercel CLI
npm i -g vercel

# تسجيل الدخول
vercel login

# نشر المشروع
vercel

# نشر على Production
vercel --prod
```

### 3️⃣ إعداد Environment Variables

في Vercel Dashboard، اذهب إلى:
**Settings → Environment Variables**

أضف المتغيرات التالية:

#### Supabase (مطلوب)
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SUPABASE_DB_URL=postgresql://...
```

#### APIs الخارجية (اختياري)
```env
OPENAI_API_KEY=sk-...
STRIPE_SECRET_KEY=sk_test_...
PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...
```

---

## ⚙️ إعدادات Vercel المتقدمة

### Build Settings

```json
{
  "buildCommand": "pnpm run build",
  "devCommand": "pnpm run dev",
  "installCommand": "pnpm install",
  "outputDirectory": ".next"
}
```

### Region Settings

- اختر **Dubai (DUB1)** للحصول على أفضل أداء في الشرق الأوسط
- أو **Frankfurt (FRA1)** كبديل

### Domain Settings

1. اذهب إلى **Settings → Domains**
2. أضف Domain مخصص: `ontarget-psp.com`
3. قم بتحديث DNS records حسب التعليمات

---

## 🔧 Build Commands

### Development
```bash
pnpm dev
# أو
npm run dev
```

### Production Build
```bash
pnpm build
pnpm start
```

### Lint
```bash
pnpm lint
```

---

## 📊 مراقبة الأداء

### Vercel Analytics

1. اذهب إلى **Analytics** في Dashboard
2. فعّل **Web Analytics** لمراقبة:
   - Page Views
   - Load Times
   - Core Web Vitals

### Vercel Speed Insights

1. اذهب إلى **Speed Insights**
2. راقب:
   - First Contentful Paint (FCP)
   - Largest Contentful Paint (LCP)
   - Cumulative Layout Shift (CLS)

---

## 🔄 CI/CD Automation

### Auto-Deploy من Git

Vercel يقوم تلقائياً بـ:

- ✅ Deploy عند كل `git push` إلى `main`
- ✅ Preview deployments لكل Pull Request
- ✅ Automatic rollback عند فشل البناء

### GitHub Actions (اختياري)

قم بإنشاء `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Vercel

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: pnpm/action-setup@v2
        with:
          version: 8
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'pnpm'
      - run: pnpm install
      - run: pnpm build
      - uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

---

## 🐛 استكشاف الأخطاء

### خطأ Build Failed

```bash
# تحقق من الأخطاء محلياً
pnpm build

# تحقق من النسخ المتوافقة
pnpm install

# نظف Cache
rm -rf .next node_modules
pnpm install
pnpm build
```

### خطأ Environment Variables

- تأكد من إضافة جميع المتغيرات في Vercel
- تحقق من عدم وجود مسافات زائدة في القيم
- أعد Deploy بعد تحديث المتغيرات

### مشاكل RTL/Arabic

- تأكد من إضافة `dir="rtl"` في `app/layout.tsx`
- تحقق من تحميل خط Tajawal بشكل صحيح

---

## 📱 PWA Deployment

المشروع يدعم PWA تلقائياً مع:

- ✅ Service Worker (`/public/sw.js`)
- ✅ Web Manifest (`/public/manifest.json`)
- ✅ Offline Support
- ✅ Install to Home Screen

---

## 🔐 الأمان

### Headers مضبوطة تلقائياً:

- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: SAMEORIGIN`
- `X-XSS-Protection: 1; mode=block`
- `Strict-Transport-Security`
- `Referrer-Policy`

### التوصيات:

- ✅ استخدم HTTPS دائماً
- ✅ فعّل Vercel Firewall
- ✅ راقب Logs بانتظام
- ✅ حدّث Dependencies بشكل دوري

---

## 📈 تحسين الأداء

### Image Optimization

```tsx
import Image from 'next/image';

<Image
  src="/image.jpg"
  alt="Description"
  width={800}
  height={600}
  priority // للصور المهمة فوق Fold
/>
```

### Code Splitting

Next.js يقوم بـ code splitting تلقائياً

### Caching

```tsx
// app/api/route.ts
export const revalidate = 3600; // Cache لمدة ساعة
```

---

## 🎉 ما بعد النشر

### 1. اختبر المنصة

- ✅ اختبر جميع الصفحات
- ✅ تحقق من RTL
- ✅ اختبر Mobile responsive
- ✅ تحقق من Supabase connection

### 2. راقب الأداء

- افحص Vercel Analytics
- راقب Error Logs
- تابع Core Web Vitals

### 3. شارك الرابط

```
https://ontarget-psp.vercel.app
```

---

## 📞 الدعم

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js Documentation](https://nextjs.org/docs)
- [Supabase Documentation](https://supabase.com/docs)

---

## 🎯 Checklist النشر

- [ ] رفع المشروع على Git
- [ ] ربط Repository مع Vercel
- [ ] إضافة Environment Variables
- [ ] اختيار Region المناسب
- [ ] تفعيل Analytics
- [ ] اختبار Build محلياً
- [ ] Deploy إلى Production
- [ ] اختبار شامل للمنصة
- [ ] إضافة Domain مخصص (اختياري)
- [ ] تفعيل SSL Certificate

---

**تم بناء هذا المشروع بـ ❤️ باستخدام Next.js و Tailwind CSS**

**Version:** 2.6.0  
**Framework:** Next.js 15.3  
**License:** Private
