# 🖥️ Desktop Sidebar System - Quick Guide

## نظام Sidebar للشاشات الكبيرة - دليل سريع

### 📋 Overview / نظرة عامة

نظام Sidebar متقدم للشاشات الأكبر من iPad (>= 1024px) مع دعم كامل للـ RTL وتأثيرات glassmorphic حديثة.

---

## 🎯 Components / المكونات

### 1. **DesktopDetailsSidebar** (Generic/عام)
مكون sidebar قابل لإعادة الاستخدام لأي نوع من المحتوى.

```tsx
import { DesktopDetailsSidebar } from '@/components/DesktopDetailsSidebar';

<DesktopDetailsSidebar
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
  title="Title"
  icon="🎯"
  subtitle="Optional subtitle"
  width="480px" // optional, default 480px
>
  {/* Your content here */}
</DesktopDetailsSidebar>
```

**Features:**
- ✅ RTL Support (auto-detects language)
- ✅ Spring animations
- ✅ Customizable width
- ✅ Glassmorphic design
- ✅ Gradient glow effects

---

### 2. **DesktopMerchantSidebar** (Specialized/متخصص)
Sidebar متخصص لعرض تفاصيل التجار.

```tsx
import { DesktopMerchantSidebar } from '@/components/DesktopMerchantSidebar';

const merchantDetail = {
  id: 'MCH-001',
  name: 'PayLink Egypt',
  code: 'PL',
  country: 'Egypt',
  status: 'active' | 'gold' | 'inactive',
  volumeToday: 'EGP 124.6K',
  joined: 'Mar 2021',
  group: 'Premium Partners',
  tabs: [...],
  volumeData: [...],
  paymentMethods: [...],
  stats: {...}
};

<DesktopMerchantSidebar
  merchant={merchantDetail}
  onClose={() => setSelectedMerchant(null)}
/>
```

**Features:**
- 📊 Animated 7-day volume chart
- 💳 Payment methods breakdown
- 📈 Success rate & statistics
- 🏷️ Interactive tabs
- 📱 Click merchant row to open

---

### 3. **DashboardWalletSidebar** (Example/مثال)
Sidebar لعرض تفاصيل المحافظ المالية.

```tsx
import { DashboardWalletSidebar } from '@/components/DashboardWalletSidebar';

const walletDetail = {
  id: 'WALLET-001',
  name: 'Main Wallet',
  balance: 125430.50,
  currency: 'USD',
  transactions24h: 87,
  volumeChange: 12.5,
  recentTransactions: [...],
  monthlyStats: {...}
};

<DashboardWalletSidebar
  wallet={walletDetail}
  onClose={() => setSelectedWallet(null)}
/>
```

---

### 4. **TransactionDetailsSidebar** (Example/مثال)
Sidebar لعرض تفاصيل المعاملات.

```tsx
import { TransactionDetailsSidebar } from '@/components/TransactionDetailsSidebar';

<TransactionDetailsSidebar
  transaction={selectedTransaction}
  onClose={() => setSelectedTransaction(null)}
/>
```

---

## 🎨 Design Features / ميزات التصميم

### Glassmorphic Effect
```css
background: linear-gradient(to-br, 
  rgba(26, 29, 35, 0.98),
  rgba(22, 24, 29, 0.98),
  rgba(18, 20, 23, 0.98)
);
backdrop-filter: blur(40px);
border: 1px solid rgba(255, 255, 255, 0.1);
```

### Gradient Accents
- **Primary**: `#8b5cf6` → `#3b82f6` (Purple to Blue)
- **Secondary**: `#6ee7b7` → `#06b6d4` (Mint to Aqua)
- **Top Border**: Gradient glow effect
- **Bottom Glow**: Fade gradient overlay

### Animations
```tsx
// Spring slide-in
initial={{ x: isRTL ? '-100%' : '100%', opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
exit={{ x: isRTL ? '-100%' : '100%', opacity: 0 }}
transition={{ type: 'spring', damping: 25, stiffness: 200 }}
```

---

## 💻 Smart Screen Detection / كشف الشاشة الذكي

### في صفحة Merchants
```tsx
onClick={() => {
  // Screens >= 1024px: Show sidebar
  if (window.innerWidth >= 1024) {
    setSelectedMerchantId(merchant.id);
  } 
  // Screens < 1024px: Navigate to detail page
  else {
    navigate(`/merchants/${merchant.id}`);
  }
}}
```

### Breakpoints
- **Mobile**: < 640px → Auto-redirect to `/mobile/apps`
- **Tablet**: 640px - 1023px → Navigate to detail page
- **Desktop**: >= 1024px → Show sidebar on same page

---

## 🔧 Implementation Steps / خطوات التطبيق

### Step 1: Import Component
```tsx
import { DesktopDetailsSidebar } from '@/components/DesktopDetailsSidebar';
```

### Step 2: Add State
```tsx
const [selectedItem, setSelectedItem] = useState<ItemType | null>(null);
```

### Step 3: Render Sidebar
```tsx
{selectedItem && (
  <DesktopDetailsSidebar
    isOpen={!!selectedItem}
    onClose={() => setSelectedItem(null)}
    title={selectedItem.name}
    icon="🎯"
  >
    {/* Your content */}
  </DesktopDetailsSidebar>
)}
```

---

## 📱 RTL Support / دعم RTL

Auto-detects language from context:
```tsx
const { language } = useLanguage();
const isRTL = language === 'ar';

// Auto-positions sidebar
className={`fixed top-0 ${isRTL ? 'left-0' : 'right-0'}`}

// Auto-adjusts border
border-${isRTL ? 'r' : 'l'}

// Auto-adjusts shadow
boxShadow: isRTL 
  ? '4px 0 40px rgba(139, 92, 246, 0.15)...'
  : '-4px 0 40px rgba(139, 92, 246, 0.15)...'
```

---

## 🎯 Use Cases / حالات الاستخدام

### ✅ When to Use Sidebar
- Merchant details
- Transaction details
- Wallet information
- User profiles
- Quick preview panels
- Settings panels

### ❌ When NOT to Use
- Complex forms (use modal)
- Multi-step processes (use modal)
- Full-page content
- Mobile screens (< 1024px)

---

## 🚀 Next Steps / الخطوات التالية

1. **Add to More Pages**: Dashboard, Wallets, Users, etc.
2. **Create More Specialized Sidebars**: User details, Wallet details, etc.
3. **Add Keyboard Shortcuts**: ESC to close, arrow keys to navigate
4. **Add Loading States**: Skeleton loaders while fetching data
5. **Add Error States**: Error handling and retry buttons

---

## 📊 Performance Tips / نصائح الأداء

- ✅ Use `AnimatePresence` for smooth exit animations
- ✅ Lazy load sidebar content when opened
- ✅ Memoize expensive calculations
- ✅ Use virtual scrolling for long lists
- ✅ Debounce search inputs

---

## 🔍 Accessibility / إمكانية الوصول

- ✅ Keyboard navigation (ESC to close)
- ✅ Focus trap within sidebar
- ✅ ARIA labels for screen readers
- ✅ High contrast mode support
- ✅ Reduced motion preference

---

## 📝 Version History / تاريخ الإصدارات

- **v2.3.0** (2026-03-16): Initial sidebar system release
  - DesktopDetailsSidebar (generic)
  - DesktopMerchantSidebar (specialized)
  - DashboardWalletSidebar (example)
  - TransactionDetailsSidebar (example)
  - RTL support
  - Smart screen detection
  - Glassmorphic design

---

## 🎉 تم بنجاح! Successfully Implemented!

الآن لديك نظام sidebar متقدم مع دعم كامل للشاشات الكبيرة! 🚀

Your platform now has a professional sidebar system for large screens! 🎯
