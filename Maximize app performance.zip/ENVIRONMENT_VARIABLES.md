# 🔐 OnTarget PSP - Environment Variables Documentation

## Overview

This document provides a complete reference for all environment variables used in the OnTarget PSP payment gateway platform.

---

## 📁 Files Created

| File | Purpose |
|------|---------|
| `.env.example` | Template with all available variables and descriptions |
| `.env` | Your actual configuration (gitignored, DO NOT commit) |
| `.gitignore` | Ensures sensitive files are not committed |
| `ENV_SETUP.md` | Comprehensive setup guide with instructions |
| `ENV_QUICK_REFERENCE.md` | Quick reference for common configurations |
| `scripts/check-env.js` | Environment validation script |

---

## 🚀 Getting Started

### 1. Initial Setup

```bash
# Copy the example file
cp .env.example .env

# Edit with your values
nano .env
```

### 2. Validate Configuration

```bash
# Run the validator
npm run env:check

# Or directly
node scripts/check-env.js
```

### 3. Generate Secure Keys

```bash
# Generate JWT secret
openssl rand -hex 32

# Generate encryption key
openssl rand -hex 32
```

---

## 📋 Variable Categories

### 1. **Application Settings** (Required)

Variables that control the basic application behavior.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `NODE_ENV` | string | `development` | Environment mode: development, staging, production |
| `APP_NAME` | string | `OnTarget PSP` | Application display name |
| `APP_URL` | string | `http://localhost:3000` | Frontend application URL |
| `API_URL` | string | `http://localhost:8000/api/v1` | Backend API URL |
| `PORT` | number | `8000` | Backend server port |
| `ALLOWED_ORIGINS` | string | `http://localhost:3000` | Comma-separated CORS origins |

**Example:**
```env
NODE_ENV=production
APP_URL=https://app.ontargetpsp.com
API_URL=https://api.ontargetpsp.com/v1
```

---

### 2. **Database Configuration** (Required)

PostgreSQL database connection settings.

| Variable | Type | Required | Description |
|----------|------|----------|-------------|
| `DATABASE_URL` | string | ✅ Yes | Full PostgreSQL connection string |
| `DB_HOST` | string | No | Database host (alternative to URL) |
| `DB_PORT` | number | No | Database port (default: 5432) |
| `DB_NAME` | string | No | Database name |
| `DB_USER` | string | No | Database username |
| `DB_PASSWORD` | string | No | Database password |
| `DB_SSL` | boolean | No | Enable SSL connection |
| `DB_POOL_MIN` | number | No | Minimum connection pool size |
| `DB_POOL_MAX` | number | No | Maximum connection pool size |

**Example:**
```env
DATABASE_URL=postgresql://ontarget:SecurePass123@db.example.com:5432/ontarget_psp?sslmode=require
```

---

### 3. **Authentication & Security** (Required)

Critical security variables for authentication and encryption.

| Variable | Type | Min Length | Description |
|----------|------|------------|-------------|
| `JWT_SECRET` | string | 32 chars | Secret for signing JWT access tokens |
| `JWT_REFRESH_SECRET` | string | 32 chars | Secret for signing refresh tokens |
| `JWT_ACCESS_EXPIRY` | string | - | Access token lifetime (e.g., "15m") |
| `JWT_REFRESH_EXPIRY` | string | - | Refresh token lifetime (e.g., "7d") |
| `ENCRYPTION_KEY` | string | 32 chars | Key for encrypting sensitive data |
| `AES_SECRET_KEY` | string | 32 chars | AES encryption key |
| `API_KEY_SALT` | string | - | Salt for API key generation |
| `WEBHOOK_SECRET` | string | 32 chars | Secret for webhook signature verification |
| `BCRYPT_ROUNDS` | number | - | Password hashing rounds (10-12) |

**Security Notes:**
- ⚠️ **NEVER** use default or example values in production
- 🔄 Rotate secrets every 90 days
- 🔐 Store production secrets in a vault (AWS Secrets Manager, etc.)
- 📝 Different secrets for dev/staging/production

---

### 4. **Payment Gateways**

#### Stripe (International)

| Variable | Required | Description |
|----------|----------|-------------|
| `STRIPE_PUBLIC_KEY` | Yes | Publishable key (starts with pk_) |
| `STRIPE_SECRET_KEY` | Yes | Secret key (starts with sk_) |
| `STRIPE_WEBHOOK_SECRET` | Yes | Webhook signing secret (starts with whsec_) |

**Test Mode:**
- Public: `pk_test_...`
- Secret: `sk_test_...`

**Production:**
- Public: `pk_live_...`
- Secret: `sk_live_...`

---

#### Paymob (Egypt)

| Variable | Required | Description |
|----------|----------|-------------|
| `PAYMOB_API_KEY` | Yes | Paymob API key |
| `PAYMOB_INTEGRATION_ID` | Yes | Integration ID from dashboard |
| `PAYMOB_HMAC_SECRET` | Yes | HMAC secret for webhooks |

---

#### Fawry (Egypt)

| Variable | Required | Description |
|----------|----------|-------------|
| `FAWRY_MERCHANT_CODE` | Yes | Merchant code |
| `FAWRY_SECRET_KEY` | Yes | API secret key |
| `FAWRY_API_URL` | Yes | API endpoint (staging/production) |

**URLs:**
- Staging: `https://atfawry.fawrystaging.com`
- Production: `https://www.atfawry.com`

---

#### Vodafone Cash (Egypt)

| Variable | Required | Description |
|----------|----------|-------------|
| `VODAFONE_MERCHANT_ID` | Yes | Merchant identifier |
| `VODAFONE_API_KEY` | Yes | API authentication key |
| `VODAFONE_SECRET_KEY` | Yes | Secret for signing requests |

---

#### InstaPay (Egypt)

| Variable | Required | Description |
|----------|----------|-------------|
| `INSTAPAY_MERCHANT_CODE` | Yes | Merchant code |
| `INSTAPAY_API_KEY` | Yes | API key |
| `INSTAPAY_ALIAS` | Yes | InstaPay alias (e.g., @yourbusiness) |

---

### 5. **Email Services**

#### SMTP Configuration

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `SMTP_HOST` | Yes | - | SMTP server hostname |
| `SMTP_PORT` | Yes | 587 | SMTP port (587 for TLS, 465 for SSL) |
| `SMTP_SECURE` | No | false | Use SSL/TLS |
| `SMTP_USER` | Yes | - | SMTP username |
| `SMTP_PASSWORD` | Yes | - | SMTP password |

#### SendGrid (Alternative)

| Variable | Required | Description |
|----------|----------|-------------|
| `SENDGRID_API_KEY` | Yes | SendGrid API key (starts with SG.) |
| `SENDGRID_FROM_EMAIL` | Yes | Verified sender email |
| `SENDGRID_FROM_NAME` | No | Display name for emails |

**Common Providers:**
- **Gmail:** `smtp.gmail.com:587` (use app password)
- **SendGrid:** API-based (recommended)
- **Amazon SES:** `email-smtp.us-east-1.amazonaws.com:587`
- **Mailgun:** `smtp.mailgun.org:587`

---

### 6. **SMS Services**

#### Twilio

| Variable | Required | Description |
|----------|----------|-------------|
| `TWILIO_ACCOUNT_SID` | Yes | Account SID (starts with AC) |
| `TWILIO_AUTH_TOKEN` | Yes | Authentication token |
| `TWILIO_PHONE_NUMBER` | Yes | Sending phone number (+1234567890) |

#### OTP Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `OTP_EXPIRY_MINUTES` | 5 | OTP code validity period |
| `OTP_LENGTH` | 6 | Number of digits in OTP |
| `OTP_MAX_ATTEMPTS` | 3 | Maximum verification attempts |

---

### 7. **File Storage**

#### AWS S3

| Variable | Required | Description |
|----------|----------|-------------|
| `AWS_ACCESS_KEY_ID` | Yes | AWS access key |
| `AWS_SECRET_ACCESS_KEY` | Yes | AWS secret key |
| `AWS_REGION` | Yes | AWS region (e.g., us-east-1) |
| `AWS_S3_BUCKET` | Yes | Default bucket name |
| `AWS_S3_BUCKET_RECEIPTS` | No | Receipts bucket |
| `AWS_S3_BUCKET_PROOFS` | No | Payment proofs bucket |

#### Local Storage

| Variable | Default | Description |
|----------|---------|-------------|
| `UPLOAD_PATH` | ./uploads | Local upload directory |
| `MAX_FILE_SIZE` | 10485760 | Max file size in bytes (10MB) |
| `ALLOWED_FILE_TYPES` | pdf,jpg,jpeg,png,csv,xlsx | Allowed extensions |

---

### 8. **Redis Cache**

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `REDIS_HOST` | Yes | localhost | Redis server host |
| `REDIS_PORT` | Yes | 6379 | Redis server port |
| `REDIS_PASSWORD` | No | - | Redis password (if auth enabled) |
| `REDIS_DB` | No | 0 | Redis database number (0-15) |
| `REDIS_TTL` | No | 3600 | Default cache TTL in seconds |

**Use Cases:**
- Session storage
- Rate limiting counters
- Transaction caching
- Queue management

---

### 9. **Fraud Detection & Security**

#### Sift Science

| Variable | Required | Description |
|----------|----------|-------------|
| `SIFT_API_KEY` | No | Sift API key for fraud detection |
| `SIFT_ACCOUNT_ID` | No | Sift account identifier |

#### Risk Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `RISK_SCORE_THRESHOLD` | 75 | Score to flag for review (0-100) |
| `AUTO_BLOCK_THRESHOLD` | 90 | Score to auto-block transaction |
| `AUTO_REVIEW_THRESHOLD` | 60 | Score to queue for manual review |

#### Rate Limiting

| Variable | Default | Description |
|----------|---------|-------------|
| `MAX_TRANSACTIONS_PER_HOUR` | 50 | Max transactions per user/hour |
| `MAX_AMOUNT_PER_HOUR` | 10000 | Max total amount per user/hour |
| `MAX_FAILED_ATTEMPTS` | 5 | Max failed payment attempts |

---

### 10. **Webhooks**

| Variable | Default | Description |
|----------|---------|-------------|
| `WEBHOOK_RETRY_ATTEMPTS` | 3 | Number of retry attempts |
| `WEBHOOK_RETRY_DELAY` | 300 | Delay between retries (seconds) |
| `WEBHOOK_TIMEOUT` | 30 | Request timeout (seconds) |
| `WEBHOOK_SIGNATURE_HEADER` | X-OnTarget-Signature | Signature header name |

---

### 11. **Monitoring & Logging**

#### Sentry (Error Tracking)

| Variable | Required | Description |
|----------|----------|-------------|
| `SENTRY_DSN` | No | Sentry project DSN |
| `SENTRY_ENVIRONMENT` | No | Environment name (dev/staging/prod) |
| `SENTRY_TRACES_SAMPLE_RATE` | No | Performance monitoring sample rate (0.0-1.0) |

#### Logging

| Variable | Default | Description |
|----------|---------|-------------|
| `LOG_LEVEL` | info | Logging level: debug, info, warn, error |
| `LOG_FILE_PATH` | ./logs | Log files directory |
| `LOG_MAX_SIZE` | 10m | Max log file size before rotation |
| `LOG_MAX_FILES` | 14 | Number of log files to keep |

---

### 12. **Feature Flags**

Enable or disable features without code changes.

| Variable | Default | Description |
|----------|---------|-------------|
| `ENABLE_WALLET_ALLOCATION` | true | Smart wallet allocation engine |
| `ENABLE_SMART_ROUTING` | true | Intelligent payment routing |
| `ENABLE_FRAUD_DETECTION` | true | Fraud detection system |
| `ENABLE_AUTO_SETTLEMENT` | true | Automatic settlement processing |
| `ENABLE_INSTANT_PAYOUTS` | false | Real-time payout capability |
| `ENABLE_MULTI_CURRENCY` | true | Multi-currency support |
| `ENABLE_RECURRING_PAYMENTS` | true | Subscription/recurring payments |
| `ENABLE_PAYMENT_LINKS` | true | Payment link generation |
| `ENABLE_QR_PAYMENTS` | true | QR code payments |
| `ENABLE_WEBHOOKS` | true | Webhook notifications |

---

### 13. **Wallet Allocation Engine**

| Variable | Default | Description |
|----------|---------|-------------|
| `WALLET_DAILY_LIMIT` | 50000 | Daily limit per wallet |
| `WALLET_TRANSACTION_LIMIT` | 5000 | Per-transaction limit |
| `WALLET_WARNING_THRESHOLD` | 80 | Warning threshold (% of capacity) |
| `AUTO_ALLOCATION_ENABLED` | true | Enable automatic allocation |
| `ALLOCATION_STRATEGY` | round_robin | Strategy: round_robin, lowest_usage, priority |
| `ALLOCATION_COOLDOWN_MINUTES` | 5 | Cooldown between allocations |

---

### 14. **Smart Routing Engine**

| Variable | Default | Description |
|----------|---------|-------------|
| `SMART_ROUTING_ENABLED` | true | Enable intelligent routing |
| `ROUTING_PREFERENCE` | cost | Preference: cost, speed, success_rate, balanced |
| `FALLBACK_ROUTING_ENABLED` | true | Enable fallback to alternative providers |
| `MAX_ROUTING_ATTEMPTS` | 3 | Maximum routing attempts per transaction |

---

### 15. **Fees & Pricing**

| Variable | Default | Description |
|----------|---------|-------------|
| `DEFAULT_TRANSACTION_FEE_PERCENT` | 2.5 | Default percentage fee |
| `DEFAULT_TRANSACTION_FEE_FIXED` | 0.30 | Default fixed fee amount |
| `MINIMUM_FEE` | 0.10 | Minimum fee to charge |
| `MAXIMUM_FEE` | 100.00 | Maximum fee cap |
| `DEFAULT_CURRENCY` | EGP | Default currency code |
| `SUPPORTED_CURRENCIES` | EGP,USD,EUR,SAR,AED | Comma-separated list |
| `CURRENCY_ROUNDING` | 2 | Decimal places for rounding |

---

### 16. **Scheduled Jobs (Cron)**

Format: `minute hour day month weekday`

| Variable | Default | Description |
|----------|---------|-------------|
| `CRON_SETTLEMENT_SCHEDULE` | 0 23 * * * | Daily settlement (11 PM) |
| `CRON_PAYOUT_SCHEDULE` | 0 1 * * * | Daily payouts (1 AM) |
| `CRON_RECONCILIATION_SCHEDULE` | 0 2 * * * | Daily reconciliation (2 AM) |
| `CRON_DAILY_REPORT` | 0 6 * * * | Daily reports (6 AM) |
| `CRON_WEEKLY_REPORT` | 0 6 * * 1 | Weekly reports (Mon 6 AM) |
| `CRON_MONTHLY_REPORT` | 0 6 1 * * | Monthly reports (1st, 6 AM) |
| `CRON_LOG_CLEANUP` | 0 0 * * 0 | Weekly log cleanup (Sun midnight) |

---

### 17. **Compliance & Regulatory**

#### PCI DSS

| Variable | Default | Description |
|----------|---------|-------------|
| `PCI_COMPLIANT_MODE` | true | Enable PCI compliance mode |
| `STORE_CARD_DETAILS` | false | Store full card details (NOT recommended) |
| `TOKENIZE_CARDS` | true | Use tokenization for cards |

#### AML/CFT

| Variable | Default | Description |
|----------|---------|-------------|
| `AML_SCREENING_ENABLED` | true | Enable AML screening |
| `TRANSACTION_MONITORING_ENABLED` | true | Monitor suspicious activity |
| `SUSPICIOUS_ACTIVITY_THRESHOLD` | 10000 | Amount threshold for flagging |

#### GDPR

| Variable | Default | Description |
|----------|---------|-------------|
| `DATA_RETENTION_DAYS` | 2555 | Data retention period (7 years) |
| `ANONYMIZE_USER_DATA` | true | Anonymize deleted user data |
| `ALLOW_DATA_EXPORT` | true | Allow users to export their data |

#### Egyptian Central Bank (CBE)

| Variable | Default | Description |
|----------|---------|-------------|
| `CBE_REPORTING_ENABLED` | true | Enable CBE reporting |
| `CBE_REPORT_PATH` | ./reports/cbe | CBE reports directory |
| `CBE_ENCRYPTION_ENABLED` | true | Encrypt CBE reports |

---

### 18. **Testing & Development**

| Variable | Default | Description |
|----------|---------|-------------|
| `TEST_MODE` | true | Enable test mode |
| `SANDBOX_MODE` | true | Use sandbox for payment providers |
| `ALLOW_TEST_CARDS` | true | Accept test card numbers |
| `MOCK_PAYMENT_PROVIDERS` | false | Use mock providers (for CI/CD) |
| `MOCK_SMS_SERVICE` | true | Mock SMS sending |
| `MOCK_EMAIL_SERVICE` | true | Mock email sending |
| `DEBUG` | true | Enable debug mode |
| `VERBOSE_LOGGING` | false | Enable verbose logs |
| `SQL_LOGGING` | false | Log SQL queries |

---

## 🔒 Security Best Practices

### 1. Key Generation

Always generate cryptographically secure random keys:

```bash
# Using OpenSSL
openssl rand -hex 32

# Using Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Using Python
python -c "import secrets; print(secrets.token_hex(32))"
```

### 2. Key Rotation Schedule

| Key Type | Rotation Frequency | Priority |
|----------|-------------------|----------|
| JWT Secrets | Every 90 days | High |
| API Keys | Every 180 days | Medium |
| Database Passwords | Every 90 days | High |
| Encryption Keys | Annually | Critical |
| Webhook Secrets | Every 180 days | Medium |

### 3. Production Secrets Storage

**Never store production secrets in .env files!**

Use a secrets management service:
- AWS Secrets Manager
- HashiCorp Vault
- Azure Key Vault
- Google Secret Manager
- 1Password for Teams
- Doppler

### 4. Access Control

```bash
# Set restrictive file permissions
chmod 600 .env

# Verify
ls -la .env
# Should show: -rw------- (600)
```

### 5. Environment Separation

Maintain separate environments:
- **.env** - Local development (gitignored)
- **.env.staging** - Staging environment (never committed)
- **.env.production** - Production (never committed, use secrets manager)

---

## ✅ Validation

### Run the Validator

```bash
# Check all environment variables
npm run env:check

# Or run directly
node scripts/check-env.js
```

### Manual Validation Checklist

- [ ] All required variables are set
- [ ] At least one payment provider configured
- [ ] JWT_SECRET is at least 32 characters
- [ ] ENCRYPTION_KEY is at least 32 characters
- [ ] No "test", "dev", or "example" in production keys
- [ ] Database connection string is valid
- [ ] Email/SMS services configured (if needed)
- [ ] File permissions are secure (600)
- [ ] .env is in .gitignore
- [ ] Production secrets are in a vault

---

## 🚨 Troubleshooting

### Common Errors

#### "Database connection failed"
```
Check:
- PostgreSQL is running: systemctl status postgresql
- Credentials are correct
- Database exists: psql -l
- Network connectivity: telnet dbhost 5432
```

#### "Invalid JWT token"
```
Check:
- JWT_SECRET is set and correct
- Same secret on all servers
- Token hasn't expired
- Clock sync across servers
```

#### "Payment provider authentication failed"
```
Check:
- API keys are correct and active
- Using correct test vs production keys
- API key permissions
- Whitelist IPs (if required)
```

#### "Redis connection timeout"
```
Check:
- Redis is running: redis-cli ping
- Host and port are correct
- Firewall allows connection
- Redis password (if set)
```

---

## 📚 Additional Resources

- **Full Setup Guide:** [ENV_SETUP.md](./ENV_SETUP.md)
- **Quick Reference:** [ENV_QUICK_REFERENCE.md](./ENV_QUICK_REFERENCE.md)
- **Security Guide:** [docs/security.md](./docs/security.md)
- **Deployment Guide:** [docs/deployment.md](./docs/deployment.md)

---

## 📞 Support

For environment configuration support:

- **Email:** devops@ontargetpsp.com
- **Documentation:** https://docs.ontargetpsp.com
- **Slack:** #ontarget-devops
- **Status:** https://status.ontargetpsp.com

---

**Last Updated:** March 14, 2026  
**Version:** 1.0.0  
**Maintained by:** OnTarget PSP DevOps Team
