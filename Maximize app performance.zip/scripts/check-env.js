#!/usr/bin/env node

/**
 * OnTarget PSP - Environment Variables Validator
 * 
 * This script validates that all required environment variables are set
 * and provides warnings for missing optional but recommended variables.
 */

const fs = require('fs');
const path = require('path');

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m'
};

// Required environment variables
const REQUIRED_VARS = [
  'NODE_ENV',
  'APP_URL',
  'API_URL',
  'DATABASE_URL',
  'JWT_SECRET',
  'ENCRYPTION_KEY',
];

// Recommended environment variables
const RECOMMENDED_VARS = [
  'REDIS_HOST',
  'STRIPE_SECRET_KEY',
  'SMTP_HOST',
  'SENTRY_DSN',
  'LOG_LEVEL',
];

// Payment provider variables (at least one required)
const PAYMENT_PROVIDER_VARS = [
  'STRIPE_SECRET_KEY',
  'PAYMOB_API_KEY',
  'FAWRY_SECRET_KEY',
  'VODAFONE_API_KEY',
];

// Security-critical variables that need strong values
const SECURITY_VARS = [
  'JWT_SECRET',
  'JWT_REFRESH_SECRET',
  'ENCRYPTION_KEY',
  'AES_SECRET_KEY',
  'WEBHOOK_SECRET',
];

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function loadEnv() {
  const envPath = path.join(process.cwd(), '.env');
  
  if (!fs.existsSync(envPath)) {
    log('❌ .env file not found!', 'red');
    log('   Run: cp .env.example .env', 'yellow');
    process.exit(1);
  }

  const envContent = fs.readFileSync(envPath, 'utf-8');
  const env = {};

  envContent.split('\n').forEach(line => {
    line = line.trim();
    if (line && !line.startsWith('#')) {
      const [key, ...valueParts] = line.split('=');
      const value = valueParts.join('=').trim();
      if (key && value) {
        env[key.trim()] = value;
      }
    }
  });

  return env;
}

function checkRequired(env) {
  log('\n📋 Checking Required Variables...', 'cyan');
  
  let allPresent = true;
  
  REQUIRED_VARS.forEach(varName => {
    if (!env[varName] || env[varName] === '') {
      log(`  ❌ ${varName} - MISSING`, 'red');
      allPresent = false;
    } else {
      log(`  ✅ ${varName}`, 'green');
    }
  });

  return allPresent;
}

function checkRecommended(env) {
  log('\n💡 Checking Recommended Variables...', 'cyan');
  
  let warnings = 0;
  
  RECOMMENDED_VARS.forEach(varName => {
    if (!env[varName] || env[varName] === '') {
      log(`  ⚠️  ${varName} - Not set`, 'yellow');
      warnings++;
    } else {
      log(`  ✅ ${varName}`, 'green');
    }
  });

  return warnings;
}

function checkPaymentProviders(env) {
  log('\n💳 Checking Payment Providers...', 'cyan');
  
  const configured = PAYMENT_PROVIDER_VARS.filter(
    varName => env[varName] && env[varName] !== ''
  );

  if (configured.length === 0) {
    log('  ❌ No payment providers configured!', 'red');
    log('     At least one payment provider is required', 'yellow');
    return false;
  } else {
    configured.forEach(provider => {
      log(`  ✅ ${provider.replace('_SECRET_KEY', '').replace('_API_KEY', '')}`, 'green');
    });
    return true;
  }
}

function checkSecurity(env) {
  log('\n🔐 Checking Security Configuration...', 'cyan');
  
  let issues = 0;
  
  SECURITY_VARS.forEach(varName => {
    const value = env[varName];
    
    if (!value || value === '') {
      log(`  ❌ ${varName} - Not set`, 'red');
      issues++;
    } else if (value.includes('test') || value.includes('dev') || value.includes('example')) {
      log(`  ⚠️  ${varName} - Contains test/dev/example (use strong production key!)`, 'yellow');
      issues++;
    } else if (value.length < 32) {
      log(`  ⚠️  ${varName} - Too short (minimum 32 characters recommended)`, 'yellow');
      issues++;
    } else {
      log(`  ✅ ${varName} - OK`, 'green');
    }
  });

  return issues;
}

function checkNodeEnv(env) {
  log('\n🌍 Checking Environment...', 'cyan');
  
  const nodeEnv = env.NODE_ENV || 'development';
  
  if (nodeEnv === 'production') {
    log(`  📦 Environment: ${nodeEnv}`, 'green');
    
    // Production-specific checks
    if (env.DEBUG === 'true') {
      log('  ⚠️  WARNING: DEBUG is enabled in production!', 'yellow');
    }
    if (env.TEST_MODE === 'true') {
      log('  ⚠️  WARNING: TEST_MODE is enabled in production!', 'yellow');
    }
    if (env.MOCK_PAYMENT_PROVIDERS === 'true') {
      log('  ❌ ERROR: Mock providers enabled in production!', 'red');
      return false;
    }
  } else {
    log(`  🔧 Environment: ${nodeEnv}`, 'blue');
  }

  return true;
}

function checkDatabase(env) {
  log('\n🗄️  Checking Database Configuration...', 'cyan');
  
  const dbUrl = env.DATABASE_URL;
  
  if (!dbUrl) {
    log('  ❌ DATABASE_URL not set', 'red');
    return false;
  }

  // Basic URL validation
  if (!dbUrl.startsWith('postgresql://') && !dbUrl.startsWith('postgres://')) {
    log('  ⚠️  DATABASE_URL should start with postgresql://', 'yellow');
  } else {
    log('  ✅ DATABASE_URL format looks correct', 'green');
  }

  // Check for default credentials
  if (dbUrl.includes('postgres:postgres@') || dbUrl.includes('password@')) {
    log('  ⚠️  Using default database credentials (change for production!)', 'yellow');
  }

  return true;
}

function generateReport(results) {
  log('\n' + '='.repeat(60), 'cyan');
  log('📊 Environment Validation Report', 'bold');
  log('='.repeat(60), 'cyan');

  const { required, recommended, paymentProviders, security, nodeEnv, database } = results;

  if (required && paymentProviders && nodeEnv && database && security === 0) {
    log('\n✅ All checks passed! Environment is properly configured.', 'green');
    return true;
  } else {
    log('\n⚠️  Some issues found:', 'yellow');
    
    if (!required) {
      log('  • Missing required variables', 'red');
    }
    if (!paymentProviders) {
      log('  • No payment providers configured', 'red');
    }
    if (!database) {
      log('  • Database configuration issues', 'red');
    }
    if (security > 0) {
      log(`  • ${security} security issue(s) found`, 'yellow');
    }
    if (recommended > 0) {
      log(`  • ${recommended} recommended variable(s) not set`, 'yellow');
    }
    
    return false;
  }
}

function main() {
  log('\n🔍 OnTarget PSP - Environment Validator', 'bold');
  log('━'.repeat(60), 'cyan');

  try {
    const env = loadEnv();

    const results = {
      required: checkRequired(env),
      recommended: checkRecommended(env),
      paymentProviders: checkPaymentProviders(env),
      security: checkSecurity(env),
      nodeEnv: checkNodeEnv(env),
      database: checkDatabase(env),
    };

    const success = generateReport(results);

    log('\n' + '━'.repeat(60), 'cyan');
    
    if (!success) {
      log('\n💡 Tip: Check ENV_SETUP.md for detailed configuration guide', 'blue');
      process.exit(1);
    }

    process.exit(0);

  } catch (error) {
    log(`\n❌ Error: ${error.message}`, 'red');
    process.exit(1);
  }
}

// Run the validator
main();
