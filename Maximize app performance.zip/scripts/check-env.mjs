#!/usr/bin/env node

/**
 * Script to check if all required environment variables are set
 * Run with: node scripts/check-env.mjs
 */

const requiredEnvVars = [
  'NEXT_PUBLIC_SUPABASE_URL',
  'NEXT_PUBLIC_SUPABASE_ANON_KEY',
];

const optionalEnvVars = [
  'SUPABASE_SERVICE_ROLE_KEY',
  'SUPABASE_DB_URL',
];

console.log('🔍 Checking environment variables...\n');

let hasErrors = false;
let hasWarnings = false;

// Check required variables
console.log('📌 Required variables:');
requiredEnvVars.forEach((varName) => {
  const value = process.env[varName];
  if (!value) {
    console.log(`  ❌ ${varName} - MISSING`);
    hasErrors = true;
  } else {
    // Show first 20 chars only for security
    const preview = value.substring(0, 20) + '...';
    console.log(`  ✅ ${varName} - Set (${preview})`);
  }
});

// Check optional variables
console.log('\n📌 Optional variables:');
optionalEnvVars.forEach((varName) => {
  const value = process.env[varName];
  if (!value) {
    console.log(`  ⚠️  ${varName} - Not set (optional)`);
    hasWarnings = true;
  } else {
    const preview = value.substring(0, 20) + '...';
    console.log(`  ✅ ${varName} - Set (${preview})`);
  }
});

// Summary
console.log('\n' + '='.repeat(50));
if (hasErrors) {
  console.log('❌ Some required environment variables are missing!');
  console.log('📝 Please create a .env.local file with the required values.');
  console.log('💡 You can copy .env.example as a template:');
  console.log('   cp .env.example .env.local\n');
  process.exit(1);
} else if (hasWarnings) {
  console.log('✅ All required variables are set!');
  console.log('⚠️  Some optional variables are not set.');
  console.log('   This is fine for basic functionality.\n');
  process.exit(0);
} else {
  console.log('✅ All environment variables are set!\n');
  process.exit(0);
}
