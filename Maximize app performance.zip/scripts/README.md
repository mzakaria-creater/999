# 🛠️ Scripts - OnTarget PSP

مجموعة من Scripts المساعدة للتطوير والنشر.

## 📜 Scripts المتاحة

### 1. check-env.mjs

فحص وجود جميع Environment Variables المطلوبة.

**الاستخدام:**
```bash
# من خلال package.json
pnpm check-env

# أو مباشرة
node scripts/check-env.mjs
```

**ماذا يفعل:**
- ✅ يتحقق من وجود المتغيرات المطلوبة
- ⚠️ ينبه عن المتغيرات الاختيارية الناقصة
- ❌ يفشل إذا كانت متغيرات مطلوبة ناقصة

**Output مثال:**
```
🔍 Checking environment variables...

📌 Required variables:
  ✅ NEXT_PUBLIC_SUPABASE_URL - Set (https://xxxxx.supa...)
  ✅ NEXT_PUBLIC_SUPABASE_ANON_KEY - Set (eyJhbGciOiJIUzI1NiIs...)

📌 Optional variables:
  ✅ SUPABASE_SERVICE_ROLE_KEY - Set (eyJhbGciOiJIUzI1NiIs...)
  ⚠️  SUPABASE_DB_URL - Not set (optional)

==================================================
✅ All required variables are set!
```

---

### 2. deploy.sh

Script تفاعلي للنشر على Vercel.

**الاستخدام:**
```bash
# جعله قابل للتنفيذ (مرة واحدة)
chmod +x scripts/deploy.sh

# تشغيل
./scripts/deploy.sh
```

**ماذا يفعل:**
1. يتحقق من تثبيت Vercel CLI
2. يفحص Environment Variables
3. يعرض خيارات النشر:
   - Preview deployment
   - Production deployment
   - Cancel

**Workflow:**
```
🚀 OnTarget PSP - Deployment Script
====================================

🔍 Checking environment variables...
✅ All required variables are set!

📋 Deployment Options:
  1) Preview deployment (staging)
  2) Production deployment
  3) Cancel

Select option (1-3): _
```

---

## 🚀 إضافة Scripts جديدة

### مثال: Script للتنظيف

```bash
# /scripts/clean.sh
#!/bin/bash
echo "🧹 Cleaning project..."
rm -rf node_modules .next out
echo "✅ Cleaned successfully!"
```

### مثال: Script للاختبار

```javascript
// /scripts/test-api.mjs
#!/usr/bin/env node

const baseUrl = 'http://localhost:3000';

async function testAPI() {
  console.log('🧪 Testing API endpoints...\n');
  
  // Health check
  const health = await fetch(`${baseUrl}/api/health`);
  console.log('Health:', await health.json());
  
  // Config
  const config = await fetch(`${baseUrl}/api/config`);
  console.log('Config:', await config.json());
}

testAPI();
```

---

## 💡 نصائح

### لـ Bash Scripts
```bash
#!/bin/bash
# اجعل script يتوقف عند أي خطأ
set -e

# اطبع كل command قبل تنفيذه (للتشخيص)
set -x
```

### لـ Node Scripts
```javascript
#!/usr/bin/env node
// استخدم ES modules
// أضف في package.json: "type": "module"

import { readFileSync } from 'fs';
import { resolve } from 'path';
```

### الأذونات
```bash
# جعل script قابل للتنفيذ
chmod +x scripts/your-script.sh

# تشغيل
./scripts/your-script.sh
```

---

## 📝 Conventions

### التسمية
- استخدم kebab-case: `check-env.mjs`
- اجعل الأسماء وصفية: `deploy.sh` بدلاً من `d.sh`

### File Extensions
- `.sh` - Bash scripts
- `.mjs` - ES module JavaScript
- `.js` - CommonJS JavaScript

### Shebang
```bash
#!/bin/bash           # Bash
#!/usr/bin/env node   # Node.js
#!/usr/bin/env python # Python
```

---

## 🔧 Scripts مفيدة أخرى (أفكار)

### Backup Environment
```bash
# backup-env.sh
cp .env.local .env.backup.$(date +%Y%m%d_%H%M%S)
```

### Check Dependencies
```bash
# check-deps.sh
pnpm outdated
```

### Bundle Analysis
```bash
# analyze.sh
ANALYZE=true pnpm build
```

### Database Migrations
```bash
# migrate.sh
supabase db push
```

---

## 📞 الحصول على المساعدة

إذا واجهت مشاكل مع scripts:

1. تأكد من الأذونات: `ls -la scripts/`
2. تأكد من Environment Variables: `pnpm check-env`
3. اقرأ error messages بعناية
4. راجع [FAQ.md](../FAQ.md)

---

**Last Updated:** March 22, 2026  
**Version:** 3.0.0
