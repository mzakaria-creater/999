#!/bin/bash

# OnTarget PSP - Deploy Script
# This script helps you deploy to Vercel

echo "🚀 OnTarget PSP - Deployment Script"
echo "===================================="
echo ""

# Check if vercel CLI is installed
if ! command -v vercel &> /dev/null
then
    echo "⚠️  Vercel CLI is not installed."
    echo "📦 Installing Vercel CLI globally..."
    npm install -g vercel
    echo "✅ Vercel CLI installed!"
    echo ""
fi

# Check environment variables
echo "🔍 Checking environment variables..."
node scripts/check-env.mjs

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Environment check failed!"
    echo "Please set up your environment variables before deploying."
    exit 1
fi

echo ""
echo "📋 Deployment Options:"
echo "  1) Preview deployment (staging)"
echo "  2) Production deployment"
echo "  3) Cancel"
echo ""
read -p "Select option (1-3): " option

case $option in
    1)
        echo ""
        echo "🔄 Deploying to preview environment..."
        vercel
        ;;
    2)
        echo ""
        read -p "⚠️  Are you sure you want to deploy to PRODUCTION? (yes/no): " confirm
        if [ "$confirm" == "yes" ]; then
            echo "🚀 Deploying to production..."
            vercel --prod
        else
            echo "❌ Deployment cancelled."
            exit 0
        fi
        ;;
    3)
        echo "❌ Deployment cancelled."
        exit 0
        ;;
    *)
        echo "❌ Invalid option. Deployment cancelled."
        exit 1
        ;;
esac

echo ""
echo "✅ Deployment completed!"
echo "🌐 Visit your Vercel dashboard to see the deployment status."
