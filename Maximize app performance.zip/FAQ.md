# ❓ الأسئلة الشائعة - OnTarget PSP

## 🚀 البدء والإعداد

### س: كيف أبدأ المشروع لأول مرة؟

```bash
# 1. استنساخ المشروع
git clone <repository-url>
cd ontarget-psp

# 2. تثبيت الحزم
pnpm install

# 3. إعداد البيئة
cp .env.example .env.local
# عدّل .env.local وأضف بيانات Supabase

# 4. تشغيل المشروع
pnpm dev
```

اقرأ [البدء_السريع.md](./البدء_السريع.md) للمزيد.

---

### س: ما الفرق بين pnpm و npm؟

**pnpm** (مُفضّل):
- ✅ أسرع في التثبيت
- ✅ يستخدم مساحة تخزين أقل
- ✅ أكثر كفاءة

**npm** (يعمل أيضاً):
- ⚠️ أبطأ قليلاً
- ⚠️ يستخدم مساحة أكبر

استخدم أي منهما، لكن **pnpm مُفضّل**.

---

### س: أين أحصل على بيانات Supabase؟

1. اذهب إلى [app.supabase.com](https://app.supabase.com)
2. سجل دخول أو أنشئ حساب
3. أنشئ مشروع جديد (أو اختر موجود)
4. من القائمة الجانبية: `Settings → API`
5. انسخ:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon/public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role key** → `SUPABASE_SERVICE_ROLE_KEY`

---

## 🔧 التطوير

### س: Port 3000 مُستخدم، ماذا أفعل؟

**الحل 1: استخدم port آخر**
```bash
pnpm dev -p 3001
```

**الحل 2: اقتل العملية على port 3000**
```bash
# Linux/Mac
kill -9 $(lsof -t -i:3000)

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

---

### س: كيف أضيف صفحة جديدة؟

**للـ Desktop:**
```tsx
// /app/(main)/my-page/page.tsx
export default function MyPage() {
  return <div>صفحتي الجديدة</div>;
}
```

**للـ Mobile:**
```tsx
// /app/mobile/my-page/page.tsx
export default function MyMobilePage() {
  return <div>صفحة موبايل</div>;
}
```

الصفحة ستكون متاحة على `/my-page` تلقائياً.

---

### س: كيف أستخدم Supabase في component؟

**Client Component:**
```tsx
'use client';
import { getSupabaseBrowserClient } from '@/lib/supabase-browser';

export default function MyComponent() {
  const supabase = getSupabaseBrowserClient();
  
  const fetchData = async () => {
    const { data } = await supabase.from('table').select('*');
    return data;
  };
}
```

**Server Component:**
```tsx
import { createClient } from '@/lib/supabase-server';

export default async function MyServerComponent() {
  const supabase = await createClient();
  const { data } = await supabase.from('table').select('*');
  
  return <div>{/* render data */}</div>;
}
```

---

### س: متى أستخدم 'use client' ومتى لا؟

**استخدم `'use client'` عندما:**
- تحتاج useState, useEffect, hooks
- تحتاج event handlers (onClick, onChange)
- تحتاج browser APIs
- تستخدم context providers

**لا تستخدم `'use client'` عندما:**
- تعرض محتوى ثابت
- تحتاج SEO optimization
- تفضل server-side rendering

---

## 🌐 النشر

### س: كيف أنشر على Vercel؟

**الطريقة السهلة:**
1. اذهب إلى [vercel.com](https://vercel.com)
2. سجل دخول مع GitHub/GitLab
3. استورد repository
4. أضف Environment Variables
5. اضغط Deploy

اقرأ [VERCEL_DEPLOYMENT.md](./VERCEL_DEPLOYMENT.md) للتفاصيل.

---

### س: ماذا أفعل إذا فشل البناء على Vercel؟

**خطوات التشخيص:**

1. **تحقق من Logs**
   - افتح deployment في Vercel
   - اقرأ Build Logs بعناية

2. **أخطاء TypeScript؟**
   ```js
   // في next.config.js
   typescript: {
     ignoreBuildErrors: true, // مؤقت فقط!
   }
   ```

3. **أخطاء ESLint؟**
   ```js
   // في next.config.js
   eslint: {
     ignoreDuringBuilds: true, // مؤقت فقط!
   }
   ```

4. **Environment Variables ناقصة؟**
   - تأكد من إضافتها في Vercel Dashboard
   - `Project Settings → Environment Variables`

---

### س: كيف أضيف domain مخصص؟

1. في Vercel: `Project → Settings → Domains`
2. أدخل domain (مثل: `ontarget-psp.com`)
3. أضف DNS records في موفر الدومين:
   ```
   Type: A
   Name: @
   Value: 76.76.21.21
   
   Type: CNAME
   Name: www
   Value: cname.vercel-dns.com
   ```
4. انتظر DNS propagation (5-30 دقيقة)

---

## 🔐 الأمان

### س: هل يمكن استخدام service_role_key في الـ frontend؟

**❌ لا! أبداً!**

- `SUPABASE_SERVICE_ROLE_KEY` خطير جداً
- استخدمه **فقط** في:
  - Server Components
  - API Routes
  - Server Actions
- **أبداً** في Client Components

---

### س: كيف أحمي API endpoints؟

```tsx
// /app/api/protected/route.ts
import { createClient } from '@/lib/supabase-server';

export async function GET(request: Request) {
  const supabase = await createClient();
  
  // تحقق من المستخدم
  const { data: { user }, error } = await supabase.auth.getUser();
  
  if (error || !user) {
    return new Response('Unauthorized', { status: 401 });
  }
  
  // المستخدم مُصرّح له
  return Response.json({ data: 'secret data' });
}
```

---

## 🎨 التصميم

### س: كيف أغيّر الألوان؟

عدّل `/src/styles/theme.css`:

```css
:root {
  --primary: 238 71% 60%;  /* اللون الأساسي */
  --secondary: 217 91% 60%;
  /* ... */
}
```

---

### س: كيف أضيف font جديد؟

```tsx
// في app/layout.tsx
import { Cairo } from 'next/font/google';

const cairo = Cairo({
  weight: ['400', '700'],
  subsets: ['arabic'],
  variable: '--font-cairo',
});

// في return
<html className={cairo.variable}>
```

```css
/* في theme.css */
:root {
  --font-sans: var(--font-cairo), system-ui;
}
```

---

### س: كيف أتحكم في RTL/LTR؟

```tsx
// تفعيل RTL (افتراضي)
<html dir="rtl" lang="ar">

// تفعيل LTR
<html dir="ltr" lang="en">
```

للتبديل ديناميكياً، استخدم `LanguageContext`.

---

## 🐛 حل المشاكل

### س: صور Unsplash لا تظهر

تأكد من `next.config.js`:
```js
images: {
  remotePatterns: [
    {
      protocol: 'https',
      hostname: 'images.unsplash.com',
    },
  ],
}
```

---

### س: "Module not found" error

```bash
# حذف node_modules و .next
rm -rf node_modules .next

# إعادة التثبيت
pnpm install

# تشغيل
pnpm dev
```

---

### س: Styles لا تطبق بشكل صحيح

1. **تأكد من import الـ CSS:**
   ```tsx
   // في app/layout.tsx
   import '@/styles/index.css';
   import '@/styles/tailwind.css';
   ```

2. **امسح Tailwind cache:**
   ```bash
   rm -rf .next/cache
   ```

3. **أعد تشغيل dev server**

---

### س: Environment variables تظهر undefined

**في Client Components:**
- يجب أن تبدأ بـ `NEXT_PUBLIC_`
- مثال: `NEXT_PUBLIC_SUPABASE_URL`

**في Server Components/API:**
- يمكن استخدام أي اسم
- مثال: `SUPABASE_SERVICE_ROLE_KEY`

**أعد تشغيل server بعد تعديل .env!**

---

### س: Hydration errors في Console

**السبب:** اختلاف بين Server و Client rendering

**الحل:**
```tsx
// استخدم dynamic import
import dynamic from 'next/dynamic';

const ClientOnlyComponent = dynamic(
  () => import('./ClientOnlyComponent'),
  { ssr: false }
);
```

---

## 📱 Mobile & Responsive

### س: كيف أختبر responsive design؟

1. **Chrome DevTools:**
   - اضغط F12
   - اضغط Device Toolbar (Ctrl+Shift+M)
   - اختر جهاز أو custom size

2. **على جهاز حقيقي:**
   ```bash
   # شغّل على network IP
   pnpm dev
   # افتح http://YOUR_IP:3000 على الهاتف
   ```

---

### س: متى يظهر Sidebar ومتى Bottom Nav؟

- **Desktop (> 768px):** Sidebar
- **Mobile (< 768px):** Bottom Navigation

التحكم في `useIsMobile` hook.

---

## 🔄 Updates & Maintenance

### س: كيف أحدّث Next.js؟

```bash
# تحديث Next.js
pnpm update next

# أو نسخة محددة
pnpm add next@latest
```

---

### س: كيف أحدّث جميع الحزم؟

```bash
# رؤية الحزم القديمة
pnpm outdated

# تحديث الكل
pnpm update

# تحديث بحذر (interactive)
pnpm update -i
```

---

## 📊 Performance

### س: كيف أحسّن الأداء؟

1. **Images:**
   - استخدم Next.js `<Image>` component
   - حدد width و height

2. **Code Splitting:**
   - استخدم dynamic imports
   - تجنب imports غير ضرورية

3. **Caching:**
   - استخدم ISR للصفحات الثابتة
   - Cache API responses

4. **Bundle Analysis:**
   ```bash
   ANALYZE=true pnpm build
   ```

---

### س: كيف أقيس الأداء؟

```bash
# Lighthouse
npx lighthouse http://localhost:3000 --view

# أو في Chrome DevTools
# F12 → Lighthouse tab → Generate report
```

---

## 💡 Best Practices

### س: ما هي أفضل الممارسات؟

1. **TypeScript:**
   - استخدم types دائماً
   - تجنب `any`

2. **Components:**
   - اجعلها صغيرة ومحددة
   - أعد استخدامها

3. **State:**
   - استخدم server state عند الإمكان
   - client state فقط للضرورة

4. **Security:**
   - لا تضع secrets في client
   - استخدم environment variables

5. **Git:**
   - Commit messages واضحة
   - استخدم branches

---

## 🆘 الحصول على المساعدة

### س: أين أجد المساعدة؟

1. **التوثيق:**
   - [README.md](./README.md)
   - [VERCEL_DEPLOYMENT.md](./VERCEL_DEPLOYMENT.md)
   - [COMMANDS.md](./COMMANDS.md)

2. **Official Docs:**
   - [Next.js Docs](https://nextjs.org/docs)
   - [Supabase Docs](https://supabase.com/docs)
   - [Vercel Docs](https://vercel.com/docs)

3. **Community:**
   - Next.js Discord
   - Supabase Discord
   - Stack Overflow

4. **GitHub Issues:**
   - افتح issue في repository

---

## 📝 المزيد

### س: كيف أساهم في المشروع؟

1. Fork المشروع
2. أنشئ branch: `git checkout -b feature/amazing`
3. Commit: `git commit -m 'Add amazing feature'`
4. Push: `git push origin feature/amazing`
5. افتح Pull Request

---

**آخر تحديث:** 22 مارس 2026  
**الإصدار:** 3.0.0

**💡 لم تجد سؤالك؟** افتح issue على GitHub!
