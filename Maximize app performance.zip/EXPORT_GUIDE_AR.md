# 📦 دليل تصدير مشروع OnTarget PSP

## 🎯 طرق تصدير المشروع

---

## **1️⃣ التصدير كملف ZIP**

### الطريقة الأولى - من خلال Terminal:
```bash
# تصدير المشروع بدون node_modules
zip -r ontarget-psp.zip . -x "node_modules/*" ".next/*" ".git/*"
```

### الطريقة الثانية - يدوياً:
1. انسخ جميع الملفات ما عدا:
   - `node_modules/`
   - `.next/`
   - `.git/`
2. اضغطهم في ملف ZIP

---

## **2️⃣ الرفع على GitHub**

```bash
# إنشاء repository جديد
git init
git add .
git commit -m "OnTarget PSP - Initial commit"

# ربط مع GitHub
git remote add origin https://github.com/username/ontarget-psp.git
git push -u origin main
```

---

## **3️⃣ النشر على Vercel** ⭐ (الأسهل والأسرع)

### الخطوات:
1. اذهب إلى: https://vercel.com
2. اضغط على **"New Project"**
3. اختر **"Import Git Repository"**
4. أو اسحب مجلد المشروع مباشرة
5. Vercel سيكتشف Next.js تلقائياً
6. أضف Environment Variables:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your-url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-key
   ```
7. اضغط **"Deploy"**

✅ سيتم النشر في أقل من دقيقة!

**الرابط النهائي:** `https://your-project.vercel.app`

---

## **4️⃣ النشر على Netlify**

### الطريقة الأولى - Drag & Drop:
1. اذهب إلى: https://app.netlify.com
2. اسحب مجلد المشروع
3. انتظر Build
4. تم! 🎉

### الطريقة الثانية - CLI:
```bash
npm install -g netlify-cli
netlify login
netlify init
netlify deploy --prod
```

---

## **5️⃣ النشر على Hosting عادي (cPanel/FTP)**

### الخطوات:
```bash
# 1. Build المشروع
npm run build

# 2. تصدير Static files
npm run export  # (بعد إضافة output: 'export' في next.config.js)

# 3. رفع مجلد out/ عبر FTP
```

⚠️ **ملاحظة:** بعض المميزات تحتاج Server-Side Rendering

---

## **6️⃣ استخدام Docker**

```bash
# Build Docker image
docker build -t ontarget-psp .

# Run locally
docker run -p 3000:3000 ontarget-psp

# Push to Docker Hub
docker tag ontarget-psp username/ontarget-psp:latest
docker push username/ontarget-psp:latest

# Deploy to any cloud
# - AWS ECS
# - Google Cloud Run
# - Azure Container Instances
# - DigitalOcean App Platform
```

---

## **7️⃣ النشر على AWS Amplify**

```bash
# 1. تثبيت Amplify CLI
npm install -g @aws-amplify/cli

# 2. إعداد Amplify
amplify init

# 3. إضافة Hosting
amplify add hosting

# 4. النشر
amplify publish
```

---

## **8️⃣ تصدير الكود للمطورين الآخرين**

### إنشاء Package للتوزيع:
```bash
# 1. نظف المشروع
rm -rf node_modules .next

# 2. أنشئ ملف README
# (موجود بالفعل)

# 3. اضغط المشروع
tar -czf ontarget-psp-v1.0.tar.gz .

# أو بصيغة ZIP
zip -r ontarget-psp-v1.0.zip . -x "node_modules/*" ".git/*"
```

---

## **9️⃣ النشر على Cloudflare Pages**

```bash
# 1. Build
npm run build

# 2. رفع على Cloudflare Pages
npx wrangler pages publish out
```

---

## **🔟 النشر على Railway**

1. اذهب إلى: https://railway.app
2. اضغط **"New Project"**
3. اختر **"Deploy from GitHub"**
4. اختر المشروع
5. Railway سيكتشف Next.js تلقائياً
6. تم! 🚀

---

## **⚙️ متغيرات البيئة المطلوبة**

عند النشر، تأكد من إضافة هذه المتغيرات:

```env
# إلزامية
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJxxx...

# للـ Backend فقط (لا ترفعها على Frontend)
SUPABASE_SERVICE_ROLE_KEY=eyJxxx...
```

---

## **📋 Checklist قبل النشر**

- [ ] اختبر المشروع محلياً: `npm run dev`
- [ ] Build بدون أخطاء: `npm run build`
- [ ] أضف `.env.local` بالمتغيرات الصحيحة
- [ ] تأكد من `.gitignore` لا يرفع الملفات الحساسة
- [ ] اختبر على Mobile
- [ ] اختبر RTL (العربية)
- [ ] راجع Performance
- [ ] أضف Analytics (اختياري)

---

## **🎁 Bonus: أوامر مفيدة**

```bash
# تنظيف المشروع
rm -rf node_modules .next
npm install

# فحص الأخطاء
npm run lint

# تحليل حجم Bundle
npm run build
# ثم افتح .next/analyze

# اختبار Production محلياً
npm run build
npm run start
```

---

## **📊 مقارنة منصات النشر**

| المنصة | السهولة | السرعة | المجاني | SSR | التقييم |
|--------|---------|--------|---------|-----|---------|
| **Vercel** | ⭐⭐⭐⭐⭐ | ⚡⚡⚡ | ✅ نعم | ✅ نعم | **الأفضل** |
| **Netlify** | ⭐⭐⭐⭐⭐ | ⚡⚡⚡ | ✅ نعم | ⚠️ محدود | ممتاز |
| **Railway** | ⭐⭐⭐⭐ | ⚡⚡ | ✅ نعم | ✅ نعم | جيد جداً |
| **AWS Amplify** | ⭐⭐⭐ | ⚡⚡ | ✅ نعم | ✅ نعم | جيد |
| **Cloudflare Pages** | ⭐⭐⭐⭐ | ⚡⚡⚡ | ✅ نعم | ⚠️ Edge | جيد جداً |
| **Docker** | ⭐⭐ | ⚡ | 💰 يعتمد | ✅ نعم | احترافي |

---

## **🏆 التوصية النهائية**

### للمبتدئين:
✅ **Vercel** - الأسهل والأسرع والأفضل

### للمحترفين:
✅ **Docker + AWS/GCP** - تحكم كامل

### للتجربة السريعة:
✅ **Netlify Drag & Drop** - في ثواني

---

## **🆘 حل المشاكل الشائعة**

### المشكلة: "Module not found"
```bash
rm -rf node_modules package-lock.json
npm install
```

### المشكلة: "Build failed"
```bash
# تأكد من إصدار Node.js
node --version  # يجب أن يكون >= 18.17

# حدّث npm
npm install -g npm@latest
```

### المشكلة: "Environment variables not working"
- تأكد من البادئة `NEXT_PUBLIC_` للمتغيرات العامة
- أعد Build بعد تغيير المتغيرات
- تأكد من ملف `.env.local` في الـ root

---

## **📞 الدعم الفني**

- 📧 Email: support@ontarget-psp.com
- 💬 Discord: [Join Server]
- 📱 GitHub: [Create Issue]
- 📚 Documentation: [Read Docs]

---

## **✅ النتيجة النهائية**

بعد اتباع هذا الدليل، ستحصل على:

✅ مشروع منشور ومتاح على الإنترنت
✅ URL عام يمكن مشاركته
✅ تحديثات تلقائية عند Push للكود
✅ SSL مجاني (HTTPS)
✅ CDN عالمي للسرعة
✅ Analytics وإحصائيات
✅ النسخ الاحتياطية التلقائية

---

**🎉 مبروك! مشروعك الآن على الإنترنت!**

يمكنك الآن مشاركة الرابط مع:
- العملاء
- المستثمرين
- الفريق
- العالم كله! 🌍
