# 📜 دليل الأوامر - OnTarget PSP

قائمة بجميع الأوامر المتاحة للتطوير والنشر.

## 🔧 أوامر التطوير

### التثبيت والإعداد

```bash
# تثبيت الحزم (يُفضل pnpm)
pnpm install

# أو باستخدام npm
npm install

# أو باستخدام yarn
yarn install
```

### التشغيل المحلي

```bash
# تشغيل development server
pnpm dev

# تشغيل على port مختلف
pnpm dev -p 3001

# تشغيل مع turbo (أسرع)
pnpm dev --turbo
```

افتح [http://localhost:3000](http://localhost:3000)

### البناء

```bash
# بناء للإنتاج
pnpm build

# تشغيل النسخة المبنية محلياً
pnpm start

# بناء وتشغيل معاً
pnpm build && pnpm start
```

### فحص الكود

```bash
# فحص TypeScript و ESLint
pnpm lint

# إصلاح الأخطاء تلقائياً (إذا أمكن)
pnpm lint --fix
```

## 🌐 أوامر النشر

### Vercel CLI

```bash
# تثبيت Vercel CLI
npm install -g vercel

# تسجيل الدخول
vercel login

# preview deployment
vercel

# production deployment
vercel --prod

# عرض logs
vercel logs

# عرض معلومات المشروع
vercel inspect
```

### استخدام Deploy Script

```bash
# جعل script قابل للتنفيذ (مرة واحدة)
chmod +x scripts/deploy.sh

# تشغيل script
./scripts/deploy.sh
```

## 🔍 أوامر الفحص والتشخيص

### فحص Environment Variables

```bash
# فحص المتغيرات البيئية
pnpm check-env

# أو مباشرة
node scripts/check-env.mjs
```

### تحليل Bundle Size

```bash
# بناء المشروع أولاً
pnpm build

# استعراض .next/analyze/ في المتصفح
# (يتطلب تفعيل analyzer في next.config.js)
```

### Performance Testing

```bash
# تشغيل Lighthouse
npx lighthouse http://localhost:3000 --view

# أو استخدم Chrome DevTools → Lighthouse tab
```

## 🧹 أوامر التنظيف

```bash
# حذف node_modules و build files
rm -rf node_modules .next out

# إعادة التثبيت
pnpm install

# حذف cache
rm -rf .next/cache
```

## 📦 إدارة الحزم

### إضافة حزمة جديدة

```bash
# إضافة حزمة
pnpm add package-name

# إضافة dev dependency
pnpm add -D package-name

# إضافة نسخة محددة
pnpm add package-name@1.2.3
```

### تحديث الحزم

```bash
# تحديث جميع الحزم
pnpm update

# تحديث حزمة محددة
pnpm update package-name

# التحقق من الحزم القديمة
pnpm outdated
```

### إزالة حزمة

```bash
pnpm remove package-name
```

## 🔐 إدارة Environment Variables

### محلياً

```bash
# نسخ ملف البيئة
cp .env.example .env.local

# تعديل الملف
nano .env.local
# أو
code .env.local
```

### في Vercel

```bash
# إضافة متغير
vercel env add VARIABLE_NAME

# عرض المتغيرات
vercel env ls

# سحب المتغيرات من Vercel
vercel env pull .env.local

# إزالة متغير
vercel env rm VARIABLE_NAME
```

## 🗃️ أوامر Git

### Workflow الأساسي

```bash
# التحقق من الحالة
git status

# إضافة التغييرات
git add .

# Commit
git commit -m "وصف التغييرات"

# Push
git push origin main

# إنشاء branch جديد
git checkout -b feature/new-feature

# التبديل بين branches
git checkout main
```

### عمليات مفيدة

```bash
# عرض التاريخ
git log --oneline

# التراجع عن commit (soft)
git reset --soft HEAD~1

# التراجع عن commit (hard - حذر!)
git reset --hard HEAD~1

# عرض الفروقات
git diff
```

## 🔄 أوامر Supabase (اختياري)

إذا كنت تستخدم Supabase CLI:

```bash
# تثبيت Supabase CLI
npm install -g supabase

# تسجيل الدخول
supabase login

# ربط المشروع
supabase link --project-ref your-project-ref

# سحب schema
supabase db pull

# دفع migrations
supabase db push

# إعادة تعيين database (حذر!)
supabase db reset
```

## 🛠️ أوامر مفيدة إضافية

### TypeScript

```bash
# فحص الأخطاء
npx tsc --noEmit

# مشاهدة الأخطاء
npx tsc --noEmit --watch
```

### Formatting

```bash
# تنسيق الكود (إذا كان Prettier مثبت)
npx prettier --write .

# فحص التنسيق
npx prettier --check .
```

### Port Management

```bash
# عرض العمليات على port 3000
lsof -i :3000

# قتل عملية على port 3000
kill -9 $(lsof -t -i:3000)
```

## 📊 أوامر Analytics & Monitoring

### Performance

```bash
# تحليل bundle
ANALYZE=true pnpm build

# عرض tree للملفات
tree -L 3 -I 'node_modules|.next'
```

### Logs

```bash
# عرض Vercel logs
vercel logs

# متابعة logs مباشرة
vercel logs --follow

# logs لـ deployment محدد
vercel logs [deployment-url]
```

## 🚀 Shortcuts مفيدة

### Development Workflow السريع

```bash
# تنظيف + تثبيت + تشغيل
rm -rf node_modules .next && pnpm install && pnpm dev

# فحص + بناء + تشغيل
pnpm lint && pnpm build && pnpm start

# فحص environment + تشغيل
pnpm check-env && pnpm dev
```

### Deployment Workflow السريع

```bash
# فحص + بناء + نشر
pnpm lint && pnpm build && vercel --prod

# نشر سريع للـ production
vercel --prod --force
```

## 💡 نصائح

1. **استخدم pnpm بدلاً من npm** - أسرع وأكثر كفاءة
2. **فعّل Git hooks** للتأكد من عدم commit أكواد معطوبة
3. **استخدم `.env.local`** للتطوير المحلي
4. **لا تنسَ `.gitignore`** للملفات الحساسة
5. **راجع logs بانتظام** في Vercel Dashboard

## 📞 الحصول على المساعدة

```bash
# عرض مساعدة Next.js
npx next --help

# عرض مساعدة Vercel
vercel --help

# عرض مساعدة pnpm
pnpm --help
```

---

**💡 Tip:** احفظ هذا الملف في Bookmarks للرجوع إليه بسرعة!
