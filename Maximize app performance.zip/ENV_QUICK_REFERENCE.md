# 🚀 OnTarget PSP - Environment Quick Reference

## 📝 Essential Commands

```bash
# Copy example environment file
cp .env.example .env

# Validate environment configuration
npm run env:check

# Generate secure keys
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## 🔑 Generate Secure Keys

```bash
# JWT Secret (32 bytes)
openssl rand -hex 32

# Encryption Key (32 bytes)
openssl rand -hex 32

# Base64 Key
openssl rand -base64 32

# UUID
node -e "console.log(require('crypto').randomUUID())"
```

---

## 🏃 Quick Setup

### Minimum Required Variables

```env
NODE_ENV=development
APP_URL=http://localhost:3000
API_URL=http://localhost:8000/api/v1
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/ontarget_psp
JWT_SECRET=your_generated_32_char_secret_here
ENCRYPTION_KEY=your_generated_32_char_key_here
STRIPE_SECRET_KEY=sk_test_your_stripe_key
```

---

## 💳 Payment Provider Quick Setup

### Stripe (International)
```env
STRIPE_PUBLIC_KEY=pk_test_xxxxx
STRIPE_SECRET_KEY=sk_test_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
```
📍 Get keys: https://dashboard.stripe.com/test/apikeys

### Paymob (Egypt)
```env
PAYMOB_API_KEY=xxxxx
PAYMOB_INTEGRATION_ID=xxxxx
PAYMOB_HMAC_SECRET=xxxxx
```
📍 Get keys: https://accept.paymob.com

### Fawry (Egypt)
```env
FAWRY_MERCHANT_CODE=xxxxx
FAWRY_SECRET_KEY=xxxxx
FAWRY_API_URL=https://atfawry.fawrystaging.com
```
📍 Register: https://merchant.fawry.com

---

## 📧 Email Quick Setup

### SendGrid (Recommended)
```env
SENDGRID_API_KEY=SG.xxxxx
SENDGRID_FROM_EMAIL=noreply@yourdomain.com
SENDGRID_FROM_NAME=OnTarget PSP
```
📍 Get API key: https://app.sendgrid.com/settings/api_keys

### Gmail SMTP
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your.email@gmail.com
SMTP_PASSWORD=your_app_password
```
📍 Generate app password: https://myaccount.google.com/apppasswords

---

## 📱 SMS Quick Setup

### Twilio
```env
TWILIO_ACCOUNT_SID=ACxxxxx
TWILIO_AUTH_TOKEN=xxxxx
TWILIO_PHONE_NUMBER=+1234567890
```
📍 Get credentials: https://console.twilio.com

---

## 🗄️ Database Quick Setup

### PostgreSQL Local
```bash
# Install PostgreSQL
brew install postgresql@15   # macOS
sudo apt install postgresql  # Ubuntu

# Create database
createdb ontarget_psp

# Connection string
DATABASE_URL=postgresql://postgres:password@localhost:5432/ontarget_psp
```

### PostgreSQL Docker
```bash
docker run -d \
  --name ontarget-db \
  -e POSTGRES_DB=ontarget_psp \
  -e POSTGRES_PASSWORD=yourpassword \
  -p 5432:5432 \
  postgres:15
```

---

## 🔴 Redis Quick Setup

### Redis Local
```bash
# Install Redis
brew install redis           # macOS
sudo apt install redis       # Ubuntu

# Start Redis
brew services start redis    # macOS
sudo systemctl start redis   # Ubuntu

# Test connection
redis-cli ping
```

### Redis Docker
```bash
docker run -d \
  --name ontarget-redis \
  -p 6379:6379 \
  redis:7-alpine
```

```env
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
```

---

## 🌍 Environment Modes

### Development
```env
NODE_ENV=development
DEBUG=true
TEST_MODE=true
MOCK_PAYMENT_PROVIDERS=true
SQL_LOGGING=true
```

### Staging
```env
NODE_ENV=staging
DEBUG=false
TEST_MODE=false
# Use sandbox payment keys
STRIPE_SECRET_KEY=sk_test_xxxxx
```

### Production
```env
NODE_ENV=production
DEBUG=false
TEST_MODE=false
# Use live payment keys
STRIPE_SECRET_KEY=sk_live_xxxxx
PCI_COMPLIANT_MODE=true
```

---

## 🛡️ Security Checklist

- [ ] JWT_SECRET is at least 32 characters
- [ ] ENCRYPTION_KEY is at least 32 characters
- [ ] No "test", "dev", or "example" in production keys
- [ ] .env file is in .gitignore
- [ ] Different keys for dev/staging/production
- [ ] File permissions: `chmod 600 .env`
- [ ] Production secrets in vault (not .env)

---

## 🧪 Test Cards

| Provider | Number | CVV | Expiry | Result |
|----------|--------|-----|--------|--------|
| Stripe | 4242 4242 4242 4242 | 123 | 12/34 | ✅ Success |
| Stripe | 4000 0000 0000 0002 | 123 | 12/34 | ❌ Decline |
| Stripe | 4000 0025 0000 3155 | 123 | 12/34 | 🔐 3D Secure |

---

## 🔥 Feature Flags

```env
# Enable/disable features
ENABLE_WALLET_ALLOCATION=true
ENABLE_SMART_ROUTING=true
ENABLE_FRAUD_DETECTION=true
ENABLE_AUTO_SETTLEMENT=true
ENABLE_INSTANT_PAYOUTS=false
ENABLE_WEBHOOKS=true
ENABLE_PAYMENT_LINKS=true
ENABLE_QR_PAYMENTS=true
```

---

## 🚨 Common Issues

### Database Connection Failed
```bash
# Check if PostgreSQL is running
psql -U postgres -l

# Restart PostgreSQL
brew services restart postgresql    # macOS
sudo systemctl restart postgresql   # Linux
```

### Redis Connection Failed
```bash
# Check if Redis is running
redis-cli ping

# Restart Redis
brew services restart redis         # macOS
sudo systemctl restart redis        # Linux
```

### Invalid JWT Token
- Ensure JWT_SECRET is at least 32 characters
- Same secret must be used across all servers
- Check token expiry settings

---

## 📊 Monitoring Setup

### Sentry (Error Tracking)
```env
SENTRY_DSN=https://xxxxx@sentry.io/xxxxx
SENTRY_ENVIRONMENT=production
```
📍 Setup: https://sentry.io

### Logging
```env
LOG_LEVEL=info              # debug, info, warn, error
LOG_FILE_PATH=./logs
```

---

## 📦 File Storage

### AWS S3
```env
AWS_ACCESS_KEY_ID=AKIAxxxxx
AWS_SECRET_ACCESS_KEY=xxxxx
AWS_REGION=us-east-1
AWS_S3_BUCKET=ontarget-documents
```

### Local Storage
```env
UPLOAD_PATH=./uploads
MAX_FILE_SIZE=10485760      # 10MB
```

---

## ⚡ Rate Limiting

```env
RATE_LIMIT_WINDOW=15                    # minutes
RATE_LIMIT_MAX_REQUESTS=100             # requests per window
RATE_LIMIT_AUTH_MAX=5                   # login attempts
```

---

## 💰 Fees Configuration

```env
DEFAULT_TRANSACTION_FEE_PERCENT=2.5     # 2.5%
DEFAULT_TRANSACTION_FEE_FIXED=0.30      # $0.30
DEFAULT_CURRENCY=EGP
SUPPORTED_CURRENCIES=EGP,USD,EUR,SAR,AED
```

---

## 📅 Scheduled Jobs

```env
# Cron format: minute hour day month weekday
CRON_SETTLEMENT_SCHEDULE=0 23 * * *     # 11 PM daily
CRON_PAYOUT_SCHEDULE=0 1 * * *          # 1 AM daily
CRON_DAILY_REPORT=0 6 * * *             # 6 AM daily
```

---

## 🌐 CORS Configuration

```env
CORS_ENABLED=true
ALLOWED_ORIGINS=http://localhost:3000,https://yourdomain.com
```

---

## 📱 Push Notifications

### Firebase
```env
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_PRIVATE_KEY=xxxxx
FIREBASE_CLIENT_EMAIL=xxxxx
```

### Slack Alerts
```env
SLACK_WEBHOOK_URL=https://hooks.slack.com/xxxxx
SLACK_CHANNEL=#ontarget-alerts
SLACK_HIGH_VALUE_THRESHOLD=10000
```

---

## 📞 Support

| Issue | Contact |
|-------|---------|
| Environment Setup | devops@ontargetpsp.com |
| Payment Integration | integrations@ontargetpsp.com |
| Security | security@ontargetpsp.com |
| General Support | support@ontargetpsp.com |

---

## 📚 Full Documentation

For detailed setup instructions, see: **[ENV_SETUP.md](./ENV_SETUP.md)**

---

**Version:** 1.0.0  
**Last Updated:** March 14, 2026
