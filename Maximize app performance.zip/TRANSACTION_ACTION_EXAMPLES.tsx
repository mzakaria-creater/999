/**
 * Transaction Action Examples
 * Real-world implementation examples for OnTarget PSP
 */

import { useState } from 'react';
import { toast } from 'sonner';
import {
  executeTransactionAction,
  approveTransaction,
  rejectTransaction,
  refundTransaction,
  type Transaction,
  type TransactionActionRequest,
} from './src/app/utils/transactionApi';

// ============================================
// EXAMPLE 1: Simple Transaction Approval
// ============================================

export function SimpleApproval({ transactionId }: { transactionId: string }) {
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    setLoading(true);
    const response = await approveTransaction(transactionId, 'Approved by admin');
    
    if (response.success) {
      toast.success('Transaction approved!');
    } else {
      toast.error(response.error?.message || 'Failed to approve');
    }
    
    setLoading(false);
  };

  return (
    <button onClick={handleApprove} disabled={loading}>
      {loading ? 'Approving...' : 'Approve Transaction'}
    </button>
  );
}

// ============================================
// EXAMPLE 2: Transaction Review with Multiple Actions
// ============================================

export function TransactionReview({ transaction }: { transaction: Transaction }) {
  const [loading, setLoading] = useState(false);
  const [action, setAction] = useState<'idle' | 'approve' | 'reject'>('idle');

  const handleAction = async (actionType: 'approve' | 'reject') => {
    setLoading(true);
    setAction(actionType);

    let response;
    
    if (actionType === 'approve') {
      response = await approveTransaction(
        transaction.id,
        'Verified payment proof and customer details'
      );
    } else {
      response = await rejectTransaction(
        transaction.id,
        'Suspicious payment proof',
        'Image appears to be manipulated'
      );
    }

    if (response.success) {
      toast.success(`Transaction ${actionType}d successfully`);
      // Trigger parent component refresh or callback
    } else {
      toast.error(response.error?.message || `Failed to ${actionType}`);
    }

    setLoading(false);
    setAction('idle');
  };

  return (
    <div className="flex gap-3">
      <button
        onClick={() => handleAction('approve')}
        disabled={loading}
        className="px-4 py-2 bg-green-500 text-white rounded-lg disabled:opacity-50"
      >
        {loading && action === 'approve' ? 'Processing...' : 'Approve'}
      </button>
      <button
        onClick={() => handleAction('reject')}
        disabled={loading}
        className="px-4 py-2 bg-red-500 text-white rounded-lg disabled:opacity-50"
      >
        {loading && action === 'reject' ? 'Processing...' : 'Reject'}
      </button>
    </div>
  );
}

// ============================================
// EXAMPLE 3: Refund Dialog
// ============================================

export function RefundDialog({ 
  transaction,
  onClose,
  onSuccess 
}: { 
  transaction: Transaction;
  onClose: () => void;
  onSuccess: (tx: Transaction) => void;
}) {
  const [amount, setAmount] = useState(transaction.amount);
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRefund = async () => {
    if (!reason.trim()) {
      toast.error('Please provide a refund reason');
      return;
    }

    if (amount <= 0 || amount > transaction.amount) {
      toast.error('Invalid refund amount');
      return;
    }

    setLoading(true);
    
    const response = await refundTransaction(
      transaction.id,
      amount,
      reason,
      'Processed via admin dashboard'
    );

    if (response.success && response.data) {
      toast.success(`Refunded ${amount} ${transaction.currency}`);
      onSuccess(response.data);
      onClose();
    } else {
      toast.error(response.error?.message || 'Refund failed');
    }

    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full">
        <h2 className="text-xl font-bold mb-4">Refund Transaction</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm mb-2">Refund Amount</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value))}
              max={transaction.amount}
              className="w-full px-3 py-2 border rounded"
            />
            <p className="text-xs text-gray-500 mt-1">
              Max: {transaction.amount} {transaction.currency}
            </p>
          </div>

          <div>
            <label className="block text-sm mb-2">Reason</label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 border rounded"
              rows={3}
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 border rounded"
          >
            Cancel
          </button>
          <button
            onClick={handleRefund}
            disabled={loading}
            className="flex-1 px-4 py-2 bg-purple-500 text-white rounded disabled:opacity-50"
          >
            {loading ? 'Processing...' : 'Process Refund'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================
// EXAMPLE 4: Using Generic executeTransactionAction
// ============================================

export function GenericActionExample({ 
  transactionId 
}: { 
  transactionId: string 
}) {
  const performAction = async (actionType: TransactionActionRequest['action']) => {
    const actionRequest: TransactionActionRequest = {
      action: actionType,
      notes: `Action: ${actionType} performed via dashboard`,
    };

    // Add specific parameters based on action type
    if (actionType === 'reject') {
      actionRequest.reason = 'Customer request';
    }

    if (actionType === 'refund') {
      actionRequest.refund_amount = 100.00;
      actionRequest.reason = 'Service not delivered';
    }

    const response = await executeTransactionAction(transactionId, actionRequest);

    if (response.success) {
      toast.success(`Action ${actionType} completed`);
      return response.data;
    } else {
      toast.error(`Action failed: ${response.error?.message}`);
      return null;
    }
  };

  return (
    <div className="flex gap-2">
      <button onClick={() => performAction('approve')}>Approve</button>
      <button onClick={() => performAction('reject')}>Reject</button>
      <button onClick={() => performAction('refund')}>Refund</button>
      <button onClick={() => performAction('cancel')}>Cancel</button>
    </div>
  );
}

// ============================================
// EXAMPLE 5: Batch Transaction Processing
// ============================================

export function BatchProcessor({ 
  transactions 
}: { 
  transactions: Transaction[] 
}) {
  const [processing, setProcessing] = useState(false);
  const [results, setResults] = useState<{
    success: number;
    failed: number;
  }>({ success: 0, failed: 0 });

  const processBatch = async () => {
    setProcessing(true);
    let successCount = 0;
    let failedCount = 0;

    for (const transaction of transactions) {
      // Only approve pending transactions
      if (transaction.status === 'pending') {
        const response = await approveTransaction(
          transaction.id,
          'Batch approval'
        );

        if (response.success) {
          successCount++;
        } else {
          failedCount++;
        }
      }
    }

    setResults({ success: successCount, failed: failedCount });
    setProcessing(false);
    
    toast.success(`Processed: ${successCount} successful, ${failedCount} failed`);
  };

  return (
    <div>
      <button
        onClick={processBatch}
        disabled={processing}
        className="px-4 py-2 bg-blue-500 text-white rounded"
      >
        {processing ? 'Processing...' : `Approve ${transactions.length} Transactions`}
      </button>

      {results.success > 0 && (
        <div className="mt-4">
          <p>✅ Approved: {results.success}</p>
          <p>❌ Failed: {results.failed}</p>
        </div>
      )}
    </div>
  );
}

// ============================================
// EXAMPLE 6: Status-Based Action Buttons
// ============================================

export function SmartActionButtons({ 
  transaction 
}: { 
  transaction: Transaction 
}) {
  const [loading, setLoading] = useState(false);

  const getAvailableActions = () => {
    const actions: Array<{
      label: string;
      action: () => Promise<void>;
      color: string;
    }> = [];

    // Approve action for pending/processing
    if (['pending', 'processing'].includes(transaction.status)) {
      actions.push({
        label: 'Approve',
        action: async () => {
          setLoading(true);
          await approveTransaction(transaction.id);
          setLoading(false);
        },
        color: 'bg-green-500',
      });
    }

    // Refund action for completed
    if (['paid', 'completed'].includes(transaction.status)) {
      actions.push({
        label: 'Refund',
        action: async () => {
          setLoading(true);
          await refundTransaction(transaction.id, undefined, 'Customer request');
          setLoading(false);
        },
        color: 'bg-purple-500',
      });
    }

    // Cancel action for pending
    if (transaction.status === 'pending') {
      actions.push({
        label: 'Cancel',
        action: async () => {
          setLoading(true);
          await executeTransactionAction(transaction.id, {
            action: 'cancel',
            reason: 'User cancelled',
          });
          setLoading(false);
        },
        color: 'bg-gray-500',
      });
    }

    return actions;
  };

  const actions = getAvailableActions();

  return (
    <div className="flex gap-2">
      {actions.map((action) => (
        <button
          key={action.label}
          onClick={action.action}
          disabled={loading}
          className={`px-4 py-2 ${action.color} text-white rounded disabled:opacity-50`}
        >
          {action.label}
        </button>
      ))}
    </div>
  );
}

// ============================================
// EXAMPLE 7: With Confirmation Dialog
// ============================================

export function ActionWithConfirmation({ 
  transaction 
}: { 
  transaction: Transaction 
}) {
  const [showConfirm, setShowConfirm] = useState(false);
  const [actionType, setActionType] = useState<'approve' | 'reject' | null>(null);

  const handleConfirm = async () => {
    if (!actionType) return;

    let response;
    if (actionType === 'approve') {
      response = await approveTransaction(transaction.id);
    } else {
      response = await rejectTransaction(transaction.id, 'User rejected');
    }

    if (response.success) {
      toast.success(`Transaction ${actionType}d`);
    }

    setShowConfirm(false);
    setActionType(null);
  };

  const initiateAction = (type: 'approve' | 'reject') => {
    setActionType(type);
    setShowConfirm(true);
  };

  return (
    <>
      <div className="flex gap-2">
        <button onClick={() => initiateAction('approve')}>
          Approve
        </button>
        <button onClick={() => initiateAction('reject')}>
          Reject
        </button>
      </div>

      {showConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-xl">
            <h3 className="text-lg font-bold mb-4">
              Confirm {actionType?.toUpperCase()}
            </h3>
            <p className="mb-4">
              Are you sure you want to {actionType} transaction {transaction.transaction_id}?
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirm(false)}
                className="px-4 py-2 border rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirm}
                className="px-4 py-2 bg-blue-500 text-white rounded"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ============================================
// EXAMPLE 8: Real-time Status Updates
// ============================================

export function TransactionWithLiveUpdates({ 
  initialTransaction 
}: { 
  initialTransaction: Transaction 
}) {
  const [transaction, setTransaction] = useState(initialTransaction);
  const [loading, setLoading] = useState(false);

  const performAction = async (
    actionFn: () => Promise<any>,
    successMessage: string
  ) => {
    setLoading(true);
    
    const response = await actionFn();
    
    if (response.success && response.data) {
      // Update local state with new transaction data
      setTransaction(response.data);
      toast.success(successMessage);
    } else {
      toast.error(response.error?.message || 'Action failed');
    }
    
    setLoading(false);
  };

  return (
    <div className="border rounded-lg p-4">
      <div className="flex justify-between items-center mb-4">
        <div>
          <p className="font-mono text-sm">{transaction.transaction_id}</p>
          <p className="text-xs text-gray-500">
            Status: <span className="font-semibold">{transaction.status}</span>
          </p>
        </div>
        <div className="text-right">
          <p className="font-bold">{transaction.amount} {transaction.currency}</p>
        </div>
      </div>

      <div className="flex gap-2">
        {transaction.status === 'pending' && (
          <>
            <button
              onClick={() => performAction(
                () => approveTransaction(transaction.id, 'Admin approved'),
                'Transaction approved'
              )}
              disabled={loading}
              className="px-3 py-1 bg-green-500 text-white rounded text-sm"
            >
              Approve
            </button>
            <button
              onClick={() => performAction(
                () => rejectTransaction(transaction.id, 'Admin rejected', 'Declined'),
                'Transaction rejected'
              )}
              disabled={loading}
              className="px-3 py-1 bg-red-500 text-white rounded text-sm"
            >
              Reject
            </button>
          </>
        )}

        {transaction.status === 'completed' && (
          <button
            onClick={() => performAction(
              () => refundTransaction(transaction.id, undefined, 'Refund requested'),
              'Refund processed'
            )}
            disabled={loading}
            className="px-3 py-1 bg-purple-500 text-white rounded text-sm"
          >
            Refund
          </button>
        )}
      </div>
    </div>
  );
}
