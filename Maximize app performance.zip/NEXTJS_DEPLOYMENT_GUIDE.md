# 🚀 OnTarget PSP - Next.js Deployment Guide

## ✅ التحويل الكامل إلى Next.js 15

تم تحويل منصة **OnTarget PSP** بنجاح إلى **Next.js 15** مع **App Router**!

---

## 📦 **1. تثبيت المكتبات**

```bash
# باستخدام npm
npm install

# أو باستخدام pnpm (موصى به)
pnpm install

# أو باستخدام yarn
yarn install
```

---

## 🏃‍♂️ **2. تشغيل المشروع محلياً**

```bash
# Development mode
npm run dev
# أو
pnpm dev
# أو
yarn dev
```

افتح المتصفح على: **http://localhost:3000**

---

## 🏗️ **3. Build للإنتاج**

```bash
npm run build
npm run start
```

---

## 🌐 **4. النشر على Vercel** (الطريقة الأسهل)

### A. من خلال واجهة Vercel:
1. اذهب إلى: https://vercel.com/new
2. استورد المشروع من GitHub
3. Vercel سيكتشف Next.js تلقائياً
4. اضغط على **Deploy**

### B. من خلال CLI:
```bash
# تثبيت Vercel CLI
npm i -g vercel

# النشر
vercel

# للإنتاج
vercel --prod
```

---

## 🚢 **5. النشر على Netlify**

### الطريقة الأولى - Netlify CLI:
```bash
# تثبيت Netlify CLI
npm install -g netlify-cli

# Build
npm run build

# النشر
netlify deploy --prod
```

### الطريقة الثانية - من خلال الواجهة:
1. اذهب إلى: https://app.netlify.com/
2. اسحب مجلد `.next` بعد عمل build
3. سيتم النشر تلقائياً

---

## 🐳 **6. النشر باستخدام Docker**

### إنشاء ملف `Dockerfile`:
```dockerfile
FROM node:20-alpine AS base

# Install dependencies
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package*.json ./
RUN npm ci

# Build
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production
FROM base AS runner
WORKDIR /app
ENV NODE_ENV production
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs
EXPOSE 3000
ENV PORT 3000

CMD ["node", "server.js"]
```

### تشغيل Docker:
```bash
# Build image
docker build -t ontarget-psp .

# Run container
docker run -p 3000:3000 ontarget-psp
```

---

## 🔐 **7. متغيرات البيئة (Environment Variables)**

### إنشاء ملف `.env.local`:
```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your-project-url.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Optional: Analytics
NEXT_PUBLIC_GA_TRACKING_ID=your-ga-id
```

### على Vercel/Netlify:
1. اذهب إلى **Settings** > **Environment Variables**
2. أضف المتغيرات أعلاه
3. احفظ وأعد النشر

---

## 📱 **8. PWA Support**

الملفات الموجودة:
- ✅ `/public/manifest.json` - PWA manifest
- ✅ `/public/sw.js` - Service Worker

للتفعيل الكامل، أضف إلى `next.config.js`:
```js
const withPWA = require('next-pwa')({
  dest: 'public',
  disable: process.env.NODE_ENV === 'development',
});

module.exports = withPWA(nextConfig);
```

---

## 🔧 **9. هيكل المشروع الجديد**

```
/app
├── layout.tsx              # Root layout
├── page.tsx                # Redirect to dashboard
├── providers.tsx           # Context providers
├── (main)/                 # Desktop routes
│   ├── layout.tsx
│   ├── dashboard/page.tsx
│   ├── transactions/page.tsx
│   ├── wallets/page.tsx
│   └── ...
├── mobile/                 # Mobile routes
│   ├── layout.tsx
│   ├── page.tsx
│   ├── dashboard/page.tsx
│   └── transactions/
│       ├── page.tsx
│       └── [id]/page.tsx
└── ...

/src/app
├── components/            # React components
├── context/              # Context providers
├── hooks/                # Custom hooks
└── pages/                # Page components (reused)
```

---

## 🎯 **10. الصفحات المتاحة**

### Desktop:
- ✅ `/dashboard` - لوحة التحكم
- ✅ `/transactions` - المعاملات
- ✅ `/wallets` - المحافظ
- ✅ `/merchants` - التجار
- ✅ `/payment-methods` - طرق الدفع
- ✅ `/payment-accounts` - حسابات الدفع
- ✅ `/payment-pages` - صفحات الدفع
- ✅ `/api-documentation` - توثيق API
- ✅ `/permissions` - الصلاحيات

### Mobile:
- ✅ `/mobile` - Mobile Dashboard
- ✅ `/mobile/dashboard` - لوحة تحكم الموبايل
- ✅ `/mobile/transactions` - معاملات الموبايل
- ✅ `/mobile/transactions/[id]` - تفاصيل المعاملة
- ✅ `/mobile/settings` - الإعدادات

---

## 📊 **11. المميزات المحفوظة**

✅ **Glassmorphic UI** - تصميم زجاجي شفاف
✅ **Role-Based Access Control** - 6 أدوار مختلفة
✅ **Arabic RTL Support** - دعم كامل للعربية
✅ **Mobile Optimized** - متجاوب 100%
✅ **FX Rates Widget** - أسعار العملات
✅ **Dark Mode** - الوضع الداكن
✅ **Recharts Integration** - مخططات بيانية
✅ **Supabase Backend** - قاعدة بيانات جاهزة
✅ **Motion Animations** - حركات سلسة

---

## 🔄 **12. الاختلافات الرئيسية**

### React Router → Next.js Router

**قبل (React Router):**
```tsx
import { Link } from 'react-router';
<Link to="/dashboard">Dashboard</Link>
```

**بعد (Next.js):**
```tsx
import Link from 'next/link';
<Link href="/dashboard">Dashboard</Link>
```

### useLocation → usePathname

**قبل:**
```tsx
import { useLocation } from 'react-router';
const location = useLocation();
const pathname = location.pathname;
```

**بعد:**
```tsx
import { usePathname } from 'next/navigation';
const pathname = usePathname();
```

### useNavigate → useRouter

**قبل:**
```tsx
import { useNavigate } from 'react-router';
const navigate = useNavigate();
navigate('/dashboard');
```

**بعد:**
```tsx
import { useRouter } from 'next/navigation';
const router = useRouter();
router.push('/dashboard');
```

---

## 🐛 **13. استكشاف الأخطاء**

### خطأ: "Module not found"
```bash
# احذف node_modules و.next
rm -rf node_modules .next
npm install
npm run dev
```

### خطأ: "Hydration error"
- تأكد من أن جميع المكونات التفاعلية تستخدم `'use client'`
- تأكد من عدم وجود اختلاف بين Server و Client

### خطأ: "Can't resolve '@/...'  "
- تأكد من وجود `tsconfig.json` الصحيح
- راجع `paths` في `compilerOptions`

---

## 📚 **14. مصادر إضافية**

- 📖 [Next.js Documentation](https://nextjs.org/docs)
- 🎨 [Tailwind CSS v4](https://tailwindcss.com/docs)
- 🚀 [Vercel Deployment](https://vercel.com/docs)
- 💾 [Supabase Docs](https://supabase.com/docs)

---

## ✨ **15. التصدير للاستخدام الخارجي**

### تصدير Static:
```bash
# أضف في next.config.js:
output: 'export',

# ثم:
npm run build
```

سيتم إنشاء مجلد `out/` يمكن رفعه على أي hosting.

### تصدير كـ Zip:
```bash
zip -r ontarget-psp-nextjs.zip . -x "node_modules/*" ".next/*" ".git/*"
```

---

## 🎉 **النتيجة النهائية**

✅ **المشروع جاهز للنشر على:**
- Vercel (موصى به)
- Netlify
- AWS Amplify
- Google Cloud Run
- Digital Ocean App Platform
- أي خادم Node.js

✅ **جميع المميزات محفوظة ومحسّنة**

✅ **SEO-friendly** مع Server-Side Rendering

✅ **أداء محسّن** مع Code Splitting تلقائي

---

## 📞 **الدعم**

لأي استفسارات:
- 📧 البريد: support@ontarget-psp.com
- 📱 GitHub Issues: [Create Issue]

---

**🚀 مبروك! مشروعك الآن جاهز للنشر على Next.js 15!**
