# 🔐 OnTarget PSP - Environment Configuration Guide

This document provides comprehensive guidance for setting up your environment variables for the OnTarget PSP payment gateway platform.

## 📋 Table of Contents

- [Quick Start](#quick-start)
- [Configuration Categories](#configuration-categories)
- [Required Variables](#required-variables)
- [Optional Variables](#optional-variables)
- [Security Best Practices](#security-best-practices)
- [Environment-Specific Setup](#environment-specific-setup)
- [Testing Configuration](#testing-configuration)
- [Production Deployment](#production-deployment)

---

## 🚀 Quick Start

### 1. Copy the Example File

```bash
cp .env.example .env
```

### 2. Edit Your Configuration

Open `.env` and replace placeholder values with your actual credentials:

```bash
nano .env
# or
vim .env
# or use your preferred editor
```

### 3. Verify Setup

```bash
# Check if all required variables are set
npm run env:check
```

---

## 📁 Configuration Categories

### 🎯 **Application Settings**

Core application configuration:

```env
NODE_ENV=development          # development, staging, production
APP_NAME=OnTarget PSP
APP_URL=http://localhost:3000
API_URL=http://localhost:8000/api/v1
PORT=8000
```

**When to modify:**
- Change `NODE_ENV` based on deployment environment
- Update `APP_URL` for production domain
- Adjust `PORT` if default conflicts with other services

---

### 🗄️ **Database Configuration**

PostgreSQL database settings:

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=ontarget_psp
DB_USER=postgres
DB_PASSWORD=your_secure_password_here
```

**Setup Instructions:**

1. **Install PostgreSQL** (if not already installed):
   ```bash
   # macOS
   brew install postgresql@15
   
   # Ubuntu
   sudo apt-get install postgresql-15
   ```

2. **Create Database:**
   ```bash
   psql -U postgres
   CREATE DATABASE ontarget_psp;
   CREATE USER ontarget WITH PASSWORD 'your_password';
   GRANT ALL PRIVILEGES ON DATABASE ontarget_psp TO ontarget;
   ```

3. **Alternative: Use Connection String:**
   ```env
   DATABASE_URL=postgresql://user:password@localhost:5432/ontarget_psp
   ```

---

### 🔴 **Redis Cache Configuration**

For session storage, rate limiting, and caching:

```env
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_DB=0
```

**Setup Instructions:**

```bash
# Install Redis
# macOS
brew install redis
brew services start redis

# Ubuntu
sudo apt-get install redis-server
sudo systemctl start redis
```

**Test Connection:**
```bash
redis-cli ping
# Should return: PONG
```

---

### 🔐 **Authentication & Security**

**CRITICAL: Generate Strong Keys for Production!**

```env
JWT_SECRET=your_super_secret_jwt_key_min_32_characters_long
JWT_REFRESH_SECRET=your_refresh_token_secret_key_here
ENCRYPTION_KEY=your_32_character_encryption_key
```

**Generate Secure Keys:**

```bash
# Generate JWT Secret (Node.js)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Generate JWT Secret (OpenSSL)
openssl rand -hex 32

# Generate Base64 Key
openssl rand -base64 32
```

**Security Recommendations:**
- ✅ Use different keys for development and production
- ✅ Store production keys in secure vault (AWS Secrets Manager, HashiCorp Vault)
- ✅ Rotate keys every 90 days
- ❌ Never commit keys to version control
- ❌ Never share keys via email or Slack

---

### 💳 **Payment Gateway Integrations**

#### **Stripe** (International)

```env
STRIPE_PUBLIC_KEY=pk_test_51234567890abcdef
STRIPE_SECRET_KEY=sk_test_51234567890abcdef
STRIPE_WEBHOOK_SECRET=whsec_test_1234567890
```

**Setup:**
1. Sign up at [stripe.com](https://stripe.com)
2. Navigate to **Developers → API Keys**
3. Copy **Publishable key** → `STRIPE_PUBLIC_KEY`
4. Copy **Secret key** → `STRIPE_SECRET_KEY`
5. Create webhook endpoint → Copy **Signing secret** → `STRIPE_WEBHOOK_SECRET`

**Test Cards:**
- Success: `4242 4242 4242 4242`
- Decline: `4000 0000 0000 0002`
- Authentication Required: `4000 0025 0000 3155`

---

#### **Fawry** (Egypt)

```env
FAWRY_MERCHANT_CODE=your_fawry_merchant_code
FAWRY_SECRET_KEY=your_fawry_secret_key
FAWRY_API_URL=https://atfawry.fawrystaging.com
```

**Setup:**
1. Register at [Fawry Merchant Portal](https://merchant.fawry.com)
2. Complete KYC verification
3. Obtain merchant code and API credentials
4. Use staging URL for testing: `https://atfawry.fawrystaging.com`
5. Production URL: `https://www.atfawry.com`

---

#### **Paymob** (Egypt)

```env
PAYMOB_API_KEY=your_paymob_api_key
PAYMOB_INTEGRATION_ID=your_integration_id
PAYMOB_HMAC_SECRET=your_hmac_secret
```

**Setup:**
1. Sign up at [Paymob](https://accept.paymob.com)
2. Dashboard → Settings → API Keys
3. Create integration → Get Integration ID
4. Copy HMAC secret for webhook verification

---

#### **Vodafone Cash** (Egypt)

```env
VODAFONE_MERCHANT_ID=your_vodafone_merchant_id
VODAFONE_API_KEY=your_vodafone_api_key
VODAFONE_SECRET_KEY=your_vodafone_secret
```

**Setup:**
Contact Vodafone Business team for merchant onboarding.

---

#### **InstaPay** (Egypt)

```env
INSTAPAY_MERCHANT_CODE=your_instapay_code
INSTAPAY_API_KEY=your_instapay_api_key
INSTAPAY_ALIAS=@yourbusiness
```

**Setup:**
Register through your bank's InstaPay merchant program.

---

### 📧 **Email Services**

#### **SMTP (General)**

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=noreply@ontargetpsp.com
SMTP_PASSWORD=your_email_password
```

**Gmail Setup:**
1. Enable 2-Factor Authentication
2. Generate App Password: [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Use app password as `SMTP_PASSWORD`

#### **SendGrid (Recommended)**

```env
SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxx
SENDGRID_FROM_EMAIL=noreply@ontargetpsp.com
SENDGRID_FROM_NAME=OnTarget PSP
```

**Setup:**
1. Sign up at [sendgrid.com](https://sendgrid.com)
2. Create API Key: Settings → API Keys → Create API Key
3. Verify sender email: Settings → Sender Authentication

---

### 📱 **SMS Services**

#### **Twilio**

```env
TWILIO_ACCOUNT_SID=AC1234567890abcdef
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1234567890
```

**Setup:**
1. Sign up at [twilio.com](https://twilio.com)
2. Console → Account Info → Copy Account SID and Auth Token
3. Buy a phone number or use trial number

**Egypt SMS Alternative:**
```env
VODAFONE_SMS_USERNAME=your_sms_username
VODAFONE_SMS_PASSWORD=your_sms_password
VODAFONE_SMS_SENDER=OnTarget
```

---

### 📦 **File Storage**

#### **AWS S3**

```env
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
AWS_REGION=us-east-1
AWS_S3_BUCKET=ontarget-psp-documents
```

**Setup:**
1. Create IAM user with S3 access
2. Generate access keys
3. Create S3 buckets:
   - `ontarget-psp-documents`
   - `ontarget-receipts`
   - `ontarget-payment-proofs`

**Bucket Policy Example:**
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::ontarget-psp-documents/*"
    }
  ]
}
```

---

### 🛡️ **Fraud Detection & Security**

#### **Sift Science**

```env
SIFT_API_KEY=your_sift_api_key
SIFT_ACCOUNT_ID=your_sift_account_id
```

**Risk Thresholds:**
```env
RISK_SCORE_THRESHOLD=75      # Flag for review
AUTO_BLOCK_THRESHOLD=90      # Automatically block
AUTO_REVIEW_THRESHOLD=60     # Queue for manual review
```

**IP Geolocation:**
```env
IPGEOLOCATION_API_KEY=your_api_key
IP_WHITELIST=127.0.0.1,::1,your_office_ip
```

---

### 📊 **Monitoring & Logging**

#### **Sentry (Error Tracking)**

```env
SENTRY_DSN=https://xxxxx@sentry.io/xxxxx
SENTRY_ENVIRONMENT=production
SENTRY_TRACES_SAMPLE_RATE=0.1
```

**Setup:**
1. Create project at [sentry.io](https://sentry.io)
2. Copy DSN from Settings → Client Keys

#### **Logging**

```env
LOG_LEVEL=info               # debug, info, warn, error
LOG_FILE_PATH=./logs
LOG_MAX_SIZE=10m
LOG_MAX_FILES=14            # Keep 2 weeks of logs
```

---

### ⚡ **Feature Flags**

Enable/disable features without code deployment:

```env
ENABLE_WALLET_ALLOCATION=true
ENABLE_SMART_ROUTING=true
ENABLE_FRAUD_DETECTION=true
ENABLE_AUTO_SETTLEMENT=true
ENABLE_INSTANT_PAYOUTS=false
ENABLE_MULTI_CURRENCY=true
ENABLE_RECURRING_PAYMENTS=true
ENABLE_PAYMENT_LINKS=true
ENABLE_QR_PAYMENTS=true
ENABLE_WEBHOOKS=true
```

---

## ✅ Required Variables

**Minimum required for basic operation:**

```env
# Application
NODE_ENV=development
APP_URL=http://localhost:3000
API_URL=http://localhost:8000/api/v1

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/ontarget_psp

# Security
JWT_SECRET=minimum_32_character_secret_key
ENCRYPTION_KEY=32_character_encryption_key_here

# At least one payment provider
STRIPE_SECRET_KEY=sk_test_xxxxx
# OR
PAYMOB_API_KEY=test_key_here
```

---

## 🔒 Security Best Practices

### 1. **Never Commit Secrets**

```bash
# Always check before committing
git status
git diff

# If accidentally committed:
git reset HEAD .env
git checkout -- .env
```

### 2. **Use Environment-Specific Files**

```
.env                    # Local development (gitignored)
.env.example           # Template (committed)
.env.production        # Production (never committed)
.env.staging           # Staging (never committed)
```

### 3. **Rotate Keys Regularly**

| Key Type | Rotation Frequency |
|----------|-------------------|
| JWT Secrets | Every 90 days |
| API Keys | Every 180 days |
| Database Passwords | Every 90 days |
| Encryption Keys | Annually |

### 4. **Use Secrets Management**

**Production Recommendations:**
- AWS Secrets Manager
- HashiCorp Vault
- Azure Key Vault
- Google Secret Manager

```bash
# Example: AWS Secrets Manager
aws secretsmanager get-secret-value \
  --secret-id ontarget/psp/production \
  --query SecretString --output text
```

### 5. **Restrict Access**

```bash
# Set proper file permissions
chmod 600 .env
```

---

## 🌍 Environment-Specific Setup

### **Development**

```env
NODE_ENV=development
DEBUG=true
TEST_MODE=true
MOCK_PAYMENT_PROVIDERS=true
MOCK_SMS_SERVICE=true
MOCK_EMAIL_SERVICE=true
SQL_LOGGING=true
```

### **Staging**

```env
NODE_ENV=staging
DEBUG=false
TEST_MODE=false
MOCK_PAYMENT_PROVIDERS=false
# Use real providers but with test/sandbox keys
STRIPE_SECRET_KEY=sk_test_xxxxx
```

### **Production**

```env
NODE_ENV=production
DEBUG=false
TEST_MODE=false
MOCK_PAYMENT_PROVIDERS=false
# Real production keys only
STRIPE_SECRET_KEY=sk_live_xxxxx
PCI_COMPLIANT_MODE=true
CBE_REPORTING_ENABLED=true
```

---

## 🧪 Testing Configuration

### Test Payment Providers

```env
TEST_MODE=true
SANDBOX_MODE=true
ALLOW_TEST_CARDS=true
```

### Mock Services (for CI/CD)

```env
MOCK_PAYMENT_PROVIDERS=true
MOCK_SMS_SERVICE=true
MOCK_EMAIL_SERVICE=true
MOCK_KYC_SERVICE=true
```

### Test Credit Cards

| Provider | Card Number | Result |
|----------|------------|--------|
| Stripe | 4242 4242 4242 4242 | Success |
| Stripe | 4000 0000 0000 0002 | Decline |
| Stripe | 4000 0025 0000 3155 | 3D Secure |

---

## 🚀 Production Deployment

### Pre-Deployment Checklist

- [ ] All test/sandbox keys replaced with production keys
- [ ] `NODE_ENV=production`
- [ ] `DEBUG=false`
- [ ] Strong passwords (min 16 chars, mixed case, numbers, symbols)
- [ ] Database backups enabled
- [ ] SSL/TLS certificates valid
- [ ] Firewall rules configured
- [ ] Rate limiting enabled
- [ ] Monitoring and alerts configured
- [ ] Secrets stored in vault (not .env file)
- [ ] Compliance checks passed (PCI DSS, GDPR, etc.)

### Deployment Methods

#### **1. Manual Deployment**
```bash
# On production server
scp .env.production user@server:/path/to/app/.env
ssh user@server
cd /path/to/app
npm install
npm run build
pm2 restart ontarget-psp
```

#### **2. Docker**
```bash
# Pass env vars at runtime
docker run -d \
  --env-file .env.production \
  ontarget/psp:latest
```

#### **3. Kubernetes**
```bash
# Create secret from env file
kubectl create secret generic ontarget-env \
  --from-env-file=.env.production

# Reference in deployment
env:
  - secretRef:
      name: ontarget-env
```

#### **4. Platform as a Service**

**Heroku:**
```bash
heroku config:set NODE_ENV=production
heroku config:set JWT_SECRET=your_secret
```

**Vercel:**
```bash
vercel env add JWT_SECRET production
```

---

## 🆘 Troubleshooting

### Common Issues

#### **1. Database Connection Failed**
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```

**Solution:**
```bash
# Check if PostgreSQL is running
sudo systemctl status postgresql

# Start PostgreSQL
sudo systemctl start postgresql

# Verify connection
psql -U postgres -d ontarget_psp
```

#### **2. Redis Connection Failed**
```
Error: Redis connection to 127.0.0.1:6379 failed
```

**Solution:**
```bash
# Check Redis status
redis-cli ping

# Start Redis
brew services start redis  # macOS
sudo systemctl start redis # Linux
```

#### **3. JWT Token Invalid**
```
Error: Invalid JWT token
```

**Solution:**
- Verify `JWT_SECRET` is at least 32 characters
- Ensure same secret on all servers
- Check token expiry settings

#### **4. Payment Provider Authentication Failed**
```
Error: Authentication failed for provider
```

**Solution:**
- Verify API keys are correct and active
- Check if using test vs production keys correctly
- Ensure webhooks are configured with correct URLs

---

## 📞 Support

For environment configuration support:

- **Email:** devops@ontargetpsp.com
- **Slack:** #ontarget-devops
- **Documentation:** https://docs.ontargetpsp.com
- **Status Page:** https://status.ontargetpsp.com

---

## 📚 Additional Resources

- [Payment Provider Documentation](./docs/payment-providers.md)
- [Security Guidelines](./docs/security.md)
- [Deployment Guide](./docs/deployment.md)
- [API Documentation](./docs/api.md)
- [Webhook Setup](./docs/webhooks.md)

---

**Last Updated:** March 14, 2026  
**Version:** 1.0.0
