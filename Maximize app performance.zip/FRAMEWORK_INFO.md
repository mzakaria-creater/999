# 🎯 OnTarget PSP - Framework Information

## 🚀 Current Framework

**OnTarget PSP uses React Router, NOT Next.js**

---

## ✅ What We Use

### Framework
- **React Router** (Data Mode)
- Package: `react-router`
- Version: Latest
- Entry: `/src/app/App.tsx`

### Routing
```tsx
import { RouterProvider, createBrowserRouter } from 'react-router';

const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: Dashboard },
      { path: 'transactions', Component: Transactions },
      // ...
    ],
  },
]);
```

### Navigation
```tsx
import { Link, useNavigate, useLocation } from 'react-router';

<Link to="/dashboard">Dashboard</Link>
```

---

## ❌ What We DON'T Use

### Not Next.js
- ❌ No Next.js App Router
- ❌ No `NextResponse`
- ❌ No `NextRequest`
- ❌ No file-based routing in `/app`
- ❌ No server components

### Not react-router-dom
- ❌ Use `react-router` instead
- ❌ `react-router-dom` doesn't work in Figma Make

---

## 📂 Project Structure

```
OnTarget PSP
├── /src                    ← ACTIVE CODE
│   └── /app
│       ├── App.tsx         ← Entry point ✅
│       ├── routes.tsx      ← Route definitions ✅
│       ├── version.ts      ← Version info ✅
│       ├── /pages          ← All pages ✅
│       ├── /components     ← All components ✅
│       └── /context        ← Providers ✅
│
├── /app                    ← LEGACY (Not used)
│   ├── (main)              ← Old Next.js structure ⚠️
│   └── mobile              ← Old Next.js structure ⚠️
│
└── /public                 ← Static assets ✅
```

---

## 🔧 Quick Reference

### Creating a New Page

1. **Create page component:**
```tsx
// /src/app/pages/MyPage.tsx
export function MyPage() {
  return <div>My Page</div>;
}
```

2. **Add to routes:**
```tsx
// /src/app/routes.tsx
import { MyPage } from './pages/MyPage';

{ path: 'my-page', Component: MyPage }
```

3. **Link to it:**
```tsx
import { Link } from 'react-router';

<Link to="/my-page">Go to My Page</Link>
```

---

### Common Patterns

**Navigation:**
```tsx
import { useNavigate } from 'react-router';

const navigate = useNavigate();
navigate('/dashboard');
```

**Get Current Path:**
```tsx
import { useLocation } from 'react-router';

const location = useLocation();
const isActive = location.pathname === '/dashboard';
```

**Route Parameters:**
```tsx
import { useParams } from 'react-router';

const { id } = useParams();
```

---

## ⚠️ Important Notes

### Environment: Figma Make
- Only supports `react-router` package
- Does NOT support `react-router-dom`
- Does NOT support Next.js

### Legacy Code
- `/app` directory exists but is NOT active
- Legacy Next.js files (ignore them)
- Active code is in `/src/app`

### No Server-Side Rendering
- This is a client-side React Router app
- No SSR, no server components
- All rendering happens in browser

---

## 📝 Version History

### v2.3.4 (Current)
- ✅ Cleaned up Next.js legacy files
- ✅ Removed middleware.ts
- ✅ Clarified framework usage

### v2.3.3
- ✅ Fixed Telegram route errors
- ✅ Cleaned Sidebar navigation

### v2.3.2
- ✅ Enhanced Binance P2P page

### v2.3.1
- ✅ Consolidated payment methods

---

## 🎓 For New Developers

**Question:** Is this Next.js?  
**Answer:** No, it's React Router.

**Question:** Can I use Next.js APIs?  
**Answer:** No, they won't work.

**Question:** Where do I create pages?  
**Answer:** `/src/app/pages/`

**Question:** How do I add routes?  
**Answer:** Edit `/src/app/routes.tsx`

**Question:** Can I use file-based routing?  
**Answer:** No, use route configuration.

---

## 🚀 Getting Started

### Development
```bash
npm run dev
```

### Build
```bash
npm run build
```

### Entry Point
```tsx
// /src/app/App.tsx
import { RouterProvider } from 'react-router';
import { router } from './routes';

export default function App() {
  return <RouterProvider router={router} />;
}
```

---

**Framework:** React Router  
**Version:** 2.3.4  
**Last Updated:** March 17, 2026

**Remember: We use React Router, NOT Next.js! 🎯**
